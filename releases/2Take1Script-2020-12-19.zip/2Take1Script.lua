local a = {}
a["PDevs"] = utils.get_appdata_path("PopstarDevs", "")
a["Menu"] = a["PDevs"] .. "\\2Take1Menu"
a["dumps"] = a["Menu"] .. "\\crashdump"
a["outfits"] = a["Menu"] .. "\\moddedOutfits"
a["vehicles"] = a["Menu"] .. "\\moddedVehicles"
a["scripts"] = a["Menu"] .. "\\scripts"
a["autoload"] = a["scripts"] .. "\\autoload"
a["2T1S"] = a["scripts"] .. "\\2Take1Script"
a["Config"] = a["2T1S"] .. "\\Config"
a["CustomFiles"] = a["2T1S"] .. "\\CustomFiles"
a["Event-Logger"] = a["2T1S"] .. "\\Event-Logger"
local b = {
    ["Auth"] = a["PDevs"] .. "\\PopstarAuth.log",
    ["Menu_log"] = a["Menu"] .. "\\2Take1Menu.log",
    ["Prep"] = a["Menu"] .. "\\2Take1Prep.log",
    ["Admin"] = a["scripts"] .. "\\2Take1Script-Admin.lua",
    ["Log_file"] = a["2T1S"] .. "\\2Take1Script.log",
    ["EXT_file"] = a["CustomFiles"] .. "\\2Take1ScriptEXT.lua",
    ["Blacklist"] = a["CustomFiles"] .. "\\2Take1Blacklist.cfg",
    ["Modders"] = a["CustomFiles"] .. "\\2Take1Modders.cfg",
    ["IPLlist"] = a["CustomFiles"] .. "\\2Take1IPLlist.txt",
    ["data"] = a["Config"] .. "\\offsets.data",
    ["Config"] = a["Config"] .. "\\2Take1Script.ini",
    ["Hotkeys"] = a["Config"] .. "\\2Take1Hotkeys.ini",
    ["Exclude"] = a["Config"] .. "\\2Take1Exclude.ini"
}
local c = {
    o = io.open,
    no = tonumber,
    wait = system.wait,
    time = utils.time_ms,
    random = math.random,
    id = player.player_id,
    d_exists = utils.dir_exists,
    ped = player.get_player_ped,
    f_exists = utils.file_exists,
    explode = fire.add_explosion,
    valid = player.is_player_valid,
    god = entity.set_entity_god_mode,
    gcoords = entity.get_entity_coords,
    visible = entity.set_entity_visible,
    script = script.trigger_script_event,
    navigate = menu.set_menu_can_navigate,
    vehicle = ped.get_vehicle_ped_is_using,
    attach = entity.attach_entity_to_entity,
    unload = streaming.set_model_as_no_longer_needed
}
local d = {}
d.write = function(e, f)
    if e and f then
        io.output(e)
        io.write(f .. "\n")
        io.close(e)
    end
end
d.time_prefix = function()
    local g = os.date("*t")
    if g.month < 10 then
        g.month = "0" .. g.month
    end
    if g.day < 10 then
        g.day = "0" .. g.day
    end
    if g.hour < 10 then
        g.hour = "0" .. g.hour
    end
    if g.min < 10 then
        g.min = "0" .. g.min
    end
    if g.sec < 10 then
        g.sec = "0" .. g.sec
    end
    return "[" .. g.year .. "-" .. g.month .. "-" .. g.day .. " " .. g.hour .. ":" .. g.min .. ":" .. g.sec .. "]"
end
d.file_name = function()
    local h = debug.getinfo(2, "S")
    local j = h.source:sub(2) or h
    j = j:sub(#j - string.find(string.reverse(j), "\\", 1) + 2)
    return j
end
d.stop = function(k)
    if k.on then
        return 0
    end
    return 1
end
d.rgbtohex = function(l)
    local m = "0X"
    for n, o in pairs(l) do
        local p = ""
        while o > 0 do
            local q = math.fmod(o, 16) + 1
            o = math.floor(o / 16)
            p = string.sub("0123456789ABCDEF", q, q) .. p
        end
        if string.len(p) == 0 then
            p = "00"
        elseif string.len(p) == 1 then
            p = "0" .. p
        end
        m = m .. p
    end
    return m
end
local r = {}
r[0] = {}
r[0][#r[0] + 1] = "section_1"
r["section_1"] = "[Main-Settings]"
r[0][#r[0] + 1] = "version"
r["version"] = 19
r[0][#r[0] + 1] = "2t1s_parent"
r["2t1s_parent"] = true
r[0][#r[0] + 1] = "exclude_friends"
r["exclude_friends"] = true
r[0][#r[0] + 1] = "logger"
r["logger"] = true
r[0][#r[0] + 1] = "load_admin"
r["load_admin"] = true
r[0][#r[0] + 1] = "section_2"
r["section_2"] = "[Blacklist]"
r[0][#r[0] + 1] = "bl_hidden"
r["bl_hidden"] = false
r[0][#r[0] + 1] = "blacklist_enabled"
r["blacklist_enabled"] = false
r[0][#r[0] + 1] = "auto_kick"
r["auto_kick"] = false
r[0][#r[0] + 1] = "mark_modder"
r["mark_modder"] = false
r[0][#r[0] + 1] = "admin_enabled"
r["admin_enabled"] = false
r[0][#r[0] + 1] = "kick_joining"
r["kick_joining"] = false
r[0][#r[0] + 1] = "section_3"
r["section_3"] = "[Modders]"
r[0][#r[0] + 1] = "modder_hidden"
r["modder_hidden"] = false
r[0][#r[0] + 1] = "remember_modder"
r["remember_modder"] = false
r[0][#r[0] + 1] = "karma_modder_scripts"
r["karma_modder_scripts"] = false
r[0][#r[0] + 1] = "unmark_friends"
r["unmark_friends"] = true
r[0][#r[0] + 1] = "speed_bypass"
r["speed_bypass"] = false
r[0][#r[0] + 1] = "name_bypass"
r["name_bypass"] = false
r[0][#r[0] + 1] = "modded_scid"
r["modded_scid"] = false
r[0][#r[0] + 1] = "modded_net_events"
r["modded_net_events"] = false
r[0][#r[0] + 1] = "modder_force_sh"
r["modder_force_sh"] = false
r[0][#r[0] + 1] = "modded_script_event"
r["modded_script_event"] = false
r[0][#r[0] + 1] = "section_4"
r["section_4"] = "[Lobby]"
r[0][#r[0] + 1] = "lobby_hidden"
r["lobby_hidden"] = false
r[0][#r[0] + 1] = "teleport_to_block"
r["teleport_to_block"] = false
r[0][#r[0] + 1] = "explode_lobby"
r["explode_lobby"] = false
r[0][#r[0] + 1] = "explode_lobby_value"
r["explode_lobby_value"] = 8
r[0][#r[0] + 1] = "explode_lobby_shake"
r["explode_lobby_shake"] = false
r[0][#r[0] + 1] = "sound_rape"
r["sound_rape"] = false
r[0][#r[0] + 1] = "kill_all_peds"
r["kill_all_peds"] = false
r[0][#r[0] + 1] = "disablecontrol"
r["disablecontrol"] = false
r[0][#r[0] + 1] = "bounty_after_death"
r["bounty_after_death"] = false
r[0][#r[0] + 1] = "bounty_after_death_value"
r["bounty_after_death_value"] = 0
r[0][#r[0] + 1] = "anonymous_bounty"
r["anonymous_bounty"] = false
r[0][#r[0] + 1] = "sms_spam"
r["sms_spam"] = false
r[0][#r[0] + 1] = "sms_spam_value"
r["sms_spam_value"] = 25
r[0][#r[0] + 1] = "karma_se"
r["karma_se"] = false
r[0][#r[0] + 1] = "punish_aliens"
r["punish_aliens"] = false
r[0][#r[0] + 1] = "force_host"
r["force_host"] = false
r[0][#r[0] + 1] = "modify_veh_speed"
r["modify_veh_speed"] = 0
r[0][#r[0] + 1] = "modify_veh_speed_include"
r["modify_veh_speed_include"] = false
r[0][#r[0] + 1] = "modify_veh_speed_overwrite"
r["modify_veh_speed_overwrite"] = false
r[0][#r[0] + 1] = "section_5"
r["section_5"] = "[Vehicle-Blacklist]"
r[0][#r[0] + 1] = "veh_blacklist"
r["veh_blacklist"] = false
r[0][#r[0] + 1] = "Oppressor"
r["Oppressor"] = false
r[0][#r[0] + 1] = "MK2_Oppressor"
r["MK2_Oppressor"] = false
r[0][#r[0] + 1] = "Lazer"
r["Lazer"] = false
r[0][#r[0] + 1] = "Hydra"
r["Hydra"] = false
r[0][#r[0] + 1] = "Deluxo"
r["Deluxo"] = false
r[0][#r[0] + 1] = "Akula"
r["Akula"] = false
r[0][#r[0] + 1] = "B_11_Strikforce"
r["B_11_Strikforce"] = false
r[0][#r[0] + 1] = "Tank"
r["Tank"] = false
r[0][#r[0] + 1] = "Khanjali"
r["Khanjali"] = false
r[0][#r[0] + 1] = "Stromberg"
r["Stromberg"] = false
r[0][#r[0] + 1] = "Buzzard"
r["Buzzard"] = false
r[0][#r[0] + 1] = "Hunter"
r["Hunter"] = false
r[0][#r[0] + 1] = "Avenger"
r["Avenger"] = false
r[0][#r[0] + 1] = "Insurgent_Pickup"
r["Insurgent_Pickup"] = false
r[0][#r[0] + 1] = "Insurgent_Pickup_Custom"
r["Insurgent_Pickup_Custom"] = false
r[0][#r[0] + 1] = "Halftrack"
r["Halftrack"] = false
r[0][#r[0] + 1] = "section_6"
r["section_6"] = "[Chat]"
r[0][#r[0] + 1] = "chat_hidden"
r["chat_hidden"] = false
r[0][#r[0] + 1] = "chat_cmd_friends"
r["chat_cmd_friends"] = true
r[0][#r[0] + 1] = "chat_cmd_all"
r["chat_cmd_all"] = false
r[0][#r[0] + 1] = "chat_log"
r["chat_log"] = false
r[0][#r[0] + 1] = "chat_russki"
r["chat_russki"] = false
r[0][#r[0] + 1] = "chat_begger"
r["chat_begger"] = false
r[0][#r[0] + 1] = "section_7"
r["section_7"] = "[Chat-Commands]"
r[0][#r[0] + 1] = "chat_cmd"
r["chat_cmd"] = false
r[0][#r[0] + 1] = "cmd_explode"
r["cmd_explode"] = false
r[0][#r[0] + 1] = "cmd_explode_all"
r["cmd_explode_all"] = false
r[0][#r[0] + 1] = "cmd_kick"
r["cmd_kick"] = false
r[0][#r[0] + 1] = "cmd_kick_all"
r["cmd_kick_all"] = false
r[0][#r[0] + 1] = "cmd_crash"
r["cmd_crash"] = false
r[0][#r[0] + 1] = "cmd_crash_all"
r["cmd_crash_all"] = false
r[0][#r[0] + 1] = "cmd_lag"
r["cmd_lag"] = false
r[0][#r[0] + 1] = "cmd_trap"
r["cmd_trap"] = false
r[0][#r[0] + 1] = "cmd_tp"
r["cmd_tp"] = false
r[0][#r[0] + 1] = "cmd_clearwanted"
r["cmd_clearwanted"] = false
r[0][#r[0] + 1] = "cmd_vehicle"
r["cmd_vehicle"] = false
r[0][#r[0] + 1] = "cmd_bigpp"
r["cmd_bigpp"] = false
r[0][#r[0] + 1] = "cmd_bigppall"
r["cmd_bigppall"] = false
r[0][#r[0] + 1] = "section_8"
r["section_8"] = "[Custom-Vehicles]"
r[0][#r[0] + 1] = "custom_vehicles_hidden"
r["custom_vehicles_hidden"] = false
r[0][#r[0] + 1] = "spawn_in_vehicle"
r["spawn_in_vehicle"] = true
r[0][#r[0] + 1] = "use_own_veh"
r["use_own_veh"] = true
r[0][#r[0] + 1] = "set_godmode"
r["set_godmode"] = false
r[0][#r[0] + 1] = "controllable_blasts"
r["controllable_blasts"] = false
r[0][#r[0] + 1] = "moveable_legs"
r["moveable_legs"] = false
r[0][#r[0] + 1] = "robot_collision"
r["robot_collision"] = false
r[0][#r[0] + 1] = "rocket_propulsion"
r["rocket_propulsion"] = false
r[0][#r[0] + 1] = "equip_weapons"
r["equip_weapons"] = false
r[0][#r[0] + 1] = "disable_tampa_notify"
r["disable_tampa_notify"] = false
r[0][#r[0] + 1] = "section_9"
r["section_9"] = "[Explosive-Beam]"
r[0][#r[0] + 1] = "explosive_beam_hidden"
r["explosive_beam_hidden"] = false
r[0][#r[0] + 1] = "exp_beam"
r["exp_beam"] = false
r[0][#r[0] + 1] = "exp_beam_type"
r["exp_beam_type"] = 59
r[0][#r[0] + 1] = "exp_beam_type_2"
r["exp_beam_type_2"] = 8
r[0][#r[0] + 1] = "exp_beam_radius"
r["exp_beam_radius"] = 10
r[0][#r[0] + 1] = "exp_beam_min"
r["exp_beam_min"] = 75
r[0][#r[0] + 1] = "exp_beam_max"
r["exp_beam_max"] = 225
r[0][#r[0] + 1] = "section_10"
r["section_10"] = "[Better-Animal-Changer]"
r[0][#r[0] + 1] = "animal_changer_hidden"
r["animal_changer_hidden"] = false
r[0][#r[0] + 1] = "bl_mdl_change"
r["bl_mdl_change"] = true
r[0][#r[0] + 1] = "revert_outfit"
r["revert_outfit"] = true
r[0][#r[0] + 1] = "section_11"
r["section_11"] = "[PTFX]"
r[0][#r[0] + 1] = "ptfx_hidden"
r["ptfx_hidden"] = false
r[0][#r[0] + 1] = "sparkling_ass"
r["sparkling_ass"] = false
r[0][#r[0] + 1] = "sparkling_tires"
r["sparkling_tires"] = false
r[0][#r[0] + 1] = "smoke_area"
r["smoke_area"] = false
r[0][#r[0] + 1] = "fire_circle"
r["fire_circle"] = false
r[0][#r[0] + 1] = "fire_fart"
r["fire_fart"] = 8
r[0][#r[0] + 1] = "fire_ass"
r["fire_ass"] = false
r[0][#r[0] + 1] = "section_12"
r["section_12"] = "[Miscellaneous]"
r[0][#r[0] + 1] = "misc_hidden"
r["misc_hidden"] = false
r[0][#r[0] + 1] = "drive_on_ocean"
r["drive_on_ocean"] = false
r[0][#r[0] + 1] = "drive_this_height"
r["drive_this_height"] = false
r[0][#r[0] + 1] = "weird_ent"
r["weird_ent"] = false
r[0][#r[0] + 1] = "real_time"
r["real_time"] = false
r[0][#r[0] + 1] = "clear_area"
r["clear_area"] = false
r[0][#r[0] + 1] = "clear_area_2"
r["clear_area_2"] = false
r[0][#r[0] + 1] = "auto_tp_wp"
r["auto_tp_wp"] = false
r[0][#r[0] + 1] = "remove_orb_cannon_cd"
r["remove_orb_cannon_cd"] = false
r[0][#r[0] + 1] = "auto_load"
r["auto_load"] = false
r[0][#r[0] + 1] = "log_modder_flags"
r["log_modder_flags"] = false
r[0][#r[0] + 1] = "section_13"
r["section_13"] = "[Weapons-Features]"
r[0][#r[0] + 1] = "load_weapons"
r["load_weapons"] = false
r[0][#r[0] + 1] = "flamethrower_scale"
r["flamethrower_scale"] = 1
r[0][#r[0] + 1] = "flamethrower"
r["flamethrower"] = false
r[0][#r[0] + 1] = "flamethrower_green"
r["flamethrower_green"] = false
r[0][#r[0] + 1] = "shoot_entitys"
r["shoot_entitys"] = false
r[0][#r[0] + 1] = "Boat"
r["Boat"] = false
r[0][#r[0] + 1] = "Bumper_Car"
r["Bumper_Car"] = false
r[0][#r[0] + 1] = "XMAS_Tree"
r["XMAS_Tree"] = false
r[0][#r[0] + 1] = "Orange_Ball"
r["Orange_Ball"] = false
r[0][#r[0] + 1] = "Stone"
r["Stone"] = false
r[0][#r[0] + 1] = "Money_Bag"
r["Money_Bag"] = false
r[0][#r[0] + 1] = "Cash_Pile"
r["Cash_Pile"] = false
r[0][#r[0] + 1] = "Trash"
r["Trash"] = false
r[0][#r[0] + 1] = "Roller_Car"
r["Roller_Car"] = false
r[0][#r[0] + 1] = "Cable_Car"
r["Cable_Car"] = false
r[0][#r[0] + 1] = "Big_Dildo"
r["Big_Dildo"] = false
r[0][#r[0] + 1] = "delete_gun"
r["delete_gun"] = false
r[0][#r[0] + 1] = "kick_gun"
r["kick_gun"] = false
r[0][#r[0] + 1] = "demigod_gun"
r["demigod_gun"] = false
r[0][#r[0] + 1] = "model_gun"
r["model_gun"] = false
r[0][#r[0] + 1] = "model_gun_ext"
r["model_gun_ext"] = false
r[0][#r[0] + 1] = "rapid_fire"
r["rapid_fire"] = false
r[0][#r[0] + 1] = "section_14"
r["section_14"] = "[Vehicle]"
r[0][#r[0] + 1] = "always_apply_mods"
r["always_apply_mods"] = false
r[0][#r[0] + 1] = "heli"
r["heli"] = false
r[0][#r[0] + 1] = "heli_i"
r["heli_i"] = 100
r[0][#r[0] + 1] = "sel_boost_speed"
r["sel_boost_speed"] = false
r[0][#r[0] + 1] = "sel_boost_speed_speed"
r["sel_boost_speed_speed"] = 100
r[0][#r[0] + 1] = "speedometer"
r["speedometer"] = false
r[0][#r[0] + 1] = "speedometer_type"
r["speedometer_type"] = 1
r[0][#r[0] + 1] = "veh_no_colision"
r["veh_no_colision"] = false
r[0][#r[0] + 1] = "auto_repair"
r["auto_repair"] = false
r[0][#r[0] + 1] = "section_15"
r["section_15"] = "[Vehicle-Colors]"
r[0][#r[0] + 1] = "veh_lights_speed"
r["veh_lights_speed"] = 125
r[0][#r[0] + 1] = "random_primary"
r["random_primary"] = false
r[0][#r[0] + 1] = "random_secondary"
r["random_secondary"] = false
r[0][#r[0] + 1] = "random_pearlescent"
r["random_pearlescent"] = false
r[0][#r[0] + 1] = "random_neon"
r["random_neon"] = false
r[0][#r[0] + 1] = "random_smoke"
r["random_smoke"] = false
r[0][#r[0] + 1] = "random_xenon"
r["random_xenon"] = false
r[0][#r[0] + 1] = "rainbow_primary"
r["rainbow_primary"] = false
r[0][#r[0] + 1] = "rainbow_secondary"
r["rainbow_secondary"] = false
r[0][#r[0] + 1] = "rainbow_pearlescent"
r["rainbow_pearlescent"] = false
r[0][#r[0] + 1] = "rainbow_neon"
r["rainbow_neon"] = false
r[0][#r[0] + 1] = "rainbow_smoke"
r["rainbow_smoke"] = false
r[0][#r[0] + 1] = "rainbow_xenon"
r["rainbow_xenon"] = false
r[0][#r[0] + 1] = "synced_random"
r["synced_random"] = false
r[0][#r[0] + 1] = "synced_rainbow"
r["synced_rainbow"] = false
r[0][#r[0] + 1] = "synced_rainbow_smooth"
r["synced_rainbow_smooth"] = false
r[0][#r[0] + 1] = "black_100"
r["black_100"] = false
r[0][#r[0] + 1] = "fade_black_red"
r["fade_black_red"] = false
r[0][#r[0] + 1] = "section_17"
r["section_17"] = "[Self]"
r[0][#r[0] + 1] = "self_hidden"
r["self_hidden"] = false
r[0][#r[0] + 1] = "random_clothes"
r["random_clothes"] = false
r[0][#r[0] + 1] = "police_outfit"
r["police_outfit"] = false
r[0][#r[0] + 1] = "random_clothes_value"
r["random_clothes_value"] = 5
r[0][#r[0] + 1] = "undead_otr"
r["undead_otr"] = false
r[0][#r[0] + 1] = "quick_regen"
r["quick_regen"] = false
r[0][#r[0] + 1] = "unlimited_regen"
r["unlimited_regen"] = false
r[0][#r[0] + 1] = "revert_health"
r["revert_health"] = false
r[0][#r[0] + 1] = "ragdoll"
r["ragdoll"] = false
r[0][#r[0] + 1] = "section_18"
r["section_18"] = "[Aim-Protection]"
r[0][#r[0] + 1] = "enable_aim_prot"
r["enable_aim_prot"] = false
r[0][#r[0] + 1] = "anonymous_punishment"
r["anonymous_punishment"] = true
r[0][#r[0] + 1] = "aim_prot_ragdoll"
r["aim_prot_ragdoll"] = false
r[0][#r[0] + 1] = "aim_prot_fire"
r["aim_prot_fire"] = false
r[0][#r[0] + 1] = "aim_prot_kill"
r["aim_prot_kill"] = false
r[0][#r[0] + 1] = "aim_prot_remove_weapon"
r["aim_prot_remove_weapon"] = false
r[0][#r[0] + 1] = "aim_prot_kick"
r["aim_prot_kick"] = false
r[0][#r[0] + 1] = "section_16"
r["section_16"] = "[Bodyguards]"
r[0][#r[0] + 1] = "bodyguards_hidden"
r["bodyguards_hidden"] = false
r[0][#r[0] + 1] = "bodyguards_god"
r["bodyguards_god"] = false
r[0][#r[0] + 1] = "bodyguards_health"
r["bodyguards_health"] = 5000
r[0][#r[0] + 1] = "bodyguards_equip_weapon"
r["bodyguards_equip_weapon"] = false
r[0][#r[0] + 1] = "bodyguards_formation_type"
r["bodyguards_formation_type"] = 0
r[0][#r[0] + 1] = "section_19"
r["section_19"] = "[Options]"
r[0][#r[0] + 1] = "options_hidden"
r["options_hidden"] = false
r[0][#r[0] + 1] = "attach_no_colision"
r["attach_no_colision"] = false
r[0][#r[0] + 1] = "continuously_assassins"
r["continuously_assassins"] = false
r[0][#r[0] + 1] = "override_notify_color"
r["override_notify_color"] = false
r[0][#r[0] + 1] = "notify_color"
r["notify_color"] = 0
r[0][#r[0] + 1] = "enable_hotkeys"
r["enable_hotkeys"] = false
r[0][#r[0] + 1] = "hotkey_notification"
r["hotkey_notification"] = false
r[0][#r[0] + 1] = "disable_history"
r["disable_history"] = false
r[0][#r[0] + 1] = "history_show_uuid"
r["history_show_uuid"] = false
r[0][#r[0] + 1] = "mwh_notify"
r["mwh_notify"] = false
r[0][#r[0] + 1] = "mwh_exclude_navigation"
r["mwh_exclude_navigation"] = true
r[0][#r[0] + 1] = "mwh_exclude_noclip"
r["mwh_exclude_noclip"] = true
r[0][#r[0] + 1] = "mwh_exclude_editorrot"
r["mwh_exclude_editorrot"] = true
r[0][#r[0] + 1] = "mwh_exclude_file"
r["mwh_exclude_file"] = false
local s = {}
s[0] = {}
s[0][#s[0] + 1] = "leave_session"
s["leave_session"] = "none"
s[0][#s[0] + 1] = "undead_otr"
s["undead_otr"] = "none"
s[0][#s[0] + 1] = "do_ragdoll"
s["do_ragdoll"] = "none"
s[0][#s[0] + 1] = "print_info_from_entity"
s["print_info_from_entity"] = "none"
s[0][#s[0] + 1] = "drive_this_height"
s["drive_this_height"] = "none"
s[0][#s[0] + 1] = "auto_tp_wp"
s["auto_tp_wp"] = "none"
s[0][#s[0] + 1] = "force_host"
s["force_host"] = "none"
s[0][#s[0] + 1] = "synced_rainbow"
s["synced_rainbow"] = "none"
s[0][#s[0] + 1] = "veh_blacklist"
s["veh_blacklist"] = "none"
s[0][#s[0] + 1] = "laser_beam_explode_waypoint"
s["laser_beam_explode_waypoint"] = "none"
s[0][#s[0] + 1] = "blacklist_enabled"
s["blacklist_enabled"] = "none"
s[0][#s[0] + 1] = "kick_joining"
s["kick_joining"] = "none"
s[0][#s[0] + 1] = "remember_modder"
s["remember_modder"] = "none"
s[0][#s[0] + 1] = "exclude_friends"
s["exclude_friends"] = "none"
s[0][#s[0] + 1] = "chat_cmd"
s["chat_cmd"] = "none"
s[0][#s[0] + 1] = "send_msg_to_script_users"
s["send_msg_to_script_users"] = "none"
s[0][#s[0] + 1] = "teleport_high_in_air"
s["teleport_high_in_air"] = "none"
s[0][#s[0] + 1] = "tp_own_veh_to_me"
s["tp_own_veh_to_me"] = "none"
s[0][#s[0] + 1] = "tp_own_veh_to_me_drive"
s["tp_own_veh_to_me_drive"] = "none"
s[0][#s[0] + 1] = "drive_own_veh"
s["drive_own_veh"] = "none"
s[0][#s[0] + 1] = "tp_to_own_veh"
s["tp_to_own_veh"] = "none"
s[0][#s[0] + 1] = "save_config"
s["save_config"] = "none"
local t = {}
t[0] = {}
t[0][#t[0] + 1] = "maxspeed"
t["maxspeed"] = {"Max-Speed-Bypass", nil}
t[0][#t[0] + 1] = "illegalname"
t["illegalname"] = {"Illegal-Name", nil}
t[0][#t[0] + 1] = "moddedscid"
t["moddedscid"] = {"Modded-SCID", nil}
t[0][#t[0] + 1] = "moddednetevent"
t["moddednetevent"] = {"Modded-Net-Event", nil}
t[0][#t[0] + 1] = "force_sh"
t["force_sh"] = {"Forced-Script-Host", nil}
t[0][#t[0] + 1] = "remembered"
t["remembered"] = {"Remembered", nil}
t[0][#t[0] + 1] = "blacklist"
t["blacklist"] = {"Blacklist", nil}
t[0][#t[0] + 1] = "script"
t["script"] = {"Modded-Script-Event", nil}
local function u(f, v, w)
    if not f then
        return
    end
    v = v or 140
    w = w or "~h~2Take1Script~h~&#166"
    if r["override_notify_color"] then
        v = r["notify_color"]
    end
    ui.notify_above_map(f, w, v)
end
local function x(f, y)
    if r["logger"] then
        if not f then
            return
        end
        local z = d.time_prefix() .. " [2Take1Script] "
        if y then
            z = z .. y .. " "
        end
        f = z .. f
        d.write(c.o(b["Log_file"], "a"), f)
    end
end
local A = {
    1,
    2,
    4,
    8,
    16,
    32,
    64,
    128,
    256,
    512,
    1024,
    2048,
    4096,
    8192,
    16384,
    32768,
    65536,
    131072,
    262144,
    524288,
    1048576,
    2097152,
    4194304,
    8388608,
    16777216,
    33554432,
    67108864,
    134217728,
    268435456,
    536870912,
    1073741824,
    2147483648,
    4294967296,
    8589934592,
    17179869184,
    34359738368,
    68719476736,
    137438953472,
    274877906944,
    549755813888,
    1099511627776,
    2199023255552,
    4398046511104,
    8796093022208,
    17592186044416,
    35184372088832,
    70368744177664,
    140737488355328,
    281474976710656,
    562949953421312,
    1125899906842624,
    2251799813685248,
    4503599627370496,
    9007199254740992,
    18014398509481984,
    36028797018963968,
    72057594037927936,
    144115188075855872,
    288230376151711744,
    576460752303423488,
    1152921504606846976,
    2305843009213693952,
    4611686018427387904
}
local B = {}
local C = {}
local D = {}
local E = {}
E.name = function(i)
    if c.valid(i) then
        return player.get_player_name(i)
    end
    return "Invalid Player"
end
E.scid = function(i)
    if c.valid(i) then
        local c = player.get_player_scid(i)
        if c ~= 4294967295 then
            return c
        end
    end
    return -1
end
E.ip = function(i)
    if c.valid(i) then
        local F = player.get_player_ip(i)
        return string.format("%i.%i.%i.%i", F >> 24 & 0xff, F >> 16 & 0xff, F >> 8 & 0xff, F & 0xff)
    end
    return -1
end
E.input = function(G, H, I, J)
    if not G then
        return nil
    end
    J = J or ""
    H = H or 64
    I = I or 0
    local K, i = input.get(G, J, H, I)
    while K == 1 do
        c.wait(0)
        K, i = input.get(G, J, H, I)
    end
    if K == 2 then
        return nil
    end
    return i
end
local L = {}
L.main = function()
    x("Loading Settings...")
    math.randomseed(c.time())
    if _2t1s then
        u("2Take1Script already loaded, stopping.", 208)
        return
    end
    if not c.d_exists(a["2T1S"]) then
        u("2Take1Script folder not found...", 208)
        u("Redownload the script and make sure you got all files!", 208)
        return
    else
        if c.f_exists(b["EXT_file"]) then
            _2t1sEXT = true
            local M, N = loadfile(b["EXT_file"])
            if M then
                local O
                O,
                    C.custom_se,
                    C.ped_assassins,
                    C.russki_chars,
                    C.begger_texts,
                    C.speedometer_units,
                    C.block_custom,
                    C.custom_attachments,
                    C.custom_vehicles,
                    C.vehicle_lag_area,
                    C.bounty_amount,
                    C.sms_texts,
                    C.weapons,
                    C.net_events,
                    C.enable_admin = xpcall(M, debug.traceback)
                x("2Take1ScriptEXT successfully loaded.")
            else
                _2t1sEXT = false
                u("ERROR Loading Script EXT, returning!", 208)
                return
            end
        else
            u("2Take1ScriptEXT.lua not found!\nMake sure you have all important files!", 208)
            return
        end
        if not c.d_exists(a["Config"]) then
            u("2Take1Script/Config folder not found...", 208)
            u("Redownload the script and make sure you got all files!", 208)
            return
        end
        if not c.d_exists(a["CustomFiles"]) then
            u("2Take1Script/CustomFiles folder not found...", 208)
            u("Redownload the script and make sure you got all files!", 208)
            return
        end
    end
    local P = c.o(b["Config"], "r")
    if P then
        for o in io.lines(b["Config"]) do
            if not string.find(o, "]", 1) and not string.find(o, "version", 1) then
                local q = ""
                while string.find(o, "=", 1) do
                    q = q .. string.sub(o, 1, 1)
                    o = string.sub(o, 2)
                end
                q = string.sub(q, 1, #q - 1)
                if r[q] ~= nil then
                    if o == "true" then
                        r[q] = true
                    elseif o == "false" then
                        r[q] = false
                    elseif type(o) == "number" then
                        r[q] = c.no(o)
                    else
                        r[q] = o
                    end
                else
                    u("I found an outdated settings entry and cant read it, save settings to overwrite it.")
                    u("Setting: '" .. q .. "' is invalid. Delete this entry or save settings.")
                end
            end
        end
        io.close(P)
    end
    P = nil
    P = c.o(b["data"], "r")
    if P then
        for Q in io.lines(b["data"]) do
            B[#B + 1] = Q
        end
        io.close(P)
    else
        u("ERROR Loading Script, returning!", 208)
        u("Missing files! Redownload the .zip folder and make sure you have all included files!!!")
        return
    end
    if c.f_exists(b["Admin"]) then
        if not l_a and r["load_admin"] then
            local R, N = loadfile(b["Admin"])
            if R then
                xpcall(R, debug.traceback)
                x("2Take1Script-Admin successfully loaded.")
            else
                u("ERROR Loading Script Admin!", 208)
            end
        end
    end
    local S = {0xedb42cd8, 0x231d58ee, 0xac07dc75, 0x58fabbdf, 0xd892c51c, 0xb3f248d0}
    hook.register_script_event_hook(
        function(T, U, V, W)
            if type(V) == "table" then
                if V[1] == 0xfaaab4a3 then
                    if V[2] == 6666 then
                        table.remove(V, 1)
                        table.remove(V, 1)
                        local X = utf8.char(table.unpack(V))
                        u(X, E.name(T), 47)
                        x(E.name(T) .. ": " .. X)
                    end
                end
                for i = 1, #S do
                    if S[i] == V[1] and #V == 5 then
                        local Y = S[c.random(1, #S)]
                        local plid = c.id()
                        local Z = c.random(-10, 100)
                        c.script(Y, T, {plid, V[3], V[4], Z})
                    end
                end
            end
        end
    )
    return true
end
L.modder_flags = function()
    x("Loading Modder-Flags...")
    for i = 18, #A do
        if player.get_modder_flag_text(A[i]) == "" then
            break
        end
        for _ = 1, #t[0] do
            if player.get_modder_flag_text(A[i]) == t[t[0][_]][1] then
                t[t[0][_]][2] = A[i]
            end
        end
    end
    for i = 1, #t[0] do
        if not t[t[0][i]][2] then
            t[t[0][i]][2] = player.add_modder_flag(t[t[0][i]][1])
        end
    end
end
L.hotkeys = function()
    x("Reading Hotkeys.")
    local a0 = c.o(b["Hotkeys"], "r")
    if a0 then
        for n in io.lines(b["Hotkeys"]) do
            if string.find(n, "version", 1) then
                local a1 = string.gsub(n, "version=", "")
                a1 = c.no(a1)
                if a1 ~= r["version"] then
                    u("Old Hotkeys-File detected. Delete the file or use the overwrite in the Hotkey-Options!", 86)
                end
            end
            if not string.find(n, "#", 1) and not string.find(n, "version", 1) then
                local q = ""
                while string.find(n, "=", 1) do
                    q = q .. string.sub(n, 1, 1)
                    n = string.sub(n, 2)
                end
                q = string.sub(q, 1, #q - 1)
                if n ~= "none" and n ~= "nil" then
                    if s[q] then
                        s[q] = n
                    else
                        u(
                            "Outdated Hotkeys entry found. Delete the file or use the overwrite in the Hotkey-Options!",
                            86
                        )
                        u("Hotkey: '" .. n .. "' with action: '" .. q .. "' is invalid. Delete this entry.", 86)
                    end
                end
            end
        end
        io.close(a0)
    end
end
L.overwrite_hotkeys = function()
    local a2 = c.o(b["Hotkeys"], "w")
    io.output(a2)
    io.write("version=" .. r["version"] .. "\n")
    for i = 1, #s[0] do
        io.write(s[0][i] .. "=" .. tostring(s[s[0][i]]) .. "\n")
    end
    io.write("################################\n")
    io.write(
        "#There are more valid Keys, but i wont list them. Currently its not supported to push 2 Keys for 1 Hotkey.\n"
    )
    io.write("#Example valid Hotkeys:\n")
    io.write("#F1-F12\n")
    io.write("#A-Z\n")
    io.write("#LCONTROL\n")
    io.write("#RSHIFT\n")
    io.write("#Insert\n")
    io.write("#Down\n")
    io.write("#PageDown\n")
    io.close(a2)
    u("Created 2Take1Hotkeys.ini file in folder '2Take1Script/Config'. Edit Hotkeys and reload Hotkeys.ini file.", 86)
end
if not L.main() then
    return
end
L.hotkeys()
L.modder_flags()
local a3 = {}
a3.ctrl = function(O, g)
    if entity.is_an_entity(O) then
        if not network.has_control_of_entity(O) then
            network.request_control_of_entity(O)
            g = g or 25
            local time = c.time() + g
            while entity.is_an_entity(O) and not network.has_control_of_entity(O) do
                c.wait(0)
                network.request_control_of_entity(O)
                if time < c.time() then
                    return false
                end
            end
        end
        return network.has_control_of_entity(O)
    end
    return false
end
a3.model = function(a4)
    if a4 and not streaming.has_model_loaded(a4) then
        streaming.request_model(a4)
        local time = c.time() + 7500
        while not streaming.has_model_loaded(a4) do
            c.wait(0)
            if time < c.time() then
                return false
            end
        end
    end
    return true
end
local a5 = {}
a5.ped = function()
    return c.ped(c.id())
end
a5.heading = function()
    return player.get_player_heading(c.id())
end
a5.coords = function()
    return c.gcoords(a5.ped())
end
local a6 = {}
a6.p = {["parent"] = 0, ["opl_parent"] = 0}
a6.t = {}
a6.o = {}
a6.add = {}
a6.add.p = function(j, a7, a8)
    return menu.add_feature(j, "parent", a7, a8)
end
a6.add.t = function(j, a7, a8)
    return menu.add_feature(j, "toggle", a7, a8)
end
a6.add.a = function(j, a7, a8)
    return menu.add_feature(j, "action", a7, a8)
end
a6.add.u = function(j, a9, a7, a8)
    return menu.add_feature(j, a9, a7, a8)
end
a6.add.pp = function(j, a7, a8)
    return menu.add_player_feature(j, "parent", a7, a8)
end
a6.add.pt = function(j, a7, a8)
    return menu.add_player_feature(j, "toggle", a7, a8)
end
a6.add.pa = function(j, a7, a8)
    return menu.add_player_feature(j, "action", a7, a8)
end
a6.add.pu = function(j, a9, a7, a8)
    return menu.add_player_feature(j, a9, a7, a8)
end
local aa = {}
aa.i = function(i, ab)
    ab = ab or false
    if c.valid(i) then
        if (ab or i ~= c.id()) and E.scid(i) ~= -1 then
            if ab or (r["exclude_friends"] and not player.is_player_friend(i) or not r["exclude_friends"]) then
                return true
            end
        end
    end
    return false
end
aa.modder = function(i)
    if c.valid(i) then
        if E.scid(i) ~= -1 and i ~= c.id() and not player.is_player_modder(i, -1) then
            if r["exclude_friends"] and not player.is_player_friend(i) or not r["exclude_friends"] then
                return true
            end
        end
    end
    return false
end
aa.vehicle = function(ac)
    if not ac then
        return
    end
    if ac ~= 0 and (vehicle.get_ped_in_vehicle_seat(ac, -1) == a5.ped() or a6.t["always_apply_mods"].on) then
        return true
    end
    return
end
local ad = {}
ad[1] = true
local ae = {}
ae.add_loop = 1
ae.start_loop = 1
ae.parents = {}
ae.players = {}
ae.event = nil
ae.lobby = nil
ae.tags = function(af)
    for i = 2, #af.children do
        local ag = af.children[i].name
        local ah = string.sub(af.children[i].children[2].name, 7)
        if ag ~= ah then
            af.children[i].name = ah
        end
        local aj = c.no(string.sub(af.children[i].children[3].name, 7))
        local ak = player.get_host()
        local al = script.get_host_of_this_script()
        for _ = 0, 31 do
            if E.scid(_) == aj then
                local am = ""
                if _ == c.id() then
                    am = am .. "Y"
                end
                if player.is_player_friend(_) then
                    am = am .. "F"
                end
                if _ == ak then
                    am = am .. "H"
                end
                if _ == al then
                    am = am .. "S"
                end
                if player.is_player_modder(_, -1) then
                    am = am .. "M"
                end
                if am ~= "" then
                    ah = ah .. " [" .. am .. "]"
                    af.children[i].name = ah
                end
            end
        end
    end
end
ae.add_players = function()
    if not r["disable_history"] then
        for i = ae.add_loop, #ae.players do
            local an = ae.players[i]["uuid"]
            local ao = ae.players[i]["added"] == false
            local ap = c.no(string.sub(ae.lobby.name, 7, 8))
            local aq = c.no(string.sub(an, #an - 1, #an))
            if not aq then
                aq = c.no(string.sub(an, #an, #an))
            end
            local ar = ap == aq
            if ao and ar then
                ae.add_loop = ae.add_loop + 1
                ae.players[i]["added"] = true
                local aj = ae.players[i]["scid"]
                local j = ae.players[i]["name"]
                local as = a6.add.p(j, ae.lobby.id).id
                a6.add.a("UUID: " .. ae.players[i]["uuid"], as).hidden = not r["history_show_uuid"]
                a6.add.a(
                    "NAME: " .. j,
                    as,
                    function()
                        utils.to_clipboard(j)
                        u("Copied NAME to clipboard!", 21)
                    end
                )
                a6.add.a(
                    "SCID: " .. aj,
                    as,
                    function()
                        utils.to_clipboard(aj)
                        u("Copied SCID to clipboard!", 21)
                    end
                )
                a6.add.a(
                    "IP: " .. ae.players[i]["ip"],
                    as,
                    function()
                        utils.to_clipboard(ae.players[i]["ip"])
                        u("Copied IP to clipboard!", 21)
                    end
                )
                a6.add.a("PlayerID: " .. ae.players[i]["player_id"], as)
                a6.add.a("First seen: " .. ae.players[i]["first_seen"], as)
                a6.add.a(
                    "Add Player to Blacklist",
                    as,
                    function()
                        if aj == E.scid(c.id()) or aj == -1 then
                            u("Choose valid Player.")
                        else
                            d.write(c.o(b["Blacklist"], "a"), aj .. " " .. j)
                            u("Player " .. j .. " added to Blocklist.", 48)
                            x("Player " .. j .. " with SCID: " .. aj .. " added to Blacklist.")
                        end
                    end
                )
                a6.add.a(
                    "Add Player to Remember-Modder",
                    as,
                    function()
                        if aj == E.scid(c.id()) or aj == -1 then
                            u("Choose valid Player.")
                        else
                            d.write(c.o(b["Modders"], "a"), aj .. " " .. j)
                            u("Modder " .. j .. " added to Remember-List.", 130)
                            x("Modder '" .. j .. "' added to Remember-List.")
                        end
                    end
                )
                a6.add.a(
                    "Copy Outfit",
                    as,
                    function()
                        local at = player.is_player_female(c.id())
                        if at == ae.players[i]["is_female"] then
                            local au = ae.players[i]["h_clothes"]
                            local av = ae.players[i]["h_textures"]
                            for _ = 1, 11 do
                                ped.set_ped_component_variation(a5.ped(), _, au[_], av[_], 2)
                            end
                            local aw = {0, 1, 2, 6, 7}
                            local ax = ae.players[i]["h_prop_ind"]
                            local ay = ae.players[i]["h_prop_text"]
                            for az = 1, #aw do
                                ped.set_ped_prop_index(a5.ped(), aw[az], ax[az], ay[az], 0)
                            end
                        else
                            u("Unluckily, you have the wrong gender!", 21)
                        end
                    end
                )
                a6.add.a(
                    "Is " .. j .. " in the current lobby?",
                    as,
                    function()
                        for _ = 0, 31 do
                            if E.scid(_) == aj then
                                u(j .. " is in your lobby!", 18)
                                return HANDLER_POP
                            end
                        end
                        u(j .. " is ~h~NOT~h~ in your lobby!", 28)
                    end
                )
                a6.add.a(
                    "Was he a modder?",
                    as,
                    function()
                        local aj = ae.players[i]["scid"]
                        if not a6.t["log_modder_flags"].on then
                            u("Enabel 'Log Modder Flags' in Misc -> Dev Tools", 39)
                        elseif not ad[aj] then
                            u("He was not flagged with any Modder-Flags", 21)
                        else
                            for _ = 1, #A do
                                if ad[aj][A[_]] then
                                    local aA = A[_]
                                    local f = player.get_modder_flag_text(aA)
                                    u(j .. " had '" .. f .. "' as a Flag!", 21)
                                end
                            end
                        end
                    end
                )
            end
        end
    end
end
ae.new_lobby = function(aB)
    local H = #ae.parents + 1
    ae.parents[H] =
        a6.add.p(
        "Lobby " .. aB,
        a6.p["player_history"],
        function()
            ae.add_players()
            ae.tags(ae.parents[H])
        end
    )
    local aC = #ae.parents - 1
    local aD = ae.parents[aC].children
    a6.add.p("Lobby Information", ae.parents[H].id).hidden = true
    ae.lobby = ae.parents[H]
    aD[1].hidden = false
    a6.add.a("Logged " .. #aD - 1 .. " Players in this Lobby!", aD[1].id)
    a6.add.a(
        "Hide this lobby from History",
        aD[1].id,
        function()
            ae.parents[H - 1].hidden = true
        end
    )
end
local aE = {}
aE.ped = function(aF, aG, aH, aI, aJ, aK)
    if not aF then
        return
    end
    aH = aH or 6
    aG = aG or a5.coords()
    aI = aI or 0.0
    aJ = aJ or true
    aK = aK or false
    return ped.create_ped(aH, aF, aG, aI, aJ, aK)
end
aE.object = function(aF, aG, aL, aM)
    if not aF then
        return
    end
    aG = aG or v3()
    aL = aL or true
    aM = aM or false
    return object.create_object(aF, aG, aL, aM)
end
aE.vehicle = function(aF, aG, aI, aL, aK)
    if not aF then
        return
    end
    aG = aG or v3()
    aI = aI or 0.0
    aL = aL or true
    aK = aK or false
    return vehicle.create_vehicle(aF, aG, aI, aL, aK)
end
local aN = {
    {"Severe Weather", {0}},
    {"Half Track", {0, 1}},
    {"Night Shark AAT", {0, 2}},
    {"APC Mission", {0, 3}},
    {"MOC Mission", {0, 4}},
    {"Tampa Mission", {0, 5}},
    {"Opressor Mission 1", {0, 6}},
    {"Opressor Mission 2", {0, 7}}
}
local aO = {
    {"Ban", -738295409, {0, 1, 5, 0}, 1648921703, {0, 1, 5, 0}},
    {"Dismiss", 1648921703, {0, 1, 5}, 1648921703, {0, 1, 5}},
    {"Terminate", 1648921703, {1, 1, 6}, 1648921703, {0, 1, 6, 0}}
}
local aP = {
    {"Boat", -1685705098, false},
    {"Bumper_Car", -77393630, false},
    {"XMAS_Tree", 238789712, false},
    {"Orange_Ball", 148511758, false},
    {"Stone", 2042668880, false},
    {"Money_Bag", 289396019, false},
    {"Cash_Pile", -295781225, false},
    {"Trash", 1919238784, false},
    {"Roller_Car", 1543894721, false},
    {"Cable_Car", -733833763, false},
    {"Big_Dildo", 1333481871, false}
}
local aQ = {
    {222, 222, 255},
    {2, 21, 255},
    {3, 83, 255},
    {0, 255, 140},
    {94, 255, 1},
    {255, 255, 0},
    {255, 150, 5},
    {255, 62, 0},
    {255, 1, 1},
    {255, 50, 100},
    {255, 5, 190},
    {35, 1, 255},
    {15, 3, 255}
}
local aR = {
    {"Oppressor", 0x34B82784},
    {"MK2_Oppressor", 0x7B54A9D3},
    {"Lazer", 0xB39B0AE6},
    {"Hydra", 0x39D6E83F},
    {"Deluxo", 0x586765FB},
    {"Akula", 0x46699F47},
    {"B_11_Strikforce", 0x64DE07A1},
    {"Tank", 0x2EA68690},
    {"Khanjali", 0xAA6F980A},
    {"Stromberg", 0x34DBA661},
    {"Buzzard", 0x2F03547B},
    {"Hunter", 0xFD707EDE},
    {"Avenger", 0x81BD2ED0},
    {"Insurgent_Pickup", 0x9114EADA},
    {"Insurgent_Pickup_Custom", 0x8D4B7A8A},
    {"Halftrack", 0xFE141DA6}
}
local aS = {
    {"cmd_explode", "!explode <playername>"},
    {"cmd_explode_all", "!explodeall	[SU]"},
    {"cmd_kick", "!kick <playername>"},
    {"cmd_kick_all", "!kickall	[SU]"},
    {"cmd_crash", "!crash <playername>	[SU]"},
    {"cmd_crash_all", "!crashall	[SU]"},
    {"cmd_lag", "!lag <playername>"},
    {"cmd_trap", "!trap <playername>"},
    {"cmd_tp", "!tp <playername>	[SU]"},
    {"cmd_clearwanted", "!clearwanted	[NOT SU]"},
    {"cmd_vehicle", "!vehicle <NAME>"},
    {"cmd_bigpp", "!bigpp <playername>"},
    {"cmd_bigppall", "!bigppall	[SU]"}
}
local aT = {
    ["lscs"] = {
        {
            "Main LSC",
            {
                {3291218330, {-357.45132446289, -134.30920410156, 38.53914642334}, {0, 0, -20}, true, true},
                {false, {-370.4, -104.72, 47}, -110.83449554443}
            }
        },
        {
            "La Mesa LSC",
            {
                {3291218330, {722.9853515625, -1089.2061767578, 23.043445587158}, {0, 0, 0}, true, true},
                {false, {700, -1085, 24}, -100}
            }
        },
        {
            "LSIA LSC",
            {
                {3291218330, {-1145.7882080078, -1991.130859375, 13.163989067078}, {0, 0, 45}, true, true},
                {false, {-1117.1, -1983.3, 23}, 104.5}
            }
        },
        {
            "Desert LSC",
            {
                {3291218330, {1178.552734375, 2646.4377441406, 37.874099731445}, {0, 0, 90}, true, true},
                {false, {1182, 2673.2, 39}, 163.3}
            }
        },
        {
            "Paleto Bay LSC",
            {
                {3291218330, {112.54597473145, 6619.6850585938, 31.604303359985}, {0, 0, -45}, true, true},
                {false, {140.8, 6601.9, 32}, 57}
            }
        },
        {
            "Bennys LSC",
            {
                {3291218330, {-208.5591583252, -1308.7404785156, 31.718006134033}, {0, 0, 90}, true, true},
                {false, {-184.2, -1292.5, 34}, 124.3}
            }
        }
    },
    ["casino"] = {
        {
            "Entrance",
            {
                {3291218330, {924.69201660156, 62.243091583252, 81.21053314209}, {0, 0, 80}, true, true},
                {3291218330, {910.31787109375, 36.022556304932, 80.59684753418}, {0, 0, 25}, true, true},
                {false, {920.8, 80.5, 80}, -177}
            }
        },
        {
            "Garage",
            {
                {3291218330, {932.78601074219, -2.0857257843018, 80.166107177734}, {0, 0, 60}, true, true},
                {false, {940, -21, 80}, 4.9}
            }
        },
        {
            "Roof",
            {
                {3291218330, {964.02569580078, 58.947933197021, 113.34354400635}, {0, 0, -30}, true, true},
                {false, {954.8, 63.34, 114}, -124.2}
            }
        }
    },
    ["mazebank"] = {
        {
            "Entrance",
            {
                {3291218330, {-81.541351318359, -792.25347900391, 44.622947692871}, {0, 0, 100}, true, true},
                {3291218330, {-70.231819152832, -802.17694091797, 44.230716705322}, {0, 0, 0}, true, true},
                {false, {-55.1, -776.5, 46}, 125.4}
            }
        },
        {
            "Garage",
            {
                {3291218330, {-83.269706726074, -773.02490234375, 39.806701660156}, {0, -35, 105}, true, true},
                {false, {-86.2, -762.2, 44}, -165.7}
            }
        },
        {
            "Roof",
            {
                {3291218330, {-66.390617370605, -813.32702636719, 320.40509033203}, {0, 0, 60}, true, true},
                {3291218330, {-66.451454162598, -822.87298583984, 321.19717407227}, {0, 0, 100}, true, true},
                {3291218330, {-68.104598999023, -818.67510986328, 323.35980224609}, {0, 90, 0}, true, true},
                {false, {-76.6, -817.6, 328}}
            }
        },
        {
            "Arena War",
            {
                {3291218330, {-371.32809448242, -1859.2064208984, 21.246929168701}, {0, 15, -75}, true, true},
                {3291218330, {-396.87942504883, -1869.1518554688, 22.718107223511}, {0, 15, -60}, true, true},
                {false, {-379.6, -1850, 23}, -166.6}
            }
        }
    },
    ["custom"] = C.block_custom
}
local aU = {1057201338, 2238511874, 762327283}
local aV = {
    62409944,
    64074298,
    155527062,
    153219155,
    131037988,
    141884823,
    104432921,
    147111499,
    9284553,
    114982881,
    137663665,
    63457,
    137601710,
    138075198,
    123017343,
    130291511,
    137851207,
    137714280,
    127448079,
    137579070,
    134412628,
    133709045,
    64234321,
    131973478,
    103019313,
    103054099,
    104041189,
    110470958,
    119266383,
    119958356,
    121397532,
    121698158,
    123849404,
    121943600,
    129159629,
    18965281,
    216820,
    56778561,
    99453545,
    99453882,
    88435916,
    174875493
}
local aW = {
    ["bl_objects"] = {},
    ["peds"] = {},
    ["attach_obj"] = {},
    ["asteroids"] = {},
    ["lag_area"] = {},
    ["custom_veh"] = {},
    ["preview_veh"] = {},
    ["temp_veh"] = {},
    ["shooting"] = {},
    ["chat_veh"] = {},
    ["bodyguards"] = {},
    ["bodyguards_veh"] = {},
    ["robot_weapon_left"] = {},
    ["robot_weapon_right"] = {},
    ["vehicle_builder"] = {}
}
local aX = {
    ["police_outfit"] = {
        ["female"] = {
            ["clothes"] = {{0, 0}, {0, 6}, {0, 14}, {0, 34}, {0, 0}, {0, 25}, {0, 0}, {0, 35}, {0, 0}, {0, 0}, {0, 48}},
            ["props"] = {{0, 45, 0}, {1, 11, 0}, {2, 4294967295, 0}, {6, 4294967295, -1}, {7, 4294967295, -1}}
        },
        ["male"] = {
            ["clothes"] = {{0, 0}, {0, 0}, {0, 0}, {0, 35}, {0, 0}, {0, 25}, {0, 0}, {0, 58}, {0, 0}, {0, 0}, {0, 55}},
            ["props"] = {{0, 46, 0}, {1, 13, 0}, {2, 4294967295, 0}, {6, 4294967295, -1}, {7, 4294967295, -1}}
        }
    },
    ["bac_outfit"] = {["textures"] = {}, ["clothes"] = {}, ["prop_text"] = {}, ["prop_ind"] = {}, ["gender"] = nil},
    ["session_crash"] = {["textures"] = {}, ["clothes"] = {}, ["prop_text"] = {}, ["prop_ind"] = {}}
}
local aY = {}
aY.hashes = {
    ["orbital_cannon_cd"] = {"ORBITAL_CANNON_COOLDOWN", 0},
    ["snacks_and_armor"] = {
        {"NO_BOUGHT_YUM_SNACKS", 30},
        {"NO_BOUGHT_HEALTH_SNACKS", 15},
        {"NO_BOUGHT_EPIC_SNACKS", 5},
        {"NUMBER_OF_ORANGE_BOUGHT", 10},
        {"NUMBER_OF_BOURGE_BOUGHT", 10},
        {"NUMBER_OF_CHAMP_BOUGHT", 5},
        {"CIGARETTES_BOUGHT", 20},
        {"MP_CHAR_ARMOUR_1_COUNT", 10},
        {"MP_CHAR_ARMOUR_2_COUNT", 10},
        {"MP_CHAR_ARMOUR_3_COUNT", 10},
        {"MP_CHAR_ARMOUR_4_COUNT", 10},
        {"MP_CHAR_ARMOUR_5_COUNT", 10}
    },
    ["kills_deaths"] = {"MPPLY_KILLS_PLAYERS", "MPPLY_DEATHS_PLAYER"},
    ["fast_run"] = {
        "CHAR_FM_ABILITY_1_UNLCK",
        "CHAR_FM_ABILITY_2_UNLCK",
        "CHAR_FM_ABILITY_3_UNLCK",
        "CHAR_ABILITY_1_UNLCK",
        "CHAR_ABILITY_2_UNLCK",
        "CHAR_ABILITY_3_UNLCK"
    },
    ["chc"] = {
        ["misc"] = {
            {"Remove Repeat Cooldown (-1)", "H3_COMPLETEDPOSIX", 0, -1},
            {"Last Approach Completed (1 2 3)", "H3_LAST_APPROACH", 0, -1, 3},
            {"Confirm First Board", "H3OPT_BITSET1", 0, -1},
            {"Confirm Second Board", "H3OPT_BITSET0", 0, -1}
        },
        ["board1"] = {
            {"1:Silent, 2:BigCon, 3:Aggressive", "H3OPT_APPROACH", 0, 1, 3, 1},
            {"1:Hard, 2:Difficulty, 3:Approach", "H3_HARD_APPROACH", 0, 1, 3, 1},
            {"0:Money, 1:Gold, 2:Art, 3:Diamond", "H3OPT_TARGET", 0, 0, 3, 3},
            {"Unlock Points of Interests", "H3OPT_POI", 0, 1023},
            {"Unlock Access Points", "H3OPT_ACCESSPOINTS", 0, 2047}
        },
        ["board2"] = {
            {"1:5%, 2:9%, 3:7%, 4:10%, 5:10%", "H3OPT_CREWWEAP", 0, 1, 5, 1},
            {"1:5%, 2:7%, 3:9%, 4:6%, 5:10%", "H3OPT_CREWDRIVER", 0, 1, 5, 1},
            {"1:3%, 2:7%, 3:5%, 4:10%, 5:9%", "H3OPT_CREWHACKER", 0, 1, 5, 1},
            {"Weapon Variation (0 1)", "H3OPT_WEAPS", 0, 0, 1},
            {"Vehicle Variation (0 1 2 3)", "H3OPT_VEHS", 0, 0, 3},
            {"Remove Duggan Heavy Guards", "H3OPT_DISRUPTSHIP", 0, 3},
            {"Equip Heavy Armor", "H3OPT_BODYARMORLVL", 0, 3},
            {"Scan Card Level", "H3OPT_KEYLEVELS", 0, 2},
            {"Mask Variation (0 till 12)", "H3OPT_MASKS", 0, 0, 12}
        }
    },
    ["cph"] = {
        ["main"] = {
            {"Target 0-5", "H4CNF_TARGET", 5},
            {"Unlock PoI -1", "H4CNF_BS_GEN", -1},
            {"Unlock Entrances", "H4CNF_BS_ENTR", 63},
            {"Unlock Support Team", "H4CNF_BS_ABIL", 63},
            {"Weapon Variation", "H4CNF_WEAPONS", 5},
            {"Disruption 1 - Guards get weak", "H4CNF_WEP_DISRP", 3},
            {"Disruption 2 - Guards get weak", "H4CNF_ARM_DISRP", 3},
            {"Disruption 3 - Guards get weak", "H4CNF_HEL_DISRP", 3},
            {"Grappel Item", "H4CNF_GRAPPEL", -1},
            {"Uniform Item", "H4CNF_UNIFORM", -1},
            {"Boltcut Item", "H4CNF_BOLTCUT", -1},
            {"Set Preps as Completed", "H4CNF_APPROACH", -1},
            {"Set Mission as Completed", "H4_MISSIONS", -1},
            {"Cooldown NORMAL", "H4_COOLDOWN", -1},
            {"Cooldown HARD", "H4_COOLDOWN_HARD", -1}
        },
        ["loot"] = {
            {"Cash", "H4LOOT_CASH_V", 21000},
            {"Weed", "H4LOOT_WEED_V", 21000},
            {"Coke", "H4LOOT_COKE_V", 21000},
            {"Gold", "H4LOOT_GOLD_V", 21000},
            {"Paint", "H4LOOT_PAINT_V", 21000}
        },
        ["scope"] = {
            {"Cash Outside", "H4LOOT_CASH_I_SCOPED", -99},
            {"Cash Outside", "H4LOOT_CASH_C_SCOPED", -99},
            {"Cash Outside", "H4LOOT_WEED_I_SCOPED", -99},
            {"Cash Outside", "H4LOOT_WEED_C_SCOPED", -99},
            {"Cash Outside", "H4LOOT_COKE_I_SCOPED", -99},
            {"Cash Outside", "H4LOOT_COKE_C_SCOPED", -99},
            {"Cash Outside", "H4LOOT_GOLD_I_SCOPED", -99},
            {"Cash Outside", "H4LOOT_GOLD_C_SCOPED", -99},
            {"Cash Outside", "H4LOOT_PAINT_SCOPED", -99}
        }
    }
}
aY.set = function(aF, z, o, aZ)
    aZ = aZ or true
    local a_, b0 = aF
    if z then
        a_ = "MP0_" .. aF
        b0 = "MP1_" .. aF
        b0 = gameplay.get_hash_key(b0)
    end
    a_ = gameplay.get_hash_key(a_)
    local b1, O = stats.stat_get_int(a_, -1)
    if b1 ~= o then
        stats.stat_set_int(a_, o, aZ)
    end
    if z then
        local b2, O = stats.stat_get_int(b0, -1)
        if b2 ~= o then
            stats.stat_set_int(b0, o, aZ)
        end
    end
end
local b3 = {}
b3.scids = {}
b3.names = {}
b3.update_ids = function()
    local b4, b5 = {}, {}
    local b6
    if c.f_exists(b["Blacklist"]) then
        local a0 = c.o(b["Blacklist"], "r")
        if a0 then
            for b7 in io.lines(b["Blacklist"]) do
                b6 = 1
                for b8 in string.gmatch(b7, "[^%s]+") do
                    if b6 == 1 then
                        table.insert(b4, b8)
                    else
                        if type(b8) == "string" then
                            table.insert(b5, b8)
                        else
                            table.insert(b5, "NoNameFound")
                        end
                    end
                    b6 = b6 + 1
                end
            end
        end
        io.close(a0)
        b3.scids = b4
        b3.names = b5
    end
end
b3.remove_scid = function(aj)
    local a0 = c.o(b["Blacklist"], "w")
    io.close(a0)
    for i = 1, #b3.scids do
        local j = b3.names[i] or "NoNameFound"
        if c.no(b3.scids[i]) ~= c.no(aj) then
            d.write(c.o(b["Blacklist"], "a"), b3.scids[i] .. " " .. j)
        else
            u("Removed SCID: '" .. aj .. "' with Name: '" .. j .. "' from Blacklist.", 48)
        end
    end
    b3.update_ids()
end
b3.add = function(aj, j, b9)
    b9 = b9 or -1
    if b9 ~= c.id() and aj ~= -1 and aj ~= E.scid(c.id()) and j ~= "" then
        local ba = false
        for i = 1, #b3.scids do
            if c.no(b3.scids[i]) == c.no(aj) then
                ba = true
            end
        end
        if not ba then
            d.write(c.o(b["Blacklist"], "a"), aj .. " " .. j)
            u("Player " .. j .. " added to Blocklist.", 48)
            x("Player " .. j .. " with SCID: " .. aj .. " added to Blacklist.")
        else
            u("SCID already in the Database.")
        end
    else
        u("Choose valid Player / enter valid SCID and NAME.")
    end
end
local bb = {"random_primary", "random_secondary", "random_pearlescent", "random_neon", "random_smoke", "random_xenon"}
local bc = {
    "rainbow_primary",
    "rainbow_secondary",
    "rainbow_pearlescent",
    "rainbow_neon",
    "rainbow_smoke",
    "rainbow_xenon"
}
local bd = {"synced_rainbow", "synced_random", "synced_rainbow_smooth"}
local be = {
    {"Max Online Health: 328", 328},
    {"Health: 100", 100},
    {"Health: 500", 500},
    {"Freemode Beast: 2500", 2500},
    {"Health: 10000", 10000},
    {"Health: 25000", 25000},
    {"Health: 50000", 50000},
    {"Health: 100000", 100000},
    {"Health: 5000000", 5000000}
}
local bf, bg, bh = 0, false, 0
local bi = v3()
local bj, bk = nil, false
local bl = {}
local bm = {}
local bn, bo
local bp
local bq
local br = nil
local bs
local bt = {}
local bu = {}
local bv, bw, bx
local by
local bz
local bA, bB
local bC = {}
local bD = {}
local bE = {}
local bF = {}
local bG
local bH
local bI
local bJ = {12, 13, 14, 43, 74}
local bK
local bL
local bM = nil
local bN = {
    ["flamethrower"] = nil,
    ["flamethrower_green"] = nil,
    ["alien"] = nil,
    ["fire_circle"] = {},
    ["fire_balls"] = {},
    ["fire_ass"] = nil,
    ["fire_ass_ball"] = nil
}
local function bO(i, bP)
    a3.ctrl(i)
    entity.set_entity_velocity(i, v3())
    entity.set_entity_coords_no_offset(i, bP)
end
local function bQ(bR, time)
    if bR and type(bR) == "table" then
        time = time or 50
        for i = 1, #bR do
            if bR[i] ~= a5.ped() and bR[i] ~= c.vehicle(a5.ped()) then
                a3.ctrl(bR[i], time)
                entity.detach_entity(bR[i])
                entity.set_entity_velocity(bR[i], v3())
                bO(bR[i], v3(8000, 8000, -1000))
                entity.delete_entity(bR[i])
            end
        end
    end
end
local function bS(bT, bU)
    for i = 1, #bT do
        if entity.is_an_entity(bT[i]) and bT[i] ~= bU then
            local aG = c.gcoords(bT[i])
            c.explode(aG, 8, true, false, 0.5, 0)
            c.explode(aG, 59, false, true, 0, 0)
            c.wait(25)
        end
    end
end
event.add_event_listener(
    "exit",
    function()
        x("")
        x("2Take1Script got unloaded.")
        x("Cleaning up...")
        u("2Take1Script got unloaded.\nUnloading Script.. :(", 200)
        for i in pairs(bu) do
            bQ({bu[i]})
        end
        for i in pairs(aW) do
            bQ(aW[i])
        end
        bQ({bA})
        bQ({by})
        if bN["flamethrower"] then
            graphics.remove_particle_fx(bN["flamethrower"], true)
        end
        if bN["flamethrower_green"] then
            graphics.remove_particle_fx(bN["flamethrower_green"], true)
        end
        if bN["fire_circle"][1] then
            for i = 1, #bN["fire_circle"] do
                graphics.remove_particle_fx(bN["fire_circle"][i], true)
            end
            bQ(bN["fire_balls"])
        end
        if bN["fire_ass"] then
            graphics.remove_particle_fx(bN["fire_ass"], true)
        end
        bQ({bN["fire_ass_ball"]})
        for i = 1, 32 do
            if bE[i] then
                hook.remove_script_event_hook(bE[i])
            end
        end
        for i = 1, 32 do
            if bF[i] then
                hook.remove_net_event_hook(bF[i])
            end
        end
        x("Going to remove Chat-Listeners...")
        for i in pairs(bm) do
            event.remove_event_listener("chat", bm[i])
        end
        if ae.event then
            event.remove_event_listener("player_join", ae.event)
        end
        x("Done.")
        _2t1s = false
        _2t1sEXT = false
    end
)
local function bV(g, bW, a4)
    x("Teleporting to Target.")
    local bX, aG, ac, bY = a5.ped()
    if type(g) == "number" then
        bY = c.vehicle(g)
        if bY ~= 0 then
            if ped.is_ped_in_any_vehicle(bX) then
                ped.clear_ped_tasks_immediately(bX)
                c.wait(10)
            end
        end
    end
    ac = c.vehicle(bX)
    if ac ~= 0 then
        a3.ctrl(ac)
        entity.set_entity_velocity(ac, v3())
        bX = ac
    end
    if type(g) == "number" then
        aG = c.gcoords(g)
    else
        aG = g
    end
    if bW then
        aG.z = aG.z + bW
    end
    bO(bX, aG)
    if a4 then
        entity.set_entity_heading(bX, a4)
    end
    if bY then
        c.wait(1500)
        ped.set_ped_into_vehicle(a5.ped(), bY, vehicle.get_free_seat(bY))
    end
    x("Done.")
end
local function bZ(a4, water, b_, c0, c1)
    if
        not a6.t["bl_mdl_change"].on or c1 or
            a6.t["bl_mdl_change"].on and not ped.is_ped_in_any_vehicle(a5.ped()) and
                (water and entity.is_entity_in_water(a5.ped()) or not water and not entity.is_entity_in_water(a5.ped()))
     then
        if c0 then
            bV(a5.coords(), 1.5)
        end
        a3.model(a4)
        player.set_player_model(a4)
        c.unload(a4)
        if b_ then
            c.wait(0)
            ped.set_ped_component_variation(a5.ped(), 4, 0, 0, 2)
        end
        if a4 == 0x9C9EFFD8 or a4 == 0x705E61F2 then
            local E = "male"
            if player.is_player_female(c.id()) then
                E = "female"
            end
            if aX["bac_outfit"]["gender"] == E then
                local au = aX["bac_outfit"]["clothes"]
                local av = aX["bac_outfit"]["textures"]
                for _ = 1, 11 do
                    ped.set_ped_component_variation(a5.ped(), _, au[_], av[_], 2)
                end
                local aw = {0, 1, 2, 6, 7}
                local ax = aX["bac_outfit"]["prop_ind"]
                local ay = aX["bac_outfit"]["prop_text"]
                for az = 1, #aw do
                    ped.set_ped_prop_index(a5.ped(), aw[az], ax[az], ay[az], 0)
                end
            end
        end
    else
        u("Model Change not possible!", 125)
    end
end
local function c2(aD, b9)
    local i = 0
    if aD then
        x("Lobby Kick!")
    end
    while i < 32 do
        if aD then
            b9 = i
        else
            i = 99
        end
        if aa.i(b9) then
            u("Attempting to Kick Player: " .. E.name(b9), 65)
            x("Attempting to Kick Player.")
            x(E.name(b9) .. ":" .. E.scid(b9))
            if network.network_is_host() then
                x("Haha, got a hostkick.")
                network.network_session_kick_player(b9)
            end
            for i = 1, #B do
                c.script(B[i], b9, {})
            end
        end
        i = i + 1
    end
end
local function c3(bT, b9, c4)
    for i = 1, #bT do
        local c5 = v3(bT[i][3][1], bT[i][3][2], bT[i][3][3])
        local c6 = v3(bT[i][4][1], bT[i][4][2], bT[i][4][3])
        local c7
        local c8 = false
        if c4 then
            c7 = bT[i][1]
        else
            a3.model(bT[i][1])
            if streaming.is_model_an_object(bT[i][1]) then
                c7 = aE.object(bT[i][1], c5)
            else
                c8 = true
                c7 = aE.ped(bT[i][1], c5)
                c.wait(0)
                ped.set_ped_can_ragdoll(c7, false)
                c.god(c7, true)
            end
            c.unload(bT[i][1])
        end
        aW["attach_obj"][#aW["attach_obj"] + 1] = c7
        if a6.t["attach_no_colision"].on then
            entity.set_entity_collision(c7, false, false, false)
        end
        if bT[i][5] then
            c.visible(c7, false)
        end
        c.attach(c7, c.ped(b9), bT[i][2], c5, c6, true, true, c8, 0, true)
    end
end
local function c9(b9, a4)
    x("Lagging Area @Player.")
    local aG = c.gcoords(c.ped(b9))
    a3.model(a4)
    aG.z = aG.z + 5
    for i = 1, 50 do
        aW["lag_area"][#aW["lag_area"] + 1] = aE.vehicle(a4, aG)
    end
    c.unload(a4)
    x("Done.")
end
local function ca(b9)
    if aa.i(b9) then
        c.navigate(false)
        local cb = {}
        while a5.coords():magnitude(c.gcoords(c.ped(b9))) < 5000 do
            local aG = a5.coords()
            bV(v3(aG.x, aG.y, aG.z + 500))
        end
        x("Sending Crash Entitys...")
        x("Distance: " .. a5.coords():magnitude(c.gcoords(c.ped(b9))))
        for i = 1, #aU do
            local a4 = aU[i]
            a3.model(a4)
            local cc = c.gcoords(c.ped(b9)) + v3(0, 0, 2.5)
            cb[i] = aE.ped(a4, cc, 26)
            c.unload(a4)
        end
        x("Waiting.")
        u("Waiting ~ 7.5 seconds...")
        local time = c.time() + 7500
        while time > c.time() do
            x("Distance: " .. a5.coords():magnitude(c.gcoords(c.ped(b9))))
            c.wait(125)
            while a5.coords():magnitude(c.gcoords(c.ped(b9))) < 5000 do
                local aG = a5.coords()
                bV(v3(aG.x, aG.y, aG.z + 500))
            end
        end
        for i = 1, #cb do
            if not a3.ctrl(cb[i], 5000) then
                u("Dont go near the player, there is a possibility that the crash peds still exist!")
            end
            bQ({cb[i]}, 5000)
        end
        bQ(cb[i], 5000)
        c.navigate(true)
    end
end
local function cd(ac)
    local ce = {11, 12, 13, 16, 18}
    local cf = {3, 2, 2, 4, 1}
    for i = 1, #ce do
        if vehicle.get_vehicle_mod(ac, ce[i]) ~= cf[i] then
            a3.ctrl(ac)
            vehicle.set_vehicle_mod(ac, ce[i], cf[i])
        end
    end
    vehicle.set_vehicle_bulletproof_tires(ac, true)
end
local function cg(aG, aI, ch)
    aI = math.rad((aI - 180) * -1)
    aG.x = aG.x + math.sin(aI) * -ch
    aG.y = aG.y + math.cos(aI) * -ch
    return aG
end
local function ci(b9)
    b9 = string.lower(b9)
    local j
    for i = 0, 31 do
        if E.scid(i) ~= -1 then
            j = string.lower(E.name(i))
            if j == b9 then
                return i
            end
        end
    end
    return -1
end
local function cj(ck)
    for i = 1, #ck do
        if a6.t[ck[i]].on then
            a6.t[ck[i]].on = false
        end
    end
end
local function cl(ac, cm, i, b6)
    a3.ctrl(ac)
    c.wait(0)
    vehicle.set_vehicle_tire_smoke_color(ac, cm[1], cm[2], cm[3])
    vehicle.set_vehicle_custom_primary_colour(ac, d.rgbtohex({cm[1], cm[2], cm[3]}))
    vehicle.set_vehicle_custom_secondary_colour(ac, d.rgbtohex({cm[1], cm[2], cm[3]}))
    vehicle.set_vehicle_custom_pearlescent_colour(ac, d.rgbtohex({cm[1], cm[2], cm[3]}))
    vehicle.set_vehicle_neon_lights_color(ac, d.rgbtohex({cm[1], cm[2], cm[3]}))
    if not i then
        i = 0
    end
    if cm[1] > 200 and cm[1] < 256 and cm[2] > 200 and cm[2] < 256 and cm[3] > 220 and cm[3] < 256 then
        i = 0
    end
    if cm[1] >= 0 and cm[1] < 30 and cm[2] >= 0 and cm[2] < 50 and cm[3] > 220 and cm[3] < 256 then
        i = 1
    end
    if cm[1] >= 0 and cm[1] < 30 and cm[2] >= 50 and cm[2] < 110 and cm[3] > 220 and cm[3] < 256 then
        i = 2
    end
    if cm[1] >= 0 and cm[1] < 30 and cm[2] >= 110 and cm[2] < 256 and cm[3] > 100 and cm[3] <= 220 then
        i = 3
    end
    if cm[1] >= 30 and cm[1] < 120 and cm[2] >= 110 and cm[2] < 256 and cm[3] >= 0 and cm[3] <= 100 then
        i = 4
    end
    if cm[1] >= 120 and cm[1] < 256 and cm[2] >= 110 and cm[2] < 256 and cm[3] >= 0 and cm[3] < 100 then
        i = 5
    end
    if cm[1] >= 120 and cm[1] < 256 and cm[2] >= 110 and cm[2] < 200 and cm[3] >= 0 and cm[3] < 100 then
        i = 6
    end
    if cm[1] >= 120 and cm[1] < 256 and cm[2] > 45 and cm[2] < 109 and cm[3] >= 0 and cm[3] < 100 then
        i = 7
    end
    if cm[1] >= 120 and cm[1] < 256 and cm[2] >= 0 and cm[2] <= 45 and cm[3] >= 0 and cm[3] < 100 then
        i = 8
    end
    if cm[1] >= 120 and cm[1] < 256 and cm[2] > 45 and cm[2] < 100 and cm[3] >= 50 and cm[3] < 150 then
        i = 9
    end
    if cm[1] >= 120 and cm[1] < 256 and cm[2] >= 0 and cm[2] <= 45 and cm[3] >= 150 and cm[3] < 256 then
        i = 10
    end
    if cm[1] >= 0 and cm[1] < 120 and cm[2] >= 0 and cm[2] <= 45 and cm[3] >= 150 and cm[3] < 256 then
        i = 11
    end
    if cm[1] >= 0 and cm[1] < 30 and cm[2] >= 0 and cm[2] <= 45 and cm[3] >= 150 and cm[3] < 256 then
        i = 12
    end
    if b6 then
        i = b6
    end
    vehicle.set_vehicle_headlight_color(ac, i)
end
local function cn(b9, U, co)
    x("Detected Chat-Command!")
    x(E.name(b9) .. ":" .. E.scid(b9))
    x("Is trying to perform " .. co .. " as a Chat-Command!")
    if a6.t["chat_cmd_friends"] and player.is_player_friend(b9) or b9 == c.id() or a6.t["chat_cmd_all"] then
        local cp
        if U then
            cp = ci(U)
        else
            x("User is entitled to perfrom Command! Executing...")
            u("Performing " .. co .. " Command for Player: " .. E.name(b9) .. " on: " .. E.name(b9))
            return true, plid
        end
        if cp ~= -1 then
            if cp == c.id() or player.is_player_friend(cp) and a6.t["exclude_friends"].on and cp ~= c.id() then
                u(E.name(b9) .. " tried to perform a Command on you or a friend!")
                x("Blocked from Performing Command!")
                return false
            else
                x("User is entitled to perfrom Command! Executing...")
                u("Performing " .. co .. " Command for Player: " .. E.name(b9) .. " on: " .. E.name(cp))
                return true, cp
            end
        end
    end
    x("Command / format / player not found / entitled. Breaking up on performing it.")
    return false
end
local function cq(bT)
    x("Blocking Area.")
    for i = 1, #bT do
        if bT[i][1] ~= false then
            a3.model(bT[i][1])
            aW["bl_objects"][#aW["bl_objects"] + 1] = aE.object(bT[i][1])
            c.unload(bT[i][1])
            local aG
            if not bT[i][2][1] then
                aG =
                    v3(
                    c.random(bT[i][2][2], bT[i][2][3]),
                    c.random(bT[i][2][4], bT[i][2][5]),
                    c.random(bT[i][2][6], bT[i][2][7])
                )
            else
                aG = v3(bT[i][2][1], bT[i][2][2], bT[i][2][3])
            end
            bO(aW["bl_objects"][#aW["bl_objects"]], aG)
            entity.set_entity_rotation(aW["bl_objects"][#aW["bl_objects"]], v3(bT[i][3][1], bT[i][3][2], bT[i][3][3]))
            if bT[i][4] then
                entity.freeze_entity(aW["bl_objects"][#aW["bl_objects"]], true)
            end
            if bT[i][5] then
                c.visible(aW["bl_objects"][#aW["bl_objects"]], false)
            end
        else
            if bT[i] then
                if a6.t["teleport_to_block"].on then
                    bV(v3(bT[i][2][1], bT[i][2][2], bT[i][2][3]), nil, bT[i][3])
                end
            end
        end
    end
    x("Blocking Done.")
end
local function cr(aD, cs, ct, cu, cv, b9)
    x("Sending Script Events to Player.")
    local i = 0
    while i < 32 do
        if aD then
            b9 = i
        else
            i = 99
        end
        if aa.i(b9) then
            if cs ~= 0 and cs then
                c.script(cs, b9, ct)
                x("SE 1 : " .. cs)
                x("Sent to Player: " .. E.name(b9))
            end
            if cu ~= 0 and cu then
                c.script(cu, b9, cv)
                x("SE 2 : " .. cu)
                x("Sent to Player: " .. E.name(b9))
            end
        end
        i = i + 1
    end
    x("Done.")
end
local function cw()
    if bk then
        bZ(bj, nil, nil, nil, true)
        c.wait(250)
        ped.set_ped_health(a5.ped(), 0)
        c.wait(3500)
        local cx = aX["session_crash"]["clothes"]
        local cy = aX["session_crash"]["textures"]
        for i = 1, 11 do
            ped.set_ped_component_variation(a5.ped(), i, cx[i], cy[i], 2)
        end
        local aw = {0, 1, 2, 6, 7}
        local ax = aX["session_crash"]["prop_ind"]
        local ay = aX["session_crash"]["prop_text"]
        for az = 1, #aw do
            ped.set_ped_prop_index(a5.ped(), aw[az], ax[az], ay[az], 0)
        end
    else
        u("First Crash Session.")
    end
end
local function cz()
    local cA = bu["llbone"]
    local cB = bu["rlbone"]
    local cC = bu["tampa"]
    local cD = v3(-4.25, 0, 12.5)
    local cE = v3(4.25, 0, 12.5)
    if cA and cB and cC then
        if entity.is_an_entity(cA) and entity.is_an_entity(cB) and entity.is_an_entity(cC) then
            a3.ctrl(cA)
            a3.ctrl(cB)
            a3.ctrl(cC)
            c.attach(cA, cC, 0, cD, v3(), true, r["robot_collision"], false, 2, true)
            c.attach(cB, cC, 0, cE, v3(), true, r["robot_collision"], false, 2, true)
        end
    end
end
local function cF(bT, a7)
    x("Attempt to spawn Custom Vehicle.")
    c.navigate(false)
    temp_veh = {}
    local aG = v3()
    local cG = v3()
    local cH = 0
    local cI = 0
    local aI = 0
    local cJ = false
    local cK = c.vehicle(a5.ped())
    if a6.t["spawn_preview"].on and aW["preview_veh"][1] then
        bQ(aW["preview_veh"])
        aW["preview_veh"] = {}
        bg = false
        c.wait(250)
    end
    for i = 1, #bT[1] do
        a3.model(bT[1][i], 7500)
    end
    for i = 2, #bT do
        aG = a5.coords()
        if bT[i][6] and i == 2 then
            aG.z = aG.z + bT[i][6]
        end
        if i > 2 then
            aG.z = aG.z + 25
        end
        if
            a6.t["use_own_veh"].on and i == 2 and entity.get_entity_model_hash(cK) == bT[i][1] or
                bT[2][1] == 0 and i == 2 and a6.t["use_own_veh"].on and cK ~= 0
         then
            x("Detected Own Vehicle, using it.")
            temp_veh[i - 1] = cK
            cJ = true
        elseif bT[2][1] == 0 and not a6.t["use_own_veh"].on then
            x("Failed at spawning Custom Vehicle.")
            u("No Vehicle found, get in a valid Vehicle")
            c.navigate(true)
            return
        else
            if streaming.is_model_a_vehicle(bT[i][1]) then
                if i == 2 then
                    aI = a5.heading()
                    if bT[i][11] then
                        bh = bT[i][11]
                    else
                        bh = 5
                    end
                    if bT[i][12] then
                        bf = bT[i][12]
                    else
                        bf = 1
                    end
                    aG = cg(aG, aI, bh)
                end
                temp_veh[i - 1] = aE.vehicle(bT[i][1], aG, aI)
                decorator.decor_set_int(temp_veh[i - 1], "MPBitset", 1 << 10)
                local v = c.random(0, 16777215)
                if bT[i][4] then
                    v = bT[i][4][1]
                end
                vehicle.set_vehicle_custom_primary_colour(temp_veh[i - 1], v)
                if bT[i][4] then
                    v = bT[i][4][2]
                end
                vehicle.set_vehicle_custom_secondary_colour(temp_veh[i - 1], v)
                if bT[i][4] then
                    v = bT[i][4][3]
                end
                vehicle.set_vehicle_custom_pearlescent_colour(temp_veh[i - 1], v)
                if bT[i][4] then
                    v = bT[i][4][4]
                end
                vehicle.set_vehicle_custom_wheel_colour(temp_veh[i - 1], v)
                v = c.random(0, 4)
                if bT[i][4] then
                    v = bT[i][4][5]
                end
                vehicle.set_vehicle_window_tint(temp_veh[i - 1], v)
                if streaming.is_model_a_plane(bT[i][1]) and i > 2 then
                    vehicle.control_landing_gear(temp_veh[i - 1], 3)
                end
            else
                temp_veh[i - 1] = aE.object(bT[i][1], aG)
            end
        end
        if i > 2 then
            aG.z = aG.z - 25
        end
        if a6.t["set_godmode"].on then
            c.god(temp_veh[i - 1], true)
        end
        if bT[i][5] then
            c.visible(temp_veh[i - 1], false)
        end
        if bT[i][13] then
            entity.set_entity_alpha(temp_veh[i - 1], bT[i][13], false)
        end
        if i > 2 then
            cH = 0
            if bT[i][7] then
                cH = bT[i][7]
            end
            cI = temp_veh[1]
            if bT[i][8] then
                cI = temp_veh[bT[i][8]]
            end
            local cL = bT[i][10]
            if cL == true then
                entity.set_entity_collision(temp_veh[i - 1], false, false, false)
            else
                cL = false
            end
            aG = v3()
            if bT[i][2] then
                aG = v3(bT[i][2][1], bT[i][2][2], bT[i][2][3])
            end
            cG = v3()
            if bT[i][3] then
                cG = v3(bT[i][3][1], bT[i][3][2], bT[i][3][3])
            end
            if bT[i][1] ~= 0 then
                c.attach(temp_veh[i - 1], cI, cH, aG, cG, false, not cL, false, 2, true)
            end
            if bT[i][9] then
                local cM
                a3.model(bT[i][9])
                aG = a5.coords()
                cM = aE.ped(bT[i][9], aG)
                c.wait(0)
                if a6.t["set_godmode"].on then
                    ped.set_ped_max_health(cM, 25000000.0)
                    ped.set_ped_health(cM, 25000000.0)
                    ped.set_ped_can_ragdoll(cM, false)
                    c.god(cM, true)
                end
                c.unload(bT[i][9])
                if bT[i][1] ~= 0 then
                    ped.set_ped_into_vehicle(cM, temp_veh[i - 1], -1)
                    vehicle.set_vehicle_doors_locked(temp_veh[i - 1], 2)
                else
                    aG = v3()
                    if bT[i][2] then
                        aG = v3(bT[i][2][1], bT[i][2][2], bT[i][2][3])
                    end
                    cG = v3()
                    if bT[i][3] then
                        cG = v3(bT[i][3][1], bT[i][3][2], bT[i][3][3])
                    end
                    c.attach(cM, cI, cH, aG, cG, false, not cL, true, 2, true)
                end
            end
        end
        if a6.t["spawn_preview"].on then
            aW["preview_veh"][#aW["preview_veh"] + 1] = temp_veh[i - 1]
        elseif a7 then
            aW[a7][#aW[a7] + 1] = temp_veh[i - 1]
        else
            aW["custom_veh"][#aW["custom_veh"] + 1] = temp_veh[i - 1]
        end
    end
    if not a6.t["spawn_preview"].on then
        if a6.t["auto_get_in"].on then
            ped.set_ped_into_vehicle(a5.ped(), temp_veh[1], -1)
        end
    end
    if not cJ then
        cd(temp_veh[1])
    end
    for i = 1, #bT[1] do
        c.unload(bT[1][i])
    end
    c.navigate(true)
    x("Spawn Custom Vehicle Done.")
end
local function cN()
    x("Loading Features...")
    if r["2t1s_parent"] then
        a6.p["parent"] = a6.add.p("2Take1Script", 0).id
    end
    a6.p["bl"] = a6.add.p("Blacklist", a6.p["parent"])
    a6.p["bl"].hidden = r["bl_hidden"]
    a6.p["bl"] = a6.p["bl"].id
    a6.t["blacklist_enabled"] =
        a6.add.t(
        "Enable Blacklist",
        a6.p["bl"],
        function(k)
            r["blacklist_enabled"] = k.on
            if k.on then
                c.wait(1000)
                b3.update_ids()
                for i = 0, 31 do
                    if aa.i(i) then
                        for cO = 1, #b3.scids do
                            if tostring(E.scid(i)) == b3.scids[cO] then
                                local j = E.name(i)
                                u("Blocked player detected.", 27)
                                u("Current name: " .. j .. "\nReal name: " .. b3.names[cO], 27)
                                x("")
                                x("Blocked Player detected.")
                                x(j .. ":" .. b3.scids[cO])
                                x("Real name:" .. b3.names[cO])
                                if a6.t["mark_modder"].on then
                                    player.set_player_as_modder(i, t["blacklist"][2])
                                end
                                if a6.t["auto_kick"].on then
                                    c2(false, i)
                                    c.wait(1000)
                                end
                            end
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    a6.t["blacklist_enabled"].on = r["blacklist_enabled"]
    a6.t["auto_kick"] =
        a6.add.t(
        "Enable Auto-Kick",
        a6.p["bl"],
        function(k)
            r["auto_kick"] = k.on
        end
    )
    a6.t["auto_kick"].on = r["auto_kick"]
    a6.t["mark_modder"] =
        a6.add.t(
        "Mark as Modder",
        a6.p["bl"],
        function(k)
            r["mark_modder"] = k.on
        end
    )
    a6.t["mark_modder"].on = r["mark_modder"]
    a6.add.a(
        "Add player by SCID",
        a6.p["bl"],
        function()
            local aj = E.input("Enter SCID", 12, 3)
            local j = E.input("Enter Name")
            if not aj or not j then
                return HANDLER_POP
            end
            b3.add(aj, j)
        end
    )
    a6.add.a(
        "Remove SCID",
        a6.p["bl"],
        function()
            local aj = E.input("Enter SCID", 12, 3)
            if not aj then
                return HANDLER_POP
            end
            b3.remove_scid(aj)
        end
    )
    a6.add.a(
        "Count Currently Blocked Players",
        a6.p["bl"],
        function()
            b3.update_ids()
            if b3.scids then
                u("Currently blocking " .. #b3.scids .. " Players.", 48)
            end
        end
    )
    a6.t["enable_admin"] =
        a6.add.t(
        "Notify on Rockstar Admin SCID",
        a6.p["bl"],
        function(k)
            if k.on then
                c.wait(1000)
                for i = 0, 31 do
                    if aa.i(i) then
                        for cO = 1, #aV do
                            if tostring(E.scid(i)) == aV[cO] then
                                local j = E.name(i)
                                u("Rockstar Admin by SCID detected!\nName: " .. j, 27)
                                x("Rockstar Admin detected.")
                                x(j .. ":" .. E.scid(i))
                                if a6.t["kick_admin"].on then
                                    c2(false, i)
                                end
                                if a6.t["crash_admin"].on then
                                    ca(i)
                                end
                            end
                        end
                    end
                end
            end
            r["admin_enabled"] = k.on
            return d.stop(k)
        end
    )
    a6.t["enable_admin"].on = r["admin_enabled"]
    a6.t["kick_admin"] =
        a6.add.t(
        "Enable Auto-Kick Rockstar Admin",
        a6.p["bl"],
        function()
            u(
                "Thats the stupidest idea you ever had! Dont enable it, disable it!\nThis will get u banned for like 99%!",
                27
            )
        end
    )
    a6.t["kick_admin"].hidden = not C.enable_admin
    a6.t["crash_admin"] =
        a6.add.t(
        "Enable Auto-Crash Rockstar Admin",
        a6.p["bl"],
        function()
            u(
                "Thats the stupidest idea you ever had! Dont enable it, disable it!\nThis will get u banned for like 99%!",
                27
            )
        end
    )
    a6.t["crash_admin"].hidden = not C.enable_admin
    a6.t["kick_joining"] =
        a6.add.t(
        "Kick new joining Players",
        a6.p["bl"],
        function(k)
            if k.on then
                local time = c.time() + 2500
                while time > c.time() do
                    c.wait(250)
                    r["kick_joining"] = k.on
                end
                if bC[1] == nil then
                    for i = 0, 31 do
                        bC[i + 1] = E.scid(i)
                        bD[E.scid(i)] = 0
                    end
                end
                for i = 0, 31 do
                    if aa.i(i) then
                        local Q = true
                        for _ = 1, #bC do
                            if bC[_] == E.scid(i) then
                                Q = false
                            end
                        end
                        if Q then
                            if bD[bC[i + 1]] <= 3 then
                                u(E.name(i) .. " is new here, sending greetings..!", 65)
                                x(E.name(i) .. " is new here, sending greetings..!")
                                c2(false, i)
                                bD[bC[i + 1]] = bD[bC[i + 1]] + 1
                            else
                                bD[bC[i + 1]] = bD[bC[i + 1]] + 1
                                if bD[bC[i + 1]] >= 17 then
                                    bD[bC[i + 1]] = 0
                                end
                            end
                        end
                    end
                end
            end
            if not k.on then
                bD = {}
                for i = 0, 31 do
                    bC[i + 1] = nil
                end
            end
            r["kick_joining"] = k.on
            return d.stop(k)
        end
    )
    a6.t["kick_joining"].on = r["kick_joining"]
    a6.p["modder"] = a6.add.p("Modders", a6.p["parent"])
    a6.p["modder"].hidden = r["modder_hidden"]
    a6.p["modder"] = a6.p["modder"].id
    a6.t["remember_modder"] =
        a6.add.t(
        "Remember every Modder",
        a6.p["modder"],
        function(k)
            if k.on then
                if c.f_exists(b["Modders"]) then
                    local a0 = c.o(b["Modders"], "r")
                    if a0 then
                        local c7 = {}
                        bl = {}
                        for cP in io.lines(b["Modders"]) do
                            while string.find(cP, " ", 1) do
                                cP = cP:gsub("(.*)%s.*$", "%1")
                            end
                            c7[#c7 + 1] = cP
                        end
                        bl = c7
                        io.close(a0)
                    end
                end
                for i = 0, 31 do
                    if aa.i(i) then
                        local aj = E.scid(i)
                        local cQ = false
                        if bl[1] then
                            for cR = 1, #bl do
                                if tostring(aj) == bl[cR] then
                                    cQ = true
                                    if not player.is_player_modder(i, -1) then
                                        u("Remembered " .. E.name(i) .. " as a Modder, remarking...", 130)
                                        x("Remembered '" .. E.name(i) .. "' as a Modder, remarking...")
                                        player.set_player_as_modder(i, t["remembered"][2])
                                    end
                                end
                            end
                        end
                        if player.is_player_modder(i, -1) and not cQ then
                            d.write(c.o(b["Modders"], "a"), aj .. " " .. E.name(i))
                            u("Modder " .. E.name(i) .. " added to Remember-List.", 130)
                            x("Modder '" .. E.name(i) .. "' added to Remember-List.")
                        end
                    end
                end
            end
            r["remember_modder"] = k.on
            return d.stop(k)
        end
    )
    a6.t["remember_modder"].on = r["remember_modder"]
    a6.p["karma_modder_scripts"] =
        a6.add.t(
        "Karma Scripts from Modders",
        a6.p["modder"],
        function(k)
            if k.on and bG == nil then
                bG =
                    hook.register_script_event_hook(
                    function(T, U, V, W)
                        if player.is_player_modder(T, -1) then
                            local Y = V[1]
                            table.remove(V, 1)
                            c.script(Y, T, V)
                            x("Karma'd Script Event from: " .. E.name(T) .. ".")
                        end
                    end
                )
            end
            if not k.on and bG then
                hook.remove_script_event_hook(bG)
                bG = nil
            end
            r["karma_modder_scripts"] = k.on
        end
    )
    a6.p["karma_modder_scripts"].on = r["karma_modder_scripts"]
    a6.p["unmark_friends"] =
        a6.add.t(
        "Unmark Friends",
        a6.p["modder"],
        function(k)
            r["unmark_friends"] = k.on
            if k.on then
                for i = 0, 31 do
                    if c.valid(i) and player.is_player_friend(i) and player.is_player_modder(i, -1) then
                        player.unset_player_as_modder(i, -1)
                    end
                end
                c.wait(250)
            end
            return d.stop(k)
        end
    )
    a6.p["unmark_friends"].on = r["unmark_friends"]
    a6.add.a(
        "Mark all as Modders",
        a6.p["modder"],
        function()
            for i = 0, 31 do
                if aa.i(i) then
                    player.set_player_as_modder(i, 1)
                end
            end
        end
    )
    a6.add.a(
        "UN-Mark all as Modders",
        a6.p["modder"],
        function()
            for i = 0, 31 do
                if aa.i(i, true) then
                    player.unset_player_as_modder(i, -1)
                end
            end
        end
    )
    a6.add.a("Modder-Detection:", a6.p["modder"])
    a6.t["speed_bypass"] =
        a6.add.t(
        "Max-Speed-Bypass",
        a6.p["modder"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    local aj = E.scid(i)
                    if
                        aa.modder(i) and player.get_player_health(i) ~= 0 and
                            interior.get_interior_from_entity(c.ped(i)) == 0
                     then
                        local cS = 45
                        local b9 = c.ped(i)
                        if
                            ai.is_task_active(b9, 403) or ai.is_task_active(b9, 408) or ai.is_task_active(b9, 335) or
                                ai.is_task_active(b9, 2) or
                                ai.is_task_active(b9, 422)
                         then
                            cS = 95
                        end
                        if ai.is_task_active(b9, 97) or ai.is_task_active(b9, 38) or ai.is_task_active(b9, 160) then
                            cS = 60
                        end
                        if ai.is_task_active(b9, 50) or ai.is_task_active(b9, 1) then
                            cS = 100
                        end
                        local ac = c.vehicle(b9)
                        if ac ~= 0 then
                            if b9 == vehicle.get_ped_in_vehicle_seat(ac, -1) then
                                b9 = ac
                                local aF = entity.get_entity_model_hash(ac)
                                if streaming.is_model_a_plane(aF) then
                                    cS = 170
                                else
                                    cS = 100
                                end
                            end
                        end
                        local cT = entity.get_entity_speed(b9)
                        cT = math.floor(cT)
                        if cT > cS then
                            u(
                                E.name(i) ..
                                    " bypassed Max-Speed-Limit of: " ..
                                        cS .. " with a speed of: " .. cT .. "\nMarking him as a Modder...",
                                130
                            )
                            x(E.name(i) .. " bypassed Max-Speed-Limit of: " .. cS .. " with a speed of: " .. cT)
                            x("Marking him as a Modder...")
                            for cR = 0, 600 do
                                if ai.is_task_active(c.ped(i), cR) then
                                    x("Current active Task: " .. cR)
                                end
                            end
                            player.set_player_as_modder(i, t["maxspeed"][2])
                        end
                    end
                end
            end
            r["speed_bypass"] = k.on
            return d.stop(k)
        end
    )
    a6.t["speed_bypass"].on = r["speed_bypass"]
    a6.t["name_bypass"] =
        a6.add.t(
        "Illegal Name",
        a6.p["modder"],
        function(k)
            c.wait(500)
            if k.on then
                for i = 0, 31 do
                    local aj = E.scid(i)
                    if aa.modder(i) then
                        local j = E.name(i)
                        if string.len(j) < 6 or string.len(j) > 16 or not string.find(j, "^[%.%-%w_]+$") then
                            u(j .. " has an illegal name!\nMarking him as a Modder...", 130)
                            x(j .. " has an illegal name!")
                            x("Marking him as a Modder...")
                            player.set_player_as_modder(i, t["illegalname"][2])
                        end
                    end
                end
            end
            r["name_bypass"] = k.on
            return d.stop(k)
        end
    )
    a6.t["name_bypass"].on = r["name_bypass"]
    a6.t["modded_scid"] =
        a6.add.t(
        "Modded SCID",
        a6.p["modder"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    system.wait(25)
                    if aa.modder(i) then
                        local aj = E.scid(i)
                        if aj < 10000 or aj > 222222222 then
                            local j = E.name(i)
                            u(j .. " has an modded SCID!\nMarking him as a Modder...", 130)
                            x(j .. " has an modded SCID!")
                            x("Marking him as a Modder...")
                            player.set_player_as_modder(i, t["moddedscid"][2])
                        end
                    end
                end
            end
            r["modded_scid"] = k.on
            return d.stop(k)
        end
    )
    a6.t["modded_scid"].on = r["modded_scid"]
    a6.t["modded_net_events"] =
        a6.add.t(
        "Modded Net-Events",
        a6.p["modder"],
        function()
            if bI == nil then
                bI =
                    hook.register_net_event_hook(
                    function(T, U, cU)
                        if aa.modder(T) and U == c.id() then
                            local cV = false
                            for i = 1, #bJ do
                                if cU == bJ[i] then
                                    cV = true
                                end
                            end
                            if cU == 9 and not player.is_player_host(T) then
                                cV = true
                            end
                            if cU == 10 and bK == nil then
                                bK = T
                                bL = c.time()
                                cV = true
                            end
                            if bL then
                                if bL + 30000 < c.time() then
                                    bL = nil
                                    bK = nil
                                end
                            end
                            if cV then
                                u(E.name(T) .. " sent a Bad Net-Event: " .. cU, 130)
                                u("Marking him as a Modder!", 130)
                                x(E.name(T) .. " sent a Bad Net-Event: " .. cU)
                                player.set_player_as_modder(T, t["moddednetevent"][2])
                                return true
                            end
                        end
                    end
                )
            else
                hook.remove_net_event_hook(bI)
                bI = nil
            end
            r["modded_net_events"] = a6.t["modded_net_events"].on
        end
    )
    a6.t["modded_net_events"].on = r["modded_net_events"]
    a6.t["modder_force_sh"] =
        a6.add.t(
        "Forcing Script-Host",
        a6.p["modder"],
        function(k)
            r["modder_force_sh"] = k.on
            if k.on then
                if bp == nil then
                    bp = script.get_host_of_this_script()
                end
                local time = c.time() + 17500
                while time > c.time() do
                    c.wait(250)
                    r["modder_force_sh"] = k.on
                end
                local cW = script.get_host_of_this_script()
                if not c.valid(bp) or E.scid(bp) == -1 then
                    bp = nil
                end
                if bp then
                    if bp ~= cW then
                        if c.valid(bp) and c.valid(cW) then
                            if E.scid(bp) ~= -1 and E.scid(cW) ~= -1 then
                                x("Script-Host changed without previous SH leaving!")
                                x("SH changed from '" .. E.name(bp) .. "' to '" .. E.name(cW) .. "'.")
                                u("Script-Host changed from '" .. E.name(bp) .. "' to '" .. E.name(cW) .. "'.", 130)
                                player.set_player_as_modder(cW, t["force_sh"][2])
                                bp = cW
                            end
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    a6.t["modder_force_sh"].on = r["modder_force_sh"]
    a6.t["modded_script_event"] =
        a6.add.t(
        "Modded Script Event",
        a6.p["modder"],
        function(k)
            r["modded_script_event"] = k.on
            if bH == nil then
                bH =
                    hook.register_script_event_hook(
                    function(T, U, V, W)
                        local cV = false
                        if #V > 1 then
                            if T ~= V[2] then
                                cV = true
                            end
                        else
                            cV = true
                        end
                        if cV then
                            u("Detected '" .. E.name(T) .. "' sending a modded Script Event!", 130)
                            x("Detected '" .. E.name(T) .. "' sending a modded Script Event!")
                            local cX = V[1] .. ", {"
                            for i = 2, #V do
                                cX = cX .. V[i]
                                if i ~= #V then
                                    cX = cX .. ", "
                                end
                            end
                            cX = cX .. "}"
                            x(cX)
                            player.set_player_as_modder(T, t["script"][2])
                        end
                    end
                )
            else
                hook.remove_script_event_hook(bH)
                bH = nil
            end
        end
    )
    a6.t["modded_script_event"].on = r["modded_script_event"]
    a6.p["lobby"] = a6.add.p("Lobby", a6.p["parent"])
    a6.p["lobby"].hidden = r["lobby_hidden"]
    a6.p["lobby"] = a6.p["lobby"].id
    a6.p["bl_veh"] = a6.add.p("Block Vehicles in Session", a6.p["lobby"]).id
    a6.t["veh_blacklist"] =
        a6.add.t(
        "Activate Block Vehicles",
        a6.p["bl_veh"],
        function(k)
            r["veh_blacklist"] = k.on
            if k.on then
                local time = c.time() + 2000
                while time > c.time() do
                    c.wait(200)
                    r["veh_blacklist"] = k.on
                end
                for i = 0, 31 do
                    if aa.i(i) then
                        local ac = c.vehicle(c.ped(i))
                        if ac ~= 0 then
                            ac = entity.get_entity_model_hash(ac)
                            for b6 = 1, #aR do
                                if a6.t[aR[b6][1]].on and ac == aR[b6][2] then
                                    x("Detected Blacklisted Vehicle " .. aR[b6][1] .. " in Session!")
                                    ac = c.vehicle(c.ped(i))
                                    a3.ctrl(ac, 100)
                                    if entity.get_entity_god_mode(ac) then
                                        a3.ctrl(ac)
                                        c.god(ac, false)
                                    end
                                    if not entity.get_entity_god_mode(ac) then
                                        x("Exploding User: " .. E.name(i))
                                        u(
                                            "Detected Blacklisted Vehicle " ..
                                                aR[b6][1] .. " from user: " .. E.name(i) .. ", exploding it!",
                                            28
                                        )
                                        entity.set_entity_velocity(ac, v3())
                                        vehicle.set_vehicle_forward_speed(ac, 0)
                                        vehicle.set_vehicle_out_of_control(ac, false, true)
                                        c.explode(c.gcoords(c.ped(i)), 59, false, true, 1, c.ped(i))
                                    end
                                end
                            end
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    a6.t["veh_blacklist"].on = r["veh_blacklist"]
    for i = 1, #aR do
        a6.t[aR[i][1]] =
            a6.add.t(
            "Block: " .. aR[i][1],
            a6.p["bl_veh"],
            function(k)
                r[aR[i][1]] = k.on
            end
        )
        a6.t[aR[i][1]].on = r[aR[i][1]]
    end
    a6.p["bl_area"] = a6.add.p("Block Areas", a6.p["lobby"]).id
    a6.t["teleport_to_block"] =
        a6.add.t(
        "Teleport to Block",
        a6.p["bl_area"],
        function(k)
            r["teleport_to_block"] = k.on
        end
    )
    a6.t["teleport_to_block"].on = r["teleport_to_block"]
    a6.add.a(
        "Clear blocking Objects",
        a6.p["bl_area"],
        function()
            bQ(aW["bl_objects"])
            aW["bl_objects"] = {}
        end
    )
    a6.p["bl_area_lsc"] = a6.add.p("Block LSCs", a6.p["bl_area"]).id
    for i = 1, #aT["lscs"] do
        a6.add.a(
            aT["lscs"][i][1],
            a6.p["bl_area_lsc"],
            function()
                cq(aT["lscs"][i][2])
            end
        )
    end
    a6.p["bl_area_casino"] = a6.add.p("Block Casino", a6.p["bl_area"]).id
    for i = 1, #aT["casino"] do
        a6.add.a(
            aT["casino"][i][1],
            a6.p["bl_area_casino"],
            function()
                cq(aT["casino"][i][2])
            end
        )
    end
    a6.p["bl_area_mazebank"] = a6.add.p("Block Maze Bank", a6.p["bl_area"]).id
    for i = 1, #aT["mazebank"] do
        a6.add.a(
            aT["mazebank"][i][1],
            a6.p["bl_area_mazebank"],
            function()
                cq(aT["mazebank"][i][2])
            end
        )
    end
    a6.p["bl_area_custom"] = a6.add.p("Custom Areas", a6.p["bl_area"]).id
    for i = 1, #aT["custom"] do
        a6.add.a(
            aT["custom"][i][1],
            a6.p["bl_area_custom"],
            function()
                cq(aT["custom"][i][2])
            end
        )
    end
    a6.p["explode"] = a6.add.p("Explosion-Features", a6.p["lobby"]).id
    a6.t["laser_beam_explode_waypoint"] =
        a6.add.a(
        "Laser Beam Explode Waypoint",
        a6.p["explode"],
        function()
            local cY = ui.get_waypoint_coord()
            if cY.x ~= 16000 then
                local cZ = c.gcoords(a5.ped()).z + 175
                for i = cZ, -50, -2 do
                    local aG = v3(cY.x, cY.y, i)
                    aG.x = math.floor(aG.x)
                    aG.y = math.floor(aG.y)
                    c.explode(aG, 59, true, false, 0, 0)
                    for b6 = 1, 2 do
                        aG.x = c.random(aG.x - 3, aG.x + 3)
                        aG.y = c.random(aG.y - 3, aG.y + 3)
                        c.explode(aG, 59, true, false, 0, 0)
                    end
                    aG.x = c.random(aG.x - 6, aG.x + 6)
                    aG.y = c.random(aG.y - 6, aG.y + 6)
                    c.explode(aG, 8, true, false, 0, 0)
                    c.wait(0)
                end
            else
                u("No Waypoint found, set a waypoint first!")
            end
        end
    )
    a6.t["explode_lobby"] =
        a6.add.u(
        "Random Explosions",
        "value_i",
        a6.p["explode"],
        function(k)
            if k.on then
                for i = 1, 5 do
                    c.explode(
                        v3(c.random(-2700, 2700), c.random(-3300, 7500), c.random(30, 90)),
                        k.value_i,
                        true,
                        false,
                        0,
                        0
                    )
                end
            end
            r["explode_lobby_value"] = k.value_i
            r["explode_lobby"] = k.on
            return d.stop(k)
        end
    )
    a6.t["explode_lobby"].max_i = 74
    a6.t["explode_lobby"].min_i = 0
    a6.t["explode_lobby"].value_i = r["explode_lobby_value"]
    a6.t["explode_lobby"].on = r["explode_lobby"]
    a6.t["explode_lobby_shake"] =
        a6.add.t(
        "Shake Cam",
        a6.p["explode"],
        function(k)
            if k.on then
                local aG = v3()
                for i = 1, 10 do
                    aG.x = c.random(-2700, 2700)
                    aG.y = c.random(-3300, 7500)
                    aG.z = c.random(30, 90)
                    c.explode(aG, 8, false, true, 20, 0)
                end
            end
            r["explode_lobby_shake"] = k.on
            return d.stop(k)
        end
    )
    a6.t["explode_lobby_shake"].on = r["explode_lobby_shake"]
    a6.p["sound"] = a6.add.p("Sound-Features", a6.p["lobby"]).id
    a6.t["sound_rape"] =
        a6.add.t(
        "Sound Rape",
        a6.p["sound"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    if aa.i(i) then
                        audio.play_sound_from_entity(2, "Wasted", c.ped(i), "DLC_IE_VV_General_Sounds")
                    end
                end
            end
            r["sound_rape"] = k.on
            return d.stop(k)
        end
    )
    a6.t["sound_rape"].on = r["sound_rape"]
    a6.add.a(
        "Garage-Door Sound - Infinite Time",
        a6.p["sound"],
        function()
            for i = 0, 31 do
                if aa.i(i) then
                    audio.play_sound_from_entity(2, "Garage_Door", c.ped(i), "DLC_HEISTS_GENERIC_SOUNDS")
                end
            end
        end
    )
    a6.t["kill_all_peds"] =
        a6.add.t(
        "Kill all PEDs",
        a6.p["lobby"],
        function(k)
            if k.on then
                local c_ = ped.get_all_peds()
                for i = 1, #c_ do
                    if not ped.is_ped_a_player(c_[i]) then
                        ped.set_ped_health(c_[i], 0)
                    end
                end
            end
            r["kill_all_peds"] = k.on
            return d.stop(k)
        end
    )
    a6.t["kill_all_peds"].on = r["kill_all_peds"]
    a6.p["lobby_vehicle"] = a6.add.p("Vehicles", a6.p["lobby"]).id
    a6.t["disablecontrol"] =
        a6.add.t(
        "Disable Control from near Vehicles",
        a6.p["lobby_vehicle"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    if aa.i(i) then
                        local ac = c.vehicle(c.ped(i))
                        if ac ~= 0 then
                            a3.ctrl(ac)
                            vehicle.set_vehicle_forward_speed(ac, 25)
                            vehicle.set_vehicle_out_of_control(ac, false, true)
                        end
                    end
                end
            end
            r["disablecontrol"] = k.on
            return d.stop(k)
        end
    )
    a6.t["disablecontrol"].on = r["disablecontrol"]
    a6.t["modify_veh_speed"] =
        a6.add.u(
        "Modify Vehicle Speeds",
        "autoaction_value_i",
        a6.p["lobby_vehicle"],
        function(k)
            r["modify_veh_speed"] = k.value_i
            local cS = 540
            if r["modify_veh_speed_override"] then
                cS = k.value_i
            end
            for i = 0, 31 do
                if aa.i(i, r["modify_veh_speed_include"]) then
                    local ac = c.vehicle(c.ped(i))
                    if ac ~= 0 then
                        a3.ctrl(ac)
                        entity.set_entity_max_speed(ac, cS)
                        vehicle.modify_vehicle_top_speed(ac, k.value_i)
                    end
                end
            end
        end
    )
    a6.t["modify_veh_speed"].min_i = -500
    a6.t["modify_veh_speed"].max_i = 1000
    a6.t["modify_veh_speed"].mod_i = 25
    a6.t["modify_veh_speed"].value_i = r["modify_veh_speed"]
    a6.add.a(
        "Reset Modifies",
        a6.p["lobby_vehicle"],
        function()
            local cS = 540
            for i = 0, 31 do
                if c.valid(i) then
                    local ac = c.vehicle(c.ped(i))
                    if ac ~= 0 then
                        a3.ctrl(ac)
                        entity.set_entity_max_speed(ac, cS)
                        vehicle.modify_vehicle_top_speed(ac, 0)
                    end
                end
            end
        end
    )
    a6.t["modify_veh_speed_include"] =
        a6.add.t(
        "Include Self & Friends",
        a6.p["lobby_vehicle"],
        function(k)
            r["modify_veh_speed_include"] = k.on
        end
    )
    a6.t["modify_veh_speed_include"].on = r["modify_veh_speed_include"]
    a6.t["modify_veh_speed_overwrite"] =
        a6.add.t(
        "Overwrite default Speedlimit",
        a6.p["lobby_vehicle"],
        function(k)
            r["modify_veh_speed_overwrite"] = k.on
        end
    )
    a6.t["modify_veh_speed_overwrite"].on = r["modify_veh_speed_overwrite"]
    a6.p["lobby_bounty"] = a6.add.p("Bounty", a6.p["lobby"]).id
    a6.t["bounty_after_death"] =
        a6.add.u(
        "Set Bounty after Death",
        "value_i",
        a6.p["lobby_bounty"],
        function(k)
            r["bounty_after_death"] = k.on
            r["bounty_after_death_value"] = k.value_i
            if k.on then
                local d0 = 0
                if a6.t["anonymous_bounty"].on then
                    d0 = 1
                end
                for i = 0, 31 do
                    if aa.i(i) then
                        if player.get_player_health(i) == 0 then
                            u(E.name(i) .. " is dead!\nSetting bounty...", 33)
                            x(E.name(i) .. " is dead!")
                            x("Setting bounty...")
                            for cR = 0, 31 do
                                if E.scid(cR) ~= -1 then
                                    c.script(
                                        -116602735,
                                        cR,
                                        {
                                            69,
                                            i,
                                            1,
                                            a6.t["bounty_after_death"].value_i,
                                            0,
                                            d0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            script.get_global_i(1652336 + 9),
                                            script.get_global_i(1652336 + 10)
                                        }
                                    )
                                end
                            end
                            c.wait(1500)
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    a6.t["bounty_after_death"].min_i = 0
    a6.t["bounty_after_death"].max_i = 10000
    a6.t["bounty_after_death"].value_i = r["bounty_after_death_value"]
    a6.t["bounty_after_death"].on = r["bounty_after_death"]
    a6.t["anonymous_bounty"] =
        a6.add.t(
        "Anonymous Bounty",
        a6.p["lobby_bounty"],
        function(k)
            r["anonymous_bounty"] = k.on
        end
    )
    a6.t["anonymous_bounty"].on = r["anonymous_bounty"]
    for i = 1, #C.bounty_amount do
        a6.add.a(
            C.bounty_amount[i] .. "$",
            a6.p["lobby_bounty"],
            function()
                local d0 = 0
                if a6.t["anonymous_bounty"].on then
                    d0 = 1
                end
                for cR = 0, 31 do
                    if E.scid(cR) ~= -1 then
                        for d1 = 0, 31 do
                            if E.scid(d1) ~= -1 then
                                c.script(
                                    -116602735,
                                    d1,
                                    {
                                        69,
                                        cR,
                                        1,
                                        C.bounty_amount[i],
                                        0,
                                        d0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        script.get_global_i(1652336 + 9),
                                        script.get_global_i(1652336 + 10)
                                    }
                                )
                            end
                        end
                    end
                end
            end
        )
    end
    a6.p["lobby_se"] = a6.add.p("Script Events", a6.p["lobby"]).id
    a6.p["lobby_se_custom"] = a6.add.p("Custom Script Events", a6.p["lobby_se"]).id
    a6.add.a(
        "Enter Custom Script Event with Parameters",
        a6.p["lobby_se_custom"],
        function()
            local d2 = {}
            local d3
            local d4 = E.input("Enter Custom SE (DEC)", 32, 3)
            if not d4 then
                u("Aborted sending Custom Event...", 100)
                return HANDLER_POP
            end
            while d3 ~= "#" do
                d3 = E.input("Enter Parameter (DEC), to EXIT and send, enter #", 32, 0)
                if not d3 then
                    u("Aborted sending Custom Event...", 100)
                    return HANDLER_POP
                end
                if d3 == "#" then
                    break
                end
                d3 = c.no(d3)
                if type(d3) == "number" then
                    d2[#d2 + 1] = d3
                else
                    u("Aborted sending Custom Event...", 100)
                    return HANDLER_POP
                end
            end
            for i = 0, 31 do
                if aa.i(i) then
                    c.script(d4, i, d2)
                end
            end
            u("Sent Custom Script Event with Parameters to Players.", 100)
        end
    )
    for i = 1, #C.custom_se do
        a6.add.a(
            C.custom_se[i][1],
            a6.p["lobby_se_custom"],
            function()
                u("Sent Custom Script Event to Players.", 100)
                for _ = 0, 31 do
                    if aa.i(_) then
                        for b6 = 1, #C.custom_se[i][2] do
                            c.script(C.custom_se[i][2][b6][1], _, C.custom_se[i][2][b6][2])
                        end
                    end
                end
            end
        )
    end
    a6.add.a(
        "Send all to Island",
        a6.p["lobby_se"],
        function()
            cr(true, 0x4d8b1e65, {1300962917})
        end
    )
    a6.p["lobby_send_2_mission"] = a6.add.p("Send all to Mission", a6.p["lobby_se"]).id
    for i = 1, #aN do
        a6.add.a(
            "Send to " .. aN[i][1],
            a6.p["lobby_send_2_mission"],
            function()
                cr(true, -545396442, aN[i][2])
                u("Sent Session to Mission")
            end
        )
    end
    a6.p["lobby_ceo"] = a6.add.p("CEO all Player", a6.p["lobby_se"]).id
    for i = 1, 3 do
        a6.add.a(
            aO[i][1],
            a6.p["lobby_ceo"],
            function()
                cr(true, aO[i][2], aO[i][3], aO[i][4], aO[i][5])
                u("Modified Players CEO")
            end
        )
    end
    a6.add.a(
        "Block - Passive",
        a6.p["lobby_se"],
        function()
            cr(true, -909357184, {1, 1})
            u("Blocked all Players from activating Passive.")
        end
    )
    a6.add.a(
        "UN-Block - Passive",
        a6.p["lobby_se"],
        function()
            cr(true, -909357184, {1, 0})
            u("UN-Blocked all Players from Passive.")
        end
    )
    a6.p["lobby_sms"] =
        a6.add.p(
        "Send SMSs to Lobby",
        a6.p["lobby"],
        function()
            u("Players must have Voice-Chat enabled to recive SMS.")
            if a6.t["sms_spam"] then
                a6.t["sms_spam"].value_i = r["sms_spam_value"]
                a6.t["sms_spam"].on = r["sms_spam"]
            end
        end
    ).id
    a6.t["sms_spam"] =
        a6.add.u(
        "Spam SMS X times",
        "value_i",
        a6.p["lobby_sms"],
        function(k)
            r["sms_spam_value"] = k.value_i
            r["sms_spam"] = k.on
        end
    )
    a6.t["sms_spam"].min_i = 25
    a6.t["sms_spam"].max_i = 5000
    a6.t["sms_spam"].mod_i = 25
    a6.t["sms_spam"].value_i = r["sms_spam_value"]
    a6.t["sms_spam"].on = r["sms_spam"]
    a6.add.a(
        "Custom SMS input",
        a6.p["lobby_sms"],
        function()
            local d5 = E.input("Enter Custom SMS", 128, 0)
            if not d5 then
                return HANDLER_POP
            end
            for i = 0, 31 do
                if aa.i(i) then
                    local o = 1
                    if a6.t["sms_spam"].on then
                        o = a6.t["sms_spam"].value_i
                    end
                    for _ = 1, o do
                        player.send_player_sms(i, d5)
                        c.wait(10)
                    end
                    if o > 1 then
                        u("Spamming SMS done.")
                    end
                end
            end
        end
    )
    a6.add.a(
        "Send SCID & IP",
        a6.p["lobby_sms"],
        function()
            for i = 0, 31 do
                if aa.i(i) then
                    local aj = tostring(E.scid(i))
                    local d6 = E.ip(i)
                    local o = 1
                    if a6.t["sms_spam"].on then
                        o = a6.t["sms_spam"].value_i
                    end
                    for az = 1, o do
                        player.send_player_sms(i, "R*SCID: " .. aj .. "~n~IP: " .. d6)
                    end
                    if o > 1 then
                        u("Spamming SMS done.")
                    end
                end
            end
        end
    )
    for i = 1, #C.sms_texts do
        a6.add.a(
            C.sms_texts[i],
            a6.p["lobby_sms"],
            function()
                for _ = 0, 31 do
                    if aa.i(_) then
                        local o = 1
                        if a6.t["sms_spam"].on then
                            o = a6.t["sms_spam"].value_i
                        end
                        for az = 1, o do
                            player.send_player_sms(_, C.sms_texts[i])
                            c.wait(20)
                        end
                        if o > 1 then
                            u("Spamming SMS done.")
                        end
                    end
                end
            end
        )
    end
    a6.p["lobby_malicious"] = a6.add.p("Malicious", a6.p["lobby"]).id
    a6.t["karma_se"] =
        a6.add.t(
        "Karma every Script Event",
        a6.p["lobby_malicious"],
        function(k)
            if bM == nil then
                bM =
                    hook.register_script_event_hook(
                    function(T, U, V, W)
                        local Y = V[1]
                        table.remove(V, 1)
                        c.script(Y, T, V)
                    end
                )
            else
                hook.remove_script_event_hook(bM)
            end
            r["karma_se"] = k.on
        end
    )
    a6.t["karma_se"].on = r["karma_se"]
    a6.t["punish_aliens"] =
        a6.add.t(
        "Punish Aliens in Lobby",
        a6.p["lobby_malicious"],
        function(k)
            r["punish_aliens"] = k.on
            if k.on then
                local time = c.time() + 15000
                while time > c.time() do
                    r["punish_aliens"] = k.on
                    c.wait(150)
                end
                for i = 0, 31 do
                    if aa.i(i) then
                        local cV = 0
                        if player.is_player_female(i) then
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 1) == 134 and
                                    (ped.get_ped_texture_variation(c.ped(i), 1) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 1) == 9)
                             then
                                cV = cV + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 4) == 113 and
                                    (ped.get_ped_texture_variation(c.ped(i), 4) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 4) == 9)
                             then
                                cV = cV + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 6) == 87 and
                                    (ped.get_ped_texture_variation(c.ped(i), 6) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 6) == 9)
                             then
                                cV = cV + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 11) == 287 and
                                    (ped.get_ped_texture_variation(c.ped(i), 11) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 11) == 9)
                             then
                                cV = cV + 1
                            end
                        else
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 1) == 134 and
                                    (ped.get_ped_texture_variation(c.ped(i), 1) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 1) == 9)
                             then
                                cV = cV + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 4) == 106 and
                                    (ped.get_ped_texture_variation(c.ped(i), 4) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 4) == 9)
                             then
                                cV = cV + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 6) == 83 and
                                    (ped.get_ped_texture_variation(c.ped(i), 6) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 6) == 9)
                             then
                                cV = cV + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 11) == 274 and
                                    (ped.get_ped_texture_variation(c.ped(i), 11) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 11) == 9)
                             then
                                cV = cV + 1
                            end
                        end
                        if cV > 1 then
                            x(E.name(i) .. " is a useless alien!")
                            x("Guilty Level: " .. cV)
                            u(E.name(i) .. " is a useless alien! Punishing him!", 23)
                            player.send_player_sms(i, "Delete your stupid alien Outfit!")
                            c3(C.custom_attachments[5][2], i)
                            c3(C.custom_attachments[8][2], i)
                            c.explode(c.gcoords(c.ped(i)), 59, false, true, 1, c.ped(i))
                            c.explode(c.gcoords(c.ped(i)), 8, true, false, 1, c.ped(i))
                            c.explode(c.gcoords(c.ped(i)), 60, true, false, 1, c.ped(i))
                            c.explode(c.gcoords(c.ped(i)), 8, true, false, 1, c.ped(i))
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    a6.t["punish_aliens"].on = r["punish_aliens"]
    a6.add.a(
        "Kick all Players",
        a6.p["lobby_malicious"],
        function()
            c2(true)
        end
    )
    a6.add.a(
        "Host Kick All",
        a6.p["lobby_malicious"],
        function()
            if network.network_is_host() then
                for i = 0, 31 do
                    if aa.i(i) then
                        network.network_session_kick_player(i)
                    end
                end
            else
                u("You are not Session-Host!")
            end
        end
    )
    a6.t["force_host"] =
        a6.add.t(
        "Kick Hosts until You become Host",
        a6.p["lobby_malicious"],
        function(k)
            if k.on then
                local time = c.time() + 7500
                while time > c.time() do
                    c.wait(250)
                    r["force_host"] = k.on
                end
                local ak = player.get_host()
                if ak ~= c.id() and E.scid(ak) ~= -1 then
                    x("You are not Host!")
                    x(E.name(ak) .. ":" .. E.scid(ak) .. " is Host!")
                    u(E.name(ak) .. " is Host!")
                    c2(false, ak)
                end
            end
            r["force_host"] = k.on
            return d.stop(k)
        end
    )
    a6.t["force_host"].on = r["force_host"]
    a6.add.a(
        "Crash Session",
        a6.p["lobby_malicious"],
        function()
            x("Crashing Session...")
            c.navigate(false)
            bj = entity.get_entity_model_hash(a5.ped())
            for i = 1, 11 do
                aX["session_crash"]["textures"][i] = ped.get_ped_texture_variation(a5.ped(), i)
                aX["session_crash"]["clothes"][i] = ped.get_ped_drawable_variation(a5.ped(), i)
            end
            local aw = {0, 1, 2, 6, 7}
            for az = 1, #aw do
                aX["session_crash"]["prop_ind"][az] = ped.get_ped_prop_index(a5.ped(), aw[az])
                aX["session_crash"]["prop_text"][az] = ped.get_ped_prop_texture_index(a5.ped(), aw[az])
            end
            bZ(0x471BE4B2, nil, nil, nil, true)
            bk = true
            c.wait(5000)
            cw()
            c.navigate(true)
            x("Done.")
        end
    )
    a6.add.a("Fix loading screen after Crash", a6.p["lobby_malicious"], cw)
    if r["2t1s_parent"] then
        a6.p["opl_parent"] = a6.add.pp("2Take1Script", 0).id
    end
    a6.add.pt(
        "Unmark Modder",
        a6.p["opl_parent"],
        function(k, b9)
            if k.on then
                if player.is_player_modder(b9, -1) then
                    player.unset_player_as_modder(b9, -1)
                end
            end
            return d.stop(k)
        end
    )
    a6.add.pt(
        "Remote Control Vehicle",
        a6.p["opl_parent"],
        function(k, d7)
            local d8 = menu.get_player_feature(k.id)
            if k.on then
                if br ~= d7 then
                    br = d7
                    for i = 1, #d8.feats do
                        if i - 1 ~= d7 and d8.feats[i].on then
                            d8.feats[i].on = false
                        end
                    end
                end
                local ac = c.vehicle(c.ped(d7))
                if ac ~= 0 then
                    if bq == nil then
                        local aF = entity.get_entity_model_hash(ac)
                        bq = aE.vehicle(aF, a5.coords())
                        ped.set_ped_into_vehicle(a5.ped(), bq, -1)
                        c.wait(50)
                    end
                    c.visible(bq, false)
                    if entity.get_entity_attached_to(ac) ~= bq then
                        a3.ctrl(bq)
                        entity.set_entity_velocity(bq, v3())
                        bO(bq, c.gcoords(ac))
                        c.wait(0)
                        entity.set_entity_rotation(bq, entity.get_entity_rotation(ac))
                        a3.ctrl(ac)
                        entity.set_entity_velocity(ac, v3())
                        entity.set_entity_max_speed(ac, 0)
                        vehicle.set_vehicle_out_of_control(ac, false, false)
                        c.attach(ac, bq, 0, v3(), v3(), true, false, false, 0, true)
                    end
                    return HANDLER_CONTINUE
                else
                    for i = 1, #d8.feats do
                        if d8.feats[i].on then
                            d8.feats[i].on = false
                        end
                    end
                    u("Target is not in a Vehicle!")
                    return HANDLER_POP
                end
            end
            if bq then
                ped.clear_ped_tasks_immediately(a5.ped())
                bQ({bq})
                bq = nil
            end
            return HANDLER_POP
        end
    )
    a6.add.pa(
        "Repair Vehicle",
        a6.p["opl_parent"],
        function(k, d7)
            local ac = c.vehicle(c.ped(d7))
            if ac ~= 0 then
                a3.ctrl(ac)
                vehicle.set_vehicle_fixed(ac)
                vehicle.set_vehicle_deformation_fixed(ac)
                vehicle.set_vehicle_can_be_visibly_damaged(ac, false)
                x("Repaired Vehicle.")
            end
        end
    )
    a6.add.pt(
        "Waypoint Player",
        a6.p["opl_parent"],
        function(k, d7)
            local d8 = menu.get_player_feature(k.id)
            if k.on then
                if bz ~= d7 then
                    bz = d7
                    for i = 1, #d8.feats do
                        if i - 1 ~= d7 and d8.feats[i].on then
                            d8.feats[i].on = false
                        end
                    end
                end
                local aG = c.gcoords(c.ped(d7))
                ui.set_new_waypoint(v2(aG.x, aG.y))
                c.wait(500)
                return HANDLER_CONTINUE
            end
            c.wait(10)
            ui.set_waypoint_off()
            c.wait(10)
            return HANDLER_POP
        end
    )
    a6.add.pa(
        "Modify Speed (0-500)",
        a6.p["opl_parent"],
        function(k, d7)
            local ac = c.vehicle(c.ped(d7))
            if ac ~= 0 then
                local cT = E.input("Enter modified Speed (0-500)", 10, 3)
                if not cT then
                    return HANDLER_POP
                end
                cT = c.no(cT)
                if cT < 0 or cT > 500 then
                    u("Invalid Speed.")
                    return HANDLER_POP
                end
                u("Setting modified Speed.")
                a3.ctrl(ac)
                entity.set_entity_max_speed(ac, cT)
                vehicle.modify_vehicle_top_speed(ac, cT)
            end
        end
    )
    a6.p["attach"] = a6.add.pp("Attach Objects", a6.p["opl_parent"]).id
    a6.add.pa(
        "Attach Entity from Aim",
        a6.p["attach"],
        function(k, b9)
            local d9 = player.get_entity_player_is_aiming_at(c.id())
            if d9 ~= 0 then
                c3({{d9, 0, {0, 0, 0}, {0, 0, 0}}}, b9, true)
            else
                u("No Entity found. Aim @Entity to attach it to Player.")
            end
        end
    )
    a6.add.pa(
        "Clear Entitys",
        a6.p["attach"],
        function()
            x("Clearing Attachments.")
            bQ(aW["attach_obj"])
            aW["attach_obj"] = {}
            u("Cleared all Attachment Entitys.")
        end
    )
    for i = 1, #C.custom_attachments do
        a6.add.pa(
            C.custom_attachments[i][1],
            a6.p["attach"],
            function(k, b9)
                c3(C.custom_attachments[i][2], b9)
            end
        )
    end
    a6.p["opl_event_logger"] = a6.add.pp("Log Events", a6.p["opl_parent"]).id
    a6.add.pt(
        "Log Script Events",
        a6.p["opl_event_logger"],
        function(k, b9)
            if k.on then
                if bE[b9] == nil then
                    bE[b9] =
                        hook.register_script_event_hook(
                        function(T, U, V, W)
                            if T == b9 then
                                local aj = E.scid(b9)
                                local j = E.name(b9)
                                local an = tostring(aj) .. "-" .. j
                                local e = a["Event-Logger"] .. "\\" .. an .. "\\" .. "Script-Events.log"
                                local z = d.time_prefix() .. " [Script-Event-Logger]"
                                local f = z
                                if not c.d_exists(a["Event-Logger"]) then
                                    utils.make_dir(a["Event-Logger"])
                                end
                                if not c.d_exists(a["Event-Logger"] .. "\\" .. an) then
                                    utils.make_dir(a["Event-Logger"] .. "\\" .. an)
                                end
                                if not c.f_exists(e) then
                                    u("Logging to folder '2Take1Script/Event-Logger/" .. an, 14)
                                    f = "Starting to log Script-Events from Player: " .. j .. ":" .. aj .. "\n" .. z
                                end
                                f = f .. "\n" .. V[1] .. ", {"
                                for i = 2, #V do
                                    f = f .. V[i]
                                    if i ~= #V then
                                        f = f .. ", "
                                    end
                                end
                                f = f .. "}\n"
                                f = f .. "Parameter count: " .. W - 1 .. "\n"
                                d.write(c.o(e, "a"), f)
                            end
                        end
                    )
                end
                return HANDLER_CONTINUE
            end
            if not k.on and bE[b9] then
                hook.remove_script_event_hook(bE[b9])
                bE[b9] = nil
            end
        end
    )
    a6.add.pa(
        "Reset Script Event Log",
        a6.p["opl_event_logger"],
        function(k, b9)
            local aj = E.scid(b9)
            local j = E.name(b9)
            local an = tostring(aj) .. "-" .. j
            local e = a["Event-Logger"] .. "\\" .. an .. "\\" .. "Script-Events.log"
            if c.f_exists(e) then
                io.remove(e)
            else
                u("There was no log to reset.", 14)
            end
        end
    )
    a6.add.pt(
        "Log Net Events",
        a6.p["opl_event_logger"],
        function(k, b9)
            if k.on then
                if bF[b9] == nil then
                    bF[b9] =
                        hook.register_net_event_hook(
                        function(T, U, cU)
                            if T == b9 then
                                local aj = E.scid(b9)
                                local j = E.name(b9)
                                local an = tostring(aj) .. "-" .. j
                                local e = a["Event-Logger"] .. "\\" .. an .. "\\" .. "Net-Events.log"
                                local z = d.time_prefix() .. " [Net-Event-Logger]"
                                local f = z
                                if not c.d_exists(a["Event-Logger"]) then
                                    utils.make_dir(a["Event-Logger"])
                                end
                                if not c.d_exists(a["Event-Logger"] .. "\\" .. an) then
                                    utils.make_dir(a["Event-Logger"] .. "\\" .. an)
                                end
                                if not c.f_exists(e) then
                                    u("Logging to folder '2Take1Script/Event-Logger/" .. an, 14)
                                    f = "Starting to log Net-Events from Player: " .. j .. ":" .. aj .. "\n" .. f
                                end
                                local da = "Unknown Net-Event"
                                if C.net_events[cU] then
                                    da = C.net_events[cU]
                                end
                                f = f .. "\nEvent: " .. da .. "\nEvent ID: " .. cU .. "\n"
                                d.write(c.o(e, "a"), f)
                            end
                        end
                    )
                end
                return HANDLER_CONTINUE
            end
            if not k.on and bF[b9] then
                hook.remove_net_event_hook(bF[b9])
                bF[b9] = nil
            end
        end
    )
    a6.add.pa(
        "Reset Net Event Log",
        a6.p["opl_event_logger"],
        function(k, b9)
            local aj = E.scid(b9)
            local j = E.name(b9)
            local an = tostring(aj) .. "-" .. j
            local e = a["Event-Logger"] .. "\\" .. an .. "\\" .. "Net-Events.log"
            if c.f_exists(e) then
                io.remove(e)
            else
                u("There was no log to reset.", 14)
            end
        end
    )
    a6.p["opl_se"] = a6.add.pp("Script-Events", a6.p["opl_parent"]).id
    a6.p["opl_se_custom"] = a6.add.pp("Custom Script Events", a6.p["opl_se"]).id
    a6.add.pa(
        "Enter Custom Script Event with Parameters",
        a6.p["opl_se_custom"],
        function(k, b9)
            local d3
            local d2 = {}
            local d4 = E.input("Enter Custom SE (DEC)", 32, 3)
            if not d4 then
                u("Aborted sending Custom Event...", 93)
                return HANDLER_POP
            end
            while d3 ~= "#" do
                d3 = E.input("Enter Parameter (DEC), to EXIT and send, enter #", 32)
                if not d3 then
                    u("Aborted sending Custom Event...", 93)
                    return HANDLER_POP
                end
                if d3 == "#" then
                    break
                end
                d3 = c.no(d3)
                if type(d3) == "number" then
                    d2[#d2 + 1] = d3
                else
                    u("Aborted sending Custom Event...", 93)
                    return HANDLER_POP
                end
            end
            c.script(d4, b9, d2)
            u("Sent Custom Script Event with Parameters to Player.", 93)
        end
    )
    for i = 1, #C.custom_se do
        a6.add.pa(
            C.custom_se[i][1],
            a6.p["opl_se_custom"],
            function(k, b9)
                u("Sent Custom Script Event to Player.", 93)
                for b6 = 1, #C.custom_se[i][2] do
                    c.script(C.custom_se[i][2][b6][1], b9, C.custom_se[i][2][b6][2])
                end
            end
        )
    end
    a6.add.pa(
        "Send Player to Island",
        a6.p["opl_se"],
        function(k, b9)
            cr(false, 0x4d8b1e65, {1300962917}, nil, nil, b9)
        end
    )
    a6.add.pa(
        "Block - Passive",
        a6.p["opl_se"],
        function(k, b9)
            cr(false, 0x54BAD868, {1, 1}, nil, nil, b9)
            u("Blocked Player from activating Passive.")
        end
    )
    a6.add.pa(
        "UN-Block - Passive",
        a6.p["opl_se"],
        function(k, b9)
            cr(false, 0x54BAD868, {2, 0}, nil, nil, b9)
            u("UN-Blocked Player from Passive.")
        end
    )
    a6.p["opl_send_2_mission"] = a6.add.pp("Send Player to Mission", a6.p["opl_se"]).id
    for i = 1, #aN do
        a6.add.pa(
            "Send to " .. aN[i][1],
            a6.p["opl_send_2_mission"],
            function(k, b9)
                cr(false, -545396442, aN[i][2], nil, nil, b9)
                u("Sent Player to Mission")
            end
        )
    end
    a6.p["opl_ceo"] = a6.add.pp("CEO", a6.p["opl_se"]).id
    for i = 1, 3 do
        a6.add.pa(
            aO[i][1],
            a6.p["opl_ceo"],
            function(k, b9)
                cr(false, aO[i][2], aO[i][3], aO[i][4], aO[i][5], b9)
                u("Modified Players CEO")
            end
        )
    end
    a6.p["opl_assassins_peds"] = a6.add.pp("Send PEDs (Assassins)", a6.p["opl_parent"]).id
    a6.add.pa(
        "Clear PEDs",
        a6.p["opl_assassins_peds"],
        function()
            bQ(aW["peds"])
            aW["peds"] = {}
        end
    )
    for i = 1, #C.ped_assassins do
        a6.add.pa(
            "Spawn " .. C.ped_assassins[i][1] .. " (3x)",
            a6.p["opl_assassins_peds"],
            function(k, b9)
                x("Spawning PEDs.")
                bs = b9
                local aF = C.ped_assassins[i][2]
                local aH = C.ped_assassins[i][3]
                local aG = v3()
                a3.model(aF)
                for i = 1, 3 do
                    aG = c.gcoords(c.ped(b9))
                    aG.x = aG.x + c.random(-10, 10)
                    aG.y = aG.y + c.random(-10, 10)
                    aW["peds"][#aW["peds"] + 1] = aE.ped(aF, aG, aH)
                    if aH ~= 28 then
                        weapon.give_delayed_weapon_to_ped(aW["peds"][#aW["peds"]], 0xDBBD7280, 0, 0)
                    end
                    ped.set_ped_max_health(aW["peds"][#aW["peds"]], 25000000.0)
                    ped.set_ped_health(aW["peds"][#aW["peds"]], 25000000.0)
                    ped.set_ped_combat_attributes(aW["peds"][#aW["peds"]], 46, true)
                    ped.set_ped_combat_ability(aW["peds"][#aW["peds"]], 2)
                    ped.set_ped_config_flag(aW["peds"][#aW["peds"]], 187, 0)
                    ped.set_ped_can_ragdoll(aW["peds"][#aW["peds"]], false)
                    for cR = 1, 26 do
                        ped.set_ped_ragdoll_blocking_flags(aW["peds"][#aW["peds"]], cR)
                    end
                    ai.task_combat_ped(aW["peds"][#aW["peds"]], c.ped(b9), 0, 16)
                end
                c.unload(aF)
                x("Done.")
            end
        )
    end
    a6.add.pa(
        "TP to Player",
        a6.p["opl_parent"],
        function(k, b9)
            bV(c.gcoords(c.ped(b9)), 3)
        end
    )
    a6.add.pa(
        "TP Players Vehicle to me",
        a6.p["opl_parent"],
        function(k, b9)
            local ac = c.vehicle(c.ped(b9))
            a3.ctrl(ac)
            entity.set_entity_velocity(ac, v3())
            bO(ac, a5.coords())
        end
    )
    a6.add.pa(
        "Add Player to Blacklist",
        a6.p["opl_parent"],
        function(k, b9)
            b3.add(E.scid(b9), E.name(b9), b9)
        end
    )
    a6.add.pa(
        "Remove from Blacklist",
        a6.p["opl_parent"],
        function(k, b9)
            b3.remove_scid(E.scid(b9))
        end
    )
    a6.p["opl_misc"] = a6.add.pp("Miscellaneous", a6.p["opl_parent"]).id
    a6.p["opl_sms"] =
        a6.add.pp(
        "Send SMSs to Player",
        a6.p["opl_misc"],
        function()
            u("Player must have Voice-Chat enabled to recive SMS.")
        end
    ).id
    a6.add.pa(
        "Custom SMS input",
        a6.p["opl_sms"],
        function(k, b9)
            local d5 = E.input("Enter Custom SMS", 128)
            if not d5 then
                return HANDLER_POP
            end
            player.send_player_sms(b9, d5)
        end
    )
    a6.add.pa(
        "Send his SCID & IP",
        a6.p["opl_sms"],
        function(k, b9)
            local aj = tostring(E.scid(b9))
            local d6 = E.ip(b9)
            local o = 1
            player.send_player_sms(b9, "R*SCID: " .. aj .. "~n~IP: " .. d6)
        end
    )
    for i = 1, #C.sms_texts do
        a6.add.pa(
            C.sms_texts[i],
            a6.p["opl_sms"],
            function(k, b9)
                player.send_player_sms(b9, C.sms_texts[i])
            end
        )
    end
    a6.add.pa(
        "Falling Asteroids",
        a6.p["opl_misc"],
        function(k, b9)
            c.navigate(false)
            local aG = v3()
            local db
            a3.model(3751297495)
            for i = 1, 25 do
                aG = c.gcoords(c.ped(b9))
                aG.x = c.random(math.floor(aG.x - 80), math.floor(aG.x + 80))
                aG.y = c.random(math.floor(aG.y - 80), math.floor(aG.y + 80))
                aG.z = aG.z + c.random(45, 90)
                db = c.random(-125, 25)
                aW["asteroids"][#aW["asteroids"] + 1] = aE.object(3751297495, aG, true, true)
                entity.apply_force_to_entity(aW["asteroids"][#aW["asteroids"]], 3, 0, 0, db, 0, 0, 0, true, true)
            end
            c.unload(3751297495)
            for i = 1, 5 do
                for i = 1, 25 do
                    aG = c.gcoords(aW["asteroids"][#aW["asteroids"] - 25 + i])
                    c.explode(aG, 8, true, false, 0, 0)
                    c.wait(50)
                end
            end
            c.navigate(true)
        end
    )
    a6.add.pa(
        "Delete Asteroids",
        a6.p["opl_misc"],
        function()
            x("Clearing Asteroids.")
            bQ(aW["asteroids"])
            aW["asteroids"] = {}
            u("Cleared all Asteroids.")
        end
    )
    a6.add.pa(
        "Apply random Force to Player",
        a6.p["opl_misc"],
        function(k, b9)
            local dc = c.ped(b9)
            if ped.is_ped_in_any_vehicle(dc) then
                dc = c.vehicle(dc)
            else
                u("It works better, if target is in a Vehicle.")
            end
            a3.ctrl(dc)
            local dd = entity.get_entity_velocity(dc)
            for i = 1, 5 do
                dd.x = c.random(math.floor(dd.x - 50), math.floor(dd.x + 50))
                dd.y = c.random(math.floor(dd.y - 50), math.floor(dd.y + 50))
                dd.z = c.random(math.floor(dd.z - 50), math.floor(dd.z + 50))
                entity.set_entity_velocity(dc, dd)
                c.wait(10)
            end
        end
    )
    a6.add.pa(
        "Trap in Stunt Tube",
        a6.p["opl_misc"],
        function(k, b9)
            local aG = c.gcoords(c.ped(b9))
            aG.z = aG.z - 5
            entity.set_entity_rotation(aE.object(1125864094, aG), v3(0, 90, 0))
        end
    )
    a6.add.pa(
        "Trap in invisible Cage",
        a6.p["opl_misc"],
        function(k, b9)
            local aG = c.gcoords(c.ped(b9))
            aG.x = aG.x + 1.24
            aG.y = aG.y + 0.24
            a3.model(401136338)
            local de = aE.object(401136338, aG)
            c.visible(de, false)
            entity.set_entity_rotation(de, v3(0, -90, 0))
            entity.freeze_entity(de, true)
            aG = c.gcoords(c.ped(b9))
            aG.x = aG.x + 0.02
            aG.y = aG.y + 0.82
            de = aE.object(401136338, aG)
            c.visible(de, false)
            entity.set_entity_rotation(de, v3(90, -90, 0))
            entity.freeze_entity(de, true)
            c.unload(401136338)
        end
    )
    a6.p["opl_bounty"] = a6.add.pp("Bounty", a6.p["opl_parent"]).id
    for i = 1, #C.bounty_amount do
        a6.add.pa(
            C.bounty_amount[i] .. "$",
            a6.p["opl_bounty"],
            function(k, b9)
                local d0 = 0
                if a6.t["anonymous_bounty"].on then
                    d0 = 1
                end
                for cR = 0, 31 do
                    if E.scid(cR) ~= -1 then
                        c.script(
                            -116602735,
                            cR,
                            {
                                69,
                                b9,
                                1,
                                C.bounty_amount[i],
                                0,
                                d0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                script.get_global_i(1652336 + 9),
                                script.get_global_i(1652336 + 10)
                            }
                        )
                    end
                end
            end
        )
    end
    a6.p["opl_lag_area"] =
        a6.add.pp(
        "Lag Area with Vehicles",
        a6.p["opl_parent"],
        function()
            u("DANGEROUS! ONLY USE WITH CAUTION!", 208)
        end
    ).id
    for i = 1, #C.vehicle_lag_area do
        a6.add.pa(
            "Lag / Rain Area with " .. C.vehicle_lag_area[i][1],
            a6.p["opl_lag_area"],
            function(k, b9)
                c9(b9, C.vehicle_lag_area[i][2])
            end
        )
    end
    a6.add.pa(
        "Delete Vehicles",
        a6.p["opl_lag_area"],
        function()
            x("Clearing Vehicles.")
            bQ(aW["lag_area"])
            aW["lag_area"] = {}
            u("Cleared Vehicles.")
        end
    )
    a6.p["opl_malicious"] = a6.add.pp("Malicious (Kick / Crash)", a6.p["opl_parent"]).id
    a6.add.pa(
        "Kick Player",
        a6.p["opl_malicious"],
        function(k, b9)
            c2(false, b9)
        end
    )
    a6.add.pa(
        "Host Kick Player",
        a6.p["opl_malicious"],
        function(k, b9)
            if network.network_is_host() then
                network.network_session_kick_player(b9)
            else
                u("You are not Session-Host!")
            end
        end
    )
    a6.add.pa(
        "Crash Player",
        a6.p["opl_malicious"],
        function(k, b9)
            ca(b9)
        end
    )
    a6.p["chat"] = a6.add.p("Chat-Features", a6.p["parent"])
    a6.p["chat"].hidden = r["chat_hidden"]
    a6.p["chat"] = a6.p["chat"].id
    a6.t["chat_log"] =
        a6.add.t(
        "Chat-Log",
        a6.p["chat"],
        function(k)
            if k.on and not bm["chat_log"] then
                bm["chat_log"] =
                    event.add_event_listener(
                    "chat",
                    function(O)
                        x("[" .. E.scid(O.player) .. ":" .. E.name(O.player) .. "] '" .. O.body .. "'", "[CHAT]")
                    end
                )
            end
            if not k.on and bm["chat_log"] then
                event.remove_event_listener("chat", bm["chat_log"])
                bm["chat_log"] = nil
            end
            r["chat_log"] = k.on
        end
    )
    a6.t["chat_log"].on = r["chat_log"]
    a6.t["chat_russki"] =
        a6.add.t(
        "Kick if Russki Char is typed",
        a6.p["chat"],
        function(k)
            if k.on and not bm["chat_russki"] then
                bm["chat_russki"] =
                    event.add_event_listener(
                    "chat",
                    function(O)
                        local b9 = O.player
                        if aa.i(b9) then
                            local f = O.body
                            for i = 1, #C.russki_chars do
                                if string.find(f, C.russki_chars[i], 1) then
                                    x("Detected '" .. C.russki_chars[i] .. "' as a Russki Char!")
                                    x("Preparing to Kick " .. E.name(b9) .. ".")
                                    u("Detected " .. E.name(b9) .. " typing forbidden Russki! Kicking Player...", 115)
                                    c2(false, b9)
                                    f = ""
                                end
                            end
                        end
                    end
                )
            end
            if not k.on and bm["chat_russki"] then
                event.remove_event_listener("chat", bm["chat_russki"])
                bm["chat_russki"] = nil
            end
            r["chat_russki"] = k.on
        end
    )
    a6.t["chat_russki"].on = r["chat_russki"]
    a6.t["chat_begger"] =
        a6.add.t(
        "Punish Money Beggers",
        a6.p["chat"],
        function(k)
            if k.on and not bm["chat_begger"] then
                bm["chat_begger"] =
                    event.add_event_listener(
                    "chat",
                    function(O)
                        local b9 = O.player
                        if aa.i(b9) then
                            local f = O.body
                            for i = 1, #C.begger_texts do
                                if string.find(f, C.begger_texts[i], 1) then
                                    x("Detected " .. E.name(b9) .. " begging for Money! Punishing Player...")
                                    u("Detected " .. E.name(b9) .. " begging for Money! Punishing Player...", 115)
                                    c3(C.custom_attachments[5][2], b9)
                                    c3(C.custom_attachments[8][2], b9)
                                    local aG = c.gcoords(c.ped(b9))
                                    local df = c.ped(b9)
                                    c.explode(aG, 59, false, true, 1, df)
                                    c.explode(aG, 8, false, true, 1, df)
                                    c.explode(aG, 59, false, true, 1, df)
                                end
                            end
                        end
                    end
                )
            end
            if not k.on and bm["chat_begger"] then
                event.remove_event_listener("chat", bm["chat_begger"])
                bm["chat_begger"] = nil
            end
            r["chat_begger"] = k.on
        end
    )
    a6.t["chat_begger"].on = r["chat_begger"]
    a6.t["send_msg_to_script_users"] =
        a6.add.a(
        "Send Message to 2Take1Script-Users",
        a6.p["chat"],
        function()
            local X = E.input("Enter Message", 128)
            if not X then
                return HANDLER_POP
            end
            if X ~= "" then
                local V = {}
                V[1] = 6666
                for bP, cm in utf8.codes(X) do
                    V[#V + 1] = cm
                end
                for i = 0, 31 do
                    if c.valid(i) then
                        if i ~= c.id() and E.scid(i) ~= -1 then
                            c.script(0xfaaab4a3, i, V)
                        end
                    end
                end
            end
        end
    )
    a6.t["chat_cmd"] =
        a6.add.t(
        "Enable Chat-Commands",
        a6.p["chat"],
        function(k)
            if k.on and not bm["chat_cmd"] then
                bm["chat_cmd"] =
                    event.add_event_listener(
                    "chat",
                    function(a4)
                        local b9 = a4.player
                        local f = a4.body
                        if a6.t["cmd_explode"] and string.find(f, "!explode ", 1) then
                            f = string.gsub(f, "!explode ", "")
                            local dg, cp = cn(b9, f, "Explode")
                            if dg then
                                local aG = c.gcoords(c.ped(cp))
                                local df = c.ped(b9)
                                c.explode(aG, 59, false, true, 1, df)
                                c.explode(aG, 8, false, true, 1, df)
                                c.explode(aG, 59, false, true, 1, df)
                            end
                        end
                        if a6.t["cmd_explode_all"] and string.find(f, "!explodeall", 1) and b9 == c.id() then
                            x("Detected !explodeall Command! Script-User is entitled, performing...")
                            for i = 0, 31 do
                                if aa.i(i) then
                                    c.explode(c.gcoords(c.ped(i)), 59, true, false, 1, c.ped(c.id()))
                                end
                            end
                        end
                        if a6.t["cmd_kick"] and string.find(f, "!kick ", 1) then
                            f = string.gsub(f, "!kick ", "")
                            local dg, cp = cn(b9, f, "Kick")
                            if dg then
                                c2(false, cp)
                            end
                        end
                        if a6.t["cmd_kick_all"] and string.find(f, "!kickall", 1) and b9 == c.id() then
                            x("Detected !kickall Command! Script-User is entitled, performing...")
                            c2(true)
                        end
                        if a6.t["cmd_crash"] and string.find(f, "!crash ", 1) then
                            x("Detected !crash Command!")
                            f = string.gsub(f, "!crash ", "")
                            local U = ci(f)
                            if U ~= -1 then
                                if U == c.id() then
                                    ca(b9)
                                elseif aa.i(U) then
                                    ca(U)
                                end
                            end
                        end
                        if a6.t["cmd_crash_all"] and string.find(f, "!crashall", 1) and b9 == c.id() then
                            x("Detected !crashall Command! Script-User is entitled, performing...")
                            for i = 0, 31 do
                                if aa.i(i) then
                                    ca(i)
                                end
                            end
                        end
                        if a6.t["cmd_lag"] and string.find(f, "!lag ", 1) then
                            f = string.gsub(f, "!lag ", "")
                            local dg, cp = cn(b9, f, "Lag")
                            if dg and #aW["lag_area"] < 101 then
                                c9(cp, 0x15F27762)
                            end
                        end
                        if a6.t["cmd_trap"] and string.find(f, "!trap ", 1) then
                            f = string.gsub(f, "!trap ", "")
                            local dg, cp = cn(b9, f, "Trap")
                            if dg then
                                local aG = c.gcoords(c.ped(cp))
                                entity.set_entity_rotation(
                                    aE.object(1125864094, v3(aG.x, aG.y, aG.z - 5)),
                                    v3(0, 90, 0)
                                )
                            end
                        end
                        if a6.t["cmd_tp"] and string.find(f, "!tp ", 1) and b9 == c.id() then
                            x("Detected !tp Command! Script-User is entitled, performing...")
                            f = string.gsub(f, "!tp ", "")
                            local U = ci(f)
                            if U ~= -1 then
                                local bW = 10
                                local aG = c.gcoords(c.ped(U))
                                if aG.z < -50 then
                                    bW = 150
                                end
                                bV(c.ped(U), bW)
                            end
                        end
                        if a6.t["cmd_clearwanted"] and string.find(f, "!clearwanted", 1) then
                            local dg, cp = cn(b9, nil, "Clearwanted")
                            if dg then
                                c.script(0xf63f672f, b9, {b9, script.get_global_i(1628955 + 1 + b9 * 614 + 532)})
                            end
                        end
                        if a6.t["cmd_vehicle"] and string.find(f, "!vehicle ", 1) then
                            f = string.gsub(f, "!vehicle ", "")
                            local dg, cp = cn(b9, nil, "Vehicle")
                            if dg then
                                local aF = gameplay.get_hash_key(f)
                                if streaming.is_model_a_vehicle(aF) then
                                    a3.model(aF)
                                    local aI = player.get_player_heading(b9)
                                    local dh = aE.vehicle(aF, cg(c.gcoords(c.ped(b9)), aI, 10), aI)
                                    a3.ctrl(dh)
                                    c.unload(aF)
                                    vehicle.set_vehicle_custom_primary_colour(dh, 0)
                                    vehicle.set_vehicle_custom_secondary_colour(dh, 0)
                                    vehicle.set_vehicle_custom_pearlescent_colour(dh, 0)
                                    vehicle.set_vehicle_custom_wheel_colour(dh, 0)
                                    vehicle.set_vehicle_window_tint(dh, 1)
                                    decorator.decor_set_int(dh, "MPBitset", 1 << 10)
                                    cd(dh)
                                    ped.set_ped_into_vehicle(c.ped(b9), dh, -1)
                                end
                            end
                        end
                        if a6.t["cmd_bigpp"] and string.find(f, "!bigpp ", 1) then
                            f = string.gsub(f, "!bigpp ", "")
                            local dg, cp = cn(b9, f, "Bigpp")
                            if dg then
                                c3(C.custom_attachments[5][2], cp)
                            end
                        end
                        if a6.t["cmd_bigppall"] and string.find(f, "!bigppall", 1) and b9 == c.id() then
                            x("Detected !bigppall Command! Script-User is entitled, performing...")
                            for i = 0, 31 do
                                if aa.i(i) then
                                    c3(C.custom_attachments[5][2], b9)
                                end
                            end
                        end
                    end
                )
            end
            if not k.on and bm["chat_cmd"] then
                event.remove_event_listener("chat", bm["chat_cmd"])
                bm["chat_cmd"] = nil
            end
            r["chat_cmd"] = k.on
        end
    )
    a6.t["chat_cmd"].on = r["chat_cmd"]
    a6.p["chat_cmd"] = a6.add.p("Chat-Commands", a6.p["chat"]).id
    for i = 1, #aS do
        a6.t[aS[i][1]] =
            a6.add.t(
            aS[i][2],
            a6.p["chat_cmd"],
            function(k)
                r[aS[i][1]] = k.on
            end
        )
        a6.t[aS[i][1]].on = r[aS[i][1]]
    end
    a6.add.a("[SU] = Script-User", a6.p["chat_cmd"])
    a6.add.a(
        "Delete Vehicles from !lag",
        a6.p["chat"],
        function()
            bQ(aW["lag_area"])
            aW["lag_area"] = {}
        end
    )
    a6.t["chat_cmd_friends"] =
        a6.add.t(
        "Chat Commands for Friends",
        a6.p["chat"],
        function(k)
            r["chat_cmd_friends"] = k.on
        end
    )
    a6.t["chat_cmd_friends"].on = r["chat_cmd_friends"]
    a6.t["chat_cmd_all"] =
        a6.add.t(
        "Chat Commands Everyone",
        a6.p["chat"],
        function(k)
            r["chat_cmd_all"] = k.on
        end
    )
    a6.t["chat_cmd_all"].on = r["chat_cmd_all"]
    a6.p["custom_veh"] = a6.add.p("Custom Vehicles", a6.p["parent"])
    a6.p["custom_veh"].hidden = r["custom_vehicles_hidden"]
    a6.p["custom_veh"] = a6.p["custom_veh"].id
    a6.p["moveablerobot"] = a6.add.p("Moveable Robot", a6.p["custom_veh"]).id
    a6.t["moveablerobot"] =
        a6.add.t(
        "Enable Robot",
        a6.p["moveablerobot"],
        function(k)
            if k.on then
                if bu["tampa"] == nil then
                    c.navigate(false)
                    local di = true
                    local ac = c.vehicle(a5.ped())
                    if ac ~= 0 then
                        if 3084515313 == entity.get_entity_model_hash(ac) then
                            bu["tampa"] = ac
                            di = false
                        end
                    end
                    if di then
                        a3.model(3084515313)
                        bu["tampa"] = aE.vehicle(3084515313, a5.coords(), a5.heading())
                        decorator.decor_set_int(bu["tampa"], "MPBitset", 1 << 10)
                        c.god(bu["tampa"], true)
                        cd(ac)
                        if a6.t["auto_get_in"].on then
                            ped.set_ped_into_vehicle(a5.ped(), bu["tampa"], -1)
                        end
                        if not r["disable_tampa_notify"] then
                            u(
                                "To get the best experience, upgrade the Tampa to use the Double Controllable Minigun!",
                                11
                            )
                            u("You can disable this message in Options.", 11)
                        end
                    end
                end
                if bu["ppdump"] == nil then
                    a3.model(0x810369E2)
                    bu["ppdump"] = aE.vehicle(0x810369E2)
                    c.god(bu["ppdump"], true)
                    c.attach(
                        bu["ppdump"],
                        bu["tampa"],
                        0,
                        v3(0, 0, 12.5),
                        v3(),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["llbone"] == nil then
                    a3.model(1803116220)
                    bu["llbone"] = aE.object(1803116220)
                    c.attach(
                        bu["llbone"],
                        bu["tampa"],
                        0,
                        v3(-4.25, 0, 12.5),
                        v3(),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["rlbone"] == nil then
                    a3.model(1803116220)
                    bu["rlbone"] = aE.object(1803116220)
                    c.attach(
                        bu["rlbone"],
                        bu["tampa"],
                        0,
                        v3(4.25, 0, 12.5),
                        v3(),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["lltrain"] == nil then
                    a3.model(1030400667)
                    bu["lltrain"] = aE.vehicle(1030400667)
                    c.god(bu["lltrain"], true)
                    c.attach(
                        bu["lltrain"],
                        bu["llbone"],
                        0,
                        v3(0, 0, -5),
                        v3(90),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["lfoot"] == nil then
                    a3.model(782665360)
                    bu["lfoot"] = aE.vehicle(782665360)
                    c.god(bu["lfoot"], true)
                    c.attach(
                        bu["lfoot"],
                        bu["llbone"],
                        0,
                        v3(0, 2, -12.5),
                        v3(),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["rltrain"] == nil then
                    a3.model(1030400667)
                    bu["rltrain"] = aE.vehicle(1030400667)
                    c.god(bu["rltrain"], true)
                    c.attach(
                        bu["rltrain"],
                        bu["rlbone"],
                        0,
                        v3(0, 0, -5),
                        v3(90),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["rfoot"] == nil then
                    a3.model(782665360)
                    bu["rfoot"] = aE.vehicle(782665360)
                    c.god(bu["rfoot"], true)
                    c.attach(
                        bu["rfoot"],
                        bu["rlbone"],
                        0,
                        v3(0, 2, -12.5),
                        v3(),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["body"] == nil then
                    a3.model(1030400667)
                    bu["body"] = aE.vehicle(1030400667)
                    c.god(bu["body"], true)
                    c.attach(
                        bu["body"],
                        bu["tampa"],
                        0,
                        v3(0, 0, 22.5),
                        v3(90),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["shoulder"] == nil then
                    a3.model(0x810369E2)
                    bu["shoulder"] = aE.vehicle(0x810369E2)
                    c.god(bu["shoulder"], true)
                    c.attach(
                        bu["shoulder"],
                        bu["tampa"],
                        0,
                        v3(0, 0, 27.5),
                        v3(),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["lheadbone"] == nil then
                    a3.model(1803116220)
                    bu["lheadbone"] = aE.object(1803116220)
                    c.attach(
                        bu["lheadbone"],
                        bu["tampa"],
                        0,
                        v3(-3.25, 0, 27.5),
                        v3(),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["rheadbone"] == nil then
                    a3.model(1803116220)
                    bu["rheadbone"] = aE.object(1803116220)
                    c.attach(
                        bu["rheadbone"],
                        bu["tampa"],
                        0,
                        v3(3.25, 0, 27.5),
                        v3(),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["lheadtrain"] == nil then
                    a3.model(1030400667)
                    bu["lheadtrain"] = aE.vehicle(1030400667)
                    c.god(bu["lheadtrain"], true)
                    c.attach(
                        bu["lheadtrain"],
                        bu["lheadbone"],
                        0,
                        v3(-3, 4, -5),
                        v3(325, 0, 45),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["lhand"] == nil then
                    a3.model(782665360)
                    bu["lhand"] = aE.vehicle(782665360)
                    c.god(bu["lhand"], true)
                    c.attach(
                        bu["lhand"],
                        bu["lheadtrain"],
                        0,
                        v3(0, 7.5, 0),
                        v3(),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["rheadtrain"] == nil then
                    a3.model(1030400667)
                    bu["rheadtrain"] = aE.vehicle(1030400667)
                    c.god(bu["rheadtrain"], true)
                    c.attach(
                        bu["rheadtrain"],
                        bu["rheadbone"],
                        0,
                        v3(3, 4, -5),
                        v3(325, 0, 315),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["rhand"] == nil then
                    a3.model(782665360)
                    bu["rhand"] = aE.vehicle(782665360)
                    c.god(bu["rhand"], true)
                    c.attach(
                        bu["rhand"],
                        bu["rheadtrain"],
                        0,
                        v3(0, 7.5, 0),
                        v3(),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["head"] == nil then
                    a3.model(-543669801)
                    bu["head"] = aE.object(-543669801)
                    c.attach(bu["head"], bu["tampa"], 0, v3(0, 0, 35), v3(), true, r["robot_collision"], false, 2, true)
                end
                c.navigate(true)
                return HANDLER_CONTINUE
            end
            if not k.on then
                for i in pairs(bu) do
                    bQ({bu[i]})
                    bu[i] = nil
                end
                if #aW["robot_weapon_left"] ~= 0 then
                    bQ(aW["robot_weapon_left"])
                    aW["robot_weapon_left"] = {}
                end
                if #aW["robot_weapon_right"] ~= 0 then
                    bQ(aW["robot_weapon_right"])
                    aW["robot_weapon_right"] = {}
                end
            end
        end
    )
    a6.t["robot_shoot"] =
        a6.add.t(
        "Controllable Blasts",
        a6.p["moveablerobot"],
        function(k)
            if k.on then
                if not a6.t["moveablerobot"].on then
                    c.wait(2500)
                end
                local dj = gameplay.get_hash_key("weapon_airstrike_rocket")
                local aG = a5.coords()
                local dk = cam.get_gameplay_cam_rot()
                dk:transformRotToDir()
                dk = dk * 1000
                aG = aG + dk
                local dl, dm, dn, aF, dp = worldprobe.raycast(cg(a5.coords(), a5.heading(), 2) + v3(0, 0, 4), aG, -1, 0)
                while not dl do
                    aG = a5.coords()
                    dk = cam.get_gameplay_cam_rot()
                    dk:transformRotToDir()
                    dk = dk * 1000
                    aG = aG + dk
                    dl, dm, dn, aF, dp = worldprobe.raycast(cg(a5.coords(), a5.heading(), 2) + v3(0, 0, 4), aG, -1, 0)
                    c.wait(0)
                end
                if ped.is_ped_shooting(a5.ped()) and c.vehicle(a5.ped()) == bu["tampa"] then
                    if a6.t["equip_weapons"].on then
                        local dq = aW["robot_weapon_left"][1]
                        local dr = entity.get_entity_heading(dq)
                        local ds = cg(c.gcoords(dq), dr, 12) + v3(0, 0, 3)
                        gameplay.shoot_single_bullet_between_coords(ds, dm, 1000, dj, a5.ped(), true, false, 50000)
                        c.wait(100)
                        local dt = aW["robot_weapon_right"][1]
                        local du = entity.get_entity_heading(dt)
                        local dv = cg(c.gcoords(dt), du, 12) + v3(0, 0, 3)
                        gameplay.shoot_single_bullet_between_coords(dv, dm, 1000, dj, a5.ped(), true, false, 50000)
                    else
                        local dw = cg(a5.coords(), a5.heading(), 8) + v3(0, 0, 15)
                        gameplay.shoot_single_bullet_between_coords(dw, dm, 1000, dj, a5.ped(), true, false, 10000)
                    end
                end
            end
            r["controllable_blasts"] = k.on
            return d.stop(k)
        end
    )
    a6.t["robot_shoot"].on = r["controllable_blasts"]
    a6.t["moveablelegs"] =
        a6.add.t(
        "Moveable Legs",
        a6.p["moveablerobot"],
        function(k)
            r["moveable_legs"] = k.on
            if k.on then
                if bu["llbone"] and bu["rlbone"] and bu["tampa"] then
                    local cT
                    local cA = bu["llbone"]
                    local cB = bu["rlbone"]
                    local cC = bu["tampa"]
                    local cD = v3(-4.25, 0, 12.5)
                    local cE = v3(4.25, 0, 12.5)
                    for i = 0, 50 do
                        if bu["tampa"] then
                            cT = entity.get_entity_speed(bu["tampa"])
                            if not k.on or cT < 2.5 then
                                cz()
                                return HANDLER_CONTINUE
                            end
                            a3.ctrl(cA)
                            a3.ctrl(cB)
                            a3.ctrl(cC)
                            c.attach(cA, cC, 0, cD, v3(i, 0, 0), true, r["robot_collision"], false, 2, true)
                            c.attach(cB, cC, 0, cE, v3(360 - i, 0, 0), true, r["robot_collision"], false, 2, true)
                            local dx = math.floor(51 - cT / 1)
                            if dx < 1 then
                                dx = 0
                            end
                            c.wait(dx)
                        end
                    end
                    for i = 50, -50, -1 do
                        if bu["tampa"] then
                            cT = entity.get_entity_speed(bu["tampa"])
                            if not k.on or cT < 2.5 then
                                cz()
                                return HANDLER_CONTINUE
                            end
                            a3.ctrl(cA)
                            a3.ctrl(cB)
                            a3.ctrl(cC)
                            c.attach(cA, cC, 0, cD, v3(i, 0, 0), true, r["robot_collision"], false, 2, true)
                            c.attach(cB, cC, 0, cE, v3(360 - i, 0, 0), true, r["robot_collision"], false, 2, true)
                            local dx = math.floor(51 - cT / 1)
                            if dx < 1 then
                                dx = 0
                            end
                            c.wait(dx)
                        end
                    end
                    for i = -50, 0 do
                        if bu["tampa"] then
                            cT = entity.get_entity_speed(bu["tampa"])
                            if not k.on or cT < 2.5 then
                                cz()
                                return HANDLER_CONTINUE
                            end
                            a3.ctrl(cA)
                            a3.ctrl(cB)
                            a3.ctrl(cC)
                            c.attach(cA, cC, 0, cD, v3(i, 0, 0), true, r["robot_collision"], false, 2, true)
                            c.attach(cB, cC, 0, cE, v3(360 - i, 0, 0), true, r["robot_collision"], false, 2, true)
                            local dx = math.floor(51 - cT / 1)
                            if dx < 1 then
                                dx = 0
                            end
                            c.wait(dx)
                        end
                    end
                end
                return HANDLER_CONTINUE
            end
            if not k.on then
                cz()
            end
        end
    )
    a6.t["moveablelegs"].on = r["moveable_legs"]
    a6.t["robot_collision"] =
        a6.add.t(
        "Collision",
        a6.p["moveablerobot"],
        function(k)
            r["robot_collision"] = k.on
            if c.vehicle(a5.ped()) == bu["tampa"] then
                u("Re-enable Robot to take effect of collision!", 11)
            end
        end
    )
    a6.t["robot_collision"].on = r["robot_collision"]
    a6.t["rocket_propulsion"] =
        a6.add.t(
        "Rocket Propulsion (Visual)",
        a6.p["moveablerobot"],
        function(k)
            if k.on and bu["body"] then
                if bu["spinning_1"] == nil then
                    a3.model(0xFB133A17)
                    bu["spinning_1"] = aE.vehicle(0xFB133A17, a5.coords())
                    c.god(bu["spinning_1"], true)
                    c.visible(bu["spinning_1"], false)
                    c.attach(
                        bu["spinning_1"],
                        bu["body"],
                        0,
                        v3(0, -5, 0),
                        v3(-180, 0, 0),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                vehicle.set_heli_blades_speed(bu["spinning_1"], 100)
                if bu["spinning_middle"] == nil then
                    a3.model(94602826)
                    bu["spinning_middle"] = aE.object(94602826)
                    c.god(bu["spinning_middle"], true)
                    c.attach(
                        bu["spinning_middle"],
                        bu["spinning_1"],
                        0,
                        v3(0, 0, 0),
                        v3(0, 0, 0),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["spinning_middle2"] == nil then
                    a3.model(94602826)
                    bu["spinning_middle2"] = aE.object(94602826)
                    c.god(bu["spinning_middle2"], true)
                    c.attach(
                        bu["spinning_middle2"],
                        bu["spinning_1"],
                        0,
                        v3(0, 0, 1.5),
                        v3(0, 0, 0),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["spinning_middle3"] == nil then
                    a3.model(94602826)
                    bu["spinning_middle3"] = aE.object(94602826)
                    c.god(bu["spinning_middle3"], true)
                    c.attach(
                        bu["spinning_middle3"],
                        bu["spinning_1"],
                        0,
                        v3(0, 0, 3),
                        v3(0, 0, 0),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                local q = entity.get_entity_bone_index_by_name(bu["spinning_1"], "rotor_main")
                if bu["glow_1"] == nil then
                    a3.model(2655881418)
                    bu["glow_1"] = aE.object(2655881418)
                    c.god(bu["glow_1"], true)
                    c.attach(
                        bu["glow_1"],
                        bu["spinning_1"],
                        q,
                        v3(2, 3, 3),
                        v3(0, 0, 0),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["glow_2"] == nil then
                    a3.model(2655881418)
                    bu["glow_2"] = aE.object(2655881418)
                    c.god(bu["glow_2"], true)
                    c.attach(
                        bu["glow_2"],
                        bu["spinning_1"],
                        q,
                        v3(2, -3, 3),
                        v3(0, 0, 0),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["glow_3"] == nil then
                    a3.model(2655881418)
                    bu["glow_3"] = aE.object(2655881418)
                    c.god(bu["glow_3"], true)
                    c.attach(
                        bu["glow_3"],
                        bu["spinning_1"],
                        q,
                        v3(4, 0, 3),
                        v3(0, 0, 0),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["glow_4"] == nil then
                    a3.model(2655881418)
                    bu["glow_4"] = aE.object(2655881418)
                    c.god(bu["glow_4"], true)
                    c.attach(
                        bu["glow_4"],
                        bu["spinning_1"],
                        q,
                        v3(-2, 3, 3),
                        v3(0, 0, 0),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["glow_5"] == nil then
                    a3.model(2655881418)
                    bu["glow_5"] = aE.object(2655881418)
                    c.god(bu["glow_5"], true)
                    c.attach(
                        bu["glow_5"],
                        bu["spinning_1"],
                        q,
                        v3(-2, -3, 3),
                        v3(0, 0, 0),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bu["glow_6"] == nil then
                    a3.model(2655881418)
                    bu["glow_6"] = aE.object(2655881418)
                    c.god(bu["glow_6"], true)
                    c.attach(
                        bu["glow_6"],
                        bu["spinning_1"],
                        q,
                        v3(-4, 0, 3),
                        v3(0, 0, 0),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
            end
            if not k.on then
                local dy = {
                    "spinning_1",
                    "glow_1",
                    "glow_2",
                    "glow_3",
                    "glow_4",
                    "glow_5",
                    "glow_6",
                    "spinning_middle",
                    "spinning_middle2",
                    "spinning_middle3"
                }
                for i = 1, #dy do
                    if bu[dy[i]] then
                        bQ({bu[dy[i]]})
                        bu[dy[i]] = nil
                    end
                end
                return HANDLER_POP
            end
            r["rocket_propulsion"] = k.on
            return HANDLER_CONTINUE
        end
    )
    a6.t["rocket_propulsion"].on = r["rocket_propulsion"]
    a6.t["equip_weapons"] =
        a6.add.t(
        "Equip Miniguns on hands",
        a6.p["moveablerobot"],
        function(k)
            r["equip_weapons"] = k.on
            if k.on and bu["lheadtrain"] and bu["rheadtrain"] then
                if #aW["robot_weapon_left"] == 0 and #aW["robot_weapon_right"] == 0 then
                    local dz = false
                    if a6.t["spawn_preview"].on then
                        dz = true
                        a6.t["spawn_preview"].on = false
                    end
                    local dA = false
                    if a6.t["auto_get_in"].on then
                        dA = true
                        a6.t["auto_get_in"].on = false
                    end
                    local bT = C.custom_vehicles[1][2]
                    cF(bT, "robot_weapon_left")
                    cF(bT, "robot_weapon_right")
                    local dB = aW["robot_weapon_left"][1]
                    local dC = aW["robot_weapon_right"][1]
                    local dD = bu["lheadtrain"]
                    local dE = bu["rheadtrain"]
                    a3.ctrl(dB)
                    a3.ctrl(dC)
                    a3.ctrl(dD)
                    a3.ctrl(dE)
                    c.attach(dB, dD, 0, v3(0, 5, 0), v3(), true, r["robot_collision"], false, 2, true)
                    c.attach(dC, dE, 0, v3(0, 5, 0), v3(), true, r["robot_collision"], false, 2, true)
                    if dz then
                        a6.t["spawn_preview"].on = true
                    end
                    if dA then
                        a6.t["auto_get_in"].on = true
                    end
                end
            end
            if not k.on then
                if #aW["robot_weapon_left"] ~= 0 then
                    bQ(aW["robot_weapon_left"])
                    aW["robot_weapon_left"] = {}
                end
                if #aW["robot_weapon_right"] ~= 0 then
                    bQ(aW["robot_weapon_right"])
                    aW["robot_weapon_right"] = {}
                end
                return HANDLER_POP
            end
            return HANDLER_CONTINUE
        end
    )
    a6.t["equip_weapons"].on = r["equip_weapons"]
    a6.add.a(
        "Drive Robot",
        a6.p["moveablerobot"],
        function()
            if bu["tampa"] then
                ped.set_ped_into_vehicle(a5.ped(), bu["tampa"], -1)
            end
        end
    )
    a6.add.a(
        "Self Destruction",
        a6.p["moveablerobot"],
        function()
            if bu["tampa"] then
                for i = 1, #aW["robot_weapon_left"] do
                    entity.detach_entity(aW["robot_weapon_left"][i])
                    entity.freeze_entity(aW["robot_weapon_left"][i], false)
                    c.god(aW["robot_weapon_left"][i], false)
                end
                for i = 1, #aW["robot_weapon_right"] do
                    entity.detach_entity(aW["robot_weapon_right"][i])
                    entity.freeze_entity(aW["robot_weapon_right"][i], false)
                    c.god(aW["robot_weapon_right"][i], false)
                end
                for i in pairs(bu) do
                    entity.detach_entity(bu[i])
                    entity.freeze_entity(bu[i], false)
                    c.god(bu[i], false)
                end
                for i = 1, #aW["robot_weapon_left"] do
                    c.explode(c.gcoords(aW["robot_weapon_left"][i]), 8, true, false, 0, 0)
                    c.wait(33)
                end
                for i = 1, #aW["robot_weapon_right"] do
                    c.explode(c.gcoords(aW["robot_weapon_right"][i]), 8, true, false, 0, 0)
                    c.wait(33)
                end
                for i in pairs(bu) do
                    c.explode(c.gcoords(bu[i]), 8, true, false, 0, 0)
                    c.wait(33)
                end
                aW["robot_weapon_left"] = {}
                aW["robot_weapon_right"] = {}
                bu = {}
                a6.t["moveablerobot"].on = false
            end
        end
    )
    a6.p["custom_spawner"] = a6.add.p("Custom Vehicles", a6.p["custom_veh"]).id
    a6.t["spawn_preview"] =
        a6.add.t(
        "Preview Custom Vehicles",
        a6.p["custom_spawner"],
        function(k)
            if #aW["preview_veh"] > 0 and k.on then
                if ped.is_ped_in_any_vehicle(a5.ped()) then
                    ped.clear_ped_tasks_immediately(a5.ped())
                end
                local aG = a5.coords()
                if not bg then
                    for i = 1, #aW["preview_veh"] do
                        entity.set_entity_no_collsion_entity(aW["preview_veh"][i], a5.ped(), true)
                    end
                    bg = true
                end
                aG.z = aG.z + bf
                local aI = a5.heading()
                aG = cg(aG, aI, bh)
                bO(aW["preview_veh"][1], aG)
                entity.set_entity_rotation(aW["preview_veh"][1], bi)
                bi.z = bi.z + 1
                if bi.z > 360 then
                    bi.z = 0
                end
            end
            if not k.on then
                bQ(aW["preview_veh"])
                aW["preview_veh"] = {}
                bg = false
                return HANDLER_POP
            end
            return d.stop(k)
        end
    )
    a6.add.a(
        "Delete Custom Vehicles",
        a6.p["custom_spawner"],
        function()
            x("Clearing Custom Vehicles.")
            bQ(aW["custom_veh"])
            aW["custom_veh"] = {}
            bQ(aW["preview_veh"])
            aW["preview_veh"] = {}
            bg = false
            u("Cleared Custom Vehicles.")
        end
    )
    for i = 1, #C.custom_vehicles do
        a6.add.a(
            C.custom_vehicles[i][1],
            a6.p["custom_spawner"],
            function()
                local bT = C.custom_vehicles[i][2]
                cF(bT)
            end
        )
    end
    a6.p["custom_veh_opt"] = a6.add.p("Options", a6.p["custom_veh"]).id
    a6.t["auto_get_in"] =
        a6.add.t(
        "Spawn in Custom Vehicle",
        a6.p["custom_veh_opt"],
        function(k)
            r["spawn_in_vehicle"] = k.on
        end
    )
    a6.t["auto_get_in"].on = r["spawn_in_vehicle"]
    a6.t["use_own_veh"] =
        a6.add.t(
        "Use Own Vehicle for Custom ones",
        a6.p["custom_veh_opt"],
        function(k)
            r["use_own_veh"] = k.on
        end
    )
    a6.t["use_own_veh"].on = r["use_own_veh"]
    a6.t["set_godmode"] =
        a6.add.t(
        "Godmode on Custom Vehicles",
        a6.p["custom_veh_opt"],
        function(k)
            r["set_godmode"] = k.on
        end
    )
    a6.t["set_godmode"].on = r["set_godmode"]
    a6.t["disable_tampa_notify"] =
        a6.add.t(
        "Disable Moveable Robot Tampa Notify",
        a6.p["custom_veh_opt"],
        function(k)
            r["disable_tampa_notify"] = k.on
        end
    )
    a6.t["disable_tampa_notify"].on = r["disable_tampa_notify"]
    a6.p["custom_veh_builder"] = a6.add.p("Custom Vehicle Creator", a6.p["custom_veh"])
    a6.p["custom_veh_builder"].hidden = true
    local dF = {
        {
            "WarMachine",
            {
                {0x9dae1398, 1030400667, 0x2F03547B, 2971578861, 3871829598, 3229200997, 0x187D938D, 782665360},
                {0x9dae1398, nil, nil, {0, 0, 0, 0, 1}, nil, nil, nil, nil, nil, nil, 15},
                {1030400667, {0, -4, 0}, nil, {0, 0, 0, 0, 1}},
                {0x2F03547B, {0, -8, 4}, {-90, 0, 0}, {0, 0, 0, 0, 1}, false, nil, nil, nil, 0x97F5FE8D, true},
                {2971578861, {-0.3, -0.6, 9.8}, {-90, 0, 0}, nil, nil, nil, 16, 3},
                {3229200997, {0, 0, 9.8}, {-90, 0, 0}, nil, nil, nil, 16, 3},
                {0x187D938D, {0, -8.25, 5.3}, nil, {0, 0, 0, 0, 1}},
                {782665360, {0, -8, 3.1}, nil, {0, 0, 0, 0, 1}}
            }
        },
        {
            "Deer Rider",
            {
                {0xE5BA6858},
                {0xE5BA6858, nil, nil, {0, 0, 0, 0, 1}, true, nil, nil, nil, nil, nil, 3},
                {0, {0, -0.225, 0.225}, nil, nil, nil, nil, nil, nil, 0xD86B5A95}
            }
        },
        {"Attach Tree", {{3015194288}, {0}, {3015194288, {0, 0, -0.3}}}},
        {
            "XXL Plane 2",
            {
                {0x39D6E83F, 0xFB133A17, 0x3D6AAA9B, 0x810369E2, 0xD577C962},
                {0x39D6E83F, nil, nil, {0, 0, 0, 0, 1}},
                {0xFB133A17, {13, 0, 0}, {90, 0, 180}, {0, 0, 0, 0, 1}, false, nil, nil, nil, 0x97F5FE8D, true},
                {0xFB133A17, {35, 0, 0}, {90, 0, 180}, {0, 0, 0, 0, 1}, false, nil, nil, nil, 0x97F5FE8D, true},
                {0xFB133A17, {-13, 0, 0}, {90, 0, 180}, {0, 0, 0, 0, 1}, false, nil, nil, nil, 0x97F5FE8D, true},
                {0xFB133A17, {-35, 0, 0}, {90, 0, 180}, {0, 0, 0, 0, 1}, false, nil, nil, nil, 0x97F5FE8D, true},
                {0x3D6AAA9B, {-13, -3.5, 0}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {-35, -3.5, 0}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {13, -3.5, 0}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {35, -3.5, 0}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {27.5, -0.5, 0}, {0, -90, -90}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {27.5, -2.8, 0}, {0, 90, -90}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {12.4, -0.5, 0}, {0, 90, 90}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {12.4, -2.8, 0}, {0, -90, 90}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {-27.5, -0.5, 0}, {0, 90, 90}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {-27.5, -2.8, 0}, {0, -90, 90}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {-12.4, -0.5, 0}, {0, -90, -90}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {-12.4, -2.8, 0}, {0, 90, -90}, {0, 0, 0, 0, 1}},
                {0x810369E2, {0, 2, -1}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0xD577C962, {3.5, -4, -0.5}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0xD577C962, {-3.5, -4, -0.5}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0xD577C962, {0, 0, 0}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0xD577C962, {0, 0, 0}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0xD577C962, {0, 0, 0}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0xD577C962, {0, 0, 0}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0xD577C962, {0, 0, 0}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0xD577C962, {0, 0, 0}, {0, 0, 0}, {0, 0, 0, 0, 1}}
            }
        }
    }
    a6.add.a(
        "Delete Custom Vehicles",
        a6.p["custom_veh_builder"].id,
        function()
            x("Clearing Custom Vehicles.")
            bQ(aW["vehicle_builder"])
            aW["vehicle_builder"] = {}
            u("Cleared Custom Vehicles.")
        end
    )
    for i = 1, #dF do
        a6.add.a(
            dF[i][1],
            a6.p["custom_veh_builder"].id,
            function()
                local bT = dF[i][2]
                cF(bT, "vehicle_builder")
            end
        )
    end
    local dG, dH, dI, dJ, dK, dL, dM, dN
    dG =
        a6.add.u(
        "Select Vehicle",
        "autoaction_value_i",
        a6.p["custom_veh_builder"].id,
        function()
            dI.value_i = 0
            dJ.value_i = 0
            dK.value_i = 0
            dL.value_i = 0
            dM.value_i = 0
            dN.value_i = 0
        end
    )
    dG.min_i = 2
    dG.max_i = 250
    dH =
        a6.add.u(
        "Attach To BoneID",
        "autoaction_value_i",
        a6.p["custom_veh_builder"].id,
        function(k)
            local bW = v3(dI.value_i / 10, dJ.value_i / 10, dK.value_i / 10)
            local dO = v3(dL.value_i, dM.value_i, dN.value_i)
            local cC = aW["vehicle_builder"][1]
            local dP = aW["vehicle_builder"][dG.value_i]
            if cC and dP then
                a3.ctrl(cC)
                a3.ctrl(dP)
                c.attach(dP, cC, dH.value_i, bW, dO, false, false, false, 2, true)
            end
        end
    )
    dH.min_i = 0
    dH.max_i = 100
    dI =
        a6.add.u(
        "Offset X",
        "autoaction_value_i",
        a6.p["custom_veh_builder"].id,
        function(k)
            local bW = v3(k.value_i / 10, dJ.value_i / 10, dK.value_i / 10)
            local dO = v3(dL.value_i, dM.value_i, dN.value_i)
            local cC = aW["vehicle_builder"][1]
            local dP = aW["vehicle_builder"][dG.value_i]
            if cC and dP then
                a3.ctrl(cC)
                a3.ctrl(dP)
                c.attach(dP, cC, dH.value_i, bW, dO, false, false, false, 2, true)
            end
        end
    )
    dI.min_i = -500
    dI.max_i = 500
    dJ =
        a6.add.u(
        "Offset Y",
        "autoaction_value_i",
        a6.p["custom_veh_builder"].id,
        function(k)
            local bW = v3(dI.value_i / 10, k.value_i / 10, dK.value_i / 10)
            local dO = v3(dL.value_i, dM.value_i, dN.value_i)
            local cC = aW["vehicle_builder"][1]
            local dP = aW["vehicle_builder"][dG.value_i]
            if cC and dP then
                a3.ctrl(cC)
                a3.ctrl(dP)
                c.attach(dP, cC, dH.value_i, bW, dO, false, false, false, 2, true)
            end
        end
    )
    dJ.min_i = -500
    dJ.max_i = 500
    dK =
        a6.add.u(
        "Offset Z",
        "autoaction_value_i",
        a6.p["custom_veh_builder"].id,
        function(k)
            local bW = v3(dI.value_i / 10, dJ.value_i / 10, k.value_i / 10)
            local dO = v3(dL.value_i, dM.value_i, dN.value_i)
            local cC = aW["vehicle_builder"][1]
            local dP = aW["vehicle_builder"][dG.value_i]
            if cC and dP then
                a3.ctrl(cC)
                a3.ctrl(dP)
                c.attach(dP, cC, dH.value_i, bW, dO, false, false, false, 2, true)
            end
        end
    )
    dK.min_i = -500
    dK.max_i = 500
    dL =
        a6.add.u(
        "Rotation X",
        "autoaction_value_i",
        a6.p["custom_veh_builder"].id,
        function(k)
            local bW = v3(dI.value_i / 10, dJ.value_i / 10, dK.value_i / 10)
            local dO = v3(k.value_i, dM.value_i, dN.value_i)
            local cC = aW["vehicle_builder"][1]
            local dP = aW["vehicle_builder"][dG.value_i]
            if cC and dP then
                a3.ctrl(cC)
                a3.ctrl(dP)
                c.attach(dP, cC, dH.value_i, bW, dO, false, false, false, 2, true)
            end
        end
    )
    dL.min_i = -360
    dL.max_i = 360
    dM =
        a6.add.u(
        "Rotation Y",
        "autoaction_value_i",
        a6.p["custom_veh_builder"].id,
        function(k)
            local bW = v3(dI.value_i / 10, dJ.value_i / 10, dK.value_i / 10)
            local dO = v3(dL.value_i, k.value_i, dN.value_i)
            local cC = aW["vehicle_builder"][1]
            local dP = aW["vehicle_builder"][dG.value_i]
            if cC and dP then
                a3.ctrl(cC)
                a3.ctrl(dP)
                c.attach(dP, cC, dH.value_i, bW, dO, false, false, false, 2, true)
            end
        end
    )
    dM.min_i = -360
    dM.max_i = 360
    dN =
        a6.add.u(
        "Rotation Z",
        "autoaction_value_i",
        a6.p["custom_veh_builder"].id,
        function(k)
            local bW = v3(dI.value_i / 10, dJ.value_i / 10, dK.value_i / 10)
            local dO = v3(dL.value_i, dM.value_i, k.value_i)
            local cC = aW["vehicle_builder"][1]
            local dP = aW["vehicle_builder"][dG.value_i]
            if cC and dP and cC ~= dP then
                a3.ctrl(cC)
                a3.ctrl(dP)
                c.attach(dP, cC, dH.value_i, bW, dO, false, false, false, 2, true)
            end
        end
    )
    dN.min_i = -360
    dN.max_i = 360
    a6.p["exp_beam"] = a6.add.p("Explosive Beam on Horn", a6.p["parent"])
    a6.p["exp_beam"].hidden = r["explosive_beam_hidden"]
    a6.p["exp_beam"] = a6.p["exp_beam"].id
    a6.t["exp_beam"] =
        a6.add.t(
        "Enable Beam on Horn",
        a6.p["exp_beam"],
        function(k)
            r["exp_beam"] = k.on
            if k.on then
                local dQ = c.id()
                if E.scid(a6.t["exp_beam_other"].value_i) ~= -1 then
                    dQ = a6.t["exp_beam_other"].value_i
                end
                local dc = c.ped(dQ)
                local ac, aG, c6, dR, dS
                local dT = v3()
                local dU, dV, dW, dX, dY, dZ
                if player.is_player_pressing_horn(dQ) then
                    ac = c.vehicle(dc)
                    for i = 0, 5 do
                        aG = c.gcoords(ac)
                        c.wait(5)
                        if i > 0 then
                            c6 = c.gcoords(ac)
                            dT.x = c6.x - aG.x
                            dT.y = c6.y - aG.y
                            dT.z = c6.z - aG.z
                            if dT.x ~= 0 and dT.y ~= 0 and dT.z ~= 0 then
                                dR = 1 / (dT.x * dT.x + dT.y * dT.y + dT.z * dT.z) ^ 0.5
                                dS = c.random(r["exp_beam_min"], r["exp_beam_max"])
                                c6.x = c6.x + dS * dR * dT.x
                                c6.y = c6.y + dS * dR * dT.y
                                c6.z = c6.z + dS * dR * dT.z
                                dU = math.floor(c6.x - r["exp_beam_radius"])
                                dV = math.floor(c6.x + r["exp_beam_radius"])
                                dW = math.floor(c6.y - r["exp_beam_radius"])
                                dX = math.floor(c6.y + r["exp_beam_radius"])
                                dY = math.floor(c6.z - r["exp_beam_radius"])
                                dZ = math.floor(c6.z + r["exp_beam_radius"])
                                c6.x = c.random(dU, dV)
                                c6.y = c.random(dW, dX)
                                c6.z = c.random(dY, dZ)
                                c.explode(c6, r["exp_beam_type"], true, false, 0.1, dc)
                                c6.x = c.random(dU, dV)
                                c6.y = c.random(dW, dX)
                                c6.z = c.random(dY, dZ)
                                c.explode(c6, r["exp_beam_type_2"], true, false, 0.1, dc)
                            end
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    a6.t["exp_beam"].on = r["exp_beam"]
    a6.t["exp_beam_type"] =
        a6.add.u(
        "Select Explosion",
        "action_value_i",
        a6.p["exp_beam"],
        function()
            r["exp_beam_type"] = a6.t["exp_beam_type"].value_i
            u("Beam Explosion Type 1: " .. r["exp_beam_type"])
        end
    )
    a6.t["exp_beam_type"].max_i = 74
    a6.t["exp_beam_type"].min_i = 0
    a6.t["exp_beam_type"].value_i = r["exp_beam_type"]
    a6.t["exp_beam_type_2"] =
        a6.add.u(
        "Select Explosion 2",
        "action_value_i",
        a6.p["exp_beam"],
        function()
            r["exp_beam_type_2"] = a6.t["exp_beam_type_2"].value_i
            u("Beam Explosion Type 2: " .. r["exp_beam_type_2"])
        end
    )
    a6.t["exp_beam_type_2"].max_i = 74
    a6.t["exp_beam_type_2"].min_i = 0
    a6.t["exp_beam_type_2"].value_i = r["exp_beam_type_2"]
    a6.t["exp_beam_radius"] =
        a6.add.u(
        "Select Scattering",
        "action_value_i",
        a6.p["exp_beam"],
        function()
            r["exp_beam_radius"] = a6.t["exp_beam_radius"].value_i
            u("Beam Radius: " .. r["exp_beam_radius"])
        end
    )
    a6.t["exp_beam_radius"].max_i = 10
    a6.t["exp_beam_radius"].min_i = 1
    a6.t["exp_beam_radius"].value_i = r["exp_beam_radius"]
    a6.t["exp_beam_min"] =
        a6.add.u(
        "Select Min Range",
        "action_value_i",
        a6.p["exp_beam"],
        function()
            r["exp_beam_min"] = a6.t["exp_beam_min"].value_i
            u("Beam Min Range: " .. r["exp_beam_min"])
        end
    )
    a6.t["exp_beam_min"].max_i = 100
    a6.t["exp_beam_min"].min_i = 10
    a6.t["exp_beam_min"].value_i = r["exp_beam_min"]
    a6.t["exp_beam_min"].mod_i = 5
    a6.t["exp_beam_max"] =
        a6.add.u(
        "Select Max Range",
        "action_value_i",
        a6.p["exp_beam"],
        function()
            r["exp_beam_max"] = a6.t["exp_beam_max"].value_i
            u("Beam Max Range: " .. r["exp_beam_max"])
        end
    )
    a6.t["exp_beam_max"].max_i = 300
    a6.t["exp_beam_max"].min_i = 100
    a6.t["exp_beam_max"].value_i = r["exp_beam_max"]
    a6.t["exp_beam_max"].mod_i = 5
    a6.t["exp_beam_other"] =
        a6.add.u(
        "Enable Horn for Player",
        "action_value_i",
        a6.p["exp_beam"],
        function()
            if E.scid(a6.t["exp_beam_other"].value_i) ~= -1 then
                u("Selected Player: " .. E.name(a6.t["exp_beam_other"].value_i))
            else
                u("Not a valid Player.")
            end
        end
    )
    a6.t["exp_beam_other"].max_i = 31
    a6.t["exp_beam_other"].min_i = -1
    a6.t["exp_beam_other"].value_i = -1
    a6.p["bac"] =
        a6.add.p(
        "Better Animal Changer",
        a6.p["parent"],
        function()
            if a6.t["revert_outfit"].on then
                if #aX["bac_outfit"]["clothes"] < 1 then
                    if player.get_player_model(c.id()) == 0x9C9EFFD8 or player.get_player_model(c.id()) == 0x705E61F2 then
                        for i = 1, 11 do
                            aX["bac_outfit"]["textures"][i] = ped.get_ped_texture_variation(a5.ped(), i)
                            aX["bac_outfit"]["clothes"][i] = ped.get_ped_drawable_variation(a5.ped(), i)
                        end
                        local aw = {0, 1, 2, 6, 7}
                        for az = 1, #aw do
                            aX["bac_outfit"]["prop_ind"][az] = ped.get_ped_prop_index(a5.ped(), aw[az])
                            aX["bac_outfit"]["prop_text"][az] = ped.get_ped_prop_texture_index(a5.ped(), aw[az])
                        end
                        local E = "male"
                        if player.is_player_female(c.id()) then
                            E = "female"
                        end
                        aX["bac_outfit"]["gender"] = E
                    end
                end
            end
        end
    )
    a6.p["bac"].hidden = r["animal_changer_hidden"]
    a6.p["bac"] = a6.p["bac"].id
    a6.p["bac_ga"] = a6.add.p("Ground Animals", a6.p["bac"]).id
    a6.add.a(
        "Bigfoot",
        a6.p["bac_ga"],
        function()
            bZ(0x61D4C771, nil, true, nil, true)
        end
    )
    a6.add.a(
        "Bigfoot 2",
        a6.p["bac_ga"],
        function()
            bZ(0xAD340F5A, nil, true, nil, true)
        end
    )
    a6.add.a(
        "Boar",
        a6.p["bac_ga"],
        function()
            bZ(0xCE5FF074)
        end
    )
    a6.add.a(
        "Cat",
        a6.p["bac_ga"],
        function()
            bZ(0x573201B8)
        end
    )
    a6.add.a(
        "Chimp",
        a6.p["bac_ga"],
        function()
            bZ(0xA8683715, nil, nil, true)
        end
    )
    a6.add.a(
        "Chop",
        a6.p["bac_ga"],
        function()
            bZ(0x14EC17EA, nil, true)
        end
    )
    a6.add.a(
        "Cow",
        a6.p["bac_ga"],
        function()
            bZ(0xFCFA9E1E)
        end
    )
    a6.add.a(
        "Coyote",
        a6.p["bac_ga"],
        function()
            bZ(0x644AC75E)
        end
    )
    a6.add.a(
        "Deer",
        a6.p["bac_ga"],
        function()
            bZ(0xD86B5A95)
        end
    )
    a6.add.a(
        "German Shepherd",
        a6.p["bac_ga"],
        function()
            bZ(0x431FC24C, nil, true)
        end
    )
    a6.add.a(
        "Hen",
        a6.p["bac_ga"],
        function()
            bZ(0x6AF51FAF)
        end
    )
    a6.add.a(
        "Husky",
        a6.p["bac_ga"],
        function()
            bZ(0x4E8F95A2, nil, true)
        end
    )
    a6.add.a(
        "Mountain Lion",
        a6.p["bac_ga"],
        function()
            bZ(0x1250D7BA, nil, true)
        end
    )
    a6.add.a(
        "Pig",
        a6.p["bac_ga"],
        function()
            bZ(0xB11BAB56)
        end
    )
    a6.add.a(
        "Poodle",
        a6.p["bac_ga"],
        function()
            bZ(0x431D501C)
        end
    )
    a6.add.a(
        "Pug",
        a6.p["bac_ga"],
        function()
            bZ(0x6D362854)
        end
    )
    a6.add.a(
        "Rabbit",
        a6.p["bac_ga"],
        function()
            bZ(0xDFB55C81)
        end
    )
    a6.add.a(
        "Rat",
        a6.p["bac_ga"],
        function()
            bZ(0xC3B52966)
        end
    )
    a6.add.a(
        "Golden Retriever",
        a6.p["bac_ga"],
        function()
            bZ(0x349F33E1, nil, true)
        end
    )
    a6.add.a(
        "Rhesus",
        a6.p["bac_ga"],
        function()
            bZ(0xC2D06F53, nil, nil, true)
        end
    )
    a6.add.a(
        "Rottweiler",
        a6.p["bac_ga"],
        function()
            bZ(0x9563221D, nil, true)
        end
    )
    a6.add.a(
        "Westy",
        a6.p["bac_ga"],
        function()
            bZ(0xAD7844BB)
        end
    )
    a6.p["bac_wa"] =
        a6.add.p(
        "Water Animals",
        a6.p["bac"],
        function()
            u("Note that these Models will only work in Water!", 48)
        end
    ).id
    a6.add.a(
        "Dolphin",
        a6.p["bac_wa"],
        function()
            bZ(0x8BBAB455, true)
        end
    )
    a6.add.a(
        "Fish",
        a6.p["bac_wa"],
        function()
            bZ(0x2FD800B7, true)
        end
    )
    a6.add.a(
        "Hammershark",
        a6.p["bac_wa"],
        function()
            bZ(0x3C831724, true)
        end
    )
    a6.add.a(
        "Humpback",
        a6.p["bac_wa"],
        function()
            bZ(0x471BE4B2, true)
        end
    )
    a6.add.a(
        "Killerwhale",
        a6.p["bac_wa"],
        function()
            bZ(0x8D8AC8B9, true)
        end
    )
    a6.add.a(
        "Shark",
        a6.p["bac_wa"],
        function()
            bZ(0x06C3F072, true, true)
        end
    )
    a6.add.a(
        "Stingray",
        a6.p["bac_wa"],
        function()
            bZ(0xA148614D, true)
        end
    )
    a6.p["bac_fa"] = a6.add.p("Flying Animals", a6.p["bac"]).id
    a6.add.a(
        "Cormorant",
        a6.p["bac_fa"],
        function()
            bZ(0x56E29962)
        end
    )
    a6.add.a(
        "Chickenhawk",
        a6.p["bac_fa"],
        function()
            bZ(0xAAB71F62)
        end
    )
    a6.add.a(
        "Crow",
        a6.p["bac_fa"],
        function()
            bZ(0x18012A9F)
        end
    )
    a6.add.a(
        "Pigeon",
        a6.p["bac_fa"],
        function()
            bZ(0x06A20728)
        end
    )
    a6.add.a(
        "Seagull",
        a6.p["bac_fa"],
        function()
            bZ(0xD3939DFD)
        end
    )
    a6.p["bac_sm"] = a6.add.p("Standard Models", a6.p["bac"]).id
    a6.add.a(
        "Franklin",
        a6.p["bac_sm"],
        function()
            bZ(0x9B22DBAF, nil, nil, nil, true)
        end
    )
    a6.add.a(
        "Michael",
        a6.p["bac_sm"],
        function()
            bZ(0x0D7114C9, nil, nil, nil, true)
        end
    )
    a6.add.a(
        "Trevor",
        a6.p["bac_sm"],
        function()
            bZ(0x9B810FA2, nil, nil, nil, true)
        end
    )
    a6.add.a(
        "MP Female",
        a6.p["bac_sm"],
        function()
            bZ(0x9C9EFFD8, nil, true, nil, true)
        end
    )
    a6.add.a(
        "MP Male",
        a6.p["bac_sm"],
        function()
            bZ(0x705E61F2, nil, true, nil, true)
        end
    )
    a6.t["bl_mdl_change"] =
        a6.add.t(
        "Safe Model Change",
        a6.p["bac"],
        function(k)
            r["bl_mdl_change"] = k.on
        end
    )
    a6.t["bl_mdl_change"].on = r["bl_mdl_change"]
    a6.t["revert_outfit"] =
        a6.add.t(
        "Revert back Outfit",
        a6.p["bac"],
        function(k)
            r["revert_outfit"] = k.on
        end
    )
    a6.t["revert_outfit"].on = r["revert_outfit"]
    a6.add.a(
        "Fix endless loading Screen",
        a6.p["bac"],
        function()
            bZ(0x9B22DBAF, nil, nil, nil, true)
            c.wait(100)
            ped.set_ped_health(a5.ped(), 0)
        end
    )
    a6.p["ptfx"] = a6.add.p("PTFX", a6.p["parent"])
    a6.p["ptfx"].hidden = r["ptfx_hidden"]
    a6.p["ptfx"] = a6.p["ptfx"].id
    a6.t["sparkling_ass"] =
        a6.add.t(
        "Sparkling Ass",
        a6.p["ptfx"],
        function(k)
            if k.on then
                graphics.set_next_ptfx_asset("scr_indep_fireworks")
                while not graphics.has_named_ptfx_asset_loaded("scr_indep_fireworks") do
                    graphics.request_named_ptfx_asset("scr_indep_fireworks")
                    c.wait(0)
                end
                graphics.start_networked_particle_fx_non_looped_at_coord(
                    "scr_indep_firework_trail_spawn",
                    a5.coords(),
                    v3(60, 0, 0),
                    0.33,
                    true,
                    true,
                    true
                )
                c.wait(25)
            end
            r["sparkling_ass"] = k.on
            return d.stop(k)
        end
    )
    a6.t["sparkling_ass"].on = r["sparkling_ass"]
    a6.t["sparkling_tires"] =
        a6.add.t(
        "Sparkling Tires",
        a6.p["ptfx"],
        function(k)
            if k.on then
                local ac = c.vehicle(a5.ped())
                if ac ~= 0 then
                    local d_ = {"wheel_lf", "wheel_rf", "wheel_lr", "wheel_rr"}
                    for i = 1, #d_ do
                        a3.model(1803116220)
                        local e0 = aE.object(1803116220, a5.coords())
                        entity.set_entity_collision(e0, false, false, false)
                        c.visible(e0, false)
                        local q = entity.get_entity_bone_index_by_name(ac, d_[i])
                        c.attach(e0, ac, q, v3(), v3(), true, true, false, 0, true)
                        graphics.set_next_ptfx_asset("scr_indep_fireworks")
                        while not graphics.has_named_ptfx_asset_loaded("scr_indep_fireworks") do
                            graphics.request_named_ptfx_asset("scr_indep_fireworks")
                            c.wait(0)
                        end
                        graphics.start_networked_particle_fx_non_looped_at_coord(
                            "scr_indep_firework_trail_spawn",
                            c.gcoords(e0),
                            v3(60, 0, 0),
                            0.5,
                            true,
                            true,
                            true
                        )
                        a3.ctrl(e0, 5)
                        entity.detach_entity(e0)
                        entity.set_entity_velocity(e0, v3())
                        bO(e0, v3(8000, 8000, -1000))
                        entity.delete_entity(e0)
                    end
                    c.unload(1803116220)
                    c.wait(25)
                end
            end
            r["sparkling_tires"] = k.on
            return d.stop(k)
        end
    )
    a6.t["sparkling_tires"].on = r["sparkling_tires"]
    a6.t["smoke_area"] =
        a6.add.t(
        "Smoke Area",
        a6.p["ptfx"],
        function(k)
            if k.on then
                for i = 1, 16 do
                    local aG = a5.coords()
                    local e1 = 2 * math.pi
                    e1 = e1 / 16
                    e1 = e1 * i
                    aG.x = aG.x + 18 * math.cos(e1)
                    aG.y = aG.y + 18 * math.sin(e1)
                    aG.z = aG.z - 2.5
                    graphics.set_next_ptfx_asset("scr_recartheft")
                    while not graphics.has_named_ptfx_asset_loaded("scr_recartheft") do
                        graphics.request_named_ptfx_asset("scr_recartheft")
                        c.wait(0)
                    end
                    graphics.start_networked_particle_fx_non_looped_at_coord(
                        "scr_wheel_burnout",
                        aG,
                        v3(),
                        2.5,
                        true,
                        true,
                        true
                    )
                    c.wait(40)
                end
            end
            r["smoke_area"] = k.on
            return d.stop(k)
        end
    )
    a6.t["smoke_area"].on = r["smoke_area"]
    a6.t["fire_circle"] =
        a6.add.t(
        "Fire Circle",
        a6.p["ptfx"],
        function(k)
            if k.on then
                if bN["fire_balls"][1] == nil then
                    for i = 1, 48 do
                        a3.model(1803116220)
                        bN["fire_balls"][i] = aE.object(1803116220, a5.coords())
                        entity.set_entity_collision(bN["fire_balls"][i], false, false, false)
                        c.visible(bN["fire_balls"][i], false)
                    end
                    c.unload(1803116220)
                end
                for i = 1, 48 do
                    local aG = a5.coords()
                    local e1 = 2 * math.pi
                    e1 = e1 / 48
                    e1 = e1 * c.random(1, 64)
                    aG.x = aG.x + 10 * math.cos(e1)
                    aG.y = aG.y + 10 * math.sin(e1)
                    aG.z = aG.z - 1.5
                    bO(bN["fire_balls"][i], aG)
                end
                c.wait(10)
                if bN["fire_circle"][1] == nil then
                    for i = 1, 48 do
                        graphics.set_next_ptfx_asset("weap_xs_vehicle_weapons")
                        while not graphics.has_named_ptfx_asset_loaded("weap_xs_vehicle_weapons") do
                            graphics.request_named_ptfx_asset("weap_xs_vehicle_weapons")
                            c.wait(0)
                        end
                        bN["fire_circle"][i] =
                            graphics.start_ptfx_looped_on_entity(
                            "muz_xs_turret_flamethrower_looping",
                            bN["fire_balls"][i],
                            v3(),
                            v3(90, 0, 0),
                            1
                        )
                    end
                end
            end
            if not k.on then
                bQ(bN["fire_balls"])
                bN["fire_balls"] = {}
                if bN["fire_circle"][1] then
                    for i = 1, #bN["fire_circle"] do
                        graphics.remove_particle_fx(bN["fire_circle"][i], true)
                    end
                    bN["fire_circle"] = {}
                end
            end
            return d.stop(k)
        end
    )
    a6.t["fire_circle"].on = r["fire_circle"]
    a6.t["fire_fart"] =
        a6.add.u(
        "Fire Fart",
        "action_value_i",
        a6.p["ptfx"],
        function(k)
            r["fire_fart"] = a6.t["fire_fart"].value_i
            local ac = c.vehicle(a5.ped())
            if ac ~= 0 then
                u("Fire Fart in a vehicle is too dangerous, get out!", 162)
            else
                local aF = 0x187D938D
                local e2 = "weap_xs_vehicle_weapons"
                local e3 = "muz_xs_turret_flamethrower_looping"
                a3.model(aF)
                local aI = a5.heading()
                local dh = aE.vehicle(aF, a5.coords(), aI)
                a3.ctrl(dh)
                c.visible(dh, false)
                c.unload(aF)
                decorator.decor_set_int(dh, "MPBitset", 1 << 10)
                ped.set_ped_into_vehicle(a5.ped(), dh, -1)
                c.wait(500)
                graphics.set_next_ptfx_asset(e2)
                while not graphics.has_named_ptfx_asset_loaded(e2) do
                    graphics.request_named_ptfx_asset(e2)
                    c.wait(0)
                end
                local e4 = k.value_i
                local fire = graphics.start_ptfx_looped_on_entity(e3, a5.ped(), v3(), v3(180, 0, 0), e4 * 0.1)
                local aG = c.gcoords(dh)
                local cG = entity.get_entity_rotation(dh)
                local dk = cG
                dk:transformRotToDir()
                dk = dk * 1 * e4
                dk.z = aG.z + 0.6666666 * e4
                local e5 = dk
                entity.set_entity_velocity(dh, e5)
                c.wait(250 * e4)
                graphics.remove_particle_fx(fire, true)
                while ped.is_ped_in_any_vehicle(a5.ped()) do
                    ai.task_leave_vehicle(a5.ped(), dh, 16)
                    c.wait(25)
                end
                bQ({dh})
            end
        end
    )
    a6.t["fire_fart"].max_i = 16
    a6.t["fire_fart"].min_i = 4
    a6.t["fire_fart"].value_i = r["fire_fart"]
    a6.t["fire_ass"] =
        a6.add.t(
        "Fire Ass",
        a6.p["ptfx"],
        function(k)
            r["fire_ass"] = k.on
            if k.on then
                if bN["fire_ass_ball"] == nil then
                    a3.model(1803116220)
                    bN["fire_ass_ball"] = aE.object(1803116220, a5.coords())
                    entity.set_entity_collision(bN["fire_ass_ball"], false, false, false)
                    c.visible(bN["fire_ass_ball"], false)
                    c.unload(1803116220)
                end
                if bN["fire_ass"] == nil then
                    local e2 = "weap_xs_vehicle_weapons"
                    local e3 = "muz_xs_turret_flamethrower_looping"
                    graphics.set_next_ptfx_asset(e2)
                    while not graphics.has_named_ptfx_asset_loaded(e2) do
                        graphics.request_named_ptfx_asset(e2)
                        c.wait(0)
                    end
                    bN["fire_ass"] = graphics.start_ptfx_looped_on_entity(e3, a5.ped(), v3(), v3(180, 0, 0), 0.333)
                end
                local aG = a5.coords()
                bO(bN["fire_ass_ball"], a5.coords())
            end
            if not k.on then
                if bN["fire_ass"] then
                    graphics.remove_particle_fx(bN["fire_ass"], true)
                    bN["fire_ass"] = nil
                end
                bQ({bN["fire_ass_ball"]})
                bN["fire_ass_ball"] = nil
            end
            return d.stop(k)
        end
    )
    a6.t["fire_ass"].on = r["fire_ass"]
    a6.p["misc"] = a6.add.p("Miscellaneous", a6.p["parent"])
    a6.p["misc"].hidden = r["misc_hidden"]
    a6.p["misc"] = a6.p["misc"].id
    a6.p["weapon"] = a6.add.p("Weapon-Features", a6.p["misc"]).id
    a6.t["load_weapons"] =
        a6.add.t(
        "Load Weapons",
        a6.p["weapon"],
        function(k)
            if k.on then
                local time = c.time() + 500
                while k.on do
                    c.wait(0)
                    if time < c.time() then
                        break
                    end
                end
                local e6 = weapon.get_all_weapon_hashes()
                for i = 1, #e6 do
                    if weapon.has_ped_got_weapon(a5.ped(), e6[i]) then
                        local e7 = false
                        for _ = 1, #C.weapons do
                            if e6[i] == C.weapons[_][1] then
                                e7 = true
                            end
                        end
                        if not e7 then
                            weapon.remove_weapon_from_ped(a5.ped(), e6[i])
                        end
                    end
                end
                for i = 1, #C.weapons do
                    if not weapon.has_ped_got_weapon(a5.ped(), C.weapons[i][1]) then
                        weapon.give_delayed_weapon_to_ped(a5.ped(), C.weapons[i][1], 0, 0)
                    end
                end
                for i = 1, #C.weapons do
                    for cR = 2, #C.weapons[i] do
                        if not weapon.has_ped_got_weapon_component(a5.ped(), C.weapons[i][1], C.weapons[i][cR]) then
                            for d1 = 2, #C.weapons[i] do
                                weapon.give_weapon_component_to_ped(a5.ped(), C.weapons[i][1], C.weapons[i][d1])
                            end
                            weapon.set_ped_ammo(a5.ped(), C.weapons[i][1], 9999)
                        end
                    end
                end
            end
            r["load_weapons"] = k.on
            return d.stop(k)
        end
    )
    a6.t["load_weapons"].on = r["load_weapons"]
    a6.p["flamethrower"] = a6.add.p("Flamethrower", a6.p["weapon"]).id
    a6.t["flamethrower_scale"] =
        a6.add.u(
        "Scale",
        "autoaction_value_i",
        a6.p["flamethrower"],
        function()
            r["flamethrower_scale"] = a6.t["flamethrower_scale"].value_i
        end
    )
    a6.t["flamethrower_scale"].min_i = 1
    a6.t["flamethrower_scale"].max_i = 25
    a6.t["flamethrower_scale"].value_i = r["flamethrower_scale"]
    a6.t["flamethrower"] =
        a6.add.t(
        "Flamethrower",
        a6.p["flamethrower"],
        function(k)
            if k.on then
                if player.is_player_free_aiming(c.id()) then
                    graphics.set_next_ptfx_asset("weap_xs_vehicle_weapons")
                    while not graphics.has_named_ptfx_asset_loaded("weap_xs_vehicle_weapons") do
                        graphics.request_named_ptfx_asset("weap_xs_vehicle_weapons")
                        c.wait(0)
                    end
                    if bN["alien"] == nil then
                        a3.model(1803116220)
                        bN["alien"] = aE.object(1803116220, a5.coords())
                        entity.set_entity_collision(bN["alien"], false, false, false)
                        c.visible(bN["alien"], false)
                        c.unload(1803116220)
                    end
                    local e8, e9 = ped.get_ped_bone_coords(a5.ped(), 0xdead, v3())
                    while not e8 do
                        c.wait(0)
                        e8, e9 = ped.get_ped_bone_coords(a5.ped(), 0xdead, v3())
                    end
                    bO(bN["alien"], e9)
                    entity.set_entity_rotation(bN["alien"], cam.get_gameplay_cam_rot())
                    if bN["flamethrower"] == nil then
                        bN["flamethrower"] =
                            graphics.start_ptfx_looped_on_entity(
                            "muz_xs_turret_flamethrower_looping",
                            bN["alien"],
                            v3(),
                            v3(),
                            r["flamethrower_scale"]
                        )
                        graphics.set_particle_fx_looped_scale(bN["flamethrower"], r["flamethrower_scale"])
                    end
                else
                    if bN["flamethrower"] then
                        graphics.remove_particle_fx(bN["flamethrower"], true)
                        bN["flamethrower"] = nil
                        bQ({bN["alien"]})
                        bN["alien"] = nil
                    end
                end
            end
            if not k.on then
                if bN["flamethrower"] then
                    graphics.remove_particle_fx(bN["flamethrower"], true)
                    bN["flamethrower"] = nil
                    bQ({bN["alien"]})
                    bN["alien"] = nil
                end
            end
            r["flamethrower"] = k.on
            return d.stop(k)
        end
    )
    a6.t["flamethrower"].on = r["flamethrower"]
    a6.t["flamethrower_green"] =
        a6.add.t(
        "Flamethrower - Green",
        a6.p["flamethrower"],
        function(k)
            if k.on then
                if player.is_player_free_aiming(c.id()) then
                    graphics.set_next_ptfx_asset("weap_xs_vehicle_weapons")
                    while not graphics.has_named_ptfx_asset_loaded("weap_xs_vehicle_weapons") do
                        graphics.request_named_ptfx_asset("weap_xs_vehicle_weapons")
                        c.wait(0)
                    end
                    if bN["alien"] == nil then
                        a3.model(1803116220)
                        bN["alien"] = aE.object(1803116220, a5.coords())
                        entity.set_entity_collision(bN["alien"], false, false, false)
                        c.visible(bN["alien"], false)
                        c.unload(1803116220)
                    end
                    local e8, e9 = ped.get_ped_bone_coords(a5.ped(), 0xdead, v3())
                    while not e8 do
                        c.wait(0)
                        e8, e9 = ped.get_ped_bone_coords(a5.ped(), 0xdead, v3())
                    end
                    bO(bN["alien"], e9)
                    entity.set_entity_rotation(bN["alien"], cam.get_gameplay_cam_rot())
                    if bN["flamethrower_green"] == nil then
                        bN["flamethrower_green"] =
                            graphics.start_ptfx_looped_on_entity(
                            "muz_xs_turret_flamethrower_looping_sf",
                            bN["alien"],
                            v3(),
                            v3(),
                            r["flamethrower_scale"]
                        )
                    end
                else
                    if bN["flamethrower_green"] then
                        graphics.remove_particle_fx(bN["flamethrower_green"], true)
                        bN["flamethrower_green"] = nil
                        bQ({bN["alien"]})
                        bN["alien"] = nil
                    end
                end
            end
            if not k.on then
                if bN["flamethrower_green"] then
                    graphics.remove_particle_fx(bN["flamethrower_green"], true)
                    bN["flamethrower_green"] = nil
                    bQ({bN["alien"]})
                    bN["alien"] = nil
                end
            end
            r["flamethrower_green"] = k.on
            return d.stop(k)
        end
    )
    a6.t["flamethrower_green"].on = r["flamethrower_green"]
    a6.p["shoot"] = a6.add.p("Shoot Objects", a6.p["weapon"]).id
    a6.t["shoot"] =
        a6.add.t(
        "Enable Object Shoot",
        a6.p["shoot"],
        function(k)
            if k.on then
                for i = 1, #aP do
                    if r[aP[i][1]] and ped.is_ped_shooting(a5.ped()) then
                        if #aW["shooting"] > 128 then
                            bQ(aW["shooting"])
                            aW["shooting"] = {}
                        end
                        a3.model(aP[i][2])
                        local aG = a5.coords()
                        local dk = cam.get_gameplay_cam_rot()
                        dk:transformRotToDir()
                        dk = dk * 8
                        aG = aG + dk
                        if streaming.is_model_an_object(aP[i][2]) then
                            aW["shooting"][#aW["shooting"] + 1] = aE.object(aP[i][2], aG)
                        end
                        dk = nil
                        local ea = a5.coords()
                        dk = cam.get_gameplay_cam_rot()
                        dk:transformRotToDir()
                        dk = dk * 100
                        ea = ea + dk
                        local dT = ea - aG
                        entity.apply_force_to_entity(
                            aW["shooting"][#aW["shooting"]],
                            3,
                            dT.x,
                            dT.y,
                            dT.z,
                            0.0,
                            0.0,
                            0.0,
                            true,
                            true
                        )
                    end
                end
            end
            if not k.on then
                bQ(aW["shooting"])
                aW["shooting"] = {}
            end
            r["shoot_entitys"] = k.on
            return d.stop(k)
        end
    )
    a6.t["shoot"].on = r["shoot_entitys"]
    a6.add.a(
        "Delete Objects",
        a6.p["shoot"],
        function()
            bQ(aW["shooting"])
            aW["shooting"] = {}
        end
    )
    for i = 1, #aP do
        a6.t[aP[i][1]] =
            a6.add.t(
            "Shoot " .. aP[i][1],
            a6.p["shoot"],
            function(k)
                aP[i][3] = k.on
                r[aP[i][1]] = k.on
            end
        )
        a6.t[aP[i][1]].on = r[aP[i][1]]
    end
    a6.t["delete_gun"] =
        a6.add.t(
        "Delete Gun",
        a6.p["weapon"],
        function(k)
            if k.on then
                if ped.is_ped_shooting(a5.ped()) then
                    local eb = player.get_entity_player_is_aiming_at(c.id())
                    if eb then
                        bQ({eb})
                    end
                end
            end
            r["delete_gun"] = k.on
            return d.stop(k)
        end
    )
    a6.t["delete_gun"].on = r["delete_gun"]
    a6.t["kick_gun"] =
        a6.add.t(
        "Kick Gun",
        a6.p["weapon"],
        function(k)
            if k.on then
                if ped.is_ped_shooting(a5.ped()) then
                    local ec = player.get_entity_player_is_aiming_at(c.id())
                    if ped.is_ped_a_player(ec) then
                        u("Kick-Gun hit: " .. E.name(ec))
                        c2(false, player.get_player_from_ped(ec))
                    end
                end
            end
            r["kick_gun"] = k.on
            return d.stop(k)
        end
    )
    a6.t["kick_gun"].on = r["kick_gun"]
    a6.t["demigod_gun"] =
        a6.add.t(
        "Give Demi-God for Player",
        a6.p["weapon"],
        function(k)
            if k.on then
                if ped.is_ped_shooting(a5.ped()) then
                    local ec = player.get_entity_player_is_aiming_at(c.id())
                    if ped.is_ped_a_player(ec) then
                        u("Attached Demi-God on Player: " .. E.name(ec))
                        c3(C.custom_attachments[1][2], player.get_player_from_ped(ec))
                    end
                end
            end
            r["demigod_gun"] = k.on
            return d.stop(k)
        end
    )
    a6.t["demigod_gun"].on = r["demigod_gun"]
    a6.p["model_gun"] = a6.add.p("Model Gun", a6.p["weapon"]).id
    a6.t["model_gun"] =
        a6.add.t(
        "Standard Model Gun (PEDs)",
        a6.p["model_gun"],
        function(k)
            if k.on then
                if bB then
                    c.visible(a5.ped(), false)
                    if bA then
                        c.visible(bA, true)
                    end
                else
                    c.visible(a5.ped(), true)
                end
                if player.is_player_free_aiming(c.id()) then
                    local ed = player.get_entity_player_is_aiming_at(c.id())
                    if ed ~= 0 then
                        ed = entity.get_entity_model_hash(ed)
                        if streaming.is_model_a_ped(ed) then
                            if bA then
                                bQ({bA})
                                bA = nil
                            end
                            local ee = entity.get_entity_model_hash(a5.ped())
                            if ed ~= ee then
                                bB = false
                                c.wait(50)
                                local ef = ped.get_current_ped_weapon(a5.ped())
                                bZ(ed, nil, nil, nil, true)
                                c.wait(25)
                                weapon.give_delayed_weapon_to_ped(a5.ped(), ef, 0, 1)
                            end
                        elseif streaming.is_model_a_vehicle(ed) and a6.t["model_gun_ext"].on then
                            bQ({bA})
                            bA = nil
                            bB = true
                            bA = aE.vehicle(ed, a5.coords())
                            c.attach(bA, a5.ped(), 0, v3(), v3(), true, true, false, 0, true)
                        elseif streaming.is_model_an_object(ed) and a6.t["model_gun_ext"].on then
                            bQ({bA})
                            bA = nil
                            a3.model(ed)
                            bA = aE.object(ed, a5.coords())
                            c.unload(ed)
                            bB = true
                            c.attach(bA, a5.ped(), 0, v3(), v3(), true, true, false, 0, true)
                        end
                    end
                end
            end
            if not k.on then
                bQ({bA})
                bA = nil
                c.visible(a5.ped(), true)
            end
            r["model_gun"] = k.on
            return d.stop(k)
        end
    )
    a6.t["model_gun"].on = r["model_gun"]
    a6.t["model_gun_ext"] =
        a6.add.t(
        "Add Objects and Vehicles to Model Gun",
        a6.p["model_gun"],
        function(k)
            r["model_gun_ext"] = k.on
        end
    )
    a6.t["model_gun_ext"].on = r["model_gun_ext"]
    a6.t["rapid_fire"] =
        a6.add.t(
        "Rapid Fire",
        a6.p["weapon"],
        function(k)
            if k.on then
                if player.is_player_free_aiming(c.id()) then
                    if ped.is_ped_shooting(a5.ped()) then
                        for i = 1, 20 do
                            local e8, eg = ped.get_ped_bone_coords(a5.ped(), 0x67f2, v3())
                            while not e8 do
                                e8, eg = ped.get_ped_bone_coords(a5.ped(), 0x67f2, v3())
                                c.wait(0)
                            end
                            local dk = cam.get_gameplay_cam_rot()
                            dk:transformRotToDir()
                            dk = dk * 1.5
                            eg = eg + dk
                            dk = nil
                            local eh = a5.coords()
                            dk = cam.get_gameplay_cam_rot()
                            dk:transformRotToDir()
                            dk = dk * 1500
                            eh = eh + dk
                            local ei = ped.get_current_ped_weapon(a5.ped())
                            gameplay.shoot_single_bullet_between_coords(eg, eh, 1, ei, a5.ped(), true, false, 1000)
                            c.wait(25)
                        end
                    end
                end
            end
            r["rapid_fire"] = k.on
            return d.stop(k)
        end
    )
    a6.t["rapid_fire"].on = r["rapid_fire"]
    a6.t["teleport_high_in_air"] =
        a6.add.a(
        "Teleport High in Air",
        a6.p["misc"],
        function()
            local aG = a5.coords()
            while aG.z < 25000 do
                aG.z = aG.z + 500
                bV(aG)
                c.wait(50)
            end
        end
    )
    a6.p["vehicle"] = a6.add.p("Vehicle", a6.p["misc"]).id
    a6.t["tp_own_veh_to_me"] =
        a6.add.a(
        "Teleport Own Vehicle to me",
        a6.p["vehicle"],
        function()
            local ac = player.get_personal_vehicle()
            local ej = c.vehicle(a5.ped())
            if ac ~= 0 and ej ~= ac then
                bO(ac, cg(a5.coords(), a5.heading(), 5))
                entity.set_entity_heading(ac, a5.heading())
            end
        end
    )
    a6.t["tp_own_veh_to_me_drive"] =
        a6.add.a(
        "Teleport Own Vehicle to me and drive",
        a6.p["vehicle"],
        function()
            local ac = player.get_personal_vehicle()
            local ej = c.vehicle(a5.ped())
            if ac ~= 0 and ej ~= ac then
                bO(ac, a5.coords())
                entity.set_entity_heading(ac, a5.heading())
                ped.set_ped_into_vehicle(a5.ped(), ac, -1)
            end
        end
    )
    a6.t["drive_own_veh"] =
        a6.add.a(
        "Drive Own Vehicle",
        a6.p["vehicle"],
        function()
            local ac = player.get_personal_vehicle()
            local ej = c.vehicle(a5.ped())
            if ac ~= 0 and ej ~= ac then
                ped.set_ped_into_vehicle(a5.ped(), ac, -1)
            end
        end
    )
    a6.t["tp_to_own_veh"] =
        a6.add.a(
        "Teleport to Own Vehicle",
        a6.p["vehicle"],
        function()
            local ac = player.get_personal_vehicle()
            local ej = c.vehicle(a5.ped())
            x(ac)
            x(ej)
            if ac ~= 0 and ej ~= ac then
                bV(cg(c.gcoords(ac), entity.get_entity_heading(ac), -5), 0, entity.get_entity_heading(ac))
            end
        end
    )
    a6.t["always_apply_mods"] =
        a6.add.t(
        "Always apply Vehicle Mods",
        a6.p["vehicle"],
        function(k)
            r["always_apply_mods"] = k.on
        end
    )
    a6.t["always_apply_mods"].on = r["always_apply_mods"]
    a6.p["vehicle_colors"] = a6.add.p("Vehicle Colors", a6.p["vehicle"]).id
    a6.t["light_speed"] =
        a6.add.u(
        "Set Speed in Milliseconds",
        "autoaction_value_i",
        a6.p["vehicle_colors"],
        function(k)
            r["veh_lights_speed"] = k.value_i
        end
    )
    a6.t["light_speed"].min_i = 25
    a6.t["light_speed"].max_i = 2500
    a6.t["light_speed"].mod_i = 25
    a6.t["light_speed"].value_i = r["veh_lights_speed"]
    a6.p["random_col"] = a6.add.p("Random Colors", a6.p["vehicle_colors"]).id
    a6.t["random_primary"] =
        a6.add.t(
        "Random Primary",
        a6.p["random_col"],
        function(k)
            if k.on then
                cj(bd)
                cj({"rainbow_primary"})
                local ac = c.vehicle(a5.ped())
                if aa.vehicle(ac) then
                    a3.ctrl(ac)
                    vehicle.set_vehicle_custom_primary_colour(ac, c.random(0, 0xffffff))
                    c.wait(a6.t["light_speed"].value_i)
                end
            end
            r["random_primary"] = k.on
            return d.stop(k)
        end
    )
    a6.t["random_primary"].on = r["random_primary"]
    a6.t["random_secondary"] =
        a6.add.t(
        "Random Secondary",
        a6.p["random_col"],
        function(k)
            if k.on then
                cj(bd)
                cj({"rainbow_secondary"})
                local ac = c.vehicle(a5.ped())
                if aa.vehicle(ac) then
                    a3.ctrl(ac)
                    vehicle.set_vehicle_custom_secondary_colour(ac, c.random(0, 0xffffff))
                    c.wait(a6.t["light_speed"].value_i)
                end
            end
            r["random_secondary"] = k.on
            return d.stop(k)
        end
    )
    a6.t["random_secondary"].on = r["random_secondary"]
    a6.t["random_pearlescent"] =
        a6.add.t(
        "Random Pearlescent",
        a6.p["random_col"],
        function(k)
            if k.on then
                cj(bd)
                cj({"rainbow_pearlescent"})
                local ac = c.vehicle(a5.ped())
                if aa.vehicle(ac) then
                    a3.ctrl(ac)
                    vehicle.set_vehicle_custom_pearlescent_colour(ac, c.random(0, 0xffffff))
                    c.wait(a6.t["light_speed"].value_i)
                end
            end
            r["random_pearlescent"] = k.on
            return d.stop(k)
        end
    )
    a6.t["random_pearlescent"].on = r["random_pearlescent"]
    a6.t["random_neon"] =
        a6.add.t(
        "Random Neon Lights",
        a6.p["random_col"],
        function(k)
            if k.on then
                cj(bd)
                cj({"rainbow_neon"})
                local ac = c.vehicle(a5.ped())
                if aa.vehicle(ac) then
                    a3.ctrl(ac)
                    local v = c.random(0, 0xffffff)
                    vehicle.set_vehicle_neon_lights_color(ac, v)
                    c.wait(a6.t["light_speed"].value_i)
                end
            end
            r["random_neon"] = k.on
            return d.stop(k)
        end
    )
    a6.t["random_neon"].on = r["random_neon"]
    a6.t["random_smoke"] =
        a6.add.t(
        "Random Smoke",
        a6.p["random_col"],
        function(k)
            if k.on then
                cj(bd)
                cj({"rainbow_smoke"})
                local ac = c.vehicle(a5.ped())
                if aa.vehicle(ac) then
                    a3.ctrl(ac)
                    local ek = c.random(0, 255)
                    local el = c.random(0, 255)
                    local em = c.random(0, 255)
                    vehicle.set_vehicle_tire_smoke_color(ac, ek, el, em)
                    c.wait(a6.t["light_speed"].value_i)
                end
            end
            r["random_smoke"] = k.on
            return d.stop(k)
        end
    )
    a6.t["random_smoke"].on = r["random_smoke"]
    a6.t["random_xenon"] =
        a6.add.t(
        "Random Xenon",
        a6.p["random_col"],
        function(k)
            if k.on then
                cj(bd)
                cj({"rainbow_xenon"})
                local ac = c.vehicle(a5.ped())
                if aa.vehicle(ac) then
                    a3.ctrl(ac)
                    vehicle.set_vehicle_headlight_color(ac, c.random(0, 12))
                    c.wait(a6.t["light_speed"].value_i)
                end
            end
            r["random_xenon"] = k.on
            return d.stop(k)
        end
    )
    a6.t["random_xenon"].on = r["random_xenon"]
    a6.p["rainbow_col"] = a6.add.p("Rainbow Colors", a6.p["vehicle_colors"]).id
    a6.t["rainbow_primary"] =
        a6.add.t(
        "Rainbow Primary",
        a6.p["rainbow_col"],
        function(k)
            if k.on then
                cj(bd)
                cj({"random_primary"})
                local ac = c.vehicle(a5.ped())
                if aa.vehicle(ac) then
                    a3.ctrl(ac)
                    for i = 1, #aQ do
                        vehicle.set_vehicle_custom_primary_colour(ac, d.rgbtohex({aQ[i][1], aQ[i][2], aQ[i][3]}))
                        c.wait(a6.t["light_speed"].value_i)
                    end
                end
            end
            r["rainbow_primary"] = k.on
            return d.stop(k)
        end
    )
    a6.t["rainbow_primary"].on = r["rainbow_primary"]
    a6.t["rainbow_secondary"] =
        a6.add.t(
        "Rainbow Secondary",
        a6.p["rainbow_col"],
        function(k)
            if k.on then
                cj(bd)
                cj({"random_secondary"})
                local ac = c.vehicle(a5.ped())
                if aa.vehicle(ac) then
                    a3.ctrl(ac)
                    for i = 1, #aQ do
                        vehicle.set_vehicle_custom_secondary_colour(ac, d.rgbtohex({aQ[i][1], aQ[i][2], aQ[i][3]}))
                        c.wait(a6.t["light_speed"].value_i)
                    end
                end
            end
            r["rainbow_secondary"] = k.on
            return d.stop(k)
        end
    )
    a6.t["rainbow_secondary"].on = r["rainbow_secondary"]
    a6.t["rainbow_pearlescent"] =
        a6.add.t(
        "Rainbow Pearlescent",
        a6.p["rainbow_col"],
        function(k)
            if k.on then
                cj(bd)
                cj({"random_pearlescent"})
                local ac = c.vehicle(a5.ped())
                if aa.vehicle(ac) then
                    a3.ctrl(ac)
                    for i = 1, #aQ do
                        vehicle.set_vehicle_custom_pearlescent_colour(ac, d.rgbtohex({aQ[i][1], aQ[i][2], aQ[i][3]}))
                        c.wait(a6.t["light_speed"].value_i)
                    end
                end
            end
            r["rainbow_pearlescent"] = k.on
            return d.stop(k)
        end
    )
    a6.t["rainbow_pearlescent"].on = r["rainbow_pearlescent"]
    a6.t["rainbow_neon"] =
        a6.add.t(
        "Rainbow Neon Lights",
        a6.p["rainbow_col"],
        function(k)
            if k.on then
                cj(bd)
                cj({"random_neon"})
                local ac = c.vehicle(a5.ped())
                if aa.vehicle(ac) then
                    a3.ctrl(ac)
                    for i = 1, #aQ do
                        vehicle.set_vehicle_neon_lights_color(ac, d.rgbtohex({aQ[i][1], aQ[i][2], aQ[i][3]}))
                        c.wait(a6.t["light_speed"].value_i)
                    end
                end
            end
            r["rainbow_neon"] = k.on
            return d.stop(k)
        end
    )
    a6.t["rainbow_neon"].on = r["rainbow_neon"]
    a6.t["rainbow_smoke"] =
        a6.add.t(
        "Rainbow Smoke",
        a6.p["rainbow_col"],
        function(k)
            if k.on then
                cj(bd)
                cj({"random_smoke"})
                local ac = c.vehicle(a5.ped())
                if aa.vehicle(ac) then
                    a3.ctrl(ac)
                    for i = 1, #aQ do
                        local cm = aQ[i]
                        vehicle.set_vehicle_tire_smoke_color(ac, cm[1], cm[2], cm[3])
                        c.wait(a6.t["light_speed"].value_i)
                    end
                end
            end
            r["rainbow_smoke"] = k.on
            return d.stop(k)
        end
    )
    a6.t["rainbow_smoke"].on = r["rainbow_smoke"]
    a6.t["rainbow_xenon"] =
        a6.add.t(
        "Rainbow Xenon",
        a6.p["rainbow_col"],
        function(k)
            if k.on then
                cj(bd)
                cj({"random_xenon"})
                local ac = c.vehicle(a5.ped())
                if aa.vehicle(ac) then
                    a3.ctrl(ac)
                    for i = 0, 12 do
                        vehicle.set_vehicle_headlight_color(ac, i)
                        c.wait(a6.t["light_speed"].value_i)
                    end
                end
            end
            r["rainbow_xenon"] = k.on
            return d.stop(k)
        end
    )
    a6.t["rainbow_xenon"].on = r["rainbow_xenon"]
    a6.t["synced_random"] =
        a6.add.t(
        "Synced Random Colors",
        a6.p["vehicle_colors"],
        function(k)
            if k.on then
                cj(bc)
                cj(bb)
                cj({"synced_rainbow_smooth", "synced_rainbow"})
                local ac = c.vehicle(a5.ped())
                if aa.vehicle(ac) then
                    cl(ac, {c.random(0, 255), c.random(0, 255), c.random(0, 255)})
                    c.wait(a6.t["light_speed"].value_i)
                end
            end
            r["synced_random"] = k.on
            return d.stop(k)
        end
    )
    a6.t["synced_random"].on = r["synced_random"]
    a6.t["synced_rainbow"] =
        a6.add.t(
        "Synced Rainbow Colors",
        a6.p["vehicle_colors"],
        function(k)
            if k.on then
                cj(bc)
                cj(bb)
                cj({"synced_random", "synced_rainbow_smooth"})
                local ac = c.vehicle(a5.ped())
                if aa.vehicle(ac) then
                    for i = 1, #aQ do
                        local cm = aQ[i]
                        cl(ac, {cm[1], cm[2], cm[3]}, i)
                        c.wait(a6.t["light_speed"].value_i)
                    end
                end
            end
            r["synced_rainbow"] = k.on
            return d.stop(k)
        end
    )
    a6.t["synced_rainbow"].on = r["synced_rainbow"]
    a6.t["synced_rainbow_smooth"] =
        a6.add.t(
        "Synced Smooth Rainbow",
        a6.p["vehicle_colors"],
        function(k)
            if k.on then
                cj(bc)
                cj(bb)
                cj({"synced_random", "synced_rainbow"})
                local ac = c.vehicle(a5.ped())
                if aa.vehicle(ac) then
                    local en
                    en = math.floor((101 - a6.t["light_speed"].value_i / 25) / 2)
                    if en < 1 then
                        en = 1
                    end
                    for i = 0, 255, en do
                        cl(ac, {255, i, 0})
                    end
                    en = math.floor((101 - a6.t["light_speed"].value_i / 25) / 2)
                    if en < 1 then
                        en = 1
                    end
                    for i = 255, 0, -en do
                        cl(ac, {i, 255, 0})
                    end
                    en = math.floor((101 - a6.t["light_speed"].value_i / 25) / 2)
                    if en < 1 then
                        en = 1
                    end
                    for i = 0, 255, en do
                        cl(ac, {0, 255, i})
                    end
                    en = math.floor((101 - a6.t["light_speed"].value_i / 25) / 2)
                    if en < 1 then
                        en = 1
                    end
                    for i = 255, 0, -en do
                        cl(ac, {0, i, 255})
                    end
                    en = math.floor((101 - a6.t["light_speed"].value_i / 25) / 2)
                    if en < 1 then
                        en = 1
                    end
                    for i = 0, 255, en do
                        cl(ac, {i, 0, 255})
                    end
                    en = math.floor((101 - a6.t["light_speed"].value_i / 25) / 2)
                    if en < 1 then
                        en = 1
                    end
                    for i = 255, 0, -en do
                        cl(ac, {255, 0, i})
                    end
                end
            end
            r["synced_rainbow_smooth"] = k.on
            return d.stop(k)
        end
    )
    a6.t["synced_rainbow_smooth"].on = r["synced_rainbow_smooth"]
    a6.add.a(
        "100% Black",
        a6.p["vehicle_colors"],
        function()
            local ac = c.vehicle(a5.ped())
            if aa.vehicle(ac) then
                cl(ac, {0, 0, 0}, 0)
            else
                u("Get in a valid Vehicle!", 173)
            end
        end
    )
    a6.t["black_100"] =
        a6.add.t(
        "100% Black",
        a6.p["vehicle_colors"],
        function(k)
            if k.on then
                cj(bc)
                cj(bb)
                cj(bd)
                cj({"fade_black_red"})
                local ac = c.vehicle(a5.ped())
                if aa.vehicle(ac) then
                    cl(ac, {0, 0, 0}, 0)
                end
            end
            r["black_100"] = k.on
            return d.stop(k)
        end
    )
    a6.t["black_100"].on = r["black_100"]
    a6.t["fade_black_red"] =
        a6.add.t(
        "Fade Black-Red",
        a6.p["vehicle_colors"],
        function(k)
            if k.on then
                cj(bc)
                cj(bb)
                cj(bd)
                cj({"black_100"})
                local ac = c.vehicle(a5.ped())
                if aa.vehicle(ac) then
                    local en
                    en = math.floor((101 - a6.t["light_speed"].value_i / 25) / 2)
                    if en < 1 then
                        en = 1
                    end
                    for i = 0, 255, en do
                        cl(ac, {i, 0, 0}, 0, 8)
                    end
                    en = math.floor((101 - a6.t["light_speed"].value_i / 25) / 2)
                    if en < 1 then
                        en = 1
                    end
                    for i = 255, 0, -en do
                        cl(ac, {i, 0, 0}, 0, 8)
                    end
                end
            end
            r["fade_black_red"] = k.on
            return d.stop(k)
        end
    )
    a6.t["fade_black_red"].on = r["fade_black_red"]
    a6.t["heli"] =
        a6.add.u(
        "Heli Blades Speed 0-100%",
        "value_i",
        a6.p["vehicle"],
        function(k)
            r["heli"] = k.on
            r["heli_i"] = k.value_i
            local ac = c.vehicle(a5.ped())
            if k.on then
                if aa.vehicle(ac) then
                    a3.ctrl(ac)
                    local cT = k.value_i / 100
                    vehicle.set_heli_blades_speed(ac, cT)
                end
            end
            return d.stop(k)
        end
    )
    a6.t["heli"].max_i = 100
    a6.t["heli"].min_i = 0
    a6.t["heli"].mod_i = 5
    a6.t["heli"].value_i = r["heli_i"]
    a6.t["heli"].on = r["heli"]
    a6.t["sel_boost_speed"] =
        a6.add.u(
        "Boost Vehicle",
        "value_i",
        a6.p["vehicle"],
        function(k)
            r["sel_boost_speed"] = k.on
            r["sel_boost_speed_speed"] = k.value_i
            local ac = c.vehicle(a5.ped())
            if k.on then
                if aa.vehicle(ac) then
                    a3.ctrl(ac)
                    entity.set_entity_max_speed(ac, k.value_i)
                    vehicle.set_vehicle_forward_speed(ac, k.value_i)
                end
            end
            if not k.on then
                entity.set_entity_max_speed(ac, 540)
            end
            return d.stop(k)
        end
    )
    a6.t["sel_boost_speed"].max_i = 50000
    a6.t["sel_boost_speed"].min_i = 0
    a6.t["sel_boost_speed"].mod_i = 50
    a6.t["sel_boost_speed"].value_i = r["sel_boost_speed_speed"]
    a6.t["sel_boost_speed"].on = r["sel_boost_speed"]
    a6.t["speedometer"] =
        a6.add.u(
        "License Plate Speedometer",
        "value_i",
        a6.p["vehicle"],
        function(k)
            r["speedometer"] = k.on
            r["speedometer_type"] = k.value_i
            bn = k.value_i
            if k.on then
                local ac = c.vehicle(a5.ped())
                if aa.vehicle(ac) then
                    if bn ~= bo then
                        u("Displaying Speed now with Unit:\n" .. C.speedometer_units[k.value_i][3], 96)
                    end
                    local eo = entity.get_entity_speed(ac) * C.speedometer_units[k.value_i][2]
                    if eo < 10 and eo > 0.01 then
                        eo = string.format("%.2f", eo)
                    elseif eo >= 10 and eo < 100 then
                        eo = string.format("%.1f", eo)
                    elseif eo < 0.01 and k.value_i == 7 then
                        eo = string.format("%.5f", eo)
                    else
                        eo = math.floor(eo)
                    end
                    a3.ctrl(ac)
                    vehicle.set_vehicle_number_plate_text(ac, tostring(eo) .. C.speedometer_units[k.value_i][1])
                end
            end
            bo = k.value_i
            return d.stop(k)
        end
    )
    a6.t["speedometer"].max_i = #C.speedometer_units
    a6.t["speedometer"].min_i = 1
    a6.t["speedometer"].value_i = r["speedometer_type"]
    a6.t["speedometer"].on = r["speedometer"]
    a6.t["veh_no_colision"] =
        a6.add.t(
        "No collision",
        a6.p["vehicle"],
        function(k)
            if k.on then
                local ac = c.vehicle(a5.ped())
                if aa.vehicle(ac) then
                    local ep = ped.get_all_peds()
                    for i = 1, #ep do
                        entity.set_entity_no_collsion_entity(ep[i], ac, true)
                        entity.set_entity_no_collsion_entity(ac, ep[i], true)
                    end
                    ep = object.get_all_objects()
                    for i = 1, #ep do
                        entity.set_entity_no_collsion_entity(ep[i], ac, true)
                        entity.set_entity_no_collsion_entity(ac, ep[i], true)
                    end
                    ep = vehicle.get_all_vehicles()
                    for i = 1, #ep do
                        entity.set_entity_no_collsion_entity(ep[i], ac, true)
                        entity.set_entity_no_collsion_entity(ac, ep[i], true)
                    end
                end
            end
            r["veh_no_colision"] = k.on
            return d.stop(k)
        end
    )
    a6.t["veh_no_colision"].on = r["veh_no_colision"]
    a6.t["auto_repair"] =
        a6.add.t(
        "Auto Repair Vehicle",
        a6.p["vehicle"],
        function(k)
            if k.on then
                local ac = c.vehicle(a5.ped())
                if aa.vehicle(ac) then
                    if vehicle.is_vehicle_damaged(ac) then
                        a3.ctrl(ac)
                        vehicle.set_vehicle_fixed(ac)
                        vehicle.set_vehicle_deformation_fixed(ac)
                        vehicle.set_vehicle_engine_health(ac, 1000)
                        vehicle.set_vehicle_can_be_visibly_damaged(ac, false)
                    end
                end
            end
            r["auto_repair"] = k.on
            return d.stop(k)
        end
    )
    a6.t["auto_repair"].on = r["auto_repair"]
    a6.t["drive_on_ocean"] =
        a6.add.t(
        "Drive / Walk on the Ocean",
        a6.p["misc"],
        function(k)
            if k.on then
                local aG = a5.coords()
                if bv == nil then
                    a3.model(1822550295)
                    bv = aE.object(1822550295, v3(aG.x, aG.y, -4))
                    c.visible(bv, false)
                end
                water.set_waves_intensity(-100000000)
                aG.z = -4
                bO(bv, aG)
            end
            r["drive_on_ocean"] = k.on
            if not k.on and bv then
                water.reset_waves_intensity()
                bQ({bv})
                bv = nil
            end
            return d.stop(k)
        end
    )
    a6.t["drive_on_ocean"].on = r["drive_on_ocean"]
    a6.t["drive_this_height"] =
        a6.add.t(
        "Drive / Walk this Height",
        a6.p["misc"],
        function(k)
            if k.on then
                local aG, bW
                if ped.is_ped_in_any_vehicle(a5.ped()) then
                    local ac = c.vehicle(a5.ped())
                    aG = c.gcoords(ac)
                    bW = 5.25
                else
                    aG = a5.coords()
                    bW = 5.85
                end
                if bw == nil then
                    a3.model(1822550295)
                    bx = aG.z - bW
                    bw = aE.object(1822550295, v3(aG.x, aG.y, bx))
                    c.visible(bw, false)
                end
                water.set_waves_intensity(-100000000)
                aG.z = bx
                bO(bw, aG)
            end
            r["drive_this_height"] = k.on
            if not k.on and bw then
                water.reset_waves_intensity()
                bQ({bw})
                bw = nil
                bx = nil
            end
            return d.stop(k)
        end
    )
    a6.t["drive_this_height"].on = r["drive_this_height"]
    a6.t["weird_ent"] =
        a6.add.t(
        "Weird Entity",
        a6.p["misc"],
        function(k)
            local ac = c.vehicle(a5.ped())
            local dp = a5.ped()
            if k.on then
                if ac ~= 0 and by == nil then
                    local aF = entity.get_entity_model_hash(ac)
                    by = aE.vehicle(aF, a5.coords())
                    dp = ac
                elseif by == nil then
                    by = ped.clone_ped(a5.ped())
                end
                c.visible(dp, false)
                entity.set_entity_collision(by, false, false, false)
                entity.set_entity_rotation(by, v3(c.random(-180, 180), c.random(-180, 180), c.random(-180, 180)))
                bO(by, a5.coords())
            end
            if not k.on then
                bQ({by})
                by = nil
                c.visible(dp, true)
            end
            r["weird_ent"] = k.on
            return d.stop(k)
        end
    )
    a6.t["weird_ent"].on = r["weird_ent"]
    a6.t["real_time"] =
        a6.add.t(
        "Real Time (Clientside)",
        a6.p["misc"],
        function(k)
            if k.on then
                local g = os.date("*t")
                time.set_clock_time(g.hour, g.min, g.sec)
                gameplay.clear_cloud_hat()
            end
            r["real_time"] = k.on
            return d.stop(k)
        end
    )
    a6.t["real_time"].on = r["real_time"]
    a6.t["clear_area"] =
        a6.add.t(
        "Gameplay Clear Area",
        a6.p["misc"],
        function(k)
            if k.on then
                local aG = a5.coords()
                gameplay.clear_area_of_cops(aG, 10000, true)
                gameplay.clear_area_of_peds(aG, 10000, true)
                gameplay.clear_area_of_vehicles(aG, 10000, false, false, false, false, false)
                gameplay.clear_area_of_objects(aG, 10000, 0)
                gameplay.clear_area_of_objects(aG, 10000, 1)
                gameplay.clear_area_of_objects(aG, 10000, 2)
                gameplay.clear_area_of_objects(aG, 10000, 6)
                gameplay.clear_area_of_objects(aG, 10000, 16)
                gameplay.clear_area_of_objects(aG, 10000, 17)
            end
            r["clear_area"] = k.on
            return d.stop(k)
        end
    )
    a6.t["clear_area"].on = r["clear_area"]
    a6.t["clear_area_2"] =
        a6.add.t(
        "Clear Area",
        a6.p["misc"],
        function(k)
            if k.on then
                local eq = ped.get_all_peds()
                for i = 1, #eq do
                    local er = eq[i]
                    if not ped.is_ped_a_player(er) and k.on then
                        a3.ctrl(er, 250)
                        entity.set_entity_velocity(er, v3())
                        bO(er, v3(8000, 8000, -1000))
                        entity.delete_entity(er)
                    end
                end
                eq = object.get_all_objects()
                for i = 1, #eq do
                    local er = eq[i]
                    if k.on then
                        a3.ctrl(er, 250)
                        entity.set_entity_velocity(er, v3())
                        bO(er, v3(8000, 8000, -1000))
                        entity.delete_entity(er)
                        c.wait(0)
                    end
                end
                eq = vehicle.get_all_vehicles()
                local es = {}
                for _ = 0, 31 do
                    if E.scid(_) ~= -1 then
                        local ac = c.vehicle(c.ped(_))
                        if aa.vehicle(ac) then
                            es[#es + 1] = ac
                        end
                    end
                end
                for i = 1, #eq do
                    local er = eq[i]
                    if k.on then
                        local eb = true
                        for az = 1, #es do
                            if er == es[az] then
                                eb = false
                            end
                        end
                        if eb then
                            a3.ctrl(er, 250)
                            entity.set_entity_velocity(er, v3())
                            bO(er, v3(8000, 8000, -1000))
                            entity.delete_entity(er)
                        end
                    end
                end
            end
            r["clear_area_2"] = k.on
            return d.stop(k)
        end
    )
    a6.t["clear_area_2"].on = r["clear_area_2"]
    a6.t["auto_tp_wp"] =
        a6.add.t(
        "Auto Teleport to Waypoint",
        a6.p["misc"],
        function(k)
            if k.on then
                local cY = ui.get_waypoint_coord()
                if cY.x ~= 16000 then
                    local aG = a5.coords()
                    local et = v2()
                    et.x = aG.x
                    et.y = aG.y
                    if cY:magnitude(et) > 35 then
                        u("Detected Waypoint, teleporting...", 172)
                        local a6 = a5.ped()
                        local eu = c.vehicle(a6)
                        if eu ~= 0 then
                            a6 = eu
                        end
                        local ev = 850
                        local e8, ew = gameplay.get_ground_z(v3(cY.x, cY.y, ev))
                        while not e8 do
                            ev = ev - 5
                            e8, ew = gameplay.get_ground_z(v3(cY.x, cY.y, ev))
                            if ev < -200 then
                                ev = -200
                                e8 = true
                            end
                        end
                        bV(v3(cY.x, cY.y, ew))
                    end
                end
            end
            r["auto_tp_wp"] = k.on
            return d.stop(k)
        end
    )
    a6.t["auto_tp_wp"].on = r["auto_tp_wp"]
    a6.t["ban_screen"] =
        a6.add.t(
        "You've Been Banned",
        a6.p["misc"],
        function(k)
            if k.on then
                local aG = v2()
                local c6 = v2()
                local ex = v2()
                aG.x = 0.5
                aG.y = 0.325
                c6.x = 0.5
                c6.y = 0.5
                ex.x = 0.5
                ex.y = 0.54
                ui.set_text_scale(3.0)
                ui.set_text_font(7)
                ui.set_text_centre(0)
                ui.set_text_color(255, 206, 67, 255)
                ui.set_text_outline(true)
                ui.draw_text("alert", aG)
                ui.set_text_scale(0.5)
                ui.set_text_centre(0)
                ui.set_text_color(255, 255, 255, 255)
                ui.draw_text("You have been banned from Grand Theft Auto Online permanently", c6)
                ui.set_text_scale(0.5)
                ui.set_text_centre(0)
                ui.draw_text("Return to Grand Theft Auto V", ex)
                ui.draw_rect(.5, .5, 1, 1, 0, 0, 0, 255)
                ui.draw_rect(.5, .492, .52, .0019, 255, 255, 255, 255)
                ui.draw_rect(.5, .585, .52, .0019, 255, 255, 255, 255)
            end
            return d.stop(k)
        end
    )
    a6.t["swap_seats"] =
        a6.add.u(
        "Swap Vehicle Seat",
        "autoaction_value_i",
        a6.p["misc"],
        function()
            local eu = c.vehicle(a5.ped())
            if eu ~= 0 then
                ped.set_ped_into_vehicle(a5.ped(), eu, a6.t["swap_seats"].value_i)
            end
        end
    )
    a6.t["swap_seats"].min_i = -1
    a6.t["swap_seats"].value_i = -1
    a6.t["swap_seats"].max_i = 15
    a6.p["stats"] = a6.add.p("Stats", a6.p["misc"]).id
    a6.add.a(
        "Reset Orbital-Cannon Cooldown",
        a6.p["stats"],
        function()
            local ey = aY.hashes["orbital_cannon_cd"]
            aY.set(ey[1], true, ey[2])
        end
    )
    a6.t["remove_orb_cannon_cd"] =
        a6.add.t(
        "Remove Orbital-Cannon Cooldown",
        a6.p["stats"],
        function(k)
            if k.on then
                local g = c.time() + 2000
                while g > c.time() do
                    r["remove_orb_cannon_cd"] = k.on
                    c.wait(250)
                end
                local ey = aY.hashes["orbital_cannon_cd"]
                aY.set(ey[1], true, ey[2])
            end
            r["remove_orb_cannon_cd"] = k.on
            return d.stop(k)
        end
    )
    a6.t["remove_orb_cannon_cd"].on = r["remove_orb_cannon_cd"]
    a6.add.a(
        "Fill Snacks and Armor",
        a6.p["stats"],
        function()
            local ey = aY.hashes["snacks_and_armor"]
            for i = 1, #ey do
                aY.set(ey[i][1], true, ey[i][2])
            end
            u("Filled Inventory with Snacks and Armor!", 39)
            x("Filled Inventory with Snacks and Armor!")
        end
    )
    a6.add.a(
        "Set KD (Kills / Death)",
        a6.p["stats"],
        function()
            local ez = E.input("Enter KD (Kills / Death)", 10, 5)
            if not ez then
                return HANDLER_POP
            end
            ez = c.no(ez)
            local ey = aY.hashes["kills_deaths"]
            local e4 = c.random(1000, 2000)
            local c_ = math.floor(ez * e4)
            local eA = math.floor(c_ / ez)
            x("Setting Stat " .. ey[1] .. " to: " .. c_)
            x("Setting Stat " .. ey[2] .. " to: " .. eA)
            aY.set(ey[1], false, c_)
            aY.set(ey[2], false, eA)
            u("New KD set, to update the KD, earn a legit kill or death!", 39)
        end
    )
    a6.add.a(
        "Unlock Fast-Run Ability",
        a6.p["stats"],
        function()
            local ey = aY.hashes["fast_run"]
            for i = 1, #ey do
                aY.set(ey[i], true, -1)
            end
            u("New Ability set, change lobby to show effect!", 39)
        end
    )
    a6.p["chc"] = a6.add.p("Casino Heist", a6.p["stats"]).id
    a6.add.a(
        "Teleport to Boards",
        a6.p["chc"],
        function()
            bV(v3(2712.885, -369.604, -54.781), 1, -173.626159)
        end
    )
    local eB = aY.hashes["chc"]["board1"]
    local eC = aY.hashes["chc"]["board2"]
    local eD = aY.hashes["chc"]["misc"]
    a6.add.a(
        "Reset Heist",
        a6.p["chc"],
        function()
            local ey = eC
            for i = 1, #ey do
                aY.set(ey[i][2], true, ey[i][3])
            end
            ey = eB
            for i = 1, #ey do
                aY.set(ey[i][2], true, ey[i][3])
            end
            ey = eD
            for i = 1, #ey do
                aY.set(ey[i][2], true, ey[i][3])
            end
            u("Resettet Casino Heist!", 39)
        end
    )
    a6.add.a(
        "Quick start, random",
        a6.p["chc"],
        function()
            local ey = eD
            aY.set(ey[1][2], true, ey[1][4])
            aY.set(ey[2][2], true, ey[2][4])
            ey = eB
            for i = 1, #ey do
                local o = ey[i][4]
                if ey[i][5] then
                    o = c.random(ey[i][4], ey[i][5])
                end
                aY.set(ey[i][2], true, o)
            end
            ey = eD
            aY.set(ey[3][2], true, ey[3][4])
            ey = eC
            for i = 1, #ey do
                local o = ey[i][4]
                if ey[i][5] then
                    o = c.random(ey[i][4], ey[i][5])
                end
                aY.set(ey[i][2], true, o)
            end
            ey = eD
            aY.set(ey[4][2], true, ey[4][4])
            u("Setted up Casino Heist with random execution. If you dont like it, Reset Heist and try again!", 39)
        end
    )
    a6.add.a(
        "Highest Payout (worst crew-members)",
        a6.p["chc"],
        function()
            local ey = eD
            aY.set(ey[1][2], true, ey[1][4])
            aY.set(ey[2][2], true, ey[2][4])
            ey = eB
            for i = 1, #ey do
                local o = ey[i][6] or ey[i][4]
                aY.set(ey[i][2], true, o)
            end
            ey = eD
            aY.set(ey[3][2], true, ey[3][4])
            ey = eC
            for i = 1, #ey do
                local o = ey[i][6] or ey[i][4]
                if #ey[i] == 5 then
                    o = c.random(ey[i][4], ey[i][5])
                end
                aY.set(ey[i][2], true, ey[i][4])
            end
            ey = eD
            aY.set(ey[4][2], true, ey[4][4])
            u("Setted up Casino Heist with highest Payout. If you dont like it, Reset Heist and try again!", 39)
        end
    )
    a6.p["chc_manual"] = a6.add.p("Manual Mode", a6.p["chc"]).id
    a6.add.a(
        "Reset last Approach",
        a6.p["chc_manual"],
        function()
            local ey = eD
            aY.set(ey[1][2], true, ey[1][4])
            aY.set(ey[2][2], true, ey[2][4])
        end
    )
    a6.o["chc_approach"] =
        a6.add.u(
        eB[1][1],
        "action_value_i",
        a6.p["chc_manual"],
        function(k)
            local ey = eB
            local o = k.value_i
            aY.set(ey[1][2], true, o)
        end
    )
    a6.o["chc_approach"].min_i = 1
    a6.o["chc_approach"].max_i = 3
    a6.o["chc_approach"].value_i = 1
    a6.o["chc_hard"] =
        a6.add.u(
        eB[2][1],
        "action_value_i",
        a6.p["chc_manual"],
        function(k)
            local ey = eB
            local o = k.value_i
            aY.set(ey[2][2], true, o)
        end
    )
    a6.o["chc_hard"].min_i = 1
    a6.o["chc_hard"].max_i = 3
    a6.o["chc_hard"].value_i = 1
    a6.o["chc_content"] =
        a6.add.u(
        eB[3][1],
        "action_value_i",
        a6.p["chc_manual"],
        function(k)
            aY.set(eB[3][2], true, k.value_i)
        end
    )
    a6.o["chc_content"].min_i = 0
    a6.o["chc_content"].max_i = 3
    a6.add.a(
        eB[4][1],
        a6.p["chc_manual"],
        function()
            local ey = eB
            aY.set(ey[4][2], true, ey[4][4])
        end
    )
    a6.add.a(
        eB[5][1],
        a6.p["chc_manual"],
        function()
            local ey = eB
            aY.set(ey[5][2], true, ey[5][4])
        end
    )
    a6.add.a(
        eD[3][1],
        a6.p["chc_manual"],
        function()
            local ey = eD
            aY.set(ey[3][2], true, ey[3][4])
        end
    )
    a6.add.a("Crew-Member-Weapon, Payout:", a6.p["chc_manual"])
    a6.o["chc_content_2"] =
        a6.add.u(
        eC[1][1],
        "action_value_i",
        a6.p["chc_manual"],
        function(k)
            local ey = eC
            aY.set(ey[1][2], true, k.value_i)
        end
    )
    a6.o["chc_content_2"].min_i = 0
    a6.o["chc_content_2"].max_i = 5
    a6.o["chc_content_2"].value_i = 1
    a6.add.a("Crew-Member-Driver, Payout:", a6.p["chc_manual"])
    a6.o["chc_content_3"] =
        a6.add.u(
        eC[2][1],
        "action_value_i",
        a6.p["chc_manual"],
        function(k)
            local ey = eC
            aY.set(ey[2][2], true, k.value_i)
        end
    )
    a6.o["chc_content_3"].min_i = 0
    a6.o["chc_content_3"].max_i = 5
    a6.o["chc_content_3"].value_i = 1
    a6.add.a("Crew-Member-Hacker, Payout:", a6.p["chc_manual"])
    a6.o["chc_content_4"] =
        a6.add.u(
        eC[3][1],
        "action_value_i",
        a6.p["chc_manual"],
        function(k)
            local ey = eC
            aY.set(ey[3][2], true, k.value_i)
        end
    )
    a6.o["chc_content_4"].min_i = 0
    a6.o["chc_content_4"].max_i = 5
    a6.o["chc_content_4"].value_i = 1
    a6.o["chc_content_5"] =
        a6.add.u(
        eC[4][1],
        "action_value_i",
        a6.p["chc_manual"],
        function(k)
            local ey = eC
            aY.set(ey[4][2], true, k.value_i)
        end
    )
    a6.o["chc_content_5"].min_i = 0
    a6.o["chc_content_5"].max_i = 1
    a6.o["chc_content_6"] =
        a6.add.u(
        eC[5][1],
        "action_value_i",
        a6.p["chc_manual"],
        function(k)
            local ey = eC
            aY.set(ey[5][2], true, k.value_i)
        end
    )
    a6.o["chc_content_6"].min_i = 0
    a6.o["chc_content_6"].max_i = 3
    a6.add.a(
        eC[6][1],
        a6.p["chc_manual"],
        function()
            local ey = eC
            aY.set(ey[6][2], true, ey[6][4])
        end
    )
    a6.add.a(
        eC[7][1],
        a6.p["chc_manual"],
        function()
            local ey = eC
            aY.set(ey[7][2], true, ey[7][4])
        end
    )
    a6.add.a(
        eC[8][1],
        a6.p["chc_manual"],
        function()
            local ey = eC
            aY.set(ey[8][2], true, ey[8][4])
        end
    )
    a6.o["chc_content_7"] =
        a6.add.u(
        eC[9][1],
        "action_value_i",
        a6.p["chc_manual"],
        function(k)
            local ey = eC
            aY.set(ey[9][2], true, k.value_i)
        end
    )
    a6.o["chc_content_7"].min_i = 0
    a6.o["chc_content_7"].max_i = 12
    a6.add.a(
        eD[4][1],
        a6.p["chc_manual"],
        function()
            local ey = eD
            aY.set(ey[4][2], true, ey[4][4])
        end
    )
    a6.p["cph"] = a6.add.p("Cayo Perico Heist", a6.p["stats"]).id
    a6.add.a(
        "Teleport ontop of Submarine (WIP)",
        a6.p["cph"],
        function()
            local eE = vehicle.get_all_vehicles()
            for i = 1, #eE do
                local ac = eE[i]
                local eF = decorator.decor_get_int(ac, "Player_Submarine")
                if eF ~= 0 then
                    local aG = c.gcoords(ac)
                    aG.z = 2
                    local aI = entity.get_entity_heading(ac)
                    bV(cg(aG, aI, 40), 3, aI - 180)
                end
            end
        end
    )
    a6.add.a(
        "Teleport to Heist-Table",
        a6.p["cph"],
        function()
            bV(v3(1561.042, 385.902, -49.685), 1, -178.7576)
        end
    )
    local eG = aY.hashes["cph"]
    local cC = eG["main"]
    local eH = eG["loot"]
    local eI = eG["scope"]
    a6.add.t(
        "Remove Enemys",
        a6.p["cph"],
        function(k)
            if k.on then
                local eJ = ped.get_all_peds()
                for i = 1, #eJ do
                    c.wait(5)
                    local dp = eJ[i]
                    local aF = entity.get_entity_model_hash(dp)
                    if aF == 2127932792 or aF == 1821116645 or aF == 193469166 then
                        a3.ctrl(dp, 500)
                        entity.set_entity_velocity(dp, v3())
                        bO(dp, cg(a5.coords(), a5.heading(), 4))
                        c.wait(5)
                        ped.set_ped_health(dp, 0)
                    end
                    if entity.is_entity_dead(dp) then
                        bQ({dp})
                    end
                end
                c.wait(500)
            end
            return d.stop(k)
        end
    )
    a6.add.t(
        "Remove Cams",
        a6.p["cph"],
        function(k)
            if k.on then
                local eK = object.get_all_objects()
                for i = 1, #eK do
                    c.wait(5)
                    local dp = eK[i]
                    local aF = entity.get_entity_model_hash(dp)
                    if aF == 4121760380 or aF == 3061645218 then
                        bQ({eK[i]})
                    end
                end
                c.wait(500)
            end
            return d.stop(k)
        end
    )
    a6.add.a(
        "Quick start, best Payout",
        a6.p["cph"],
        function()
            for i = 1, #eH do
                aY.set(eH[i][2], true, eH[i][3])
            end
            for i = 1, #eI do
                aY.set(eI[i][2], true, eI[i][3])
            end
            for i = 1, #cC do
                aY.set(cC[i][2], true, cC[i][3])
            end
        end
    )
    a6.add.a(
        "TP to Entrance (Fingerprint)",
        a6.p["cph"],
        function()
            bV(v3(5009.8017578125, -5750.55859375, 28.845287322998), 1, -38.5843)
        end
    )
    a6.p["player_history"] = a6.add.p("Player History", a6.p["misc"]).id
    a6.t["detect_lobby_change_for_history"] =
        a6.add.t(
        "Detect lobby change",
        a6.p["player_history"],
        function(k)
            if k.on and not r["disable_history"] then
                if ae.lobby == nil and ae.event == nil then
                    ae.parents[1] =
                        a6.add.p(
                        "Lobby 1 (1-50 Players)",
                        a6.p["player_history"],
                        function()
                            ae.add_players()
                            ae.tags(ae.parents[1])
                        end
                    )
                    a6.add.p("Lobby Information", ae.parents[1].id).hidden = true
                    ae.lobby = ae.parents[1]
                    ae.event =
                        event.add_event_listener(
                        "player_join",
                        function(O)
                            if O.player == c.id() and not r["disable_history"] then
                                ae.new_lobby(c.no(string.sub(ae.lobby.name, 7, 8)) + 1 .. " (1-50 Players)")
                                ae.start_loop = #ae.players - 1
                            end
                        end
                    )
                end
                c.wait(100)
                local W = 0
                for i = 1, #ae.parents do
                    if c.no(string.sub(ae.lobby.name, 7, 8)) == c.no(string.sub(ae.parents[i].name, 7, 7)) then
                        W = W + 1
                    end
                end
                if #ae.lobby.children >= 51 then
                    local aB = c.no(string.sub(ae.lobby.name, 7, 8))
                    aB = aB .. " (" .. W * 50 + 1 .. "-" .. W * 50 + 50 .. " Players)"
                    ae.new_lobby(aB)
                end
            end
            c.wait(250)
            return d.stop(k)
        end
    )
    a6.t["detect_lobby_change_for_history"].on = true
    a6.t["detect_lobby_change_for_history"].hidden = true
    a6.t["get_players_for_history"] =
        a6.add.t(
        "Get Players",
        a6.p["player_history"],
        function(k)
            if k.on and not r["disable_history"] then
                ae.add_players()
                c.wait(2500)
                for i = 0, 31 do
                    if c.valid(i) then
                        local aj = E.scid(i)
                        local j = E.name(i)
                        local eL = true
                        local an = aj .. ":" .. j .. ":" .. i .. ":" .. string.sub(ae.lobby.name, 7, 8)
                        for _ = ae.start_loop, #ae.players do
                            if not ae.players[_] then
                                eL = true
                            elseif an == ae.players[_]["uuid"] then
                                eL = false
                            end
                        end
                        if eL then
                            local av = {}
                            local au = {}
                            for az = 1, 11 do
                                av[az] = ped.get_ped_texture_variation(c.ped(i), az)
                                au[az] = ped.get_ped_drawable_variation(c.ped(i), az)
                            end
                            local ax = {}
                            local ay = {}
                            local aw = {0, 1, 2, 6, 7}
                            for az = 1, #aw do
                                ax[az] = ped.get_ped_prop_index(c.ped(i), aw[az])
                                ay[az] = ped.get_ped_prop_texture_index(c.ped(i), aw[az])
                            end
                            ae.players[#ae.players + 1] = {
                                ["scid"] = aj,
                                ["name"] = j,
                                ["ip"] = E.ip(i),
                                ["first_seen"] = d.time_prefix(),
                                ["is_female"] = player.is_player_female(i),
                                ["h_textures"] = av,
                                ["h_clothes"] = au,
                                ["h_prop_ind"] = ax,
                                ["h_prop_text"] = ay,
                                ["uuid"] = an,
                                ["player_id"] = i,
                                ["added"] = false
                            }
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    a6.t["get_players_for_history"].on = true
    a6.t["get_players_for_history"].hidden = true
    a6.p["utils"] = a6.add.p("Utils", a6.p["misc"]).id
    a6.p["outfits"] =
        a6.add.p(
        "Delete Custom Outfits",
        a6.p["utils"],
        function()
            u("Attention!\nDeleting cant be reverted!", 208)
            local aX = utils.get_all_files_in_directory(a["outfits"] .. "\\", "ini")
            local eM = a6.p["outfits"].children
            for i = 1, #aX do
                local eL = true
                for _ = 1, #eM do
                    if eM[_].name == aX[i] then
                        eL = false
                    end
                end
                if eL then
                    a6.add.a(
                        aX[i],
                        a6.p["outfits"].id,
                        function(k)
                            if c.f_exists(a["outfits"] .. "\\" .. aX[i]) then
                                if io.remove(a["outfits"] .. "\\" .. aX[i]) == true then
                                    x("Deleted Outfit: " .. aX[i])
                                    return HANDLER_CONTINUE
                                end
                                u("ERROR deleting the file, try again!")
                                return HANDLER_POP
                            end
                            menu.delete_feature(k.id)
                        end
                    )
                end
            end
        end
    )
    a6.p["vehicles"] =
        a6.add.p(
        "Delete Custom Vehicles",
        a6.p["utils"],
        function()
            u("Attention!\nDeleting cant be reverted!", 208)
            local eN = utils.get_all_files_in_directory(a["vehicles"] .. "\\", "ini")
            local eM = a6.p["vehicles"].children
            for i = 1, #eN do
                local eL = true
                for _ = 1, #eM do
                    if eM[_].name == eN[i] then
                        eL = false
                    end
                end
                if eL then
                    a6.add.a(
                        eN[i],
                        a6.p["vehicles"].id,
                        function(k)
                            if c.f_exists(a["vehicles"] .. "\\" .. eN[i]) then
                                if io.remove(a["vehicles"] .. "\\" .. eN[i]) then
                                    x("Deleted Vehicle: " .. aX[i])
                                    return HANDLER_CONTINUE
                                end
                                u("ERROR deleting the file, try again!")
                                return HANDLER_POP
                            end
                            menu.delete_feature(k.id)
                        end
                    )
                end
            end
        end
    )
    a6.t["auto_load"] =
        a6.add.t(
        "autoexec Scripts from folder 'autoload'",
        a6.p["utils"],
        function(k)
            r["auto_load"] = k.on
            if k.on then
                if c.d_exists(a["autoload"]) then
                    local b = utils.get_all_files_in_directory(a["autoload"], "lua")
                    if b then
                        x("Found Scripts for autoexecuting!")
                        for i = 1, #b do
                            x(b[i])
                            local eO = string.sub(b[i], 1, -5)
                            c.wait(5000)
                            if not require("\\autoload\\" .. eO) then
                                u("ERROR Loading Script " .. b[i] .. "!", 208)
                            else
                                u("Loaded Script " .. b[i] .. " succesfully!", 166)
                                x("Loaded Script " .. b[i] .. " succesfully!")
                            end
                        end
                    end
                else
                    u("No folder 'autoload' found, create a folder and place any script inside!", 174)
                end
            end
        end
    )
    a6.t["auto_load"].on = r["auto_load"]
    a6.t["leave_session"] =
        a6.add.a(
        "Leave-Session",
        a6.p["utils"],
        function()
            local time = c.time() + 8500
            while time > c.time() do
            end
        end
    )
    a6.add.t(
        "Auto-Hostkick-Yourself",
        a6.p["utils"],
        function(k)
            if k.on then
                if network.network_is_host() then
                    u("Hostkicking-Yourself!")
                    x("Hostkicking-Yourself!")
                    network.network_session_kick_player(c.id())
                end
            end
            return d.stop(k)
        end
    )
    a6.p["ipl_config"] =
        a6.add.p(
        "IPL-Loader",
        a6.p["misc"],
        function()
            if not c.f_exists(b["IPLlist"]) then
                u("No IPL-List File found.")
                u("Download '2Take1Script.zip' again and make sure you have all files!")
                bt["load_ipls"].hidden = true
                bt["range_start"].hidden = true
                bt["range_end"].hidden = true
                bt["remove_ipls"].hidden = true
            else
                bt["load_ipls"].hidden = false
                bt["range_start"].hidden = false
                bt["range_end"].hidden = false
                bt["remove_ipls"].hidden = false
            end
        end
    ).id
    bt["load_ipls"] =
        a6.add.a(
        "Load ALL IPLs from File",
        a6.p["ipl_config"],
        function()
            for eP in io.lines(b["IPLlist"]) do
                streaming.request_ipl(eP)
            end
        end
    )
    bt["range_start"] = a6.add.u("Select starting line for range", "action_value_i", a6.p["ipl_config"])
    bt["range_start"].max_i = 8550
    bt["range_start"].mod_i = 50
    bt["range_end"] = a6.add.u("Select ending line for range", "action_value_i", a6.p["ipl_config"])
    bt["range_end"].max_i = 8550
    bt["range_end"].mod_i = 50
    bt["remove_ipls"] =
        a6.add.a(
        "Remove ALL IPLs between selected Range",
        a6.p["ipl_config"],
        function()
            local b6 = 0
            local eQ = bt["range_start"].value_i
            for eP in io.lines(b["IPLlist"]) do
                if b6 == eQ then
                    eQ = eQ + 1
                    if eQ <= bt["range_end"].value_i then
                        streaming.remove_ipl(eP)
                    end
                end
                b6 = b6 + 1
            end
        end
    )
    a6.p["debug"] = a6.add.p("Dev Tools", a6.p["misc"]).id
    a6.add.a(
        "Delete Entity from Aim",
        a6.p["debug"],
        function()
            bQ({player.get_entity_player_is_aiming_at(c.id())})
        end
    )
    a6.add.a(
        "Get input Hash Key",
        a6.p["debug"],
        function()
            local eR = E.input("Enter Name(PED, OBJECT, etc)")
            if not eR then
                return HANDLER_POP
            end
            x("")
            x("******************************")
            x("String: " .. eR)
            local aF = tostring(gameplay.get_hash_key(eR))
            x("Hash: " .. aF)
            u(string.format("%s %s", eR, aF))
        end
    )
    a6.add.a(
        "Notify & Print String from file",
        a6.p["debug"],
        function()
            local eS = "slod_small_quadped"
            local eT = gameplay.get_hash_key(eS)
            x("")
            x("******************************")
            x("String: " .. eS)
            x("Hash: " .. eT)
            u("String: " .. eS)
            u("Hash: " .. eT)
        end
    )
    a6.t["print_info_from_entity"] =
        a6.add.a(
        "Print Info from Entity @Aim to file",
        a6.p["debug"],
        function()
            local d9 = player.get_entity_player_is_aiming_at(c.id())
            local eU, aG, cG
            if d9 ~= 0 then
                while d9 ~= 0 do
                    eU = entity.get_entity_model_hash(d9)
                    aG = entity.get_entity_coords(d9)
                    cG = entity.get_entity_rotation(d9)
                    x("")
                    x("Printing infos about Entity:")
                    x("******************************")
                    x("Hash: " .. eU)
                    x("Entity Type: " .. entity.get_entity_type(d9))
                    x("Entity: " .. d9)
                    x("Coords X: " .. aG.x)
                    x("Coords Y: " .. aG.y)
                    x("Coords Z: " .. aG.z)
                    x("Rot X: " .. cG.x)
                    x("Rot Y: " .. cG.y)
                    x("Rot Z: " .. cG.z)
                    x("Heading: " .. entity.get_entity_heading(d9))
                    x("Entity population_type: " .. entity.get_entity_population_type(d9))
                    if entity.is_entity_static(d9) then
                        x("Entity is static")
                    end
                    if entity.does_entity_have_drawable(d9) then
                        x("Entity has a drawable")
                    end
                    if entity.is_entity_in_water(d9) then
                        x("Entity is in water")
                    end
                    if entity.is_entity_a_ped(d9) then
                        x("Entity is a PED")
                    elseif entity.is_entity_a_vehicle(d9) then
                        x("Entity is a VEHICLE")
                    elseif entity.is_entity_an_object(d9) then
                        x("Entity is a OBJECT")
                    end
                    if entity.is_entity_dead(d9) then
                        x("Entity is DEAD")
                    end
                    if entity.is_entity_on_fire(d9) then
                        x("Entity is ON FIRE")
                    end
                    if entity.is_entity_visible(d9) then
                        x("Entity is VISIBLE")
                    else
                        x("Entity is INvisible")
                    end
                    if entity.is_entity_attached(d9) then
                        d9 = entity.get_entity_attached_to(d9)
                        x("")
                        x("Attached Entity found. Continue printing infos of Entity.")
                        x("Attached Entity Info:")
                    else
                        d9 = 0
                        x("")
                        x("")
                        x("")
                    end
                end
                u("Printed Info about Entity to file.")
            else
                u("Nothing found for Info-Printing.")
            end
        end
    )
    a6.add.a(
        "Clear 2Take1Script.log",
        a6.p["debug"],
        function()
            d.write(c.o(b["Log_file"], "w"), "Cleared 2Take1Script.log")
            u("Cleared 2Take1Script.log", 204)
        end
    )
    a6.add.a(
        "Clear Menu Log-Files",
        a6.p["debug"],
        function()
            d.write(c.o(b["Auth"], "w"), "PopstarAuth.log cleared by 2Take1Script")
            u("Cleared PopstarAuth.log", 204)
            x("Cleared PopstarAuth.log")
            d.write(c.o(b["Menu_log"], "w"), "2Take1Menu.log cleared by 2Take1Script")
            u("Cleared 2Take1Menu.log", 204)
            x("Cleared 2Take1Menu.log")
            d.write(c.o(b["Prep"], "w"), "2Take1Prep.log cleared by 2Take1Script")
            u("Cleared 2Take1Prep.log", 204)
            x("Cleared 2Take1Prep.log")
        end
    )
    a6.add.a(
        "Clear crashdumps",
        a6.p["debug"],
        function()
            local eV = utils.get_all_files_in_directory(a["dumps"], "dump")
            if eV[1] then
                u("Found dumps, deleting...", 204)
                for i = 1, #eV do
                    io.remove(a["dumps"] .. "\\" .. eV[i])
                end
                u("Cleared crashdumps.", 204)
                x("Cleared crashdumps.")
            else
                u("No dumps found.", 204)
            end
        end
    )
    a6.t["log_modder_flags"] =
        a6.add.t(
        "Log Modder Flags",
        a6.p["debug"],
        function(k)
            if k.on then
                local time = c.time() + 2500
                while time > c.time() do
                    c.wait(250)
                    r["log_modder_flags"] = k.on
                end
                for i = 0, 31 do
                    if c.valid(i) then
                        for _ = 1, #A do
                            if player.is_player_modder(i, A[_]) then
                                local aA = A[_]
                                local f = player.get_modder_flag_text(aA)
                                if ad[E.scid(i)] then
                                    if not ad[E.scid(i)][aA] then
                                        ad[E.scid(i)][aA] = true
                                        x(E.scid(i) .. ":" .. E.name(i) .. " is a Modder with Tag: " .. f)
                                    end
                                else
                                    ad[E.scid(i)] = {}
                                end
                            end
                        end
                    end
                end
            end
            r["log_modder_flags"] = k.on
            return d.stop(k)
        end
    )
    a6.t["log_modder_flags"].on = r["log_modder_flags"]
    a6.t["logger"] =
        a6.add.t(
        "Enable Log from this Lua-Script",
        a6.p["debug"],
        function(k)
            r["logger"] = k.on
        end
    )
    a6.t["logger"].on = r["logger"]
    a6.p["self"] = a6.add.p("Self", a6.p["parent"])
    a6.p["self"].hidden = r["self_hidden"]
    a6.p["self"] = a6.p["self"].id
    a6.t["random_clothes"] =
        a6.add.u(
        "Random Clothes",
        "value_i",
        a6.p["self"],
        function(k)
            if k.on then
                c.wait(math.floor(1000 / k.value_i))
                ped.set_ped_random_component_variation(a5.ped())
            end
            r["random_clothes"] = k.on
            return d.stop(k)
        end
    )
    a6.t["random_clothes"].min_i = 1
    a6.t["random_clothes"].max_i = 25
    a6.t["random_clothes"].value_i = r["random_clothes_value"]
    a6.t["random_clothes"].on = r["random_clothes"]
    a6.t["police_outfit"] =
        a6.add.t(
        "Force Police Outfit",
        a6.p["self"],
        function(k)
            if k.on then
                local E = "male"
                if player.is_player_female(c.id()) then
                    E = "female"
                end
                local eW = aX["police_outfit"][E]
                for i = 1, #eW["clothes"] do
                    ped.set_ped_component_variation(a5.ped(), i, eW["clothes"][i][2], eW["clothes"][i][1], 2)
                end
                for i = 1, #eW["props"] do
                    ped.set_ped_prop_index(a5.ped(), eW["props"][i][1], eW["props"][i][2], eW["props"][i][3], 0)
                end
                c.wait(250)
            end
            r["police_outfit"] = k.on
            return d.stop(k)
        end
    )
    a6.t["police_outfit"].on = r["police_outfit"]
    a6.p["health"] = a6.add.p("Health", a6.p["self"]).id
    a6.add.a(
        "Fill Health",
        a6.p["health"],
        function()
            local eX = player.get_player_max_health(c.id())
            local eY = player.get_player_health(c.id())
            if eX ~= eY then
                ped.set_ped_health(a5.ped(), eX)
                u("Filled health!")
            end
        end
    )
    a6.t["undead_otr"] =
        a6.add.t(
        "Undead OTR",
        a6.p["health"],
        function(k)
            if k.on then
                local eX = player.get_player_max_health(c.id())
                if eX ~= 0 then
                    ped.set_ped_max_health(a5.ped(), 0)
                end
            end
            if not k.on then
                ped.set_ped_max_health(a5.ped(), 328)
            end
            r["undead_otr"] = k.on
            return d.stop(k)
        end
    )
    a6.t["undead_otr"].on = r["undead_otr"]
    a6.t["quick_regen"] =
        a6.add.t(
        "Quick regen",
        a6.p["health"],
        function(k)
            if k.on then
                local eX = player.get_player_max_health(c.id())
                local eY = player.get_player_health(c.id())
                if eX > eY then
                    ped.set_ped_health(a5.ped(), eY + 1)
                end
            end
            r["quick_regen"] = k.on
            return d.stop(k)
        end
    )
    a6.t["quick_regen"].on = r["quick_regen"]
    a6.t["unlimited_regen"] =
        a6.add.t(
        "Unlimited health-regen!",
        a6.p["health"],
        function(k)
            if k.on then
                local eY = player.get_player_health(c.id())
                local eZ = eY + eY * 0.005
                if eZ < 500000000 then
                    ped.set_ped_health(a5.ped(), eZ)
                    ped.set_ped_max_health(a5.ped(), eZ)
                end
            end
            if not k.on and r["revert_health"] then
                ped.set_ped_max_health(a5.ped(), 328)
                ped.set_ped_health(a5.ped(), 328)
            end
            r["unlimited_regen"] = k.on
            return d.stop(k)
        end
    )
    a6.t["unlimited_regen"].on = r["unlimited_regen"]
    a6.t["revert_health"] =
        a6.add.t(
        "Revert health after disabling Unlimited-regen",
        a6.p["health"],
        function(k)
            r["revert_health"] = k.on
        end
    )
    a6.t["revert_health"].on = r["revert_health"]
    a6.p["more_health"] = a6.add.p("Health Boosts", a6.p["health"]).id
    for i = 1, #be do
        a6.add.a(
            be[i][1],
            a6.p["more_health"],
            function()
                ped.set_ped_health(a5.ped(), be[i][2])
                ped.set_ped_max_health(a5.ped(), be[i][2])
                u("Health set to:\n" .. be[i][2])
            end
        )
    end
    a6.t["do_ragdoll"] =
        a6.add.a(
        "Ragdoll",
        a6.p["self"],
        function()
            ped.set_ped_to_ragdoll(a5.ped(), 2500, 0, 0)
        end
    )
    a6.t["ragdoll"] =
        a6.add.t(
        "Ragdoll",
        a6.p["self"],
        function(k)
            if k.on then
                ped.set_ped_to_ragdoll(a5.ped(), 2500, 0, 0)
            end
            r["ragdoll"] = k.on
            return d.stop(k)
        end
    )
    a6.t["ragdoll"].on = r["ragdoll"]
    a6.p["aim_protection"] = a6.add.p("Aim Protection", a6.p["self"]).id
    a6.t["enable_aim_prot"] =
        a6.add.t(
        "Enable Aim Protection",
        a6.p["aim_protection"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    if aa.i(i) then
                        local U = player.get_entity_player_is_aiming_at(i)
                        if U ~= 0 then
                            if U == a5.ped() then
                                u(E.name(i) .. " is aiming at you!", 173)
                                local df = a5.ped()
                                if r["anonymous_punishment"] then
                                    df = c.ped(i)
                                end
                                if r["aim_prot_ragdoll"] then
                                    u("Ragdolling " .. E.name(i) .. "!", 173)
                                    x("Ragdolling " .. E.name(i) .. "!")
                                    c.explode(c.gcoords(c.ped(i)), 70, true, false, 1, df)
                                    c.wait(75)
                                end
                                if r["aim_prot_fire"] then
                                    u("Setting " .. E.name(i) .. " on fire!", 173)
                                    x("Setting " .. E.name(i) .. " on fire!")
                                    c.explode(c.gcoords(c.ped(i)), 3, true, false, 0, df)
                                    c.wait(75)
                                end
                                if r["aim_prot_kill"] then
                                    u("Killing " .. E.name(i) .. "!", 173)
                                    x("Killing " .. E.name(i) .. "!")
                                    c.explode(c.gcoords(c.ped(i)), 8, false, true, 0, df)
                                    c.wait(75)
                                end
                                if r["aim_prot_remove_weapon"] then
                                    u("Removing Weapon from " .. E.name(i) .. "!", 173)
                                    x("Removing Weapon from " .. E.name(i) .. "!")
                                    ped.set_ped_can_switch_weapons(c.ped(i), false)
                                    weapon.remove_weapon_from_ped(c.ped(i), ped.get_current_ped_weapon(c.ped(i)))
                                    ped.set_ped_can_switch_weapons(c.ped(i), false)
                                    c.wait(75)
                                end
                                if r["aim_prot_kick"] then
                                    c2(false, i)
                                end
                            end
                        end
                    end
                end
            end
            r["enable_aim_prot"] = k.on
            return d.stop(k)
        end
    )
    a6.t["enable_aim_prot"].on = r["enable_aim_prot"]
    a6.t["anonymous_punishment"] =
        a6.add.t(
        "Anonymous Punishment",
        a6.p["aim_protection"],
        function(k)
            r["anonymous_punishment"] = k.on
        end
    )
    a6.t["anonymous_punishment"].on = r["anonymous_punishment"]
    a6.t["aim_prot_ragdoll"] =
        a6.add.t(
        "Ragdoll Player",
        a6.p["aim_protection"],
        function(k)
            r["aim_prot_ragdoll"] = k.on
        end
    )
    a6.t["aim_prot_ragdoll"].on = r["aim_prot_ragdoll"]
    a6.t["aim_prot_fire"] =
        a6.add.t(
        "Set on Fire",
        a6.p["aim_protection"],
        function(k)
            r["aim_prot_fire"] = k.on
        end
    )
    a6.t["aim_prot_fire"].on = r["aim_prot_fire"]
    a6.t["aim_prot_kill"] =
        a6.add.t(
        "Kill Player",
        a6.p["aim_protection"],
        function(k)
            r["aim_prot_kill"] = k.on
        end
    )
    a6.t["aim_prot_kill"].on = r["aim_prot_kill"]
    a6.t["aim_prot_remove_weapon"] =
        a6.add.t(
        "Remove Current Weapon",
        a6.p["aim_protection"],
        function(k)
            r["aim_prot_remove_weapon"] = k.on
        end
    )
    a6.t["aim_prot_remove_weapon"].on = r["aim_prot_remove_weapon"]
    a6.t["aim_prot_kick"] =
        a6.add.t(
        "Kick Player",
        a6.p["aim_protection"],
        function(k)
            r["aim_prot_kick"] = k.on
        end
    )
    a6.t["aim_prot_kick"].on = r["aim_prot_kick"]
    a6.p["bodyguards"] = a6.add.p("Bodyguards", a6.p["self"])
    a6.p["bodyguards"].hidden = r["bodyguards_hidden"]
    a6.p["bodyguards"] = a6.p["bodyguards"].id
    a6.t["bodyguards_god"] =
        a6.add.t(
        "Godmode for Bodyguards",
        a6.p["bodyguards"],
        function(k)
            r["bodyguards_god"] = k.on
        end
    )
    a6.t["bodyguards_god"].on = r["bodyguards_god"]
    a6.t["bodyguards_health"] =
        a6.add.u(
        "Set Health of Bodyguards",
        "autoaction_value_i",
        a6.p["bodyguards"],
        function(k)
            u("Bodyguards Health set to: " .. k.value_i)
            r["bodyguards_health"] = k.value_i
        end
    )
    a6.t["bodyguards_health"].min_i = 5000
    a6.t["bodyguards_health"].max_i = 50000
    a6.t["bodyguards_health"].mod_i = 5000
    a6.t["bodyguards_health"].value_i = r["bodyguards_health"]
    a6.t["bodyguards_equip_weapon"] =
        a6.add.t(
        "Equip Bodyguards with MG",
        a6.p["bodyguards"],
        function(k)
            r["bodyguards_equip_weapon"] = k.on
        end
    )
    a6.t["bodyguards_equip_weapon"].on = r["bodyguards_equip_weapon"]
    a6.t["bodyguards_formation"] =
        a6.add.u(
        "Set Formation",
        "autoaction_value_i",
        a6.p["bodyguards"],
        function(k)
            r["bodyguards_formation_type"] = k.value_i
        end
    )
    a6.t["bodyguards_formation"].min_i = 0
    a6.t["bodyguards_formation"].max_i = 3
    a6.t["bodyguards_formation"].value_i = r["bodyguards_formation_type"]
    a6.t["bodyguards"] =
        a6.add.t(
        "Enable Bodyguards",
        a6.p["bodyguards"],
        function(k)
            if k.on then
                local e_ = player.get_player_group(c.id())
                local aF = 0x613E626C
                for i = 1, 7 do
                    if not aW["bodyguards"][i] or entity.is_entity_dead(aW["bodyguards"][i]) then
                        if aW["bodyguards"][i] and entity.is_entity_dead(aW["bodyguards"][i]) then
                            bQ({aW["bodyguards"][i]})
                        end
                        a3.model(aF)
                        aW["bodyguards"][i] = aE.ped(aF, cg(a5.coords(), a5.heading(), 4), 29)
                        c.unload(aF)
                        if a6.t["bodyguards_god"].on then
                            c.god(aW["bodyguards"][i], true)
                        else
                            ped.set_ped_max_health(aW["bodyguards"][i], a6.t["bodyguards_health"].value_i)
                            ped.set_ped_health(aW["bodyguards"][i], a6.t["bodyguards_health"].value_i)
                        end
                        local f0 = ui.add_blip_for_entity(aW["bodyguards"][i])
                        ui.set_blip_sprite(f0, 310)
                        ui.set_blip_colour(f0, 80)
                        if a6.t["bodyguards_equip_weapon"].on then
                            weapon.give_delayed_weapon_to_ped(aW["bodyguards"][i], 0x22D8FE39, 0, 1)
                            weapon.give_delayed_weapon_to_ped(aW["bodyguards"][i], 0xDBBD7280, 0, 1)
                        end
                        ped.set_ped_combat_ability(aW["bodyguards"][i], 100)
                        ped.set_ped_as_group_member(aW["bodyguards"][i], e_)
                        entity.set_entity_as_mission_entity(aW["bodyguards"][i], 1, 1)
                    end
                    if not entity.is_entity_dead(aW["bodyguards"][i]) then
                        a3.ctrl(aW["bodyguards"][i])
                        ped.set_group_formation(e_, a6.t["bodyguards_formation"].value_i)
                        if player.is_player_free_aiming(c.id()) then
                            local U = player.get_entity_player_is_aiming_at(c.id())
                            if U ~= 0 then
                                ai.task_shoot_at_entity(aW["bodyguards"][i], U, 100, 0xC6EE6B4C)
                            else
                                local aG = a5.coords()
                                local dk = cam.get_gameplay_cam_rot()
                                dk:transformRotToDir()
                                dk = dk * c.random(1, 50)
                                aG = aG + dk
                                ai.task_shoot_gun_at_coord(aW["bodyguards"][i], aG, 100, 0xC6EE6B4C)
                            end
                        end
                        if a5.coords():magnitude(c.gcoords(aW["bodyguards"][i])) > 50 then
                            bO(aW["bodyguards"][i], cg(a5.coords(), a5.heading(), -5))
                        end
                    end
                end
            end
            if not k.on then
                bQ(aW["bodyguards"])
                aW["bodyguards"] = {}
            end
            return d.stop(k)
        end
    )
    a6.p["opt"] = a6.add.p("Options", a6.p["parent"])
    a6.p["opt"].hidden = r["options_hidden"]
    a6.p["opt"] = a6.p["opt"].id
    a6.p["hotkeys"] = a6.add.p("Hotkey Settings", a6.p["opt"]).id
    a6.t["enable_hotkeys"] =
        a6.add.t(
        "Enable Hotkeys",
        a6.p["hotkeys"],
        function(k)
            r["enable_hotkeys"] = k.on
            if k.on then
                c.wait(50)
                if not c.f_exists(b["Hotkeys"]) then
                    L.overwrite_hotkeys()
                end
                for i = 1, #s[0] do
                    local f1 = s[0][i]
                    local f2 = s[f1]
                    if f2 ~= "none" then
                        local n = MenuKey()
                        n:push_str(f2)
                        if n:is_down() then
                            local f3 = a6.t[f1]
                            local f4 = f3.name
                            x(f2 .. ":'" .. f4 .. "' got pressed.")
                            if r["hotkey_notification"] then
                                u(f2 .. ":'" .. f4 .. "' got pressed.", 86)
                            end
                            if f3.type == 512 then
                                f3.on = true
                                c.wait(100)
                                f3.on = false
                            else
                                if f3.on then
                                    f3.on = false
                                else
                                    f3.on = true
                                end
                            end
                            c.wait(250)
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    a6.t["enable_hotkeys"].on = r["enable_hotkeys"]
    a6.add.a(
        "Reload 2Take1Hotkeys.ini",
        a6.p["hotkeys"],
        function()
            L.hotkeys()
            u("Reloaded Hotkeys.ini", 86)
        end
    )
    a6.t["hotkey_notification"] =
        a6.add.t(
        "Hotkey Notifications",
        a6.p["hotkeys"],
        function(k)
            r["hotkey_notification"] = k.on
        end
    )
    a6.t["hotkey_notification"].on = r["hotkey_notification"]
    a6.add.a(
        "Print active Hotkeys",
        a6.p["hotkeys"],
        function()
            for i = 1, #s[0] do
                local n = s[0][i]
                if s[n] ~= "none" then
                    u(s[n] .. ': "' .. a6.t[n].name .. '"', 86)
                end
            end
        end
    )
    a6.add.a("Overwrite / Update File - Hotkeys.ini", a6.p["hotkeys"], L.overwrite_hotkeys)
    a6.p["mwh"] = a6.add.p("Menu-Wide-Hotkeys", a6.p["opt"]).id
    local f5 = {}
    local f6 = {}
    local f7 = {}
    local f8 = c.o(b["Exclude"], "r")
    if f8 then
        for f9 in io.lines(b["Exclude"]) do
            if not string.find(f9, ";", 1) then
                f7[#f7 + 1] = f9
            end
        end
        io.close(f8)
    end
    a6.t["mwh_notify"] =
        a6.add.t(
        "Menu-Wide Hotkey Notifications",
        a6.p["mwh"],
        function(k)
            if k.on then
                c.wait(50)
                if #f5 == 0 then
                    local a0 = c.o(a["Menu"] .. "\\2Take1Menu.ini", "r")
                    if a0 then
                        local i = 1
                        for f9 in io.lines(a["Menu"] .. "\\2Take1Menu.ini") do
                            if i > 1 and i < 50 then
                                local q = ""
                                while string.find(f9, "=", 1) do
                                    q = q .. string.sub(f9, 1, 1)
                                    f9 = string.sub(f9, 2)
                                end
                                q = string.sub(q, 1, #q - 1)
                                if string.find(f9, "NOMOD+", 1) then
                                    f9 = string.gsub(f9, "NOMOD*+", "")
                                end
                                f5[i - 1] = f9
                                f6[i - 1] = q
                            end
                            i = i + 1
                        end
                        io.close(a0)
                    end
                end
                for i = 1, #f5 do
                    local f2 = f5[i]
                    local fa = f6[i]
                    local ao = f2 ~= "none"
                    local ar = true
                    if r["mwh_exclude_navigation"] then
                        if string.find(fa, "Menu", 1) then
                            ar = false
                        end
                    end
                    if r["mwh_exclude_noclip"] then
                        if string.find(fa, "NoClip", 1) then
                            ar = false
                        end
                    end
                    if r["mwh_exclude_editorrot"] then
                        if string.find(fa, "EditorRot", 1) then
                            ar = false
                        end
                    end
                    if r["mwh_exclude_file"] then
                        for _ = 1, #f7 do
                            if string.find(fa, f7[_], 1) then
                                ar = false
                            end
                        end
                    end
                    if ao and ar then
                        local n = MenuKey()
                        n:push_str(f2)
                        if n:is_down() then
                            u(f2 .. ":'" .. fa .. "' got pressed.", 86)
                            c.wait(250)
                        end
                    end
                end
            end
            r["mwh_notify"] = k.on
            return d.stop(k)
        end
    )
    a6.t["mwh_notify"].on = r["mwh_notify"]
    a6.t["mwh_exclude_navigation"] =
        a6.add.t(
        "Exclude Navigation Keys",
        a6.p["mwh"],
        function(k)
            r["mwh_exclude_navigation"] = k.on
        end
    )
    a6.t["mwh_exclude_navigation"].on = r["mwh_exclude_navigation"]
    a6.t["mwh_exclude_noclip"] =
        a6.add.t(
        "Exclude NoClip Keys",
        a6.p["mwh"],
        function(k)
            r["mwh_exclude_noclip"] = k.on
        end
    )
    a6.t["mwh_exclude_noclip"].on = r["mwh_exclude_noclip"]
    a6.t["mwh_exclude_editorrot"] =
        a6.add.t(
        "Exclude EditorRotation Keys",
        a6.p["mwh"],
        function(k)
            r["mwh_exclude_editorrot"] = k.on
        end
    )
    a6.t["mwh_exclude_editorrot"].on = r["mwh_exclude_editorrot"]
    a6.t["mwh_exclude_file"] =
        a6.add.t(
        "Exclude Keys from File",
        a6.p["mwh"],
        function(k)
            if not c.f_exists(b["Exclude"]) then
                local fb = c.o(b["Exclude"], "a")
                io.output(fb)
                io.write(";Write down each Hotkey from 2Take1Menu.ini file which should not get a notify.\n")
                io.write(';Example, the "Exit" Hotkey should not get a notify, then just add it here.\n')
                io.write(";Each excluded hotkey gets a single line:\n")
                io.write("Exit")
                io.close(fb)
                u(
                    "Edit '2Take1Exclude.ini' to exclude specific hotkeys. The file is found in '2Take1Script/Config'",
                    86
                )
            end
            r["mwh_exclude_file"] = k.on
        end
    )
    a6.t["mwh_exclude_file"].on = r["mwh_exclude_file"]
    a6.add.a(
        "Reload 2Take1Exclude.ini",
        a6.p["mwh"],
        function()
            local f8 = c.o(b["Exclude"], "r")
            if f8 then
                f7 = {}
                for f9 in io.lines(b["Exclude"]) do
                    if not string.find(f9, ";", 1) then
                        f7[#f7 + 1] = f9
                    end
                end
                io.close(f8)
                u("Reloaded Exclude Hotkeys.", 86)
            end
        end
    )
    a6.t["exclude_friends"] =
        a6.add.t(
        "Exclude Friends from Harmful Lobby Events",
        a6.p["opt"],
        function(k)
            r["exclude_friends"] = k.on
        end
    )
    a6.t["exclude_friends"].on = r["exclude_friends"]
    a6.t["attach_no_colision"] =
        a6.add.t(
        "Attached Entitys No Collision",
        a6.p["opt"],
        function(k)
            r["attach_no_colision"] = k.on
        end
    )
    a6.t["attach_no_colision"].on = r["attach_no_colision"]
    a6.t["continuously_assassins"] =
        a6.add.t(
        "Continuously Assassin Peds",
        a6.p["opt"],
        function(k)
            r["continuously_assassins"] = k.on
            if k.on and #aW["peds"] > 0 then
                if E.scid(bs) ~= -1 then
                    local U = c.ped(bs)
                    for i = 1, #aW["peds"] do
                        ai.task_goto_entity(aW["peds"][i], U, 10, 500, 500)
                        ai.task_combat_ped(aW["peds"][i], U, 0, 16)
                    end
                end
            else
                c.wait(500)
            end
            return d.stop(k)
        end
    )
    a6.t["continuously_assassins"].on = r["continuously_assassins"]
    a6.t["disable_history"] =
        a6.add.t(
        "Disable Player-History",
        a6.p["opt"],
        function(k)
            r["disable_history"] = k.on
        end
    )
    a6.t["override_notify_color"] =
        a6.add.u(
        "Force Notification Color",
        "value_i",
        a6.p["opt"],
        function(k)
            r["override_notify_color"] = k.on
            r["notify_color"] = k.value_i
        end
    )
    a6.t["override_notify_color"].max_i = 223
    a6.t["override_notify_color"].on = r["override_notify_color"]
    a6.t["override_notify_color"].value_i = r["notify_color"]
    a6.add.a(
        "Show Notification Color",
        a6.p["opt"],
        function()
            u("Example Text\nNotification color: " .. r["notify_color"])
        end
    )
    a6.t["2t1s_parent"] =
        a6.add.t(
        "2Take1Script Parent",
        a6.p["opt"],
        function(k)
            r["2t1s_parent"] = k.on
        end
    )
    a6.t["2t1s_parent"].on = r["2t1s_parent"]
    a6.t["save_config"] =
        a6.add.a(
        "Save Configuration",
        a6.p["opt"],
        function()
            local a0 = c.o(b["Config"], "w+")
            io.output(a0)
            for i = 1, #r[0] do
                local q = r[0][i]
                if not string.find(q, "section", 1) then
                    io.write(q .. "=" .. tostring(r[q]) .. "\n")
                else
                    io.write(tostring(r[q]) .. "\n")
                end
            end
            io.close(a0)
            x("Saved Configuration to file.")
            u("Saved Configuration to file.", 25)
        end
    )
    a6.p["testing_area"] = a6.add.p("Testing Area", 0)
    a6.p["testing_area"].hidden = true
    a6.p["testing_area"] = a6.p["testing_area"].id
    a6.p["entity_pools_mgr"] = a6.add.p("Entity Pools Mgr", a6.p["testing_area"]).id
    a6.p["all_vehicles"] =
        a6.add.p(
        "All Vehicles",
        a6.p["entity_pools_mgr"],
        function(k)
        end
    ).id
    a6.add.a(
        "Explode all Vehicles",
        a6.p["all_vehicles"],
        function()
            bS(vehicle.get_all_vehicles(), c.vehicle(a5.ped()))
        end
    )
    a6.add.a(
        "Delete all Vehicles",
        a6.p["all_vehicles"],
        function()
            bQ(vehicle.get_all_vehicles())
        end
    )
    a6.add.a(
        "Teleport all Vehicles to me",
        a6.p["all_vehicles"],
        function()
            local eN = vehicle.get_all_vehicles()
            for i = 1, #eN do
                if eN[i] ~= c.vehicle(a5.ped()) then
                    bO(eN[i], cg(a5.coords(), a5.heading(), 25))
                end
            end
        end
    )
    a6.p["all_vehicles_single"] =
        a6.add.p(
        "Vehicles",
        a6.p["all_vehicles"],
        function(k)
            while #k.children ~= 0 do
                c.navigate(false)
                while #k.children[1].children ~= 0 do
                    menu.delete_feature(k.children[1].children[1].id)
                end
                menu.delete_feature(k.children[1].id)
                c.wait(0)
            end
            local eN = vehicle.get_all_vehicles()
            for i = 1, #eN do
                local ac = eN[i]
                local fc = entity.get_entity_model_hash(ac)
                local j = D.veh.GetNameFromHash(fc) or "NoVehicleDataFound"
                if ac == c.vehicle(a5.ped()) then
                    j = j .. " [SELF]"
                end
                local fd = vehicle.get_ped_in_vehicle_seat(ac, -1)
                if fd and ped.is_ped_a_player(fd) then
                    local b9 = player.get_player_from_ped(fd)
                    if b9 ~= c.id() then
                        j = j .. " [" .. E.name(b9) .. "]"
                    end
                end
                local fe = a6.add.p(j, a6.p["all_vehicles_single"]).id
                a6.add.a(
                    "Teleport into Vehicle",
                    fe,
                    function()
                        if entity.is_an_entity(ac) then
                            local ff = vehicle.get_free_seat(ac)
                            ped.set_ped_into_vehicle(a5.ped(), ac, ff)
                        end
                    end
                )
                a6.add.a(
                    "Teleport Vehicle to me",
                    fe,
                    function()
                        if entity.is_an_entity(ac) then
                            if c.vehicle(a5.ped()) ~= ac then
                                bO(ac, cg(a5.coords(), a5.heading(), 5))
                            end
                        end
                    end
                )
                local fg
                a6.add.t(
                    "Line ESP",
                    fe,
                    function(k)
                        if not fg then
                            fg = true
                            u("Leaving this Feature will disable the ESP")
                        end
                        if k.on and entity.is_an_entity(ac) then
                            ui.draw_line(a5.coords(), c.gcoords(ac), 255, 0, 0, 255)
                        end
                        return d.stop(k)
                    end
                )
                c.wait(0)
            end
            c.navigate(true)
        end
    ).id
    a6.p["all_peds"] = a6.add.p("All Peds", a6.p["entity_pools_mgr"]).id
    a6.add.a(
        "Explode all Peds",
        a6.p["all_peds"],
        function()
            bS(ped.get_all_peds(), a5.ped())
        end
    )
    a6.add.a(
        "Delete all Peds",
        a6.p["all_peds"],
        function()
            bQ(ped.get_all_peds())
        end
    )
    a6.p["all_objects"] = a6.add.p("All Objects", a6.p["entity_pools_mgr"]).id
    a6.add.a(
        "Explode all Objects",
        a6.p["all_objects"],
        function()
            bS(object.get_all_objects())
        end
    )
    a6.add.a(
        "Delete all Objects",
        a6.p["all_objects"],
        function()
            bQ(object.get_all_objects())
        end
    )
    a6.add.a(
        "Explode ALL",
        a6.p["entity_pools_mgr"],
        function()
            bS(vehicle.get_all_vehicles(), c.vehicle(a5.ped()))
            bS(ped.get_all_peds(), a5.ped())
            bS(object.get_all_objects())
        end
    )
    a6.add.a(
        "Delete ALL",
        a6.p["entity_pools_mgr"],
        function()
            bQ(vehicle.get_all_vehicles())
            bQ(ped.get_all_peds())
            bQ(object.get_all_objects())
        end
    )
    local fh
    a6.add.t(
        "Monkey Trunk",
        a6.p["testing_area"],
        function(k)
            if k.on then
                if not fh then
                    local ac = c.vehicle(a5.ped())
                    if entity.get_entity_model_hash(ac) == 0xB822A1AA then
                        fh = ac
                    else
                        a3.model(0xB822A1AA)
                        fh = aE.vehicle(0xB822A1AA, a5.coords(), a5.heading())
                        ped.set_ped_into_vehicle(a5.ped(), fh, -1)
                    end
                end
            end
            if not k.on and fh then
                bQ({fh})
                fh = nil
            end
            return d.stop(k)
        end
    )
    local fi = {}
    a6.add.t(
        "Deploy Monkeys",
        a6.p["testing_area"],
        function(k)
            if k.on then
                if fh then
                    if #fi < 20 then
                        local ff
                        if vehicle.get_ped_in_vehicle_seat(fh, 1) == 0 then
                            ff = 1
                        elseif vehicle.get_ped_in_vehicle_seat(fh, 2) == 0 then
                            ff = 2
                        end
                        if ff then
                            a3.model(0xA8683715)
                            fi[#fi + 1] = aE.ped(0xA8683715, a5.coords(), 28)
                            c.god(fi[#fi], true)
                            ped.set_ped_max_health(fi[#fi], 500000)
                            ped.set_ped_health(fi[#fi], 500000)
                            ped.set_ped_into_vehicle(fi[#fi], fh, ff)
                            ped.set_ped_relationship_group_hash(fi[#fi], 2229074605)
                            ai.task_leave_vehicle(fi[#fi], fh, 256)
                        end
                        for i = 1, #fi do
                            c.wait(2500)
                            local ac = c.vehicle(fi[i])
                            if ac == 0 then
                                weapon.give_delayed_weapon_to_ped(fi[#fi], 0x61012683, 0, 1)
                            end
                        end
                    end
                end
            end
            if not k.on then
                bQ(fi)
                fi = {}
            end
            return d.stop(k)
        end
    )
    x("")
    x("")
    x("Loaded 2Take1Script successfully. :)")
    x("")
    u("2Take1Script successfully loaded. :)", 210)
    _2t1s = true
end
cN()
