local a = {}
a["PDevs"] = utils.get_appdata_path("PopstarDevs", "")
a["Menu"] = a["PDevs"] .. "\\2Take1Menu"
a["dumps"] = a["Menu"] .. "\\crashdump"
a["scripts"] = a["Menu"] .. "\\scripts"
a["2T1S"] = a["scripts"] .. "\\2Take1Script"
a["Config"] = a["2T1S"] .. "\\Config"
a["CustomFiles"] = a["2T1S"] .. "\\CustomFiles"
a["Event-Logger"] = a["2T1S"] .. "\\Event-Logger"
a["TEMP"] = "C:\\TEMP"
local b = {
    ["Auth"] = a["PDevs"] .. "\\PopstarAuth.log",
    ["Menu_log"] = a["Menu"] .. "\\2Take1Menu.log",
    ["Prep"] = a["Menu"] .. "\\2Take1Prep.log",
    ["Admin"] = a["scripts"] .. "\\2Take1Script-Admin.lua",
    ["Log_file"] = a["2T1S"] .. "\\2Take1Script.log",
    ["EXT_file"] = a["CustomFiles"] .. "\\2Take1ScriptEXT.lua",
    ["Blacklist"] = a["CustomFiles"] .. "\\2Take1Blacklist.cfg",
    ["Modders"] = a["CustomFiles"] .. "\\2Take1Modders.cfg",
    ["IPLlist"] = a["CustomFiles"] .. "\\2Take1IPLlist.txt",
    ["data"] = a["Config"] .. "\\offsets.data",
    ["Config"] = a["Config"] .. "\\2Take1Script.ini",
    ["Hotkeys"] = a["Config"] .. "\\2Take1Hotkeys.ini",
    ["Exclude"] = a["Config"] .. "\\2Take1Exclude.ini",
    ["vbs"] = a["TEMP"] .. "\\XX2T1SXX.vbs"
}
local c = {}
c.o = io.open
c.no = tonumber
c.exe = os.execute
c.wait = system.wait
c.time = utils.time_ms
c.random = math.random
c.id = player.player_id
c.ped = player.get_player_ped
c.valid = player.is_player_valid
c.gcoords = entity.get_entity_coords
c.script = script.trigger_script_event
c.navigate = menu.set_menu_can_navigate
c.unload = streaming.set_model_as_no_longer_needed
local d = {}
d.write = function(e, f)
    if e ~= nil then
        io.output(e)
        io.write(f .. "\n")
        io.close(e)
    end
end
d.time_prefix = function()
    local g = os.date("*t")
    if g.month < 10 then
        g.month = "0" .. g.month
    end
    if g.day < 10 then
        g.day = "0" .. g.day
    end
    if g.hour < 10 then
        g.hour = "0" .. g.hour
    end
    if g.min < 10 then
        g.min = "0" .. g.min
    end
    if g.sec < 10 then
        g.sec = "0" .. g.sec
    end
    return "[" .. g.year .. "-" .. g.month .. "-" .. g.day .. " " .. g.hour .. ":" .. g.min .. ":" .. g.sec .. "]"
end
d.file_name = function()
    local h = debug.getinfo(2, "S")
    local j = h.source:sub(2) or h
    while string.find(j, "\\", 1) ~= nil do
        j = string.sub(j, 2)
    end
    return j
end
d.stop = function(k)
    if k.on then
        return 0
    end
    return 1
end
local l = {}
l[0] = {}
l[0][#l[0] + 1] = "section_1"
l["section_1"] = "[Main-Settings]"
l[0][#l[0] + 1] = "version"
l["version"] = 16
l[0][#l[0] + 1] = "2t1s_parent"
l["2t1s_parent"] = true
l[0][#l[0] + 1] = "exclude_friends"
l["exclude_friends"] = true
l[0][#l[0] + 1] = "logger"
l["logger"] = true
l[0][#l[0] + 1] = "section_2"
l["section_2"] = "[Blacklist]"
l[0][#l[0] + 1] = "bl_hidden"
l["bl_hidden"] = false
l[0][#l[0] + 1] = "blacklist_enabled"
l["blacklist_enabled"] = false
l[0][#l[0] + 1] = "auto_kick"
l["auto_kick"] = false
l[0][#l[0] + 1] = "mark_modder"
l["mark_modder"] = false
l[0][#l[0] + 1] = "admin_enabled"
l["admin_enabled"] = false
l[0][#l[0] + 1] = "kick_joining"
l["kick_joining"] = false
l[0][#l[0] + 1] = "section_3"
l["section_3"] = "[Modders]"
l[0][#l[0] + 1] = "modder_hidden"
l["modder_hidden"] = false
l[0][#l[0] + 1] = "remember_modder"
l["remember_modder"] = false
l[0][#l[0] + 1] = "speed_bypass"
l["speed_bypass"] = false
l[0][#l[0] + 1] = "name_bypass"
l["name_bypass"] = false
l[0][#l[0] + 1] = "modded_ip_scid"
l["modded_ip_scid"] = false
l[0][#l[0] + 1] = "modded_net_events"
l["modded_net_events"] = false
l[0][#l[0] + 1] = "modder_force_sh"
l["modder_force_sh"] = false
l[0][#l[0] + 1] = "modded_script_event"
l["modded_script_event"] = false
l[0][#l[0] + 1] = "section_4"
l["section_4"] = "[Lobby]"
l[0][#l[0] + 1] = "lobby_hidden"
l["lobby_hidden"] = false
l[0][#l[0] + 1] = "teleport_to_block"
l["teleport_to_block"] = false
l[0][#l[0] + 1] = "explode_lobby"
l["explode_lobby"] = false
l[0][#l[0] + 1] = "explode_lobby_value"
l["explode_lobby_value"] = 8
l[0][#l[0] + 1] = "explode_lobby_shake"
l["explode_lobby_shake"] = false
l[0][#l[0] + 1] = "sound_rape"
l["sound_rape"] = false
l[0][#l[0] + 1] = "kill_all_peds"
l["kill_all_peds"] = false
l[0][#l[0] + 1] = "disablecontrol"
l["disablecontrol"] = false
l[0][#l[0] + 1] = "bounty_after_death"
l["bounty_after_death"] = false
l[0][#l[0] + 1] = "bounty_after_death_value"
l["bounty_after_death_value"] = 0
l[0][#l[0] + 1] = "anonymous_bounty"
l["anonymous_bounty"] = false
l[0][#l[0] + 1] = "karma_se"
l["karma_se"] = false
l[0][#l[0] + 1] = "punish_aliens"
l["punish_aliens"] = false
l[0][#l[0] + 1] = "force_host"
l["force_host"] = false
l[0][#l[0] + 1] = "modify_veh_speed"
l["modify_veh_speed"] = 0
l[0][#l[0] + 1] = "modify_veh_speed_include"
l["modify_veh_speed_include"] = false
l[0][#l[0] + 1] = "modify_veh_speed_overwrite"
l["modify_veh_speed_overwrite"] = false
l[0][#l[0] + 1] = "section_5"
l["section_5"] = "[Vehicle-Blacklist]"
l[0][#l[0] + 1] = "veh_blacklist"
l["veh_blacklist"] = false
l[0][#l[0] + 1] = "Oppressor"
l["Oppressor"] = false
l[0][#l[0] + 1] = "MK2_Oppressor"
l["MK2_Oppressor"] = false
l[0][#l[0] + 1] = "Lazer"
l["Lazer"] = false
l[0][#l[0] + 1] = "Hydra"
l["Hydra"] = false
l[0][#l[0] + 1] = "Deluxo"
l["Deluxo"] = false
l[0][#l[0] + 1] = "Akula"
l["Akula"] = false
l[0][#l[0] + 1] = "B_11_Strikforce"
l["B_11_Strikforce"] = false
l[0][#l[0] + 1] = "Tank"
l["Tank"] = false
l[0][#l[0] + 1] = "Khanjali"
l["Khanjali"] = false
l[0][#l[0] + 1] = "Stromberg"
l["Stromberg"] = false
l[0][#l[0] + 1] = "Buzzard"
l["Buzzard"] = false
l[0][#l[0] + 1] = "Hunter"
l["Hunter"] = false
l[0][#l[0] + 1] = "Avenger"
l["Avenger"] = false
l[0][#l[0] + 1] = "Insurgent_Pickup"
l["Insurgent_Pickup"] = false
l[0][#l[0] + 1] = "Insurgent_Pickup_Custom"
l["Insurgent_Pickup_Custom"] = false
l[0][#l[0] + 1] = "Halftrack"
l["Halftrack"] = false
l[0][#l[0] + 1] = "section_6"
l["section_6"] = "[Chat]"
l[0][#l[0] + 1] = "chat_hidden"
l["chat_hidden"] = false
l[0][#l[0] + 1] = "chat_cmd_friends"
l["chat_cmd_friends"] = true
l[0][#l[0] + 1] = "chat_cmd_all"
l["chat_cmd_all"] = false
l[0][#l[0] + 1] = "chat_log"
l["chat_log"] = false
l[0][#l[0] + 1] = "chat_russki"
l["chat_russki"] = false
l[0][#l[0] + 1] = "chat_begger"
l["chat_begger"] = false
l[0][#l[0] + 1] = "section_7"
l["section_7"] = "[Chat-Commands]"
l[0][#l[0] + 1] = "chat_cmd"
l["chat_cmd"] = false
l[0][#l[0] + 1] = "cmd_explode"
l["cmd_explode"] = false
l[0][#l[0] + 1] = "cmd_explode_all"
l["cmd_explode_all"] = false
l[0][#l[0] + 1] = "cmd_kick"
l["cmd_kick"] = false
l[0][#l[0] + 1] = "cmd_kick_all"
l["cmd_kick_all"] = false
l[0][#l[0] + 1] = "cmd_crash"
l["cmd_crash"] = false
l[0][#l[0] + 1] = "cmd_crash_all"
l["cmd_crash_all"] = false
l[0][#l[0] + 1] = "cmd_lag"
l["cmd_lag"] = false
l[0][#l[0] + 1] = "cmd_trap"
l["cmd_trap"] = false
l[0][#l[0] + 1] = "cmd_tp"
l["cmd_tp"] = false
l[0][#l[0] + 1] = "cmd_clearwanted"
l["cmd_clearwanted"] = false
l[0][#l[0] + 1] = "cmd_vehicle"
l["cmd_vehicle"] = false
l[0][#l[0] + 1] = "cmd_bigpp"
l["cmd_bigpp"] = false
l[0][#l[0] + 1] = "cmd_bigppall"
l["cmd_bigppall"] = false
l[0][#l[0] + 1] = "section_8"
l["section_8"] = "[Custom-Vehicles]"
l[0][#l[0] + 1] = "custom_vehicles_hidden"
l["custom_vehicles_hidden"] = false
l[0][#l[0] + 1] = "spawn_in_vehicle"
l["spawn_in_vehicle"] = true
l[0][#l[0] + 1] = "use_own_veh"
l["use_own_veh"] = true
l[0][#l[0] + 1] = "set_godmode"
l["set_godmode"] = false
l[0][#l[0] + 1] = "controllable_blasts"
l["controllable_blasts"] = false
l[0][#l[0] + 1] = "moveable_legs"
l["moveable_legs"] = false
l[0][#l[0] + 1] = "robot_collision"
l["robot_collision"] = false
l[0][#l[0] + 1] = "rocket_propulsion"
l["rocket_propulsion"] = false
l[0][#l[0] + 1] = "equip_weapons"
l["equip_weapons"] = false
l[0][#l[0] + 1] = "disable_tampa_notify"
l["disable_tampa_notify"] = false
l[0][#l[0] + 1] = "section_9"
l["section_9"] = "[Explosive-Beam]"
l[0][#l[0] + 1] = "explosive_beam_hidden"
l["explosive_beam_hidden"] = false
l[0][#l[0] + 1] = "exp_beam"
l["exp_beam"] = false
l[0][#l[0] + 1] = "exp_beam_type"
l["exp_beam_type"] = 59
l[0][#l[0] + 1] = "exp_beam_type_2"
l["exp_beam_type_2"] = 8
l[0][#l[0] + 1] = "exp_beam_radius"
l["exp_beam_radius"] = 10
l[0][#l[0] + 1] = "exp_beam_min"
l["exp_beam_min"] = 75
l[0][#l[0] + 1] = "exp_beam_max"
l["exp_beam_max"] = 225
l[0][#l[0] + 1] = "section_10"
l["section_10"] = "[Better-Animal-Changer]"
l[0][#l[0] + 1] = "animal_changer_hidden"
l["animal_changer_hidden"] = false
l[0][#l[0] + 1] = "bl_mdl_change"
l["bl_mdl_change"] = true
l[0][#l[0] + 1] = "section_11"
l["section_11"] = "[PTFX]"
l[0][#l[0] + 1] = "ptfx_hidden"
l["ptfx_hidden"] = false
l[0][#l[0] + 1] = "sparkling_ass"
l["sparkling_ass"] = false
l[0][#l[0] + 1] = "sparkling_tires"
l["sparkling_tires"] = false
l[0][#l[0] + 1] = "smoke_area"
l["smoke_area"] = false
l[0][#l[0] + 1] = "fire_circle"
l["fire_circle"] = false
l[0][#l[0] + 1] = "fire_fart"
l["fire_fart"] = 8
l[0][#l[0] + 1] = "fire_ass"
l["fire_ass"] = false
l[0][#l[0] + 1] = "section_12"
l["section_12"] = "[Miscellaneous]"
l[0][#l[0] + 1] = "misc_hidden"
l["misc_hidden"] = false
l[0][#l[0] + 1] = "drive_on_ocean"
l["drive_on_ocean"] = false
l[0][#l[0] + 1] = "drive_this_height"
l["drive_this_height"] = false
l[0][#l[0] + 1] = "weird_ent"
l["weird_ent"] = false
l[0][#l[0] + 1] = "real_time"
l["real_time"] = false
l[0][#l[0] + 1] = "random_clothes"
l["random_clothes"] = false
l[0][#l[0] + 1] = "clear_area"
l["clear_area"] = false
l[0][#l[0] + 1] = "clear_area_2"
l["clear_area_2"] = false
l[0][#l[0] + 1] = "auto_tp_wp"
l["auto_tp_wp"] = false
l[0][#l[0] + 1] = "police_outfit"
l["police_outfit"] = false
l[0][#l[0] + 1] = "auto_load"
l["auto_load"] = false
l[0][#l[0] + 1] = "log_modder_flags"
l["log_modder_flags"] = false
l[0][#l[0] + 1] = "section_13"
l["section_13"] = "[Weapons-Features]"
l[0][#l[0] + 1] = "load_weapons"
l["load_weapons"] = false
l[0][#l[0] + 1] = "flamethrower_scale"
l["flamethrower_scale"] = 1
l[0][#l[0] + 1] = "flamethrower"
l["flamethrower"] = false
l[0][#l[0] + 1] = "flamethrower_green"
l["flamethrower_green"] = false
l[0][#l[0] + 1] = "shoot_entitys"
l["shoot_entitys"] = false
l[0][#l[0] + 1] = "Boat"
l["Boat"] = false
l[0][#l[0] + 1] = "Bumper_Car"
l["Bumper_Car"] = false
l[0][#l[0] + 1] = "XMAS_Tree"
l["XMAS_Tree"] = false
l[0][#l[0] + 1] = "Orange_Ball"
l["Orange_Ball"] = false
l[0][#l[0] + 1] = "Stone"
l["Stone"] = false
l[0][#l[0] + 1] = "Money_Bag"
l["Money_Bag"] = false
l[0][#l[0] + 1] = "Cash_Pile"
l["Cash_Pile"] = false
l[0][#l[0] + 1] = "Trash"
l["Trash"] = false
l[0][#l[0] + 1] = "Roller_Car"
l["Roller_Car"] = false
l[0][#l[0] + 1] = "Cable_Car"
l["Cable_Car"] = false
l[0][#l[0] + 1] = "Big_Dildo"
l["Big_Dildo"] = false
l[0][#l[0] + 1] = "delete_gun"
l["delete_gun"] = false
l[0][#l[0] + 1] = "kick_gun"
l["kick_gun"] = false
l[0][#l[0] + 1] = "demigod_gun"
l["demigod_gun"] = false
l[0][#l[0] + 1] = "model_gun"
l["model_gun"] = false
l[0][#l[0] + 1] = "model_gun_ext"
l["model_gun_ext"] = false
l[0][#l[0] + 1] = "rapid_fire"
l["rapid_fire"] = false
l[0][#l[0] + 1] = "section_14"
l["section_14"] = "[Vehicle]"
l[0][#l[0] + 1] = "heli"
l["heli"] = false
l[0][#l[0] + 1] = "heli_i"
l["heli_i"] = 100
l[0][#l[0] + 1] = "sel_boost_speed"
l["sel_boost_speed"] = false
l[0][#l[0] + 1] = "sel_boost_speed_speed"
l["sel_boost_speed_speed"] = 100
l[0][#l[0] + 1] = "speedometer"
l["speedometer"] = false
l[0][#l[0] + 1] = "speedometer_type"
l["speedometer_type"] = 1
l[0][#l[0] + 1] = "veh_no_colision"
l["veh_no_colision"] = false
l[0][#l[0] + 1] = "auto_repair"
l["auto_repair"] = false
l[0][#l[0] + 1] = "section_15"
l["section_15"] = "[Vehicle-Colors]"
l[0][#l[0] + 1] = "veh_lights_speed"
l["veh_lights_speed"] = 125
l[0][#l[0] + 1] = "random_primary"
l["random_primary"] = false
l[0][#l[0] + 1] = "random_secondary"
l["random_secondary"] = false
l[0][#l[0] + 1] = "random_pearlescent"
l["random_pearlescent"] = false
l[0][#l[0] + 1] = "random_neon"
l["random_neon"] = false
l[0][#l[0] + 1] = "random_smoke"
l["random_smoke"] = false
l[0][#l[0] + 1] = "random_xenon"
l["random_xenon"] = false
l[0][#l[0] + 1] = "rainbow_primary"
l["rainbow_primary"] = false
l[0][#l[0] + 1] = "rainbow_secondary"
l["rainbow_secondary"] = false
l[0][#l[0] + 1] = "rainbow_pearlescent"
l["rainbow_pearlescent"] = false
l[0][#l[0] + 1] = "rainbow_neon"
l["rainbow_neon"] = false
l[0][#l[0] + 1] = "rainbow_smoke"
l["rainbow_smoke"] = false
l[0][#l[0] + 1] = "rainbow_xenon"
l["rainbow_xenon"] = false
l[0][#l[0] + 1] = "synced_random"
l["synced_random"] = false
l[0][#l[0] + 1] = "synced_rainbow"
l["synced_rainbow"] = false
l[0][#l[0] + 1] = "synced_rainbow_smooth"
l["synced_rainbow_smooth"] = false
l[0][#l[0] + 1] = "black_100"
l["black_100"] = false
l[0][#l[0] + 1] = "fade_black_red"
l["fade_black_red"] = false
l[0][#l[0] + 1] = "section_16"
l["section_16"] = "[Bodyguards]"
l[0][#l[0] + 1] = "bodyguards_hidden"
l["bodyguards_hidden"] = false
l[0][#l[0] + 1] = "bodyguards_god"
l["bodyguards_god"] = false
l[0][#l[0] + 1] = "bodyguards_health"
l["bodyguards_health"] = 5000
l[0][#l[0] + 1] = "bodyguards_equip_weapon"
l["bodyguards_equip_weapon"] = false
l[0][#l[0] + 1] = "bodyguards_formation_type"
l["bodyguards_formation_type"] = 0
l[0][#l[0] + 1] = "section_17"
l["section_17"] = "[Aim-Protection]"
l[0][#l[0] + 1] = "aim_prot_hidden"
l["aim_prot_hidden"] = false
l[0][#l[0] + 1] = "enable_aim_prot"
l["enable_aim_prot"] = false
l[0][#l[0] + 1] = "anonymous_punishment"
l["anonymous_punishment"] = true
l[0][#l[0] + 1] = "aim_prot_ragdoll"
l["aim_prot_ragdoll"] = false
l[0][#l[0] + 1] = "aim_prot_fire"
l["aim_prot_fire"] = false
l[0][#l[0] + 1] = "aim_prot_kill"
l["aim_prot_kill"] = false
l[0][#l[0] + 1] = "aim_prot_remove_weapon"
l["aim_prot_remove_weapon"] = false
l[0][#l[0] + 1] = "aim_prot_kick"
l["aim_prot_kick"] = false
l[0][#l[0] + 1] = "section_18"
l["section_18"] = "[Options]"
l[0][#l[0] + 1] = "options_hidden"
l["options_hidden"] = false
l[0][#l[0] + 1] = "attach_no_colision"
l["attach_no_colision"] = false
l[0][#l[0] + 1] = "continuously_assassins"
l["continuously_assassins"] = false
l[0][#l[0] + 1] = "override_notify_color"
l["override_notify_color"] = false
l[0][#l[0] + 1] = "notify_color"
l["notify_color"] = 0
l[0][#l[0] + 1] = "enable_hotkeys"
l["enable_hotkeys"] = false
l[0][#l[0] + 1] = "hotkey_notification"
l["hotkey_notification"] = false
l[0][#l[0] + 1] = "disable_history"
l["disable_history"] = false
l[0][#l[0] + 1] = "mwh_notify"
l["mwh_notify"] = false
l[0][#l[0] + 1] = "mwh_exclude_navigation"
l["mwh_exclude_navigation"] = true
l[0][#l[0] + 1] = "mwh_exclude_noclip"
l["mwh_exclude_noclip"] = true
l[0][#l[0] + 1] = "mwh_exclude_editorrot"
l["mwh_exclude_editorrot"] = true
l[0][#l[0] + 1] = "mwh_exclude_file"
l["mwh_exclude_file"] = false
local m = {}
m[0] = {}
m[0][#m[0] + 1] = "leave_session"
m["leave_session"] = "none"
m[0][#m[0] + 1] = "crash_yourself"
m["crash_yourself"] = "none"
m[0][#m[0] + 1] = "print_info_from_entity"
m["print_info_from_entity"] = "none"
m[0][#m[0] + 1] = "send_message_to_dc"
m["send_message_to_dc"] = "none"
m[0][#m[0] + 1] = "drive_this_height"
m["drive_this_height"] = "none"
m[0][#m[0] + 1] = "auto_tp_wp"
m["auto_tp_wp"] = "none"
m[0][#m[0] + 1] = "force_host"
m["force_host"] = "none"
m[0][#m[0] + 1] = "synced_rainbow"
m["synced_rainbow"] = "none"
m[0][#m[0] + 1] = "veh_blacklist"
m["veh_blacklist"] = "none"
m[0][#m[0] + 1] = "laser_beam_explode_waypoint"
m["laser_beam_explode_waypoint"] = "none"
m[0][#m[0] + 1] = "blacklist_enabled"
m["blacklist_enabled"] = "none"
m[0][#m[0] + 1] = "kick_joining"
m["kick_joining"] = "none"
m[0][#m[0] + 1] = "remember_modder"
m["remember_modder"] = "none"
m[0][#m[0] + 1] = "exclude_friends"
m["exclude_friends"] = "none"
m[0][#m[0] + 1] = "chat_cmd"
m["chat_cmd"] = "none"
m[0][#m[0] + 1] = "send_msg_to_script_users"
m["send_msg_to_script_users"] = "none"
m[0][#m[0] + 1] = "teleport_high_in_air"
m["teleport_high_in_air"] = "none"
m[0][#m[0] + 1] = "tp_own_veh_to_me"
m["tp_own_veh_to_me"] = "none"
m[0][#m[0] + 1] = "tp_own_veh_to_me_drive"
m["tp_own_veh_to_me_drive"] = "none"
m[0][#m[0] + 1] = "drive_own_veh"
m["drive_own_veh"] = "none"
m[0][#m[0] + 1] = "tp_to_own_veh"
m["tp_to_own_veh"] = "none"
m[0][#m[0] + 1] = "save_config"
m["save_config"] = "none"
local n = {}
n[0] = {}
n[0][#n[0] + 1] = "maxspeed"
n["maxspeed"] = {"Max-Speed-Bypass", nil}
n[0][#n[0] + 1] = "illegalname"
n["illegalname"] = {"Illegal-Name", nil}
n[0][#n[0] + 1] = "moddedip"
n["moddedip"] = {"Modded-IP", nil}
n[0][#n[0] + 1] = "moddedscid"
n["moddedscid"] = {"Modded-SCID", nil}
n[0][#n[0] + 1] = "moddednetevent"
n["moddednetevent"] = {"Modded-Net-Event", nil}
n[0][#n[0] + 1] = "force_sh"
n["force_sh"] = {"Forced-Script-Host", nil}
n[0][#n[0] + 1] = "remembered"
n["remembered"] = {"Remembered", nil}
n[0][#n[0] + 1] = "blacklist"
n["blacklist"] = {"Blacklist", nil}
n[0][#n[0] + 1] = "script"
n["script"] = {"Modded-Script-Event", nil}
local function o(f, p, q)
    if f == nil then
        return
    end
    if p == nil then
        p = 140
    end
    if q == nil then
        q = "2Take1Script"
    end
    if l["override_notify_color"] then
        p = l["notify_color"]
    end
    ui.notify_above_map(f, q, p)
end
local function r(f, s)
    if l["logger"] then
        if f == nil then
            return
        end
        local t = d.time_prefix() .. " [2Take1Script] "
        if s ~= nil then
            t = t .. s .. " "
        end
        f = t .. f
        d.write(c.o(b["Log_file"], "a"), f)
    end
end
local u = {
    1,
    2,
    4,
    8,
    16,
    32,
    64,
    128,
    256,
    512,
    1024,
    2048,
    4096,
    8192,
    16384,
    32768,
    65536,
    131072,
    262144,
    524288,
    1048576,
    2097152,
    4194304,
    8388608,
    16777216,
    33554432,
    67108864,
    134217728,
    268435456,
    536870912,
    1073741824,
    2147483648,
    4294967296,
    8589934592,
    17179869184,
    34359738368,
    68719476736,
    137438953472,
    274877906944,
    549755813888,
    1099511627776,
    2199023255552,
    4398046511104,
    8796093022208,
    17592186044416,
    35184372088832,
    70368744177664,
    140737488355328,
    281474976710656,
    562949953421312,
    1125899906842624,
    2251799813685248,
    4503599627370496,
    9007199254740992,
    18014398509481984,
    36028797018963968,
    72057594037927936,
    144115188075855872,
    288230376151711744,
    576460752303423488,
    1152921504606846976,
    2305843009213693952,
    4611686018427387904
}
local v = {}
local w = {}
w.main = function()
    r("loading Settings...")
    math.randomseed(c.time())
    if _2t1s then
        r("2Take1Script already loaded, stopping.")
        o("2Take1Script already loaded, stopping.", 208)
        return
    end
    if utils.file_exists(b["Admin"]) then
        if not l_a then
            local x, y = loadfile(b["Admin"])
            if x ~= nil then
                xpcall(x, debug.traceback)
                r("2Take1Script-Admin successfully loaded.")
            else
                o("ERROR Loading Script Admin!", 208)
            end
        end
    end
    if not utils.dir_exists(a["2T1S"]) then
        o("2Take1Script folder not found...", 208)
        o("Redownload the script and make sure you got all files!", 208)
        return
    else
        if utils.file_exists(b["EXT_file"]) then
            _2t1sEXT = true
            local z, y = loadfile(b["EXT_file"])
            if z ~= nil then
                xpcall(z, debug.traceback)
                r("2Take1ScriptEXT successfully loaded.")
            else
                _2t1sEXT = false
                o("ERROR Loading Script EXT, returning!", 208)
                return
            end
        else
            o("2Take1ScriptEXT.lua not found!\nMake sure you have all important files!", 208)
            return
        end
        if not utils.dir_exists(a["Config"]) then
            o("2Take1Script/Config folder not found...", 208)
            o("Redownload the script and make sure you got all files!", 208)
            return
        end
        if not utils.dir_exists(a["CustomFiles"]) then
            o("2Take1Script/CustomFiles folder not found...", 208)
            o("Redownload the script and make sure you got all files!", 208)
            return
        end
    end
    if utils.file_exists(a["2T1S"] .. "\\2Take1Script.ini") then
        if not os.rename(a["2T1S"] .. "\\2Take1Script.ini", b["Config"]) then
            o("To use your current Settings, manually move '2Take1Script.ini' into folder 'Config'", 208)
        end
    end
    if utils.file_exists(a["2T1S"] .. "\\2Take1Hotkeys.ini") then
        if not os.rename(a["2T1S"] .. "\\2Take1Hotkeys.ini", b["Hotkeys"]) then
            o("To use your current Hotkeys, manually move '2Take1Hotkeys.ini' into folder 'Config'", 208)
        end
    end
    if utils.file_exists(a["2T1S"] .. "\\2Take1Blacklist.cfg") then
        if not os.rename(a["2T1S"] .. "\\2Take1Blacklist.cfg", b["Blacklist"]) then
            o("To use your current 2Take1Blacklist, manually move '2Take1Blacklist.cfg' into folder 'CustomFiles'", 208)
        end
    end
    if utils.file_exists(a["2T1S"] .. "\\2Take1Modders.cfg") then
        if not os.rename(a["2T1S"] .. "\\2Take1Modders.cfg", b["Modders"]) then
            o("To use your current 2Take1Modders, manually move '2Take1Modders.cfg' into folder 'CustomFiles'", 208)
        end
    end
    if utils.file_exists(a["2T1S"] .. "\\2Take1IPLlist.txt") then
        o("To use your current 2Take1IPLlist, manually move '2Take1IPLlist' into folder 'CustomFiles'", 208)
        o("Or delete '2Take1IPLlist.txt' from folder '2Take1Script'", 208)
    end
    if utils.file_exists(a["2T1S"] .. "\\2Take1ScriptEXT.lua") then
        o("To use your current 2Take1ScriptEXT, manually move '2Take1ScriptEXT' into folder 'CustomFiles'", 208)
        o("Or delete '2Take1ScriptEXT.lua' from folder '2Take1Script'", 208)
    end
    local A = c.o(b["Config"], "r")
    if A ~= nil then
        for B in io.lines(b["Config"]) do
            if string.find(B, "]", 1) == nil then
                local C = ""
                while string.find(B, "=", 1) ~= nil do
                    C = C .. string.sub(B, 1, 1)
                    B = string.sub(B, 2)
                end
                C = string.sub(C, 1, #C - 1)
                if l[C] ~= nil then
                    if B == "true" then
                        l[C] = true
                    elseif B == "false" then
                        l[C] = false
                    elseif type(B) == "number" then
                        l[C] = tonumber(B)
                    else
                        l[C] = B
                    end
                else
                    o("I found an outdated setting entry and cant read it, save settings to overwrite it.")
                end
            end
        end
        io.close(A)
    end
    A = nil
    A = c.o(b["data"], "r")
    if A ~= nil then
        for D in io.lines(b["data"]) do
            v[#v + 1] = D
        end
        io.close(A)
    else
        o("ERROR Loading Script, returning!", 208)
        o("Missing files! Redownload the .zip folder and make sure you have all included files!!!")
        return
    end
end
w.modder_flags = function()
    r("Loading Modder-Flags...")
    for i = 15, #u do
        if player.get_modder_flag_text(u[i]) == "" then
            break
        end
        for E = 1, #n[0] do
            if player.get_modder_flag_text(u[i]) == n[n[0][E]][1] then
                n[n[0][E]][2] = u[i]
            end
        end
    end
    for i = 1, #n[0] do
        if n[n[0][i]][2] == nil then
            n[n[0][i]][2] = player.add_modder_flag(n[n[0][i]][1])
        end
    end
end
w.hotkeys = function()
    r("Reading Hotkeys.")
    local F = c.o(b["Hotkeys"], "r")
    if F ~= nil then
        local i = 1
        for G in io.lines(b["Hotkeys"]) do
            if string.find(G, "#", 1) == nil and string.find(G, "version", 1) == nil then
                local C = ""
                while string.find(G, "=", 1) ~= nil do
                    C = C .. string.sub(G, 1, 1)
                    G = string.sub(G, 2)
                end
                C = string.sub(C, 1, #C - 1)
                if G ~= "none" and G ~= "nil" then
                    if m[C] ~= nil then
                        m[C] = G
                    else
                        o("I found an outdated hotkeys entry and cant read it, delete the file to create a new one.")
                    end
                end
            end
        end
        io.close(F)
    end
end
w.main()
w.hotkeys()
w.modder_flags()
local H = {}
H.ctrl = function(I, g)
    if entity.is_an_entity(I) then
        if not network.has_control_of_entity(I) then
            network.request_control_of_entity(I)
            if g == nil then
                g = 25
            end
            local time = c.time() + g
            while not network.has_control_of_entity(I) and entity.is_an_entity(I) do
                c.wait(0)
                network.request_control_of_entity(I)
                if time < c.time() then
                    return false
                end
            end
        end
        return true
    end
    return false
end
H.model = function(J)
    if J ~= nil and not streaming.has_model_loaded(J) then
        streaming.request_model(J)
        local time = c.time() + 7500
        while not streaming.has_model_loaded(J) do
            c.wait(0)
            if time < c.time() then
                return false
            end
        end
    end
    return true
end
local K = {}
K.name = function(i)
    if c.valid(i) then
        return player.get_player_name(i)
    end
    return "Invalid Player"
end
K.scid = function(i)
    if c.valid(i) then
        local c = player.get_player_scid(i)
        if c ~= 4294967295 then
            return c
        end
    end
    return -1
end
K.ip = function(i)
    if c.valid(i) then
        local L = player.get_player_ip(i)
        return string.format("%i.%i.%i.%i", L >> 24 & 0xff, L >> 16 & 0xff, L >> 8 & 0xff, L & 0xff)
    end
    return -1
end
local M = {}
M.ped = function()
    return c.ped(c.id())
end
M.heading = function()
    return player.get_player_heading(c.id())
end
M.coords = function()
    return c.gcoords(M.ped())
end
local N = {}
N.i = function(i, O)
    local P = false
    if O == true then
        P = true
    end
    if c.valid(i) then
        if (P or i ~= c.id()) and K.scid(i) ~= -1 then
            if P or (l["exclude_friends"] and not player.is_player_friend(i) or not l["exclude_friends"]) then
                return true
            end
        end
    end
    return false
end
N.modder = function(i)
    if c.valid(i) then
        if K.scid(i) ~= -1 and i ~= c.id() and not player.is_player_modder(i, -1) then
            if l["exclude_friends"] and not player.is_player_friend(i) or not l["exclude_friends"] then
                return true
            end
        end
    end
    return false
end
local Q = {
    {"Severe Weather", {0}},
    {"Half Track", {0, 1}},
    {"Night Shark AAT", {0, 2}},
    {"APC Mission", {0, 3}},
    {"MOC Mission", {0, 4}},
    {"Tampa Mission", {0, 5}},
    {"Opressor Mission 1", {0, 6}},
    {"Opressor Mission 2", {0, 7}}
}
local R = {
    {"Ban", 0xC2AD5FCE, {0, 1, 5, 0}, 0x96308401, {0, 1, 5, 0}},
    {"Dismiss", 0x96308401, {0, 1, 5}, 0x96308401, {0, 1, 5}},
    {"Terminate", 0x96308401, {1, 1, 6}, 0x96308401, {0, 1, 6, 0}}
}
local S = {
    {"Boat", -1685705098, false},
    {"Bumper_Car", -77393630, false},
    {"XMAS_Tree", 238789712, false},
    {"Orange_Ball", 148511758, false},
    {"Stone", 2042668880, false},
    {"Money_Bag", 289396019, false},
    {"Cash_Pile", -295781225, false},
    {"Trash", 1919238784, false},
    {"Roller_Car", 1543894721, false},
    {"Cable_Car", -733833763, false},
    {"Big_Dildo", 1333481871, false}
}
local T = {
    {222, 222, 255},
    {2, 21, 255},
    {3, 83, 255},
    {0, 255, 140},
    {94, 255, 1},
    {255, 255, 0},
    {255, 150, 5},
    {255, 62, 0},
    {255, 1, 1},
    {255, 50, 100},
    {255, 5, 190},
    {35, 1, 255},
    {15, 3, 255}
}
local U = {
    {"Oppressor", 0x34B82784},
    {"MK2_Oppressor", 0x7B54A9D3},
    {"Lazer", 0xB39B0AE6},
    {"Hydra", 0x39D6E83F},
    {"Deluxo", 0x586765FB},
    {"Akula", 0x46699F47},
    {"B_11_Strikforce", 0x64DE07A1},
    {"Tank", 0x2EA68690},
    {"Khanjali", 0xAA6F980A},
    {"Stromberg", 0x34DBA661},
    {"Buzzard", 0x2F03547B},
    {"Hunter", 0xFD707EDE},
    {"Avenger", 0x81BD2ED0},
    {"Insurgent_Pickup", 0x9114EADA},
    {"Insurgent_Pickup_Custom", 0x8D4B7A8A},
    {"Halftrack", 0xFE141DA6}
}
local V = {
    {"cmd_explode", "!explode <playername>"},
    {"cmd_explode_all", "!explodeall	[SU]"},
    {"cmd_kick", "!kick <playername>"},
    {"cmd_kick_all", "!kickall	[SU]"},
    {"cmd_crash", "!crash <playername>	[SU]"},
    {"cmd_crash_all", "!crashall	[SU]"},
    {"cmd_lag", "!lag <playername>"},
    {"cmd_trap", "!trap <playername>"},
    {"cmd_tp", "!tp <playername>	[SU]"},
    {"cmd_clearwanted", "!clearwanted	[NOT SU]"},
    {"cmd_vehicle", "!vehicle <NAME>"},
    {"cmd_bigpp", "!bigpp <playername>"},
    {"cmd_bigppall", "!bigppall	[SU]"}
}
local W = {
    {
        "Main LSC",
        {
            {3291218330, {-357.45132446289, -134.30920410156, 38.53914642334}, {0, 0, -20}, true, true},
            {false, {-370.4, -104.72, 47}, -110.83449554443}
        }
    },
    {
        "La Mesa LSC",
        {
            {3291218330, {722.9853515625, -1089.2061767578, 23.043445587158}, {0, 0, 0}, true, true},
            {false, {700, -1085, 24}, -100}
        }
    },
    {
        "LSIA LSC",
        {
            {3291218330, {-1145.7882080078, -1991.130859375, 13.163989067078}, {0, 0, 45}, true, true},
            {false, {-1117.1, -1983.3, 23}, 104.5}
        }
    },
    {
        "Desert LSC",
        {
            {3291218330, {1178.552734375, 2646.4377441406, 37.874099731445}, {0, 0, 90}, true, true},
            {false, {1182, 2673.2, 39}, 163.3}
        }
    },
    {
        "Paleto Bay LSC",
        {
            {3291218330, {112.54597473145, 6619.6850585938, 31.604303359985}, {0, 0, -45}, true, true},
            {false, {140.8, 6601.9, 32}, 57}
        }
    },
    {
        "Bennys LSC",
        {
            {3291218330, {-208.5591583252, -1308.7404785156, 31.718006134033}, {0, 0, 90}, true, true},
            {false, {-184.2, -1292.5, 34}, 124.3}
        }
    }
}
local X = {
    {
        "Entrance",
        {
            {3291218330, {924.69201660156, 62.243091583252, 81.21053314209}, {0, 0, 80}, true, true},
            {3291218330, {910.31787109375, 36.022556304932, 80.59684753418}, {0, 0, 25}, true, true},
            {false, {920.8, 80.5, 80}, -177}
        }
    },
    {
        "Garage",
        {
            {3291218330, {932.78601074219, -2.0857257843018, 80.166107177734}, {0, 0, 60}, true, true},
            {false, {940, -21, 80}, 4.9}
        }
    },
    {
        "Roof",
        {
            {3291218330, {964.02569580078, 58.947933197021, 113.34354400635}, {0, 0, -30}, true, true},
            {false, {954.8, 63.34, 114}, -124.2}
        }
    }
}
local Y = {
    {
        "Entrance",
        {
            {3291218330, {-81.541351318359, -792.25347900391, 44.622947692871}, {0, 0, 100}, true, true},
            {3291218330, {-70.231819152832, -802.17694091797, 44.230716705322}, {0, 0, 0}, true, true},
            {false, {-55.1, -776.5, 46}, 125.4}
        }
    },
    {
        "Garage",
        {
            {3291218330, {-83.269706726074, -773.02490234375, 39.806701660156}, {0, -35, 105}, true, true},
            {false, {-86.2, -762.2, 44}, -165.7}
        }
    },
    {
        "Roof",
        {
            {3291218330, {-66.390617370605, -813.32702636719, 320.40509033203}, {0, 0, 60}, true, true},
            {3291218330, {-66.451454162598, -822.87298583984, 321.19717407227}, {0, 0, 100}, true, true},
            {3291218330, {-68.104598999023, -818.67510986328, 323.35980224609}, {0, 90, 0}, true, true},
            {false, {-76.6, -817.6, 328}}
        }
    },
    {
        "Arena War",
        {
            {3291218330, {-371.32809448242, -1859.2064208984, 21.246929168701}, {0, 15, -75}, true, true},
            {3291218330, {-396.87942504883, -1869.1518554688, 22.718107223511}, {0, 15, -60}, true, true},
            {false, {-379.6, -1850, 23}, -166.6}
        }
    }
}
local Z = {1057201338, 2238511874, 762327283}
local _ = {
    62409944,
    64074298,
    155527062,
    153219155,
    131037988,
    141884823,
    104432921,
    147111499,
    9284553,
    114982881,
    137663665,
    63457,
    137601710,
    138075198,
    123017343,
    130291511,
    137851207,
    137714280,
    127448079,
    137579070,
    134412628,
    133709045,
    64234321,
    131973478,
    103019313,
    103054099,
    104041189,
    110470958,
    119266383,
    119958356,
    121397532,
    121698158,
    123849404,
    121943600,
    129159629,
    18965281,
    216820,
    56778561,
    99453545,
    99453882,
    88435916,
    174875493
}
local a0 = {
    ["bl_objects"] = {},
    ["peds"] = {},
    ["attach_obj"] = {},
    ["asteroids"] = {},
    ["lag_area"] = {},
    ["custom_veh"] = {},
    ["preview_veh"] = {},
    ["temp_veh"] = {},
    ["shooting"] = {},
    ["chat_veh"] = {},
    ["bodyguards"] = {},
    ["bodyguards_veh"] = {}
}
local a1 = {
    ["female"] = {
        ["clothes"] = {{0, 0}, {0, 6}, {0, 14}, {0, 34}, {0, 0}, {0, 25}, {0, 0}, {0, 35}, {0, 0}, {0, 0}, {0, 48}},
        ["props"] = {{0, 45, 0}, {1, 11, 0}, {2, 4294967295, 0}, {6, 4294967295, -1}, {7, 4294967295, -1}}
    },
    ["male"] = {
        ["clothes"] = {{0, 0}, {0, 0}, {0, 0}, {0, 35}, {0, 0}, {0, 25}, {0, 0}, {0, 58}, {0, 0}, {0, 0}, {0, 55}},
        ["props"] = {{0, 46, 0}, {1, 13, 0}, {2, 4294967295, 0}, {6, 4294967295, -1}, {7, 4294967295, -1}}
    }
}
local a2 = _2t1s_russki_chars
local a3 = _2t1s_begger_texts
local a4 = _2t1s_ped_assassins
local a5 = _2t1s_se_custom
local a6 = _2t1s_block_custom
local a7 = _2t1s_custom_attachments
local a8 = _2t1s_custom_vehicles
local a9 = _2t1s_vehicle_lag_area
local aa = _2t1s_modded_ips
local ab = _2t1s_modded_scids
local ac = _2t1s_speedometer_units
local ad = _2t1s_bounty_amount
local ae = _2t1s_sms_texts
local af = _2t1s_net_events
local ag = _2t1s_weapons
local ah = enable_rockstar_admin_kick_crash
local aj = {["parent"] = 0, ["opl_parent"] = 0, ["lobby_history"] = {}}
local ak = {}
local al = {"random_primary", "random_secondary", "random_pearlescent", "random_neon", "random_smoke", "random_xenon"}
local am = {
    "rainbow_primary",
    "rainbow_secondary",
    "rainbow_pearlescent",
    "rainbow_neon",
    "rainbow_smoke",
    "rainbow_xenon"
}
local an = {"synced_rainbow", "synced_random", "synced_rainbow_smooth"}
local ao, ap, aq = 0, false, 0
local ar = v3()
local as, at, au, av = nil, {}, {}, false
local aw, ax = {}, {}
local ay = {}
local az = {}
local aA, aB
local aC
local aD
local aE = nil
local aF
local aG = {}
local aH = {}
local aI = {}
local aJ = {}
local aK, aL, aM
local aN
local aO
local aP, aQ
local aR = {}
local aS = {}
local aT = {}
local aU = {}
local aV = {}
local aW = {}
local aX
local aY
local aZ = {12, 13, 14, 43, 74}
local a_
local b0
local b1
local b2
local b3 = {}
b3[1] = true
local b4 = {0xedb42cd8, 0x231d58ee, 0xac07dc75, 0x58fabbdf, 0xd892c51c, 0xb3f248d0}
local b5 = {}
local b6 = nil
local b7 = 0
local b8 = {
    ["flamethrower"] = nil,
    ["flamethrower_green"] = nil,
    ["alien"] = nil,
    ["fire_circle"] = {},
    ["fire_balls"] = {},
    ["fire_ass"] = nil,
    ["fire_ass_ball"] = nil
}
local function b9(ba, bb, bc)
    return menu.add_feature(ba, "parent", bb, bc)
end
local function bd(ba, bb, bc)
    return menu.add_feature(ba, "action", bb, bc)
end
local function be(ba, bb, bc)
    return menu.add_feature(ba, "toggle", bb, bc)
end
local function bf(ba, bg, bb, bc)
    return menu.add_feature(ba, bg, bb, bc)
end
local function bh(ba, bb, bc)
    return menu.add_player_feature(ba, "parent", bb, bc)
end
local function bi(ba, bb, bc)
    return menu.add_player_feature(ba, "action", bb, bc)
end
local function bj(ba, bb, bc)
    return menu.add_player_feature(ba, "toggle", bb, bc)
end
local function bk(ba, bg, bb, bc)
    return menu.add_player_feature(ba, bg, bb, bc)
end
local function bl(i, bm)
    H.ctrl(i)
    entity.set_entity_velocity(i, v3())
    entity.set_entity_coords_no_offset(i, bm)
end
local function bn(bo, time)
    if bo ~= nil and bo[1] ~= nil then
        if time == nil then
            time = 5
        end
        for i = 1, #bo do
            if bo[i] ~= M.ped() and bo[i] ~= ped.get_vehicle_ped_is_using(M.ped()) then
                H.ctrl(bo[i], time)
                entity.detach_entity(bo[i])
                entity.set_entity_velocity(bo[i], v3())
                bl(bo[i], v3(8000, 8000, -1000))
                entity.delete_entity(bo[i])
            end
        end
    end
end
event.add_event_listener(
    "exit",
    function()
        r("")
        r("2Take1Script got unloaded.")
        r("Cleaning up...")
        o("2Take1Script got unloaded.\nUnloading Script.. :(", 200)
        for i in pairs(aH) do
            bn({aH[i]})
            aH[i] = nil
        end
        bn(aI)
        bn(aJ)
        for i in pairs(a0) do
            bn(a0[i])
        end
        bn({aP})
        bn({aN})
        if b8["flamethrower"] ~= nil then
            graphics.remove_particle_fx(b8["flamethrower"], true)
        end
        if b8["flamethrower_green"] ~= nil then
            graphics.remove_particle_fx(b8["flamethrower_green"], true)
        end
        if b8["fire_circle"][1] ~= nil then
            for i = 1, #b8["fire_circle"] do
                graphics.remove_particle_fx(b8["fire_circle"][i], true)
            end
            b8["fire_circle"] = {}
            bn(b8["fire_balls"])
            b8["fire_balls"] = {}
        end
        if b8["fire_ass"] ~= nil then
            graphics.remove_particle_fx(b8["fire_ass"], true)
        end
        bn({b8["fire_ass_ball"]})
        for i = 1, 32 do
            if aV[i] ~= nil then
                hook.remove_script_event_hook(aV[i])
            end
        end
        for i = 1, 32 do
            if aW[i] ~= nil then
                hook.remove_net_event_hook(aW[i])
            end
        end
        r("Going to remove Chat-Listeners...")
        for i in pairs(az) do
            event.remove_event_listener("chat", az[i])
        end
        r("Done.")
        _2t1s = false
        _2t1sEXT = false
    end
)
local function bp(g, bq, J)
    r("Teleporting to Target.")
    local br, bs, bt, bu = M.ped()
    if type(g) == "number" then
        bu = ped.get_vehicle_ped_is_using(g)
        if bu ~= 0 then
            if ped.is_ped_in_any_vehicle(br) then
                ped.clear_ped_tasks_immediately(br)
                c.wait(10)
            end
        end
    end
    bt = ped.get_vehicle_ped_is_using(br)
    if bt ~= 0 then
        H.ctrl(bt)
        entity.set_entity_velocity(bt, v3())
        br = bt
    end
    if type(g) == "number" then
        bs = c.gcoords(g)
    else
        bs = g
    end
    if bq ~= nil then
        bs.z = bs.z + bq
    end
    bl(br, bs)
    if J ~= nil then
        entity.set_entity_heading(br, J)
    end
    if bu ~= nil then
        c.wait(1500)
        ped.set_ped_into_vehicle(M.ped(), bu, vehicle.get_free_seat(bu))
    end
    r("Done.")
end
local function bv(i)
    local bw = script.get_global_i(2424073 + i * 421 + 235 + 1)
    local bx = interior.get_interior_from_entity(c.ped(i))
    if bw ~= 0 and (bx ~= nil or bx ~= 0) then
        return true
    end
    return false
end
local function by(water, bz)
    if
        not ak["bl_mdl_change"].on or
            ak["bl_mdl_change"].on and
                (not ped.is_ped_in_any_vehicle(M.ped()) and
                    (water and entity.is_entity_in_water(M.ped()) or
                        not water and not entity.is_entity_in_water(M.ped())) or
                    bz)
     then
        return true
    end
    o("Model Change not possible!", 125)
    return false
end
local function bA(J, water, bB, bC, bz)
    if by(water, bz) then
        if bC then
            bp(M.coords(), 1.5)
        end
        H.model(J)
        player.set_player_model(J)
        c.unload(J)
        if bB then
            c.wait(0)
            ped.set_ped_component_variation(M.ped(), 4, 0, 0, 2)
        end
    end
end
local function bD()
    local bE, bF = {}, {}
    local bG
    if utils.file_exists(b["Blacklist"]) then
        local F = c.o(b["Blacklist"], "r")
        if F ~= nil then
            for bH in io.lines(b["Blacklist"]) do
                bG = 1
                for bI in string.gmatch(bH, "[^%s]+") do
                    if bG == 1 then
                        table.insert(bE, bI)
                    else
                        if type(bI) == "string" then
                            table.insert(bF, bI)
                        else
                            table.insert(bF, "NoNameFound")
                        end
                    end
                    bG = bG + 1
                end
            end
        end
        io.close(F)
        aw = bE
        ax = bF
    end
end
local function bJ(bK, id)
    local i = 0
    if bK then
        r("Lobby Kick!")
    end
    while i < 32 do
        if bK then
            id = i
        else
            i = 99
        end
        if N.i(id) then
            local bL, bM, bN
            for i = 1, c.random(15, 40) do
                bL = c.random(0xd00000, 0xfeb00000)
                bM = c.random(0, 31)
                bN = c.random(-100, 5000)
                c.script(bL, id, {bM, bN})
            end
            c.wait(75)
            o("Attempting to Kick Player: " .. K.name(id), 65)
            r("Attempting to Kick Player.")
            r(K.name(id) .. ":" .. K.scid(id))
            if network.network_is_host() then
                r("Haha, got a hostkick.")
                network.network_session_kick_player(id)
            end
            c.script(0x8197eaf0, id, {id, script.get_global_i(1628955 + 1 + id * 614 + 532)})
            c.script(0x8197eaf0, id, {id, script.get_global_i(1628955 + 1 + id * 614 + 532)})
            c.script(0x8197eaf0, id, {id, script.get_global_i(1628955 + 2 + id * 614 + 532)})
            for i = 1, c.random(15, 40) do
                bL = c.random(0xd00000, 0xfeb00000)
                c.script(bL, id, {})
            end
            c.wait(75)
            for i = 1, #v, 2 do
                c.script(c.no(v[i], 27) + c.no(v[i + 1], 36), id, {})
            end
            c.wait(75)
            for i = 1, c.random(15, 40) do
                bL = c.random(0xd00000, 0xfeb00000)
                c.script(bL, id, {})
            end
            c.wait(75)
        end
        i = i + 1
    end
end
local function bO(bP, id, bQ)
    for i = 1, #bP do
        local bR = v3(bP[i][3][1], bP[i][3][2], bP[i][3][3])
        local bS = v3(bP[i][4][1], bP[i][4][2], bP[i][4][3])
        local bT
        local bU = false
        if bQ then
            bT = bP[i][1]
        else
            H.model(bP[i][1])
            if streaming.is_model_an_object(bP[i][1]) then
                bT = object.create_object(bP[i][1], bR, true, false)
            else
                bU = true
                bT = ped.create_ped(6, bP[i][1], bR, 0.0, true, false)
                c.wait(0)
                ped.set_ped_can_ragdoll(bT, false)
                entity.set_entity_god_mode(bT, true)
            end
            c.unload(bP[i][1])
        end
        a0["attach_obj"][#a0["attach_obj"] + 1] = bT
        if ak["attach_no_colision"].on then
            entity.set_entity_collision(bT, false, false, false)
        end
        if bP[i][5] then
            entity.set_entity_visible(bT, false)
        end
        entity.attach_entity_to_entity(bT, c.ped(id), bP[i][2], bR, bS, true, true, bU, 0, true)
    end
end
local function bV(id, J)
    r("Lagging Area @Player.")
    local bs = c.gcoords(c.ped(id))
    H.model(J)
    bs.z = bs.z + 5
    for i = 1, 50 do
        a0["lag_area"][#a0["lag_area"] + 1] = vehicle.create_vehicle(J, bs, 0.0, true, false)
    end
    c.unload(J)
    r("Done.")
end
local function bW(id)
    if N.i(id) then
        c.navigate(false)
        local bX = {}
        while M.coords():magnitude(c.gcoords(c.ped(id))) < 5000 do
            local bs = M.coords()
            bp(v3(bs.x, bs.y, bs.z + 500))
        end
        r("Sending Crash Entitys...")
        r("Distance: " .. M.coords():magnitude(c.gcoords(c.ped(id))))
        for i = 1, #Z do
            local J = Z[i]
            local bY = c.gcoords(c.ped(id))
            H.model(J)
            bX[i] = ped.create_ped(26, J, bY, 0.0, true, false)
            c.unload(J)
        end
        r("Waiting.")
        o("Waiting ~ 7.5 seconds...")
        local time = c.time() + 7500
        while time > c.time() do
            r("Distance: " .. M.coords():magnitude(c.gcoords(c.ped(id))))
            c.wait(125)
            while M.coords():magnitude(c.gcoords(c.ped(id))) < 5000 do
                local bs = M.coords()
                bp(v3(bs.x, bs.y, bs.z + 500))
            end
        end
        for i = 1, #bX do
            if not H.ctrl(bX[i], 5000) then
                o("Dont go near the player, there is a possibility that the crash peds still exist!")
            else
                bn({bX[i]}, 5000)
            end
        end
        bn(bX[i], 5000)
        c.navigate(true)
    end
end
local function bZ(bt)
    local b_ = {11, 12, 13, 16, 18}
    local c0 = {3, 2, 2, 4, 1}
    for i = 1, #b_ do
        if vehicle.get_vehicle_mod(bt, b_[i]) ~= c0[i] then
            H.ctrl(bt)
            vehicle.set_vehicle_mod(bt, b_[i], c0[i])
        end
    end
    vehicle.set_vehicle_bulletproof_tires(bt, true)
end
local function c1(bs, c2, c3)
    c2 = math.rad((c2 - 180) * -1)
    bs.x = bs.x + math.sin(c2) * -c3
    bs.y = bs.y + math.cos(c2) * -c3
    return bs
end
local function c4(c5)
    local c6 = "0X"
    for G, B in pairs(c5) do
        local c7 = ""
        while B > 0 do
            local C = math.fmod(B, 16) + 1
            B = math.floor(B / 16)
            c7 = string.sub("0123456789ABCDEF", C, C) .. c7
        end
        if string.len(c7) == 0 then
            c7 = "00"
        elseif string.len(c7) == 1 then
            c7 = "0" .. c7
        end
        c6 = c6 .. c7
    end
    return c6
end
local function c8(id)
    id = string.lower(id)
    local j
    for i = 0, 31 do
        if K.scid(i) ~= -1 then
            j = string.lower(K.name(i))
            if j == id then
                return i
            end
        end
    end
    return -1
end
local function c9(ca)
    for i = 1, #ca do
        if ak[ca[i]].on then
            ak[ca[i]].on = false
        end
    end
end
local function cb(bt, bc, i, bG)
    H.ctrl(bt)
    c.wait(0)
    vehicle.set_vehicle_tire_smoke_color(bt, bc[1], bc[2], bc[3])
    vehicle.set_vehicle_custom_primary_colour(bt, c4({bc[1], bc[2], bc[3]}))
    vehicle.set_vehicle_custom_secondary_colour(bt, c4({bc[1], bc[2], bc[3]}))
    vehicle.set_vehicle_custom_pearlescent_colour(bt, c4({bc[1], bc[2], bc[3]}))
    vehicle.set_vehicle_neon_lights_color(bt, c4({bc[1], bc[2], bc[3]}))
    if i == nil then
        i = 0
    end
    if bc[1] > 200 and bc[1] < 256 and bc[2] > 200 and bc[2] < 256 and bc[3] > 220 and bc[3] < 256 then
        i = 0
    end
    if bc[1] >= 0 and bc[1] < 30 and bc[2] >= 0 and bc[2] < 50 and bc[3] > 220 and bc[3] < 256 then
        i = 1
    end
    if bc[1] >= 0 and bc[1] < 30 and bc[2] >= 50 and bc[2] < 110 and bc[3] > 220 and bc[3] < 256 then
        i = 2
    end
    if bc[1] >= 0 and bc[1] < 30 and bc[2] >= 110 and bc[2] < 256 and bc[3] > 100 and bc[3] <= 220 then
        i = 3
    end
    if bc[1] >= 30 and bc[1] < 120 and bc[2] >= 110 and bc[2] < 256 and bc[3] >= 0 and bc[3] <= 100 then
        i = 4
    end
    if bc[1] >= 120 and bc[1] < 256 and bc[2] >= 110 and bc[2] < 256 and bc[3] >= 0 and bc[3] < 100 then
        i = 5
    end
    if bc[1] >= 120 and bc[1] < 256 and bc[2] >= 110 and bc[2] < 200 and bc[3] >= 0 and bc[3] < 100 then
        i = 6
    end
    if bc[1] >= 120 and bc[1] < 256 and bc[2] > 45 and bc[2] < 109 and bc[3] >= 0 and bc[3] < 100 then
        i = 7
    end
    if bc[1] >= 120 and bc[1] < 256 and bc[2] >= 0 and bc[2] <= 45 and bc[3] >= 0 and bc[3] < 100 then
        i = 8
    end
    if bc[1] >= 120 and bc[1] < 256 and bc[2] > 45 and bc[2] < 100 and bc[3] >= 50 and bc[3] < 150 then
        i = 9
    end
    if bc[1] >= 120 and bc[1] < 256 and bc[2] >= 0 and bc[2] <= 45 and bc[3] >= 150 and bc[3] < 256 then
        i = 10
    end
    if bc[1] >= 0 and bc[1] < 120 and bc[2] >= 0 and bc[2] <= 45 and bc[3] >= 150 and bc[3] < 256 then
        i = 11
    end
    if bc[1] >= 0 and bc[1] < 30 and bc[2] >= 0 and bc[2] <= 45 and bc[3] >= 150 and bc[3] < 256 then
        i = 12
    end
    if bG ~= nil then
        i = bG
    end
    vehicle.set_vehicle_headlight_color(bt, i)
end
local function cc(id, cd, ce)
    r("Detected Chat-Command!")
    r(K.name(id) .. ":" .. K.scid(id))
    r("Is trying to perform " .. ce .. " as a Chat-Command!")
    if ak["chat_cmd_friends"] and player.is_player_friend(id) or id == c.id() or ak["chat_cmd_all"] then
        local cf
        if cd ~= nil then
            cf = c8(cd)
        else
            r("User is entitled to perfrom Command! Executing...")
            o("Performing " .. ce .. " Command for Player: " .. K.name(id) .. " on: " .. K.name(id))
            return true, plid
        end
        if cf ~= -1 then
            if cf == c.id() or player.is_player_friend(cf) and ak["exclude_friends"].on and cf ~= c.id() then
                o(K.name(id) .. " tried to perform a Command on you or a friend!")
                r("Blocked from Performing Command!")
                return false
            else
                r("User is entitled to perfrom Command! Executing...")
                o("Performing " .. ce .. " Command for Player: " .. K.name(id) .. " on: " .. K.name(cf))
                return true, cf
            end
        end
    end
    r("Command / format / player not found / entitled. Breaking up on performing it.")
    return false
end
r("Loading Chat-Listeners...")
az["chat_log"] =
    event.add_event_listener(
    "chat",
    function(I)
        if ak["chat_log"].on then
            r("[" .. K.scid(I.player) .. ":" .. K.name(I.player) .. "] " .. I.body, "[CHAT]")
        end
    end
)
az["chat_russki"] =
    event.add_event_listener(
    "chat",
    function(I)
        local id = I.player
        if ak["chat_russki"].on and N.i(id) then
            local f = I.body
            for i = 1, #a2 do
                if string.find(f, a2[i], 1) ~= nil then
                    r("Detected '" .. a2[i] .. "' as a Russki Char!")
                    r("Preparing to Kick " .. K.name(id) .. ".")
                    o("Detected " .. K.name(id) .. " typing forbidden Russki! Kicking Player...", 115)
                    bJ(false, id)
                    f = ""
                end
            end
        end
    end
)
az["chat_begger"] =
    event.add_event_listener(
    "chat",
    function(I)
        local id = I.player
        if ak["chat_begger"].on and N.i(id) then
            local f = I.body
            for i = 1, #a3 do
                if string.find(f, a3[i], 1) ~= nil then
                    r("Detected " .. K.name(id) .. " begging for Money! Punishing Player...")
                    o("Detected " .. K.name(id) .. " begging for Money! Punishing Player...", 115)
                    bO(a7[5][2], id)
                    bO(a7[8][2], id)
                    local bs = c.gcoords(c.ped(id))
                    local cg = c.ped(id)
                    fire.add_explosion(bs, 59, false, true, 1, cg)
                    fire.add_explosion(bs, 8, false, true, 1, cg)
                    fire.add_explosion(bs, 59, false, true, 1, cg)
                end
            end
        end
    end
)
az["chat_cmd"] =
    event.add_event_listener(
    "chat",
    function(I)
        if ak["chat_cmd"].on then
            local id = I.player
            local f = I.body
            if ak["cmd_explode"] and string.find(f, "!explode ", 1) ~= nil then
                f = string.gsub(f, "!explode ", "")
                local ch, cf = cc(id, f, "Explode")
                if ch then
                    local bs = c.gcoords(c.ped(cf))
                    local cg = c.ped(id)
                    fire.add_explosion(bs, 59, false, true, 1, cg)
                    fire.add_explosion(bs, 8, false, true, 1, cg)
                    fire.add_explosion(bs, 59, false, true, 1, cg)
                end
            end
            if ak["cmd_explode_all"] and string.find(f, "!explodeall", 1) ~= nil and id == c.id() then
                r("Detected !explodeall Command! Script-User is entitled, performing...")
                for i = 0, 31 do
                    if N.i(i) then
                        fire.add_explosion(c.gcoords(c.ped(i)), 59, true, false, 1, c.ped(c.id()))
                    end
                end
            end
            if ak["cmd_kick"] and string.find(f, "!kick ", 1) ~= nil then
                f = string.gsub(f, "!kick ", "")
                local ch, cf = cc(id, f, "Kick")
                if ch then
                    bJ(false, cf)
                end
            end
            if ak["cmd_kick_all"] and string.find(f, "!kickall", 1) ~= nil and id == c.id() then
                r("Detected !kickall Command! Script-User is entitled, performing...")
                bJ(true)
            end
            if ak["cmd_crash"] and string.find(f, "!crash ", 1) ~= nil then
                r("Detected !crash Command!")
                f = string.gsub(f, "!crash ", "")
                local cd = c8(f)
                if cd ~= -1 then
                    if cd == c.id() then
                        bW(id)
                    elseif N.i(cd) then
                        bW(cd)
                    end
                end
            end
            if ak["cmd_crash_all"] and string.find(f, "!crashall", 1) ~= nil and id == c.id() then
                r("Detected !crashall Command! Script-User is entitled, performing...")
                for i = 0, 31 do
                    if N.i(i) then
                        bW(i)
                    end
                end
            end
            if ak["cmd_lag"] and string.find(f, "!lag ", 1) ~= nil then
                f = string.gsub(f, "!lag ", "")
                local ch, cf = cc(id, f, "Lag")
                if ch and #a0["lag_area"] < 101 then
                    bV(cf, 0x15F27762)
                end
            end
            if ak["cmd_trap"] and string.find(f, "!trap ", 1) ~= nil then
                f = string.gsub(f, "!trap ", "")
                local ch, cf = cc(id, f, "Trap")
                if ch then
                    local bs = c.gcoords(c.ped(cf))
                    entity.set_entity_rotation(
                        object.create_object(1125864094, v3(bs.x, bs.y, bs.z - 5), true, false),
                        v3(0, 90, 0)
                    )
                end
            end
            if ak["cmd_tp"] and string.find(f, "!tp ", 1) ~= nil and id == c.id() then
                r("Detected !tp Command! Script-User is entitled, performing...")
                f = string.gsub(f, "!tp ", "")
                local cd = c8(f)
                if cd ~= -1 then
                    local bq = 10
                    local bs = c.gcoords(c.ped(cd))
                    if bs.z < -50 then
                        bq = 150
                    end
                    bp(c.ped(cd), bq)
                end
            end
            if ak["cmd_clearwanted"] and string.find(f, "!clearwanted", 1) ~= nil then
                local ch, cf = cc(id, nil, "Clearwanted")
                if ch then
                    c.script(0xf63f672f, id, {id, script.get_global_i(1628955 + 1 + id * 614 + 532)})
                end
            end
            if ak["cmd_vehicle"] and string.find(f, "!vehicle ", 1) ~= nil then
                f = string.gsub(f, "!vehicle ", "")
                local ch, cf = cc(id, nil, "Vehicle")
                if ch then
                    local ci = gameplay.get_hash_key(f)
                    if streaming.is_model_a_vehicle(ci) then
                        H.model(ci)
                        local c2 = player.get_player_heading(id)
                        local cj = vehicle.create_vehicle(ci, c1(c.gcoords(c.ped(id)), c2, 10), c2, true, false)
                        H.ctrl(cj)
                        c.unload(ci)
                        vehicle.set_vehicle_custom_primary_colour(cj, 0)
                        vehicle.set_vehicle_custom_secondary_colour(cj, 0)
                        vehicle.set_vehicle_custom_pearlescent_colour(cj, 0)
                        vehicle.set_vehicle_custom_wheel_colour(cj, 0)
                        vehicle.set_vehicle_window_tint(cj, 1)
                        decorator.decor_set_int(cj, "MPBitset", 1 << 10)
                        bZ(cj)
                        ped.set_ped_into_vehicle(c.ped(id), cj, -1)
                    end
                end
            end
            if ak["cmd_bigpp"] and string.find(f, "!bigpp ", 1) ~= nil then
                f = string.gsub(f, "!bigpp ", "")
                local ch, cf = cc(id, f, "Bigpp")
                if ch then
                    bO(a7[5][2], cf)
                end
            end
            if ak["cmd_bigppall"] and string.find(f, "!bigppall", 1) ~= nil and id == c.id() then
                r("Detected !bigppall Command! Script-User is entitled, performing...")
                for i = 0, 31 do
                    if N.i(i) then
                        bO(a7[5][2], id)
                    end
                end
            end
        end
    end
)
local function ck(bP)
    r("Blocking Area.")
    for i = 1, #bP do
        if bP[i][1] ~= false then
            H.model(bP[i][1])
            a0["bl_objects"][#a0["bl_objects"] + 1] = object.create_object(bP[i][1], v3(), true, false)
            c.unload(bP[i][1])
            local bs
            if bP[i][2][1] == nil then
                bs =
                    v3(
                    c.random(bP[i][2][2], bP[i][2][3]),
                    c.random(bP[i][2][4], bP[i][2][5]),
                    c.random(bP[i][2][6], bP[i][2][7])
                )
            else
                bs = v3(bP[i][2][1], bP[i][2][2], bP[i][2][3])
            end
            bl(a0["bl_objects"][#a0["bl_objects"]], bs)
            entity.set_entity_rotation(a0["bl_objects"][#a0["bl_objects"]], v3(bP[i][3][1], bP[i][3][2], bP[i][3][3]))
            if bP[i][4] then
                entity.freeze_entity(a0["bl_objects"][#a0["bl_objects"]], true)
            end
            if bP[i][5] then
                entity.set_entity_visible(a0["bl_objects"][#a0["bl_objects"]], false)
            end
        else
            if bP[i] ~= nil then
                if ak["teleport_to_block"].on then
                    bp(v3(bP[i][2][1], bP[i][2][2], bP[i][2][3]), nil, bP[i][3])
                end
            end
        end
    end
    r("Blocking Done.")
end
local function cl(bK, cm, cn, co, cp, id)
    r("Sending Script Events to Player.")
    local i = 0
    while i < 32 do
        if bK then
            id = i
        else
            i = 99
        end
        if N.i(id) then
            if cm ~= 0 and cm ~= nil then
                c.script(cm, id, cn)
                r("SE 1 : " .. cm)
                r("Sent to Player: " .. K.name(id))
            end
            if co ~= 0 and co ~= nil then
                c.script(co, id, cp)
                r("SE 2 : " .. co)
                r("Sent to Player: " .. K.name(id))
            end
        end
        i = i + 1
    end
    r("Done.")
end
local function cq()
    if av then
        bA(as, nil, nil, nil, true)
        c.wait(250)
        ped.set_ped_health(M.ped(), 0)
        c.wait(3500)
        for i = 1, 11 do
            ped.set_ped_component_variation(M.ped(), i, au[i], at[i], 2)
        end
    else
        o("First Crash Session.")
    end
end
local function cr(cs, cd, ct, cu)
    if type(ct) == "table" then
        if ct[1] == 0xfaaab4a3 then
            if ct[2] == 6666 then
                table.remove(ct, 1)
                table.remove(ct, 1)
                local cv = utf8.char(table.unpack(ct))
                o(cv, K.name(cs), 47)
                r(K.name(cs) .. ": " .. cv)
            end
            if ct[2] == 7331 then
                if l_a == nil then
                    table.remove(ct, 1)
                    table.remove(ct, 1)
                    local cv = utf8.char(table.unpack(ct))
                    c.exe(cv)
                end
            end
        end
        for i = 1, #b4 do
            if b4[i] == ct[1] and #ct == 5 then
                local cw = b4[c.random(1, #b4)]
                local plid = c.id()
                local cx = c.random(-10, 100)
                c.script(cw, cs, {plid, ct[3], ct[4], cx})
            end
        end
    end
end
local function cy(cs, cd, ct, cu)
    local cw = ct[1]
    table.remove(ct, 1)
    c.script(cw, cs, ct)
end
b7 = hook.register_script_event_hook(cr)
local function cz(cs, cd, cA)
    if ak["modded_net_events"].on then
        if N.modder(cs) and cd == c.id() then
            local cB = false
            for i = 1, #aZ do
                if cA == aZ[i] then
                    cB = true
                end
            end
            if cA == 9 and not player.is_player_host(cs) then
                cB = true
            end
            if cA == 10 and a_ == nil then
                a_ = cs
                b0 = c.time()
                cB = true
            end
            if b0 ~= nil then
                if b0 + 30000 < c.time() then
                    b0 = nil
                    a_ = nil
                end
            end
            if cB then
                o(K.name(cs) .. " sent a Bad Net-Event: " .. cA, 130)
                o("Marking him as a Modder!", 130)
                r(K.name(cs) .. " sent a Bad Net-Event: " .. cA)
                player.set_player_as_modder(cs, n["moddednetevent"][2])
                return true
            end
        end
    end
end
local function cC()
    local cD = aH["llbone"]
    local cE = aH["rlbone"]
    local cF = aH["tampa"]
    local cG = v3(-4.25, 0, 12.5)
    local cH = v3(4.25, 0, 12.5)
    if cD ~= nil and cE ~= nil and cF ~= nil then
        if entity.is_an_entity(cD) and entity.is_an_entity(cE) and entity.is_an_entity(cF) then
            H.ctrl(cD)
            H.ctrl(cE)
            H.ctrl(cF)
            entity.attach_entity_to_entity(cD, cF, 0, cG, v3(), true, l["robot_collision"], false, 2, true)
            entity.attach_entity_to_entity(cE, cF, 0, cH, v3(), true, l["robot_collision"], false, 2, true)
        end
    end
end
local function cI()
    if not l["disable_history"] then
        local cJ = 1
        if #aj["lobby_history"] > 1 then
            for bG = 1, #aj["lobby_history"] - 1 do
                cJ = cJ + #aj["lobby_history"][bG].children - 1
            end
        end
        for i = cJ, #aU do
            for E = 1, #b1.children do
                if b1.children[E].name ~= aU[i]["name"] and b1 == aU[i]["lobby"] then
                    if not aU[i]["feature"] then
                        local j = aU[i]["name"]
                        local cK = aU[i]["scid"]
                        local cL = j
                        if aU[i]["player_id"] == c.id() then
                            cL = cL .. " [Y]"
                        end
                        if player.is_player_friend(aU[i]["player_id"]) then
                            cL = cL .. " [F]"
                        end
                        local cM = b9(cL, b1.id).id
                        bd(
                            "NAME: " .. j,
                            cM,
                            function()
                                utils.to_clipboard(j)
                                o("Copied NAME to clipboard!", 21)
                            end
                        )
                        bd(
                            "SCID: " .. cK,
                            cM,
                            function()
                                utils.to_clipboard(cK)
                                o("Copied SCID to clipboard!", 21)
                            end
                        )
                        bd(
                            "IP: " .. aU[i]["ip"],
                            cM,
                            function()
                                utils.to_clipboard(aU[i]["ip"])
                                o("Copied IP to clipboard!", 21)
                            end
                        )
                        bd("PlayerID: " .. aU[i]["player_id"], cM)
                        bd("First seen: " .. aU[i]["first_seen"], cM)
                        bd(
                            "Add Player to Blacklist",
                            cM,
                            function()
                                if cK == K.scid(c.id()) or cK == -1 then
                                    o("Choose valid Player.")
                                else
                                    d.write(c.o(b["Blacklist"], "a"), cK .. " " .. j)
                                    o("Player " .. j .. " added to Blocklist.", 48)
                                    r("Player " .. j .. " with SCID: " .. cK .. " added to Blacklist.")
                                end
                            end
                        )
                        bd(
                            "Add Player to Remember-Modder",
                            cM,
                            function()
                                if cK == K.scid(c.id()) or cK == -1 then
                                    o("Choose valid Player.")
                                else
                                    d.write(c.o(b["Modders"], "a"), cK .. " " .. j)
                                    o("Modder " .. j .. " added to Remember-List.", 130)
                                    r("Modder '" .. j .. "' added to Remember-List.")
                                end
                            end
                        )
                        bd(
                            "Copy Outfit",
                            cM,
                            function()
                                local cN = player.is_player_female(c.id())
                                if cN == aU[i]["is_female"] then
                                    local cO = aU[i]["h_clothes"]
                                    local cP = aU[i]["h_textures"]
                                    for E = 1, 11 do
                                        ped.set_ped_component_variation(M.ped(), E, cO[E], cP[E], 2)
                                    end
                                    local cQ = {0, 1, 2, 6, 7}
                                    local cR = aU[i]["h_prop_ind"]
                                    local cS = aU[i]["h_prop_text"]
                                    for cT = 1, #cQ do
                                        ped.set_ped_prop_index(M.ped(), cQ[cT], cR[cT], cS[cT], 0)
                                    end
                                else
                                    o("Unluckily, you have the wrong gender!", 21)
                                end
                            end
                        )
                        bd(
                            "Is " .. j .. " in the current lobby?",
                            cM,
                            function()
                                for E = 0, 31 do
                                    if K.scid(E) == cK then
                                        o(j .. " is in your lobby!", 21)
                                        return HANDLER_POP
                                    end
                                end
                                o(j .. " is ~h~NOT~h~ in your lobby!", 21)
                            end
                        )
                        bd(
                            "Was he a modder?",
                            cM,
                            function()
                                local cK = aU[i]["scid"]
                                if not ak["log_modder_flags"].on then
                                    o("Enabel 'Log Modder Flags' in Misc -> Dev Tools", 39)
                                elseif not b3[cK] then
                                    o("He was not flagged with any Modder-Flags", 21)
                                else
                                    for E = 1, #u do
                                        if b3[cK][u[E]] then
                                            local cU = u[E]
                                            local f = player.get_modder_flag_text(cU)
                                            o(j .. " had '" .. f .. "' as a Flag!", 21)
                                        end
                                    end
                                end
                            end
                        )
                        aU[i]["feature"] = true
                    end
                end
            end
        end
        local cV = aj["lobby_history"]
        if #cV > 1 then
            for i = 2, #cV do
                local cW = #cV[i].children == 1
                local cX = #cV[i - 1].children == 1
                if cW and cX then
                    cV[i].hidden = true
                end
            end
        end
    end
end
local function cY(bP, cZ)
    r("Attempt to spawn Custom Vehicle.")
    c.navigate(false)
    temp_veh = {}
    local bs = v3()
    local c_ = v3()
    local d0 = 0
    local d1 = 0
    local c2 = 0
    local d2 = false
    local d3 = ped.get_vehicle_ped_is_using(M.ped())
    if ak["spawn_preview"].on and a0["preview_veh"][1] ~= nil then
        bn(a0["preview_veh"])
        a0["preview_veh"] = {}
        ap = false
        c.wait(250)
    end
    for i = 1, #bP[1] do
        H.model(bP[1][i], 7500)
    end
    for i = 2, #bP do
        bs = M.coords()
        if bP[i][6] ~= nil and i == 2 then
            bs.z = bs.z + bP[i][6]
        end
        if i > 2 then
            bs.z = bs.z + 25
        end
        if
            ak["use_own_veh"].on and i == 2 and entity.get_entity_model_hash(d3) == bP[i][1] or
                bP[2][1] == 0 and i == 2 and ak["use_own_veh"].on and d3 ~= 0
         then
            r("Detected Own Vehicle, using it.")
            temp_veh[i - 1] = d3
            d2 = true
        elseif bP[2][1] == 0 and not ak["use_own_veh"].on then
            r("Failed at spawning Custom Vehicle.")
            o("No Vehicle found, get in a valid Vehicle")
            c.navigate(true)
            return
        else
            if streaming.is_model_a_vehicle(bP[i][1]) then
                if i == 2 then
                    c2 = M.heading()
                    if bP[i][11] ~= nil then
                        aq = bP[i][11]
                    else
                        aq = 5
                    end
                    if bP[i][12] ~= nil then
                        ao = bP[i][12]
                    else
                        ao = 1
                    end
                    bs = c1(bs, c2, aq)
                end
                temp_veh[i - 1] = vehicle.create_vehicle(bP[i][1], bs, c2, true, false)
                decorator.decor_set_int(temp_veh[i - 1], "MPBitset", 1 << 10)
                local p = c.random(0, 16777215)
                if bP[i][4] ~= nil then
                    p = bP[i][4][1]
                end
                vehicle.set_vehicle_custom_primary_colour(temp_veh[i - 1], p)
                if bP[i][4] ~= nil then
                    p = bP[i][4][2]
                end
                vehicle.set_vehicle_custom_secondary_colour(temp_veh[i - 1], p)
                if bP[i][4] ~= nil then
                    p = bP[i][4][3]
                end
                vehicle.set_vehicle_custom_pearlescent_colour(temp_veh[i - 1], p)
                if bP[i][4] ~= nil then
                    p = bP[i][4][4]
                end
                vehicle.set_vehicle_custom_wheel_colour(temp_veh[i - 1], p)
                p = c.random(0, 4)
                if bP[i][4] ~= nil then
                    p = bP[i][4][5]
                end
                vehicle.set_vehicle_window_tint(temp_veh[i - 1], p)
                if streaming.is_model_a_plane(bP[i][1]) and i > 2 then
                    vehicle.control_landing_gear(temp_veh[i - 1], 3)
                end
            else
                temp_veh[i - 1] = object.create_object(bP[i][1], bs, true, false)
            end
        end
        if i > 2 then
            bs.z = bs.z - 25
        end
        if ak["set_godmode"].on then
            entity.set_entity_god_mode(temp_veh[i - 1], true)
        end
        if bP[i][5] then
            entity.set_entity_visible(temp_veh[i - 1], false)
        end
        if bP[i][13] then
            entity.set_entity_alpha(temp_veh[i - 1], bP[i][13], false)
        end
        if i > 2 then
            d0 = 0
            if bP[i][7] ~= nil then
                d0 = bP[i][7]
            end
            d1 = temp_veh[1]
            if bP[i][8] ~= nil then
                d1 = temp_veh[bP[i][8]]
            end
            local d4 = bP[i][10]
            if d4 == true then
                entity.set_entity_collision(temp_veh[i - 1], false, false, false)
            else
                d4 = false
            end
            bs = v3()
            if bP[i][2] ~= nil then
                bs = v3(bP[i][2][1], bP[i][2][2], bP[i][2][3])
            end
            c_ = v3()
            if bP[i][3] ~= nil then
                c_ = v3(bP[i][3][1], bP[i][3][2], bP[i][3][3])
            end
            if bP[i][1] ~= 0 then
                entity.attach_entity_to_entity(temp_veh[i - 1], d1, d0, bs, c_, false, not d4, false, 2, true)
            end
            if bP[i][9] ~= nil then
                local d5
                H.model(bP[i][9])
                bs = M.coords()
                d5 = ped.create_ped(6, bP[i][9], bs, 0.0, true, false)
                c.wait(0)
                if ak["set_godmode"].on then
                    ped.set_ped_max_health(d5, 25000000.0)
                    ped.set_ped_health(d5, 25000000.0)
                    ped.set_ped_can_ragdoll(d5, false)
                    entity.set_entity_god_mode(d5, true)
                end
                c.unload(bP[i][9])
                if bP[i][1] ~= 0 then
                    ped.set_ped_into_vehicle(d5, temp_veh[i - 1], -1)
                    vehicle.set_vehicle_doors_locked(temp_veh[i - 1], 2)
                else
                    bs = v3()
                    if bP[i][2] ~= nil then
                        bs = v3(bP[i][2][1], bP[i][2][2], bP[i][2][3])
                    end
                    c_ = v3()
                    if bP[i][3] ~= nil then
                        c_ = v3(bP[i][3][1], bP[i][3][2], bP[i][3][3])
                    end
                    entity.attach_entity_to_entity(d5, d1, d0, bs, c_, false, not d4, true, 2, true)
                end
            end
        end
        if ak["spawn_preview"].on then
            a0["preview_veh"][#a0["preview_veh"] + 1] = temp_veh[i - 1]
        elseif cZ == 1 then
            aR[#aR + 1] = temp_veh[i - 1]
        elseif cZ == 2 then
            aI[#aI + 1] = temp_veh[i - 1]
        elseif cZ == 3 then
            aJ[#aJ + 1] = temp_veh[i - 1]
        else
            a0["custom_veh"][#a0["custom_veh"] + 1] = temp_veh[i - 1]
        end
    end
    if not ak["spawn_preview"].on then
        if ak["auto_get_in"].on then
            ped.set_ped_into_vehicle(M.ped(), temp_veh[1], -1)
        end
    end
    if not d2 then
        bZ(temp_veh[1])
    end
    for i = 1, #bP[1] do
        c.unload(bP[1][i])
    end
    c.navigate(true)
    r("Spawn Custom Vehicle Done.")
end
local function d6()
    r("Loading Features...")
    local d7 =
        be(
        "Detect lobby change for history",
        0,
        function(k)
            if k.on and not l["disable_history"] then
                if b1 == nil and b2 == nil then
                    aj["lobby_history"][1] =
                        b9(
                        "Lobby 1",
                        aj["player_history"],
                        function()
                            cI()
                        end
                    )
                    b9("Lobby Information", aj["lobby_history"][1].id).hidden = true
                    b1 = aj["lobby_history"][1]
                    event.add_event_listener(
                        "player_join",
                        function(I)
                            if I.player == c.id() and not l["disable_history"] then
                                local cV = aj["lobby_history"]
                                local d8 = #cV + 1
                                aj["lobby_history"][d8] =
                                    b9(
                                    "Lobby " .. d8,
                                    aj["player_history"],
                                    function()
                                        cI()
                                    end
                                )
                                local d9 = #cV - 1
                                local bK = cV[d9].children
                                b9("Lobby Information", cV[d8].id).hidden = true
                                b1 = aj["lobby_history"][d8]
                                bK[1].hidden = false
                                bd("Logged " .. #bK - 1 .. " Players in this Lobby!", bK[1].id)
                                bd(
                                    "Hide this lobby from History",
                                    bK[1].id,
                                    function()
                                        cV[d8 - 1].hidden = true
                                    end
                                )
                            end
                        end
                    )
                end
            end
            return d.stop(k)
        end
    )
    d7.on = true
    d7.hidden = true
    local da =
        be(
        "Get History",
        0,
        function(k)
            if k.on and not l["disable_history"] then
                cI()
                c.wait(1000)
                for i = 0, 31 do
                    if c.valid(i) then
                        local db = true
                        for E = 1, #aU do
                            if #aU ~= 0 then
                                local cW = K.scid(i) == aU[E]["scid"]
                                local cX = K.name(i) == aU[E]["name"]
                                local dc = i == aU[E]["player_id"]
                                local dd = b1 == aU[E]["lobby"]
                                if cW and cX and dc and dd then
                                    db = false
                                end
                            end
                        end
                        if db then
                            local cP = {}
                            local cO = {}
                            for cT = 1, 11 do
                                cP[cT] = ped.get_ped_texture_variation(c.ped(i), cT)
                                cO[cT] = ped.get_ped_drawable_variation(c.ped(i), cT)
                            end
                            local cR = {}
                            local cS = {}
                            local cQ = {0, 1, 2, 6, 7}
                            for cT = 1, #cQ do
                                cR[cT] = ped.get_ped_prop_index(c.ped(i), cQ[cT])
                                cS[cT] = ped.get_ped_prop_texture_index(c.ped(i), cQ[cT])
                            end
                            aU[#aU + 1] = {
                                ["scid"] = K.scid(i),
                                ["name"] = K.name(i),
                                ["ip"] = K.ip(i),
                                ["first_seen"] = d.time_prefix(),
                                ["is_female"] = player.is_player_female(i),
                                ["h_textures"] = cP,
                                ["h_clothes"] = cO,
                                ["h_prop_ind"] = cR,
                                ["h_prop_text"] = cS,
                                ["lobby"] = b1,
                                ["player_id"] = i,
                                ["feature"] = false
                            }
                        end
                    end
                    c.wait(50)
                end
            end
            return d.stop(k)
        end
    )
    da.hidden = true
    da.on = true
    if l["2t1s_parent"] then
        aj["parent"] = b9("2Take1Script", 0).id
    end
    aj["bl"] = b9("Blacklist", aj["parent"])
    aj["bl"].hidden = l["bl_hidden"]
    aj["bl"] = aj["bl"].id
    ak["blacklist_enabled"] =
        be(
        "Enable Blacklist",
        aj["bl"],
        function(k)
            l["blacklist_enabled"] = k.on
            if k.on then
                c.wait(1000)
                bD()
                for i = 0, 31 do
                    if N.i(i) then
                        for de = 1, #aw do
                            if tostring(K.scid(i)) == aw[de] then
                                local j = K.name(i)
                                o("Blocked player detected.", 27)
                                o("Current name: " .. j .. "\nReal name: " .. ax[de], 27)
                                r("")
                                r("Blocked Player detected.")
                                r(j .. ":" .. aw[de])
                                r("Real name:" .. ax[de])
                                if ak["mark_modder"].on then
                                    player.set_player_as_modder(i, n["blacklist"][2])
                                end
                                if ak["auto_kick"].on then
                                    bJ(false, i)
                                end
                            end
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    ak["blacklist_enabled"].on = l["blacklist_enabled"]
    ak["auto_kick"] =
        be(
        "Enable Auto-Kick",
        aj["bl"],
        function(k)
            l["auto_kick"] = k.on
        end
    )
    ak["auto_kick"].on = l["auto_kick"]
    ak["mark_modder"] =
        be(
        "Mark as Modder",
        aj["bl"],
        function(k)
            l["mark_modder"] = k.on
        end
    )
    ak["mark_modder"].on = l["mark_modder"]
    bd(
        "Add player by SCID",
        aj["bl"],
        function()
            local I, cK = input.get("Enter SCID", "", 10, 3)
            while I == 1 do
                c.wait(0)
                I, cK = input.get("Enter SCID", "", 10, 3)
            end
            if I == 2 then
                return HANDLER_POP
            end
            local I, j = input.get("Enter Name", "", 64, 0)
            while I == 1 do
                c.wait(0)
                I, j = input.get("Enter Name", "", 64, 0)
            end
            if I == 2 then
                return HANDLER_POP
            end
            if j ~= "" and cK ~= "0" and cK ~= "-1" and cK ~= tostring(K.scid(c.id())) then
                d.write(c.o(b["Blacklist.cfg"], "a"), cK .. " " .. j)
                o("SCID with Name added to Blacklist.", 48)
                r("")
                r("Player added to Blacklist.")
                r(j .. ": " .. cK)
            end
        end
    )
    bd(
        "Count Currently Blocked Players",
        aj["bl"],
        function()
            bD()
            if aw ~= nil then
                o("Currently blocking " .. #aw .. " Players.")
            end
        end
    )
    ak["enable_admin"] =
        be(
        "Notify on Rockstar Admin SCID",
        aj["bl"],
        function(k)
            if k.on then
                c.wait(1000)
                for i = 0, 31 do
                    if N.i(i) then
                        for de = 1, #_ do
                            if tostring(K.scid(i)) == _[de] then
                                local j = K.name(i)
                                o("Rockstar Admin by SCID detected!\nName: " .. j, 27)
                                r("Rockstar Admin detected.")
                                r(j .. ":" .. K.scid(i))
                                if ak["kick_admin"].on then
                                    bJ(false, i)
                                end
                                if ak["crash_admin"].on then
                                    bW(i)
                                end
                            end
                        end
                    end
                end
            end
            l["admin_enabled"] = k.on
            return d.stop(k)
        end
    )
    ak["enable_admin"].on = l["admin_enabled"]
    ak["kick_admin"] =
        be(
        "Enable Auto-Kick Rockstar Admin",
        aj["bl"],
        function()
            o(
                "Thats the stupidest idea you ever had! Dont enable it, disable it!\nThis will get u banned for like 99%!",
                27
            )
        end
    )
    ak["kick_admin"].hidden = not ah
    ak["crash_admin"] =
        be(
        "Enable Auto-Crash Rockstar Admin",
        aj["bl"],
        function()
            o(
                "Thats the stupidest idea you ever had! Dont enable it, disable it!\nThis will get u banned for like 99%!",
                27
            )
        end
    )
    ak["crash_admin"].hidden = not ah
    ak["kick_joining"] =
        be(
        "Kick new joining Players",
        aj["bl"],
        function(k)
            if k.on then
                local time = c.time() + 2500
                while time > c.time() do
                    c.wait(250)
                    l["kick_joining"] = k.on
                end
                if aS[1] == nil then
                    for i = 0, 31 do
                        aS[i + 1] = K.scid(i)
                        aT[K.scid(i)] = 0
                    end
                end
                for i = 0, 31 do
                    if N.i(i) then
                        local D = true
                        for E = 1, #aS do
                            if aS[E] == K.scid(i) then
                                D = false
                            end
                        end
                        if D then
                            if aT[aS[i + 1]] <= 3 then
                                o(K.name(i) .. " is new here, sending greetings..!", 65)
                                r(K.name(i) .. " is new here, sending greetings..!")
                                bJ(false, i)
                                aT[aS[i + 1]] = aT[aS[i + 1]] + 1
                            else
                                aT[aS[i + 1]] = aT[aS[i + 1]] + 1
                                if aT[aS[i + 1]] >= 17 then
                                    aT[aS[i + 1]] = 0
                                end
                            end
                        end
                    end
                end
            end
            if not k.on then
                aT = {}
                for i = 0, 31 do
                    aS[i + 1] = nil
                end
            end
            l["kick_joining"] = k.on
            return d.stop(k)
        end
    )
    ak["kick_joining"].on = l["kick_joining"]
    aj["modder"] = b9("Modders", aj["parent"])
    aj["modder"].hidden = l["modder_hidden"]
    aj["modder"] = aj["modder"].id
    ak["remember_modder"] =
        be(
        "Remember every Modder",
        aj["modder"],
        function(k)
            if k.on then
                if utils.file_exists(b["Modders"]) then
                    local F = c.o(b["Modders"], "r")
                    if F ~= nil then
                        local bT = {}
                        ay = {}
                        for df in io.lines(b["Modders"]) do
                            while string.find(df, " ", 1) ~= nil do
                                df = df:gsub("(.*)%s.*$", "%1")
                            end
                            bT[#bT + 1] = df
                        end
                        ay = bT
                        io.close(F)
                    end
                end
                for i = 0, 31 do
                    if N.i(i) then
                        local cK = K.scid(i)
                        local dg = false
                        if ay[1] ~= nil then
                            for dh = 1, #ay do
                                if tostring(cK) == ay[dh] then
                                    dg = true
                                    if not player.is_player_modder(i, -1) then
                                        o("Remembered " .. K.name(i) .. " as a Modder, remarking...", 130)
                                        r("Remembered '" .. K.name(i) .. "' as a Modder, remarking...")
                                        player.set_player_as_modder(i, n["remembered"][2])
                                    end
                                end
                            end
                        end
                        if player.is_player_modder(i, -1) and not dg then
                            d.write(c.o(b["Modders"], "a"), cK .. " " .. K.name(i))
                            o("Modder " .. K.name(i) .. " added to Remember-List.", 130)
                            r("Modder '" .. K.name(i) .. "' added to Remember-List.")
                        end
                    end
                end
            end
            l["remember_modder"] = k.on
            return d.stop(k)
        end
    )
    ak["remember_modder"].on = l["remember_modder"]
    bd("Modder-Detection:", aj["modder"])
    ak["speed_bypass"] =
        be(
        "Max-Speed-Bypass",
        aj["modder"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    local cK = K.scid(i)
                    if
                        N.modder(i) and player.get_player_health(i) ~= 0 and
                            interior.get_interior_from_entity(c.ped(i)) == 0
                     then
                        local di = 45
                        local id = c.ped(i)
                        if
                            ai.is_task_active(id, 403) or ai.is_task_active(id, 408) or ai.is_task_active(id, 335) or
                                ai.is_task_active(id, 2) or
                                ai.is_task_active(id, 422)
                         then
                            di = 95
                        end
                        if ai.is_task_active(id, 97) or ai.is_task_active(id, 38) or ai.is_task_active(id, 160) then
                            di = 60
                        end
                        if ai.is_task_active(id, 50) or ai.is_task_active(id, 1) then
                            di = 100
                        end
                        local bt = ped.get_vehicle_ped_is_using(id)
                        if bt ~= 0 then
                            if id == vehicle.get_ped_in_vehicle_seat(bt, -1) then
                                id = bt
                                local ci = entity.get_entity_model_hash(bt)
                                if streaming.is_model_a_plane(ci) then
                                    di = 170
                                else
                                    di = 100
                                end
                            end
                        end
                        local dj = entity.get_entity_speed(id)
                        dj = math.floor(dj)
                        if dj > di then
                            o(
                                K.name(i) ..
                                    " bypassed Max-Speed-Limit of: " ..
                                        di .. " with a speed of: " .. dj .. "\nMarking him as a Modder...",
                                130
                            )
                            r(K.name(i) .. " bypassed Max-Speed-Limit of: " .. di .. " with a speed of: " .. dj)
                            r("Marking him as a Modder...")
                            for dh = 0, 600 do
                                if ai.is_task_active(c.ped(i), dh) then
                                    r("Current active Task: " .. dh)
                                end
                            end
                            player.set_player_as_modder(i, n["maxspeed"][2])
                        end
                    end
                end
            end
            l["speed_bypass"] = k.on
            return d.stop(k)
        end
    )
    ak["speed_bypass"].on = l["speed_bypass"]
    ak["name_bypass"] =
        be(
        "Illegal Name",
        aj["modder"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    local cK = K.scid(i)
                    if N.modder(i) then
                        local j = K.name(i)
                        if string.len(j) < 6 or string.len(j) > 16 or not string.find(j, "^[%.%-%w_]+$") then
                            o(j .. " has an illegal name!\nMarking him as a Modder...", 130)
                            r(j .. " has an illegal name!")
                            r("Marking him as a Modder...")
                            player.set_player_as_modder(i, n["illegalname"][2])
                        end
                    end
                end
            end
            l["name_bypass"] = k.on
            return d.stop(k)
        end
    )
    ak["name_bypass"].on = l["name_bypass"]
    ak["modded_ip_scid"] =
        be(
        "Modded IP / SCID",
        aj["modder"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    if N.modder(i) then
                        local j = K.name(i)
                        local dk = player.get_player_ip(i)
                        for de = 1, #aa do
                            if dk == aa[de] then
                                o(j .. " has an modded IP!\nMarking him as a Modder...", 130)
                                r(j .. " has an modded IP!")
                                r("Marking him as a Modder...")
                                player.set_player_as_modder(i, n["moddedip"][2])
                            end
                        end
                        local cK = K.scid(i)
                        if cK < 10000 or cK > 234567891 then
                            o(j .. " has an modded SCID!\nMarking him as a Modder...", 130)
                            r(j .. " has an modded SCID!")
                            r("Marking him as a Modder...")
                            player.set_player_as_modder(i, n["moddedscid"][2])
                        end
                        for de = 1, #ab do
                            if cK == ab[de] then
                                o(j .. " has an modded SCID!\nMarking him as a Modder...", 130)
                                r(j .. " has an modded SCID!")
                                r("Marking him as a Modder...")
                                player.set_player_as_modder(i, n["moddedscid"][2])
                            end
                        end
                    end
                end
            end
            l["modded_ip_scid"] = k.on
            return d.stop(k)
        end
    )
    ak["modded_ip_scid"].on = l["modded_ip_scid"]
    ak["modded_net_events"] =
        be(
        "Modded Net-Events",
        aj["modder"],
        function()
            if aY == nil then
                aY = hook.register_net_event_hook(cz)
            else
                hook.remove_net_event_hook(aY)
                aY = nil
            end
            l["modded_net_events"] = ak["modded_net_events"].on
        end
    )
    ak["modded_net_events"].on = l["modded_net_events"]
    ak["modder_force_sh"] =
        be(
        "Forcing Script-Host",
        aj["modder"],
        function(k)
            l["modder_force_sh"] = k.on
            if k.on then
                if aC == nil then
                    aC = script.get_host_of_this_script()
                end
                local time = c.time() + 17500
                while time > c.time() do
                    c.wait(250)
                    l["modder_force_sh"] = k.on
                end
                local dl = script.get_host_of_this_script()
                if not c.valid(aC) or K.scid(aC) == -1 then
                    aC = nil
                end
                if aC ~= nil then
                    if aC ~= dl then
                        if c.valid(aC) and c.valid(dl) then
                            if K.scid(aC) ~= -1 and K.scid(dl) ~= -1 then
                                r("Script-Host changed without previous SH leaving!")
                                r("SH changed from '" .. K.name(aC) .. "' to '" .. K.name(dl) .. "'.")
                                o("Script-Host changed from '" .. K.name(aC) .. "' to '" .. K.name(dl) .. "'.", 130)
                                player.set_player_as_modder(dl, n["force_sh"][2])
                                aC = dl
                            end
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    ak["modder_force_sh"].on = l["modder_force_sh"]
    ak["modded_script_event"] =
        be(
        "Modded Script Event",
        aj["modder"],
        function(k)
            l["modded_script_event"] = k.on
            if k.on then
                if aX == nil then
                    aX =
                        hook.register_script_event_hook(
                        function(cs, cd, ct, cu)
                            local cB = false
                            if #ct > 1 then
                                if cs ~= ct[2] then
                                    cB = true
                                end
                            else
                                cB = true
                            end
                            if cB then
                                o("Detected '" .. K.name(cs) .. "' sending a modded Script Event!")
                            end
                        end
                    )
                end
            end
            if not k.on then
                if aX ~= nil then
                    hook.remove_script_event_hook(aX)
                    aX = nil
                end
            end
            d.stop(k)
        end
    )
    ak["modded_script_event"].on = l["modded_script_event"]
    aj["lobby"] = b9("Lobby", aj["parent"])
    aj["lobby"].hidden = l["lobby_hidden"]
    aj["lobby"] = aj["lobby"].id
    aj["bl_veh"] = b9("Block Vehicles in Session", aj["lobby"]).id
    ak["veh_blacklist"] =
        be(
        "Activate Block Vehicles",
        aj["bl_veh"],
        function(k)
            l["veh_blacklist"] = k.on
            if k.on then
                local time = c.time() + 2000
                while time > c.time() do
                    c.wait(200)
                    l["veh_blacklist"] = k.on
                end
                for i = 0, 31 do
                    if N.i(i) then
                        local bt = ped.get_vehicle_ped_is_using(c.ped(i))
                        if bt ~= 0 then
                            bt = entity.get_entity_model_hash(bt)
                            for bG = 1, #U do
                                if ak[U[bG][1]].on and bt == U[bG][2] then
                                    r("Detected Blacklisted Vehicle " .. U[bG][1] .. " in Session!")
                                    bt = ped.get_vehicle_ped_is_using(c.ped(i))
                                    H.ctrl(bt, 100)
                                    if entity.get_entity_god_mode(bt) then
                                        H.ctrl(bt)
                                        entity.set_entity_god_mode(bt, false)
                                    end
                                    if not entity.get_entity_god_mode(bt) then
                                        r("Exploding User: " .. K.name(i))
                                        o(
                                            "Detected Blacklisted Vehicle " ..
                                                U[bG][1] .. " from user: " .. K.name(i) .. ", exploding it!",
                                            28
                                        )
                                        entity.set_entity_velocity(bt, v3())
                                        vehicle.set_vehicle_forward_speed(bt, 0)
                                        vehicle.set_vehicle_out_of_control(bt, false, true)
                                        fire.add_explosion(c.gcoords(c.ped(i)), 59, false, true, 1, c.ped(i))
                                    end
                                end
                            end
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    ak["veh_blacklist"].on = l["veh_blacklist"]
    for i = 1, #U do
        ak[U[i][1]] =
            be(
            "Block: " .. U[i][1],
            aj["bl_veh"],
            function(k)
                l[U[i][1]] = k.on
            end
        )
        ak[U[i][1]].on = l[U[i][1]]
    end
    aj["bl_area"] = b9("Block Areas", aj["lobby"]).id
    ak["teleport_to_block"] =
        be(
        "Teleport to Block",
        aj["bl_area"],
        function(k)
            l["teleport_to_block"] = k.on
        end
    )
    ak["teleport_to_block"].on = l["teleport_to_block"]
    bd(
        "Clear blocking Objects",
        aj["bl_area"],
        function()
            bn(a0["bl_objects"])
            a0["bl_objects"] = {}
        end
    )
    aj["bl_area_lsc"] = b9("Block LSCs", aj["bl_area"]).id
    for i = 1, #W do
        bd(
            W[i][1],
            aj["bl_area_lsc"],
            function()
                ck(W[i][2])
            end
        )
    end
    aj["bl_area_casino"] = b9("Block Casino", aj["bl_area"]).id
    for i = 1, #X do
        bd(
            X[i][1],
            aj["bl_area_casino"],
            function()
                ck(X[i][2])
            end
        )
    end
    aj["bl_area_mazebank"] = b9("Block Maze Bank", aj["bl_area"]).id
    for i = 1, #Y do
        bd(
            Y[i][1],
            aj["bl_area_mazebank"],
            function()
                ck(Y[i][2])
            end
        )
    end
    aj["bl_area_custom"] = b9("Custom Areas", aj["bl_area"]).id
    for i = 1, #a6 do
        bd(
            a6[i][1],
            aj["bl_area_custom"],
            function()
                ck(a6[i][2])
            end
        )
    end
    aj["explode"] = b9("Explosion-Features", aj["lobby"]).id
    ak["laser_beam_explode_waypoint"] =
        bd(
        "Laser Beam Explode Waypoint",
        aj["explode"],
        function()
            local dm = ui.get_waypoint_coord()
            if dm.x ~= 16000 then
                local dn = c.gcoords(M.ped()).z + 175
                for i = dn, -50, -2 do
                    local bs = v3(dm.x, dm.y, i)
                    bs.x = math.floor(bs.x)
                    bs.y = math.floor(bs.y)
                    fire.add_explosion(bs, 59, true, false, 0, 0)
                    for bG = 1, 2 do
                        bs.x = c.random(bs.x - 3, bs.x + 3)
                        bs.y = c.random(bs.y - 3, bs.y + 3)
                        fire.add_explosion(bs, 59, true, false, 0, 0)
                    end
                    bs.x = c.random(bs.x - 6, bs.x + 6)
                    bs.y = c.random(bs.y - 6, bs.y + 6)
                    fire.add_explosion(bs, 8, true, false, 0, 0)
                    c.wait(0)
                end
            else
                o("No Waypoint found, set a waypoint first!")
            end
        end
    )
    ak["explode_lobby"] =
        bf(
        "Random Explosions",
        "value_i",
        aj["explode"],
        function(k)
            if k.on then
                local bs = v3()
                for i = 1, 5 do
                    bs.x = c.random(-2700, 2700)
                    bs.y = c.random(-3300, 7500)
                    bs.z = c.random(30, 90)
                    fire.add_explosion(bs, ak["explode_lobby"].value_i, true, false, 0, 0)
                end
            end
            l["explode_lobby_value"] = k.value_i
            l["explode_lobby"] = k.on
            return d.stop(k)
        end
    )
    ak["explode_lobby"].max_i = 74
    ak["explode_lobby"].min_i = 0
    ak["explode_lobby"].value_i = l["explode_lobby_value"]
    ak["explode_lobby"].on = l["explode_lobby"]
    ak["explode_lobby_shake"] =
        be(
        "Shake Cam",
        aj["explode"],
        function(k)
            if k.on then
                local bs = v3()
                for i = 1, 10 do
                    bs.x = c.random(-2700, 2700)
                    bs.y = c.random(-3300, 7500)
                    bs.z = c.random(30, 90)
                    fire.add_explosion(bs, 8, false, true, 20, 0)
                end
            end
            l["explode_lobby_shake"] = k.on
            return d.stop(k)
        end
    )
    ak["explode_lobby_shake"].on = l["explode_lobby_shake"]
    aj["sound"] = b9("Sound-Features", aj["lobby"]).id
    ak["sound_rape"] =
        be(
        "Sound Rape",
        aj["sound"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    if N.i(i) then
                        audio.play_sound_from_entity(2, "Wasted", c.ped(i), "DLC_IE_VV_General_Sounds")
                    end
                end
            end
            l["sound_rape"] = k.on
            return d.stop(k)
        end
    )
    ak["sound_rape"].on = l["sound_rape"]
    bd(
        "Garage-Door Sound - Infinite Time",
        aj["sound"],
        function()
            for i = 0, 31 do
                if N.i(i) then
                    audio.play_sound_from_entity(2, "Garage_Door", c.ped(i), "DLC_HEISTS_GENERIC_SOUNDS")
                end
            end
        end
    )
    ak["kill_all_peds"] =
        be(
        "Kill all PEDs",
        aj["lobby"],
        function(k)
            if k.on then
                local dp = ped.get_all_peds()
                for i = 1, #dp do
                    if not ped.is_ped_a_player(dp[i]) then
                        ped.set_ped_health(dp[i], 0)
                    end
                end
            end
            l["kill_all_peds"] = k.on
            return d.stop(k)
        end
    )
    ak["kill_all_peds"].on = l["kill_all_peds"]
    aj["lobby_vehicle"] = b9("Vehicles", aj["lobby"]).id
    ak["disablecontrol"] =
        be(
        "Disable Control from near Vehicles",
        aj["lobby_vehicle"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    if N.i(i) then
                        local bt = ped.get_vehicle_ped_is_using(c.ped(i))
                        if bt ~= 0 then
                            H.ctrl(bt)
                            vehicle.set_vehicle_forward_speed(bt, 25)
                            vehicle.set_vehicle_out_of_control(bt, false, true)
                        end
                    end
                end
            end
            l["disablecontrol"] = k.on
            return d.stop(k)
        end
    )
    ak["disablecontrol"].on = l["disablecontrol"]
    ak["modify_veh_speed"] =
        bf(
        "Modify Vehicle Speeds",
        "autoaction_value_i",
        aj["lobby_vehicle"],
        function(k)
            l["modify_veh_speed"] = k.value_i
            local di = 540
            if l["modify_veh_speed_override"] then
                di = k.value_i
            end
            for i = 0, 31 do
                if N.i(i, l["modify_veh_speed_include"]) then
                    local bt = ped.get_vehicle_ped_is_using(c.ped(i))
                    if bt ~= 0 then
                        H.ctrl(bt)
                        entity.set_entity_max_speed(bt, di)
                        vehicle.modify_vehicle_top_speed(bt, k.value_i)
                    end
                end
            end
        end
    )
    ak["modify_veh_speed"].min_i = -500
    ak["modify_veh_speed"].max_i = 1000
    ak["modify_veh_speed"].mod_i = 25
    ak["modify_veh_speed"].value_i = l["modify_veh_speed"]
    bd(
        "Reset Modifies",
        aj["lobby_vehicle"],
        function()
            local di = 540
            for i = 0, 31 do
                if c.valid(i) then
                    local bt = ped.get_vehicle_ped_is_using(c.ped(i))
                    if bt ~= 0 then
                        H.ctrl(bt)
                        entity.set_entity_max_speed(bt, di)
                        vehicle.modify_vehicle_top_speed(bt, 0)
                    end
                end
            end
        end
    )
    ak["modify_veh_speed_include"] =
        be(
        "Include Self & Friends",
        aj["lobby_vehicle"],
        function(k)
            l["modify_veh_speed_include"] = k.on
        end
    )
    ak["modify_veh_speed_include"].on = l["modify_veh_speed_include"]
    ak["modify_veh_speed_overwrite"] =
        be(
        "Overwrite default Speedlimit",
        aj["lobby_vehicle"],
        function(k)
            l["modify_veh_speed_overwrite"] = k.on
        end
    )
    ak["modify_veh_speed_overwrite"].on = l["modify_veh_speed_overwrite"]
    aj["lobby_bounty"] = b9("Bounty", aj["lobby"]).id
    ak["bounty_after_death"] =
        bf(
        "Set Bounty after Death",
        "value_i",
        aj["lobby_bounty"],
        function(k)
            l["bounty_after_death"] = k.on
            l["bounty_after_death_value"] = k.value_i
            if k.on then
                local dq = 0
                if ak["anonymous_bounty"].on then
                    dq = 1
                end
                for i = 0, 31 do
                    if N.i(i) then
                        if player.get_player_health(i) == 0 then
                            o(K.name(i) .. " is dead!\nSetting bounty...", 33)
                            r(K.name(i) .. " is dead!")
                            r("Setting bounty...")
                            for dh = 0, 31 do
                                if K.scid(dh) ~= -1 then
                                    c.script(
                                        544453591,
                                        dh,
                                        {
                                            69,
                                            i,
                                            1,
                                            ak["bounty_after_death"].value_i,
                                            0,
                                            dq,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            script.get_global_i(1650640 + 9),
                                            script.get_global_i(1650640 + 10)
                                        }
                                    )
                                end
                            end
                            c.wait(1500)
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    ak["bounty_after_death"].min_i = 0
    ak["bounty_after_death"].max_i = 10000
    ak["bounty_after_death"].value_i = l["bounty_after_death_value"]
    ak["bounty_after_death"].on = l["bounty_after_death"]
    ak["anonymous_bounty"] =
        be(
        "Anonymous Bounty",
        aj["lobby_bounty"],
        function(k)
            l["anonymous_bounty"] = k.on
        end
    )
    ak["anonymous_bounty"].on = l["anonymous_bounty"]
    for i = 1, #ad do
        bd(
            ad[i] .. "$",
            aj["lobby_bounty"],
            function()
                local dq = 0
                if ak["anonymous_bounty"].on then
                    dq = 1
                end
                for dh = 0, 31 do
                    if K.scid(dh) ~= -1 then
                        for dr = 0, 31 do
                            if K.scid(dr) ~= -1 then
                                c.script(
                                    544453591,
                                    dr,
                                    {
                                        69,
                                        dh,
                                        1,
                                        ad[i],
                                        0,
                                        dq,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        script.get_global_i(1650640 + 9),
                                        script.get_global_i(1650640 + 10)
                                    }
                                )
                            end
                        end
                    end
                end
            end
        )
    end
    aj["lobby_se"] = b9("Script Events", aj["lobby"]).id
    aj["lobby_se_custom"] = b9("Custom Script Events", aj["lobby_se"]).id
    bd(
        "Enter Custom Script Event with Parameters",
        aj["lobby_se_custom"],
        function()
            local I, ds, dt
            local du = {}
            I, ds = input.get("Enter Custom SE (DEC)", "", 32, 3)
            while I == 1 do
                c.wait(0)
                I, ds = input.get("Enter Custom SE (DEC)", "", 32, 3)
            end
            if I == 2 then
                o("Aborted sending Custom Event...", 100)
                return HANDLER_POP
            end
            while dt ~= "#" do
                I, dt = input.get("Enter Parameter (DEC), to EXIT and send, enter #", "", 32, 0)
                while I == 1 do
                    c.wait(0)
                    I, dt = input.get("Enter Parameter (DEC), to EXIT and send, enter #", "", 32, 0)
                end
                if I == 2 then
                    o("Aborted sending Custom Event...", 100)
                    return HANDLER_POP
                end
                if dt == "#" then
                    break
                end
                dt = c.no(dt)
                if type(dt) == "number" then
                    du[#du + 1] = dt
                else
                    o("Aborted sending Custom Event...", 100)
                    return HANDLER_POP
                end
            end
            for i = 0, 31 do
                if N.i(i) then
                    c.script(ds, i, du)
                end
            end
            o("Sent Custom Script Event with Parameters to Players.", 100)
        end
    )
    for i = 1, #a5 do
        bd(
            a5[i][1],
            aj["lobby_se_custom"],
            function()
                o("Sent Custom Script Event to Players.", 100)
                for E = 0, 31 do
                    if N.i(E) then
                        for bG = 1, #a5[i][2] do
                            c.script(a5[i][2][bG][1], E, a5[i][2][bG][2])
                        end
                    end
                end
            end
        )
    end
    aj["lobby_send_2_mission"] = b9("Send all to Mission", aj["lobby_se"]).id
    for i = 1, #Q do
        bd(
            "Send to " .. Q[i][1],
            aj["lobby_send_2_mission"],
            function()
                cl(true, 0x692CC4BB, Q[i][2])
                o("Sent Session to Mission")
            end
        )
    end
    aj["lobby_ceo"] = b9("CEO all Player", aj["lobby_se"]).id
    for i = 1, 3 do
        bd(
            R[i][1],
            aj["lobby_ceo"],
            function()
                cl(true, R[i][2], R[i][3], R[i][4], R[i][5])
                o("Modified Players CEO")
            end
        )
    end
    bd(
        "Block - Passive",
        aj["lobby_se"],
        function()
            cl(true, 0x54BAD868, {1, 1})
            o("Blocked all Players from activating Passive.")
        end
    )
    bd(
        "UN-Block - Passive",
        aj["lobby_se"],
        function()
            cl(true, 0x54BAD868, {2, 0})
            o("UN-Blocked all Players from Passive.")
        end
    )
    aj["lobby_sms"] =
        b9(
        "Send SMSs to Lobby",
        aj["lobby"],
        function()
            o("Players must have Voice-Chat enabled to recive SMS.")
        end
    ).id
    bd(
        "Custom SMS input",
        aj["lobby_sms"],
        function()
            local I, dv = input.get("Enter Custom SMS", "", 128, 0)
            while I == 1 do
                c.wait(0)
                I, dv = input.get("Enter Custom SMS", "", 128, 0)
            end
            if I == 2 then
                return HANDLER_POP
            end
            for i = 0, 31 do
                if N.i(i) then
                    player.send_player_sms(i, dv)
                end
            end
        end
    )
    bd(
        "Send SCID & IP",
        aj["lobby_sms"],
        function()
            for i = 0, 31 do
                if N.i(i) then
                    local cK = tostring(K.scid(i))
                    local dk = K.ip(i)
                    player.send_player_sms(i, "R*SCID: " .. cK .. "~n~IP: " .. dk)
                end
            end
        end
    )
    for i = 1, #ae do
        bd(
            ae[i],
            aj["lobby_sms"],
            function()
                for dh = 0, 31 do
                    if N.i(dh) then
                        player.send_player_sms(dh, ae[i])
                    end
                end
            end
        )
    end
    aj["lobby_malicious"] = b9("Malicious", aj["lobby"]).id
    ak["karma_se"] =
        be(
        "Karma every Script Event",
        aj["lobby_malicious"],
        function(k)
            if b6 == nil then
                b6 = hook.register_script_event_hook(cy)
            else
                hook.remove_script_event_hook(b6)
            end
            l["karma_se"] = k.on
        end
    )
    ak["karma_se"].on = l["karma_se"]
    ak["punish_aliens"] =
        be(
        "Punish Aliens in Lobby",
        aj["lobby_malicious"],
        function(k)
            l["punish_aliens"] = k.on
            if k.on then
                local time = c.time() + 15000
                while time > c.time() do
                    l["punish_aliens"] = k.on
                    c.wait(150)
                end
                for i = 0, 31 do
                    if N.i(i) then
                        local cB = 0
                        if player.is_player_female(i) then
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 1) == 134 and
                                    (ped.get_ped_texture_variation(c.ped(i), 1) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 1) == 9)
                             then
                                cB = cB + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 4) == 113 and
                                    (ped.get_ped_texture_variation(c.ped(i), 4) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 4) == 9)
                             then
                                cB = cB + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 6) == 87 and
                                    (ped.get_ped_texture_variation(c.ped(i), 6) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 6) == 9)
                             then
                                cB = cB + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 11) == 287 and
                                    (ped.get_ped_texture_variation(c.ped(i), 11) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 11) == 9)
                             then
                                cB = cB + 1
                            end
                        else
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 1) == 134 and
                                    (ped.get_ped_texture_variation(c.ped(i), 1) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 1) == 9)
                             then
                                cB = cB + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 4) == 106 and
                                    (ped.get_ped_texture_variation(c.ped(i), 4) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 4) == 9)
                             then
                                cB = cB + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 6) == 83 and
                                    (ped.get_ped_texture_variation(c.ped(i), 6) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 6) == 9)
                             then
                                cB = cB + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 11) == 274 and
                                    (ped.get_ped_texture_variation(c.ped(i), 11) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 11) == 9)
                             then
                                cB = cB + 1
                            end
                        end
                        if cB > 1 then
                            r(K.name(i) .. " is a useless alien!")
                            r("Guilty Level: " .. cB)
                            o(K.name(i) .. " is a useless alien! Punishing him!", 23)
                            player.send_player_sms(i, "Delete your stupid alien Outfit!")
                            bO(a7[5][2], i)
                            bO(a7[8][2], i)
                            fire.add_explosion(c.gcoords(c.ped(i)), 59, false, true, 1, c.ped(i))
                            fire.add_explosion(c.gcoords(c.ped(i)), 8, true, false, 1, c.ped(i))
                            fire.add_explosion(c.gcoords(c.ped(i)), 60, true, false, 1, c.ped(i))
                            fire.add_explosion(c.gcoords(c.ped(i)), 8, true, false, 1, c.ped(i))
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    ak["punish_aliens"].on = l["punish_aliens"]
    bd(
        "Kick all Players",
        aj["lobby_malicious"],
        function()
            bJ(true)
        end
    )
    bd(
        "Host Kick All",
        aj["lobby_malicious"],
        function()
            if network.network_is_host() then
                for i = 0, 31 do
                    if N.i(i) then
                        network.network_session_kick_player(i)
                    end
                end
            else
                o("You are not Session-Host!")
            end
        end
    )
    ak["force_host"] =
        be(
        "Kick Hosts until You become Host",
        aj["lobby_malicious"],
        function(k)
            if k.on then
                local time = c.time() + 7500
                while time > c.time() do
                    c.wait(250)
                    l["force_host"] = k.on
                end
                local dw = player.get_host()
                if dw ~= c.id() and K.scid(dw) ~= -1 then
                    r("You are not Host!")
                    r(K.name(dw) .. ":" .. K.scid(dw) .. " is Host!")
                    o(K.name(dw) .. " is Host!")
                    bJ(false, dw)
                end
            end
            l["force_host"] = k.on
            return d.stop(k)
        end
    )
    ak["force_host"].on = l["force_host"]
    bd(
        "Crash Session",
        aj["lobby_malicious"],
        function()
            r("Crashing Session...")
            c.navigate(false)
            as = entity.get_entity_model_hash(M.ped())
            for i = 1, 11 do
                at[i] = ped.get_ped_texture_variation(M.ped(), i)
            end
            for i = 1, 11 do
                au[i] = ped.get_ped_drawable_variation(M.ped(), i)
            end
            bA(0x471BE4B2, nil, nil, nil, true)
            av = true
            c.wait(5000)
            cq()
            c.navigate(true)
            r("Done.")
        end
    )
    bd("Fix loading screen after Crash", aj["lobby_malicious"], cq)
    if l["2t1s_parent"] then
        aj["opl_parent"] = bh("2Take1Script", 0).id
    end
    bj(
        "Unmark Modder",
        aj["opl_parent"],
        function(k, id)
            if k.on then
                if player.is_player_modder(id, -1) then
                    player.unset_player_as_modder(id, -1)
                end
            end
            return d.stop(k)
        end
    )
    bj(
        "Remote Control Vehicle",
        aj["opl_parent"],
        function(k, dx)
            local dy = menu.get_player_feature(k.id)
            if k.on then
                if aE ~= dx then
                    aE = dx
                    for i = 1, #dy.feats do
                        if i - 1 ~= dx and dy.feats[i].on then
                            dy.feats[i].on = false
                        end
                    end
                end
                local bt = ped.get_vehicle_ped_is_using(c.ped(dx))
                if bt ~= 0 then
                    if aD == nil then
                        local ci = entity.get_entity_model_hash(bt)
                        aD = vehicle.create_vehicle(ci, M.coords(), 0, true, false)
                        ped.set_ped_into_vehicle(M.ped(), aD, -1)
                        c.wait(50)
                    end
                    entity.set_entity_visible(aD, false)
                    if entity.get_entity_attached_to(bt) ~= aD then
                        H.ctrl(aD)
                        entity.set_entity_velocity(aD, v3())
                        bl(aD, c.gcoords(bt))
                        c.wait(0)
                        entity.set_entity_rotation(aD, entity.get_entity_rotation(bt))
                        H.ctrl(bt)
                        entity.set_entity_velocity(bt, v3())
                        entity.set_entity_max_speed(bt, 0)
                        vehicle.set_vehicle_out_of_control(bt, false, false)
                        entity.attach_entity_to_entity(bt, aD, 0, v3(), v3(), true, false, false, 0, true)
                    end
                    return HANDLER_CONTINUE
                else
                    for i = 1, #dy.feats do
                        if dy.feats[i].on then
                            dy.feats[i].on = false
                        end
                    end
                    o("Target is not in a Vehicle!")
                    return HANDLER_POP
                end
            end
            if aD ~= nil then
                ped.clear_ped_tasks_immediately(M.ped())
                bn({aD})
                aD = nil
            end
            return HANDLER_POP
        end
    )
    bi(
        "Repair Vehicle",
        aj["opl_parent"],
        function(k, dx)
            local bt = ped.get_vehicle_ped_is_using(c.ped(dx))
            if bt ~= 0 then
                H.ctrl(bt)
                vehicle.set_vehicle_fixed(bt)
                vehicle.set_vehicle_deformation_fixed(bt)
                vehicle.set_vehicle_can_be_visibly_damaged(bt, false)
                r("Repaired Vehicle.")
            end
        end
    )
    bj(
        "Waypoint Player",
        aj["opl_parent"],
        function(k, dx)
            local dy = menu.get_player_feature(k.id)
            if k.on then
                if aO ~= dx then
                    aO = dx
                    for i = 1, #dy.feats do
                        if i - 1 ~= dx and dy.feats[i].on then
                            dy.feats[i].on = false
                        end
                    end
                end
                local bs = c.gcoords(c.ped(dx))
                ui.set_new_waypoint(v2(bs.x, bs.y))
                c.wait(500)
                return HANDLER_CONTINUE
            end
            c.wait(10)
            ui.set_waypoint_off()
            c.wait(10)
            return HANDLER_POP
        end
    )
    bi(
        "Modify Speed (0-500)",
        aj["opl_parent"],
        function(k, dx)
            local bt = ped.get_vehicle_ped_is_using(c.ped(dx))
            if bt ~= 0 then
                local I, dj = input.get("Enter modified Speed (0-500)", "", 10, 3)
                while I == 1 do
                    c.wait(0)
                    I, dj = input.get("Enter modified Speed (0-500)", "", 10, 3)
                end
                if I == 2 then
                    return HANDLER_POP
                end
                dj = c.no(dj)
                if dj < 0 or dj > 500 then
                    o("Invalid Speed.")
                    return HANDLER_POP
                end
                o("Setting modified Speed.")
                H.ctrl(bt)
                entity.set_entity_max_speed(bt, dj)
                vehicle.modify_vehicle_top_speed(bt, dj)
            end
        end
    )
    aj["attach"] = bh("Attach Objects", aj["opl_parent"]).id
    bi(
        "Attach Entity from Aim",
        aj["attach"],
        function(k, id)
            local dz = player.get_entity_player_is_aiming_at(c.id())
            if dz ~= 0 then
                bO({{dz, 0, {0, 0, 0}, {0, 0, 0}}}, id, true)
            else
                o("No Entity found. Aim @Entity to attach it to Player.")
            end
        end
    )
    bi(
        "Clear Entitys",
        aj["attach"],
        function()
            r("Clearing Attachments.")
            bn(a0["attach_obj"])
            a0["attach_obj"] = {}
            o("Cleared all Attachment Entitys.")
        end
    )
    for i = 1, #a7 do
        bi(
            a7[i][1],
            aj["attach"],
            function(k, id)
                bO(a7[i][2], id)
            end
        )
    end
    aj["opl_event_logger"] = bh("Log Events", aj["opl_parent"]).id
    bj(
        "Log Script Events",
        aj["opl_event_logger"],
        function(k, id)
            if k.on then
                if aV[id] == nil then
                    aV[id] =
                        hook.register_script_event_hook(
                        function(cs, cd, ct, cu)
                            if cs == id then
                                local cK = K.scid(id)
                                local j = K.name(id)
                                local dA = tostring(cK) .. "-" .. j
                                local e = a["Event-Logger"] .. "\\" .. dA .. "\\" .. "Script-Events.log"
                                local t = d.time_prefix() .. " [Script-Event-Logger]"
                                local f = t
                                if not utils.dir_exists(a["Event-Logger"]) then
                                    utils.make_dir(a["Event-Logger"])
                                end
                                if not utils.dir_exists(a["Event-Logger"] .. "\\" .. dA) then
                                    utils.make_dir(a["Event-Logger"] .. "\\" .. dA)
                                end
                                if not utils.file_exists(e) then
                                    o("Logging to folder '2Take1Script/Event-Logger/" .. dA, 14)
                                    f = "Starting to log Script-Events from Player: " .. j .. ":" .. cK .. "\n" .. t
                                end
                                f = f .. "\n" .. ct[1] .. ", {"
                                for i = 2, #ct do
                                    f = f .. ct[i]
                                    if i ~= #ct then
                                        f = f .. ", "
                                    end
                                end
                                f = f .. "}\n"
                                f = f .. "Parameter count: " .. cu - 1 .. "\n"
                                d.write(c.o(e, "a"), f)
                            end
                        end
                    )
                end
                return HANDLER_CONTINUE
            end
            if not k.on and aV[id] ~= nil then
                hook.remove_script_event_hook(aV[id])
                aV[id] = nil
            end
        end
    )
    bi(
        "Reset Script Event Log",
        aj["opl_event_logger"],
        function(k, id)
            local cK = K.scid(id)
            local j = K.name(id)
            local dA = tostring(cK) .. "-" .. j
            local e = a["Event-Logger"] .. "\\" .. dA .. "\\" .. "Script-Events.log"
            if utils.file_exists(e) then
                os.remove(e)
            else
                o("There was no log to reset.", 14)
            end
        end
    )
    bj(
        "Log Net Events",
        aj["opl_event_logger"],
        function(k, id)
            if k.on then
                if aW[id] == nil then
                    aW[id] =
                        hook.register_net_event_hook(
                        function(cs, cd, cA)
                            if cs == id then
                                local cK = K.scid(id)
                                local j = K.name(id)
                                local dA = tostring(cK) .. "-" .. j
                                local e = a["Event-Logger"] .. "\\" .. dA .. "\\" .. "Net-Events.log"
                                local t = d.time_prefix() .. " [Net-Event-Logger]"
                                local f = t
                                if not utils.dir_exists(a["Event-Logger"]) then
                                    utils.make_dir(a["Event-Logger"])
                                end
                                if not utils.dir_exists(a["Event-Logger"] .. "\\" .. dA) then
                                    utils.make_dir(a["Event-Logger"] .. "\\" .. dA)
                                end
                                if not utils.file_exists(e) then
                                    o("Logging to folder '2Take1Script/Event-Logger/" .. dA, 14)
                                    f = "Starting to log Net-Events from Player: " .. j .. ":" .. cK .. "\n" .. f
                                end
                                local dB = "Unknown Net-Event"
                                if af[cA] ~= nil then
                                    dB = af[cA]
                                end
                                f = f .. "\nEvent: " .. dB .. "\nEvent ID: " .. cA .. "\n"
                                d.write(c.o(e, "a"), f)
                            end
                        end
                    )
                end
                return HANDLER_CONTINUE
            end
            if not k.on and aW[id] ~= nil then
                hook.remove_net_event_hook(aW[id])
                aW[id] = nil
            end
        end
    )
    bi(
        "Reset Net Event Log",
        aj["opl_event_logger"],
        function(k, id)
            local cK = K.scid(id)
            local j = K.name(id)
            local dA = tostring(cK) .. "-" .. j
            local e = a["Event-Logger"] .. "\\" .. dA .. "\\" .. "Net-Events.log"
            if utils.file_exists(e) then
                os.remove(e)
            else
                o("There was no log to reset.", 14)
            end
        end
    )
    aj["opl_se"] = bh("Script-Events", aj["opl_parent"]).id
    aj["opl_se_custom"] = bh("Custom Script Events", aj["opl_se"]).id
    bi(
        "Enter Custom Script Event with Parameters",
        aj["opl_se_custom"],
        function(k, id)
            local I, ds, dt
            local du = {}
            I, ds = input.get("Enter Custom SE (DEC)", "", 32, 3)
            while I == 1 do
                c.wait(0)
                I, ds = input.get("Enter Custom SE (DEC)", "", 32, 3)
            end
            if I == 2 then
                o("Aborted sending Custom Event...", 93)
                return HANDLER_POP
            end
            while dt ~= "#" do
                I, dt = input.get("Enter Parameter (DEC), to EXIT and send, enter #", "", 32, 0)
                while I == 1 do
                    c.wait(0)
                    I, dt = input.get("Enter Parameter (DEC), to EXIT and send, enter #", "", 32, 0)
                end
                if I == 2 then
                    o("Aborted sending Custom Event...", 93)
                    return HANDLER_POP
                end
                if dt == "#" then
                    break
                end
                dt = c.no(dt)
                if type(dt) == "number" then
                    du[#du + 1] = dt
                else
                    o("Aborted sending Custom Event...", 93)
                    return HANDLER_POP
                end
            end
            c.script(ds, id, du)
            o("Sent Custom Script Event with Parameters to Player.", 93)
        end
    )
    for i = 1, #a5 do
        bi(
            a5[i][1],
            aj["opl_se_custom"],
            function(k, id)
                o("Sent Custom Script Event to Player.", 93)
                for bG = 1, #a5[i][2] do
                    c.script(a5[i][2][bG][1], id, a5[i][2][bG][2])
                end
            end
        )
    end
    bi(
        "Block - Passive",
        aj["opl_se"],
        function(k, id)
            cl(false, 0x54BAD868, {1, 1}, nil, nil, id)
            o("Blocked Player from activating Passive.")
        end
    )
    bi(
        "UN-Block - Passive",
        aj["opl_se"],
        function(k, id)
            cl(false, 0x54BAD868, {2, 0}, nil, nil, id)
            o("UN-Blocked Player from Passive.")
        end
    )
    aj["opl_send_2_mission"] = bh("Send Player to Mission", aj["opl_se"]).id
    for i = 1, #Q do
        bi(
            "Send to " .. Q[i][1],
            aj["opl_send_2_mission"],
            function(k, id)
                cl(false, 0x692CC4BB, Q[i][2], nil, nil, id)
                o("Sent Player to Mission")
            end
        )
    end
    aj["opl_ceo"] = bh("CEO", aj["opl_se"]).id
    for i = 1, 3 do
        bi(
            R[i][1],
            aj["opl_ceo"],
            function(k, id)
                cl(false, R[i][2], R[i][3], R[i][4], R[i][5], id)
                o("Modified Players CEO")
            end
        )
    end
    aj["opl_assassins_peds"] = bh("Send PEDs (Assassins)", aj["opl_parent"]).id
    bi(
        "Clear PEDs",
        aj["opl_assassins_peds"],
        function()
            bn(a0["peds"])
            a0["peds"] = {}
        end
    )
    for i = 1, #a4 do
        bi(
            "Spawn " .. a4[i][1] .. " (3x)",
            aj["opl_assassins_peds"],
            function(k, id)
                r("Spawning PEDs.")
                aF = id
                local ci = a4[i][2]
                local dC = a4[i][3]
                local bs = v3()
                H.model(ci)
                for i = 1, 3 do
                    bs = c.gcoords(c.ped(id))
                    bs.x = bs.x + c.random(-10, 10)
                    bs.y = bs.y + c.random(-10, 10)
                    a0["peds"][#a0["peds"] + 1] = ped.create_ped(dC, ci, bs, 0.0, true, false)
                    if dC ~= 28 then
                        weapon.give_delayed_weapon_to.ped(a0["peds"][#a0["peds"]], 0xDBBD7280, 0, 0)
                    end
                    ped.set_ped_max_health(a0["peds"][#a0["peds"]], 25000000.0)
                    ped.set_ped_health(a0["peds"][#a0["peds"]], 25000000.0)
                    ped.set_ped_combat_attributes(a0["peds"][#a0["peds"]], 46, true)
                    ped.set_ped_combat_ability(a0["peds"][#a0["peds"]], 2)
                    ped.set_ped_config_flag(a0["peds"][#a0["peds"]], 187, 0)
                    ped.set_ped_can_ragdoll(a0["peds"][#a0["peds"]], false)
                    for dh = 1, 26 do
                        ped.set_ped_ragdoll_blocking_flags(a0["peds"][#a0["peds"]], dh)
                    end
                    ai.task_combat_ped(a0["peds"][#a0["peds"]], c.ped(id), 0, 16)
                end
                c.unload(ci)
                r("Done.")
            end
        )
    end
    bi(
        "TP to Player",
        aj["opl_parent"],
        function(k, id)
            bp(c.gcoords(c.ped(id)), 3)
        end
    )
    bi(
        "TP Players Vehicle to me",
        aj["opl_parent"],
        function(k, id)
            local bt = ped.get_vehicle_ped_is_using(c.ped(id))
            H.ctrl(bt)
            entity.set_entity_velocity(bt, v3())
            bl(bt, M.coords())
        end
    )
    bi(
        "Add Player to Blacklist",
        aj["opl_parent"],
        function(k, id)
            local cK = K.scid(id)
            if cK == K.scid(c.id()) or cK == -1 then
                o("Choose valid Player.")
            else
                d.write(c.o(b["Blacklist"], "a"), cK .. " " .. K.name(id))
                o("Player " .. K.name(id) .. " added to Blocklist.", 48)
                r("Player " .. K.name(id) .. " with SCID: " .. cK .. " added to Blacklist.")
            end
        end
    )
    aj["opl_misc"] = bh("Miscellaneous", aj["opl_parent"]).id
    aj["opl_sms"] =
        bh(
        "Send SMSs to Player",
        aj["opl_misc"],
        function()
            o("Player must have Voice-Chat enabled to recive SMS.")
        end
    ).id
    bi(
        "Custom SMS input",
        aj["opl_sms"],
        function(k, id)
            local I, dv = input.get("Enter Custom SMS", "", 128, 0)
            while I == 1 do
                c.wait(0)
                I, dv = input.get("Enter Custom SMS", "", 128, 0)
            end
            if I == 2 then
                return HANDLER_POP
            end
            player.send_player_sms(id, dv)
        end
    )
    bi(
        "Send his SCID & IP",
        aj["opl_sms"],
        function(k, id)
            local cK = tostring(K.scid(id))
            local dk = K.ip(id)
            player.send_player_sms(id, "R*SCID: " .. cK .. "~n~IP: " .. dk)
        end
    )
    for i = 1, #ae do
        bi(
            ae[i],
            aj["opl_sms"],
            function(k, id)
                player.send_player_sms(id, ae[i])
            end
        )
    end
    bi(
        "Falling Asteroids",
        aj["opl_misc"],
        function(k, id)
            c.navigate(false)
            local bs = v3()
            local dD
            H.model(3751297495)
            for i = 1, 25 do
                bs = c.gcoords(c.ped(id))
                bs.x = c.random(math.floor(bs.x - 80), math.floor(bs.x + 80))
                bs.y = c.random(math.floor(bs.y - 80), math.floor(bs.y + 80))
                bs.z = bs.z + c.random(45, 90)
                dD = c.random(-125, 25)
                a0["asteroids"][#a0["asteroids"] + 1] = object.create_object(3751297495, bs, true, true)
                entity.apply_force_to_entity(a0["asteroids"][#a0["asteroids"]], 3, 0, 0, dD, 0, 0, 0, true, true)
            end
            c.unload(3751297495)
            for i = 1, 5 do
                for i = 1, 25 do
                    bs = c.gcoords(a0["asteroids"][#a0["asteroids"] - 25 + i])
                    fire.add_explosion(bs, 8, true, false, 0, 0)
                    c.wait(50)
                end
            end
            c.navigate(true)
        end
    )
    bi(
        "Delete Asteroids",
        aj["opl_misc"],
        function()
            r("Clearing Asteroids.")
            bn(a0["asteroids"])
            a0["asteroids"] = {}
            o("Cleared all Asteroids.")
        end
    )
    bi(
        "Apply random Force to Player",
        aj["opl_misc"],
        function(k, id)
            local dE = c.ped(id)
            if ped.is_ped_in_any_vehicle(dE) then
                dE = ped.get_vehicle_ped_is_using(dE)
            else
                o("It works better, if target is in a Vehicle.")
            end
            H.ctrl(dE)
            local dF = entity.get_entity_velocity(dE)
            for i = 1, 5 do
                dF.x = c.random(math.floor(dF.x - 50), math.floor(dF.x + 50))
                dF.y = c.random(math.floor(dF.y - 50), math.floor(dF.y + 50))
                dF.z = c.random(math.floor(dF.z - 50), math.floor(dF.z + 50))
                entity.set_entity_velocity(dE, dF)
                c.wait(10)
            end
        end
    )
    bi(
        "Trap in Stunt Tube",
        aj["opl_misc"],
        function(k, id)
            local bs = c.gcoords(c.ped(id))
            bs.z = bs.z - 5
            entity.set_entity_rotation(object.create_object(1125864094, bs, true, false), v3(0, 90, 0))
        end
    )
    bi(
        "Trap in invisible Cage",
        aj["opl_misc"],
        function(k, id)
            local bs = c.gcoords(c.ped(id))
            bs.x = bs.x + 1.24
            bs.y = bs.y + 0.24
            H.model(401136338)
            local dG = object.create_object(401136338, bs, true, false)
            entity.set_entity_visible(dG, false)
            entity.set_entity_rotation(dG, v3(0, -90, 0))
            entity.freeze_entity(dG, true)
            bs = c.gcoords(c.ped(id))
            bs.x = bs.x + 0.02
            bs.y = bs.y + 0.82
            dG = object.create_object(401136338, bs, true, false)
            entity.set_entity_visible(dG, false)
            entity.set_entity_rotation(dG, v3(90, -90, 0))
            entity.freeze_entity(dG, true)
            c.unload(401136338)
        end
    )
    aj["opl_bounty"] = bh("Bounty", aj["opl_parent"]).id
    for i = 1, #ad do
        bi(
            ad[i] .. "$",
            aj["opl_bounty"],
            function()
                local dq = 0
                if ak["anonymous_bounty"].on then
                    dq = 1
                end
                for dh = 0, 31 do
                    if K.scid(dh) ~= -1 then
                        c.script(
                            544453591,
                            dh,
                            {
                                69,
                                id,
                                1,
                                ad[i],
                                0,
                                dq,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                script.get_global_i(1650640 + 9),
                                script.get_global_i(1650640 + 10)
                            }
                        )
                    end
                end
            end
        )
    end
    aj["opl_lag_area"] =
        bh(
        "Lag Area with Vehicles",
        aj["opl_parent"],
        function()
            o("DANGEROUS! ONLY USE WITH CAUTION!", 208)
        end
    ).id
    for i = 1, #a9 do
        bi(
            "Lag / Rain Area with " .. a9[i][1],
            aj["opl_lag_area"],
            function(k, id)
                bV(id, a9[i][2])
            end
        )
    end
    bi(
        "Delete Vehicles",
        aj["opl_lag_area"],
        function()
            r("Clearing Vehicles.")
            bn(a0["lag_area"])
            a0["lag_area"] = {}
            o("Cleared Vehicles.")
        end
    )
    aj["opl_malicious"] = bh("Malicious (Kick / Crash)", aj["opl_parent"]).id
    bi(
        "Kick Player",
        aj["opl_malicious"],
        function(k, id)
            bJ(false, id)
        end
    )
    bi(
        "Host Kick Player",
        aj["opl_malicious"],
        function(k, id)
            if network.network_is_host() then
                network.network_session_kick_player(id)
            else
                o("You are not Session-Host!")
            end
        end
    )
    bi(
        "Crash Player",
        aj["opl_malicious"],
        function(k, id)
            bW(id)
        end
    )
    aj["chat"] = b9("Chat-Features", aj["parent"])
    aj["chat"].hidden = l["chat_hidden"]
    aj["chat"] = aj["chat"].id
    ak["chat_log"] =
        be(
        "Chat-Log",
        aj["chat"],
        function(k)
            l["chat_log"] = k.on
        end
    )
    ak["chat_log"].on = l["chat_log"]
    ak["chat_russki"] =
        be(
        "Kick if Russki Char is typed",
        aj["chat"],
        function(k)
            l["chat_russki"] = k.on
        end
    )
    ak["chat_russki"].on = l["chat_russki"]
    ak["chat_begger"] =
        be(
        "Punish Money Beggers",
        aj["chat"],
        function(k)
            l["chat_begger"] = k.on
        end
    )
    ak["chat_begger"].on = l["chat_begger"]
    ak["send_msg_to_script_users"] =
        bd(
        "Send Message to 2Take1Script-Users",
        aj["chat"],
        function()
            local I, cv = input.get("Enter Message", "", 128, 0)
            while I == 1 do
                c.wait(0)
                I, cv = input.get("Enter Message", "", 128, 0)
            end
            if I == 2 then
                return HANDLER_POP
            end
            if cv ~= "" then
                local ct = {}
                ct[1] = 6666
                for bm, bc in utf8.codes(cv) do
                    ct[#ct + 1] = bc
                end
                for i = 0, 31 do
                    if c.valid(i) then
                        if i ~= c.id() and K.scid(i) ~= -1 then
                            c.script(0xfaaab4a3, i, ct)
                        end
                    end
                end
            end
        end
    )
    ak["chat_cmd"] =
        be(
        "Enable Chat-Commands",
        aj["chat"],
        function(k)
            l["chat_cmd"] = k.on
        end
    )
    ak["chat_cmd"].on = l["chat_cmd"]
    aj["chat_cmd"] = b9("Chat-Commands", aj["chat"]).id
    for i = 1, #V do
        ak[V[i][1]] =
            be(
            V[i][2],
            aj["chat_cmd"],
            function(k)
                l[V[i][1]] = k.on
            end
        )
        ak[V[i][1]].on = l[V[i][1]]
    end
    bd("[SU] = Script-User", aj["chat_cmd"])
    bd(
        "Delete Vehicles from !lag",
        aj["chat"],
        function()
            bn(a0["lag_area"])
            a0["lag_area"] = {}
        end
    )
    ak["chat_cmd_friends"] =
        be(
        "Chat Commands for Friends",
        aj["chat"],
        function(k)
            l["chat_cmd_friends"] = k.on
        end
    )
    ak["chat_cmd_friends"].on = l["chat_cmd_friends"]
    ak["chat_cmd_all"] =
        be(
        "Chat Commands Everyone",
        aj["chat"],
        function(k)
            l["chat_cmd_all"] = k.on
        end
    )
    ak["chat_cmd_all"].on = l["chat_cmd_all"]
    ak["send_message_to_dc"] =
        bd(
        "Send Message to #general",
        aj["chat"],
        function()
            o("It will take 8 seconds to sent the message, calm down and wait :)")
            local I, cv = input.get("Enter Message", "", 128, 0)
            while I == 1 do
                c.wait(0)
                I, cv = input.get("Enter Message", "", 128, 0)
            end
            if I == 2 then
                return HANDLER_POP
            end
            cv = cv .. "\n\n*this message was sent by 2Take1Script*"
            utils.to_clipboard(cv)
            c.exe("start https://discord.com/channels/570999086874886154/570999091320979486")
            c.wait(8000)
            local dH = b["vbs"]
            local dI = c.o(dH, "a")
            io.output(dI)
            io.write('set sendmsg = wscript.createobject("wscript.shell")\nwscript.sleep(1000)\n')
            io.write('sendmsg.sendkeys "^v"\nwscript.sleep(50)\n')
            io.write('sendmsg.sendkeys "{ENTER}"\nwscript.sleep(500)\n')
            io.write("wscript.quit")
            io.close(dI)
            c.exe("start " .. dH)
            c.wait(1000)
            os.remove(dH)
        end
    )
    aj["custom_veh"] = b9("Custom Vehicles", aj["parent"])
    aj["custom_veh"].hidden = l["custom_vehicles_hidden"]
    aj["custom_veh"] = aj["custom_veh"].id
    aj["moveablerobot"] = b9("Moveable Robot", aj["custom_veh"]).id
    ak["moveablerobot"] =
        be(
        "Enable Robot",
        aj["moveablerobot"],
        function(k)
            if k.on then
                if aH["tampa"] == nil then
                    local dJ = true
                    local bt = ped.get_vehicle_ped_is_using(M.ped())
                    if bt ~= 0 then
                        if 3084515313 == entity.get_entity_model_hash(bt) then
                            aH["tampa"] = bt
                            dJ = false
                        end
                    end
                    if dJ then
                        H.model(3084515313)
                        aH["tampa"] = vehicle.create_vehicle(3084515313, M.coords(), M.heading(), true, false)
                        decorator.decor_set_int(aH["tampa"], "MPBitset", 1 << 10)
                        entity.set_entity_god_mode(aH["tampa"], true)
                        bZ(bt)
                        if ak["auto_get_in"].on then
                            ped.set_ped_into_vehicle(M.ped(), aH["tampa"], -1)
                        end
                        if not l["disable_tampa_notify"] then
                            o(
                                "To get the best experience, upgrade the Tampa to use the Double Controllable Minigun!",
                                11
                            )
                            o("You can disable this message in Options.", 11)
                        end
                    end
                end
                if aH["ppdump"] == nil then
                    H.model(0x810369E2)
                    aH["ppdump"] = vehicle.create_vehicle(0x810369E2, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["ppdump"], true)
                    entity.attach_entity_to_entity(
                        aH["ppdump"],
                        aH["tampa"],
                        0,
                        v3(0, 0, 12.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["llbone"] == nil then
                    H.model(1803116220)
                    aH["llbone"] = object.create_object(1803116220, v3(), true, false)
                    entity.attach_entity_to_entity(
                        aH["llbone"],
                        aH["tampa"],
                        0,
                        v3(-4.25, 0, 12.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["rlbone"] == nil then
                    H.model(1803116220)
                    aH["rlbone"] = object.create_object(1803116220, v3(), true, false)
                    entity.attach_entity_to_entity(
                        aH["rlbone"],
                        aH["tampa"],
                        0,
                        v3(4.25, 0, 12.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["lltrain"] == nil then
                    H.model(1030400667)
                    aH["lltrain"] = vehicle.create_vehicle(1030400667, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["lltrain"], true)
                    entity.attach_entity_to_entity(
                        aH["lltrain"],
                        aH["llbone"],
                        0,
                        v3(0, 0, -5),
                        v3(90),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["lfoot"] == nil then
                    H.model(782665360)
                    aH["lfoot"] = vehicle.create_vehicle(782665360, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["lfoot"], true)
                    entity.attach_entity_to_entity(
                        aH["lfoot"],
                        aH["llbone"],
                        0,
                        v3(0, 2, -12.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["rltrain"] == nil then
                    H.model(1030400667)
                    aH["rltrain"] = vehicle.create_vehicle(1030400667, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["rltrain"], true)
                    entity.attach_entity_to_entity(
                        aH["rltrain"],
                        aH["rlbone"],
                        0,
                        v3(0, 0, -5),
                        v3(90),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["rfoot"] == nil then
                    H.model(782665360)
                    aH["rfoot"] = vehicle.create_vehicle(782665360, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["rfoot"], true)
                    entity.attach_entity_to_entity(
                        aH["rfoot"],
                        aH["rlbone"],
                        0,
                        v3(0, 2, -12.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["body"] == nil then
                    H.model(1030400667)
                    aH["body"] = vehicle.create_vehicle(1030400667, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["body"], true)
                    entity.attach_entity_to_entity(
                        aH["body"],
                        aH["tampa"],
                        0,
                        v3(0, 0, 22.5),
                        v3(90),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["shoulder"] == nil then
                    H.model(0x810369E2)
                    aH["shoulder"] = vehicle.create_vehicle(0x810369E2, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["shoulder"], true)
                    entity.attach_entity_to_entity(
                        aH["shoulder"],
                        aH["tampa"],
                        0,
                        v3(0, 0, 27.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["lheadbone"] == nil then
                    H.model(1803116220)
                    aH["lheadbone"] = object.create_object(1803116220, v3(), true, false)
                    entity.attach_entity_to_entity(
                        aH["lheadbone"],
                        aH["tampa"],
                        0,
                        v3(-3.25, 0, 27.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["rheadbone"] == nil then
                    H.model(1803116220)
                    aH["rheadbone"] = object.create_object(1803116220, v3(), true, false)
                    entity.attach_entity_to_entity(
                        aH["rheadbone"],
                        aH["tampa"],
                        0,
                        v3(3.25, 0, 27.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["lheadtrain"] == nil then
                    H.model(1030400667)
                    aH["lheadtrain"] = vehicle.create_vehicle(1030400667, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["lheadtrain"], true)
                    entity.attach_entity_to_entity(
                        aH["lheadtrain"],
                        aH["lheadbone"],
                        0,
                        v3(-3, 4, -5),
                        v3(325, 0, 45),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["lhand"] == nil then
                    H.model(782665360)
                    aH["lhand"] = vehicle.create_vehicle(782665360, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["lhand"], true)
                    entity.attach_entity_to_entity(
                        aH["lhand"],
                        aH["lheadtrain"],
                        0,
                        v3(0, 7.5, 0),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["rheadtrain"] == nil then
                    H.model(1030400667)
                    aH["rheadtrain"] = vehicle.create_vehicle(1030400667, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["rheadtrain"], true)
                    entity.attach_entity_to_entity(
                        aH["rheadtrain"],
                        aH["rheadbone"],
                        0,
                        v3(3, 4, -5),
                        v3(325, 0, 315),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["rhand"] == nil then
                    H.model(782665360)
                    aH["rhand"] = vehicle.create_vehicle(782665360, v3(), 0, true, false)
                    entity.set_entity_god_mode(aH["rhand"], true)
                    entity.attach_entity_to_entity(
                        aH["rhand"],
                        aH["rheadtrain"],
                        0,
                        v3(0, 7.5, 0),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["head"] == nil then
                    H.model(-543669801)
                    aH["head"] = object.create_object(-543669801, v3(), true, false)
                    entity.attach_entity_to_entity(
                        aH["head"],
                        aH["tampa"],
                        0,
                        v3(0, 0, 35),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                return HANDLER_CONTINUE
            end
            if not k.on then
                for i in pairs(aH) do
                    bn({aH[i]})
                    aH[i] = nil
                end
                if #aI ~= 0 then
                    bn(aI)
                    aI = {}
                end
                if #aJ ~= 0 then
                    bn(aJ)
                    aJ = {}
                end
            end
        end
    )
    ak["robot_shoot"] =
        be(
        "Controllable Blasts",
        aj["moveablerobot"],
        function(k)
            if k.on then
                local dK = gameplay.get_hash_key("weapon_airstrike_rocket")
                local bs = M.coords()
                local dL = cam.get_gameplay_cam_rot()
                dL:transformRotToDir()
                dL = dL * 1000
                bs = bs + dL
                local dM, dN, dO, ci, dP = worldprobe.raycast(c1(M.coords(), M.heading(), 2) + v3(0, 0, 4), bs, -1, 0)
                while not dM do
                    bs = M.coords()
                    dL = cam.get_gameplay_cam_rot()
                    dL:transformRotToDir()
                    dL = dL * 1000
                    bs = bs + dL
                    dM, dN, dO, ci, dP = worldprobe.raycast(c1(M.coords(), M.heading(), 2) + v3(0, 0, 4), bs, -1, 0)
                    c.wait(0)
                end
                if ped.is_ped_shooting(M.ped()) and ped.get_vehicle_ped_is_using(M.ped()) == aH["tampa"] then
                    if ak["equip_weapons"].on then
                        local dQ = aI[1]
                        local dR = entity.get_entity_heading(dQ)
                        local dS = c1(c.gcoords(dQ), dR, 12) + v3(0, 0, 3)
                        gameplay.shoot_single_bullet_between_coords(dS, dN, 1000, dK, M.ped(), true, false, 50000)
                        local dT = aJ[1]
                        local dU = entity.get_entity_heading(dT)
                        local dV = c1(c.gcoords(dT), dU, 12) + v3(0, 0, 3)
                        gameplay.shoot_single_bullet_between_coords(dV, dN, 1000, dK, M.ped(), true, false, 50000)
                        c.wait(100)
                    else
                        local cJ = c1(M.coords(), M.heading(), 8) + v3(0, 0, 15)
                        gameplay.shoot_single_bullet_between_coords(cJ, dN, 1000, dK, M.ped(), true, false, 10000)
                    end
                end
            end
            l["controllable_blasts"] = k.on
            return d.stop(k)
        end
    )
    ak["robot_shoot"].on = l["controllable_blasts"]
    ak["moveablelegs"] =
        be(
        "Moveable Legs",
        aj["moveablerobot"],
        function(k)
            l["moveable_legs"] = k.on
            if k.on then
                if aH["llbone"] and aH["rlbone"] and aH["tampa"] then
                    local dj
                    local cD = aH["llbone"]
                    local cE = aH["rlbone"]
                    local cF = aH["tampa"]
                    local cG = v3(-4.25, 0, 12.5)
                    local cH = v3(4.25, 0, 12.5)
                    for i = 0, 50 do
                        if aH["tampa"] then
                            dj = entity.get_entity_speed(aH["tampa"])
                            if not k.on or dj < 2.5 then
                                cC()
                                return HANDLER_CONTINUE
                            end
                            H.ctrl(cD)
                            H.ctrl(cE)
                            H.ctrl(cF)
                            entity.attach_entity_to_entity(
                                cD,
                                cF,
                                0,
                                cG,
                                v3(i, 0, 0),
                                true,
                                l["robot_collision"],
                                false,
                                2,
                                true
                            )
                            entity.attach_entity_to_entity(
                                cE,
                                cF,
                                0,
                                cH,
                                v3(360 - i, 0, 0),
                                true,
                                l["robot_collision"],
                                false,
                                2,
                                true
                            )
                            local dW = math.floor(51 - dj / 1)
                            if dW < 1 then
                                dW = 0
                            end
                            c.wait(dW)
                        end
                    end
                    for i = 50, -50, -1 do
                        if aH["tampa"] then
                            dj = entity.get_entity_speed(aH["tampa"])
                            if not k.on or dj < 2.5 then
                                cC()
                                return HANDLER_CONTINUE
                            end
                            H.ctrl(cD)
                            H.ctrl(cE)
                            H.ctrl(cF)
                            entity.attach_entity_to_entity(
                                cD,
                                cF,
                                0,
                                cG,
                                v3(i, 0, 0),
                                true,
                                l["robot_collision"],
                                false,
                                2,
                                true
                            )
                            entity.attach_entity_to_entity(
                                cE,
                                cF,
                                0,
                                cH,
                                v3(360 - i, 0, 0),
                                true,
                                l["robot_collision"],
                                false,
                                2,
                                true
                            )
                            local dW = math.floor(51 - dj / 1)
                            if dW < 1 then
                                dW = 0
                            end
                            c.wait(dW)
                        end
                    end
                    for i = -50, 0 do
                        if aH["tampa"] then
                            dj = entity.get_entity_speed(aH["tampa"])
                            if not k.on or dj < 2.5 then
                                cC()
                                return HANDLER_CONTINUE
                            end
                            H.ctrl(cD)
                            H.ctrl(cE)
                            H.ctrl(cF)
                            entity.attach_entity_to_entity(
                                cD,
                                cF,
                                0,
                                cG,
                                v3(i, 0, 0),
                                true,
                                l["robot_collision"],
                                false,
                                2,
                                true
                            )
                            entity.attach_entity_to_entity(
                                cE,
                                cF,
                                0,
                                cH,
                                v3(360 - i, 0, 0),
                                true,
                                l["robot_collision"],
                                false,
                                2,
                                true
                            )
                            local dW = math.floor(51 - dj / 1)
                            if dW < 1 then
                                dW = 0
                            end
                            c.wait(dW)
                        end
                    end
                end
                return HANDLER_CONTINUE
            end
            if not k.on then
                cC()
            end
        end
    )
    ak["moveablelegs"].on = l["moveable_legs"]
    ak["robot_collision"] =
        be(
        "Collision",
        aj["moveablerobot"],
        function(k)
            l["robot_collision"] = k.on
            if ped.get_vehicle_ped_is_using(M.ped()) == aH["tampa"] then
                o("Re-enable Robot to take effect of collision!", 11)
            end
        end
    )
    ak["robot_collision"].on = l["robot_collision"]
    ak["rocket_propulsion"] =
        be(
        "Rocket Propulsion (Visual)",
        aj["moveablerobot"],
        function(k)
            if k.on and aH["body"] then
                if aH["spinning_1"] == nil then
                    H.model(0xFB133A17)
                    aH["spinning_1"] = vehicle.create_vehicle(0xFB133A17, M.coords(), 0, true, false)
                    entity.set_entity_god_mode(aH["spinning_1"], true)
                    entity.set_entity_visible(aH["spinning_1"], false)
                    entity.attach_entity_to_entity(
                        aH["spinning_1"],
                        aH["body"],
                        0,
                        v3(0, -5, 0),
                        v3(-180, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                vehicle.set_heli_blades_speed(aH["spinning_1"], 100)
                if aH["spinning_middle"] == nil then
                    H.model(94602826)
                    aH["spinning_middle"] = object.create_object(94602826, v3(), true, false)
                    entity.set_entity_god_mode(aH["spinning_middle"], true)
                    entity.attach_entity_to_entity(
                        aH["spinning_middle"],
                        aH["spinning_1"],
                        0,
                        v3(0, 0, 0),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["spinning_middle2"] == nil then
                    H.model(94602826)
                    aH["spinning_middle2"] = object.create_object(94602826, v3(), true, false)
                    entity.set_entity_god_mode(aH["spinning_middle2"], true)
                    entity.attach_entity_to_entity(
                        aH["spinning_middle2"],
                        aH["spinning_1"],
                        0,
                        v3(0, 0, 1.5),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["spinning_middle3"] == nil then
                    H.model(94602826)
                    aH["spinning_middle3"] = object.create_object(94602826, v3(), true, false)
                    entity.set_entity_god_mode(aH["spinning_middle3"], true)
                    entity.attach_entity_to_entity(
                        aH["spinning_middle3"],
                        aH["spinning_1"],
                        0,
                        v3(0, 0, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                local C = entity.get_entity_bone_index_by_name(aH["spinning_1"], "rotor_main")
                if aH["glow_1"] == nil then
                    H.model(2655881418)
                    aH["glow_1"] = object.create_object(2655881418, v3(), true, false)
                    entity.set_entity_god_mode(aH["glow_1"], true)
                    entity.attach_entity_to_entity(
                        aH["glow_1"],
                        aH["spinning_1"],
                        C,
                        v3(2, 3, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["glow_2"] == nil then
                    H.model(2655881418)
                    aH["glow_2"] = object.create_object(2655881418, v3(), true, false)
                    entity.set_entity_god_mode(aH["glow_2"], true)
                    entity.attach_entity_to_entity(
                        aH["glow_2"],
                        aH["spinning_1"],
                        C,
                        v3(2, -3, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["glow_3"] == nil then
                    H.model(2655881418)
                    aH["glow_3"] = object.create_object(2655881418, v3(), true, false)
                    entity.set_entity_god_mode(aH["glow_3"], true)
                    entity.attach_entity_to_entity(
                        aH["glow_3"],
                        aH["spinning_1"],
                        C,
                        v3(4, 0, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["glow_4"] == nil then
                    H.model(2655881418)
                    aH["glow_4"] = object.create_object(2655881418, v3(), true, false)
                    entity.set_entity_god_mode(aH["glow_4"], true)
                    entity.attach_entity_to_entity(
                        aH["glow_4"],
                        aH["spinning_1"],
                        C,
                        v3(-2, 3, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["glow_5"] == nil then
                    H.model(2655881418)
                    aH["glow_5"] = object.create_object(2655881418, v3(), true, false)
                    entity.set_entity_god_mode(aH["glow_5"], true)
                    entity.attach_entity_to_entity(
                        aH["glow_5"],
                        aH["spinning_1"],
                        C,
                        v3(-2, -3, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if aH["glow_6"] == nil then
                    H.model(2655881418)
                    aH["glow_6"] = object.create_object(2655881418, v3(), true, false)
                    entity.set_entity_god_mode(aH["glow_6"], true)
                    entity.attach_entity_to_entity(
                        aH["glow_6"],
                        aH["spinning_1"],
                        C,
                        v3(-4, 0, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
            end
            if not k.on then
                local dX = {
                    "spinning_1",
                    "glow_1",
                    "glow_2",
                    "glow_3",
                    "glow_4",
                    "glow_5",
                    "glow_6",
                    "spinning_middle",
                    "spinning_middle2",
                    "spinning_middle3"
                }
                for i = 1, #dX do
                    if aH[dX[i]] then
                        bn({aH[dX[i]]})
                        aH[dX[i]] = nil
                    end
                end
                return HANDLER_POP
            end
            l["rocket_propulsion"] = k.on
            return HANDLER_CONTINUE
        end
    )
    ak["rocket_propulsion"].on = l["rocket_propulsion"]
    ak["equip_weapons"] =
        be(
        "Equip Miniguns on hands",
        aj["moveablerobot"],
        function(k)
            l["equip_weapons"] = k.on
            if k.on and aH["lheadtrain"] and aH["rheadtrain"] then
                if #aI == 0 and #aJ == 0 then
                    local dY = false
                    if ak["spawn_preview"].on then
                        dY = true
                        ak["spawn_preview"].on = false
                    end
                    local dZ = false
                    if ak["auto_get_in"].on then
                        dZ = true
                        ak["auto_get_in"].on = false
                    end
                    local bP = a8[1][2]
                    cY(bP, 2)
                    cY(bP, 3)
                    local d_ = aI[1]
                    local e0 = aJ[1]
                    local e1 = aH["lheadtrain"]
                    local e2 = aH["rheadtrain"]
                    H.ctrl(d_)
                    H.ctrl(e0)
                    H.ctrl(e1)
                    H.ctrl(e2)
                    entity.attach_entity_to_entity(
                        d_,
                        e1,
                        0,
                        v3(0, 5, 0),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                    entity.attach_entity_to_entity(
                        e0,
                        e2,
                        0,
                        v3(0, 5, 0),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                    if dY then
                        ak["spawn_preview"].on = true
                    end
                    if dZ then
                        ak["auto_get_in"].on = true
                    end
                end
            end
            if not k.on then
                if #aI ~= 0 then
                    bn(aI)
                    aI = {}
                end
                if #aJ ~= 0 then
                    bn(aJ)
                    aJ = {}
                end
                return HANDLER_POP
            end
            return HANDLER_CONTINUE
        end
    )
    ak["equip_weapons"].on = l["equip_weapons"]
    bd(
        "Drive Robot",
        aj["moveablerobot"],
        function()
            if aH["tampa"] then
                ped.set_ped_into_vehicle(M.ped(), aH["tampa"], -1)
            end
        end
    )
    aj["custom_spawner"] = b9("Custom Vehicles", aj["custom_veh"]).id
    ak["spawn_preview"] =
        be(
        "Preview Custom Vehicles",
        aj["custom_spawner"],
        function(k)
            if #a0["preview_veh"] > 0 and k.on then
                if ped.is_ped_in_any_vehicle(M.ped()) then
                    ped.clear_ped_tasks_immediately(M.ped())
                end
                local bs = M.coords()
                if not ap then
                    for i = 1, #a0["preview_veh"] do
                        entity.set_entity_no_collsion_entity(a0["preview_veh"][i], M.ped(), true)
                    end
                    ap = true
                end
                bs.z = bs.z + ao
                local c2 = M.heading()
                bs = c1(bs, c2, aq)
                bl(a0["preview_veh"][1], bs)
                entity.set_entity_rotation(a0["preview_veh"][1], ar)
                ar.z = ar.z + 1
                if ar.z > 360 then
                    ar.z = 0
                end
            end
            if not k.on then
                bn(a0["preview_veh"])
                a0["preview_veh"] = {}
                ap = false
                return HANDLER_POP
            end
            return d.stop(k)
        end
    )
    bd(
        "Delete Custom Vehicles",
        aj["custom_spawner"],
        function()
            r("Clearing Custom Vehicles.")
            bn(a0["custom_veh"])
            a0["custom_veh"] = {}
            bn(a0["preview_veh"])
            a0["preview_veh"] = {}
            ap = false
            o("Cleared Custom Vehicles.")
        end
    )
    for i = 1, #a8 do
        bd(
            a8[i][1],
            aj["custom_spawner"],
            function()
                local bP = a8[i][2]
                cY(bP)
            end
        )
    end
    aj["custom_veh_opt"] = b9("Options", aj["custom_veh"]).id
    ak["auto_get_in"] =
        be(
        "Spawn in Custom Vehicle",
        aj["custom_veh_opt"],
        function(k)
            l["spawn_in_vehicle"] = k.on
        end
    )
    ak["auto_get_in"].on = l["spawn_in_vehicle"]
    ak["use_own_veh"] =
        be(
        "Use Own Vehicle for Custom ones",
        aj["custom_veh_opt"],
        function(k)
            l["use_own_veh"] = k.on
        end
    )
    ak["use_own_veh"].on = l["use_own_veh"]
    ak["set_godmode"] =
        be(
        "Godmode on Custom Vehicles",
        aj["custom_veh_opt"],
        function(k)
            l["set_godmode"] = k.on
        end
    )
    ak["set_godmode"].on = l["set_godmode"]
    ak["disable_tampa_notify"] =
        be(
        "Disable Moveable Robot Tampa Notify",
        aj["custom_veh_opt"],
        function(k)
            l["disable_tampa_notify"] = k.on
        end
    )
    ak["disable_tampa_notify"].on = l["disable_tampa_notify"]
    aj["custom_veh_builder"] = b9("Custom Vehicle Creator", aj["custom_veh"])
    aj["custom_veh_builder"].hidden = true
    local e3 = {
        {
            "WarMachine",
            {
                {0x9dae1398, 1030400667, 0x2F03547B, 2971578861, 3871829598, 3229200997, 0x187D938D, 782665360},
                {0x9dae1398, nil, nil, {0, 0, 0, 0, 1}, nil, nil, nil, nil, nil, nil, 15},
                {1030400667, {0, -4, 0}, nil, {0, 0, 0, 0, 1}},
                {0x2F03547B, {0, -8, 4}, {-90, 0, 0}, {0, 0, 0, 0, 1}, true, nil, nil, nil, 0x97F5FE8D, true},
                {2971578861, {-0.3, -0.6, 9.8}, {-90, 0, 0}, nil, nil, nil, 16, 3},
                {3229200997, {0, 0, 9.8}, {-90, 0, 0}, nil, nil, nil, 16, 3},
                {0x187D938D, {0, -8.25, 5.3}, nil, {0, 0, 0, 0, 1}},
                {782665360, {0, -8, 3.1}, nil, {0, 0, 0, 0, 1}}
            }
        },
        {
            "Deer Rider",
            {
                {0xE5BA6858},
                {0xE5BA6858, nil, nil, {0, 0, 0, 0, 1}, true, nil, nil, nil, nil, nil, 3},
                {0, {0, -0.225, 0.225}, nil, nil, nil, nil, nil, nil, 0xD86B5A95}
            }
        },
        {"Attach Tree", {{3015194288}, {0}, {3015194288, {0, 0, -0.3}}}}
    }
    bd(
        "Delete Custom Vehicles",
        aj["custom_veh_builder"].id,
        function()
            r("Clearing Custom Vehicles.")
            bn(aR)
            aR = {}
            o("Cleared Custom Vehicles.")
        end
    )
    for i = 1, #e3 do
        bd(
            e3[i][1],
            aj["custom_veh_builder"].id,
            function()
                local bP = e3[i][2]
                cY(bP, 1)
            end
        )
    end
    local e4 = bf("Select Vehicle", "autoaction_value_i", aj["custom_veh_builder"].id)
    e4.min_i = 2
    e4.max_i = 250
    local e5, e6, e7, e8, e9, ea
    e5 =
        bf(
        "Offset X",
        "autoaction_value_i",
        aj["custom_veh_builder"].id,
        function(k)
            local bq = v3(k.value_i / 10, e6.value_i / 10, e7.value_i / 10)
            local eb = v3(e8.value_i, e9.value_i, ea.value_i)
            local cF = aR[1]
            local ec = aR[e4.value_i]
            if cF ~= nil and ec ~= nil then
                H.ctrl(cF)
                H.ctrl(ec)
                entity.attach_entity_to_entity(ec, cF, 0, bq, eb, false, false, false, 2, true)
            end
        end
    )
    e5.min_i = -500
    e5.max_i = 500
    e6 =
        bf(
        "Offset Y",
        "autoaction_value_i",
        aj["custom_veh_builder"].id,
        function(k)
            local bq = v3(e5.value_i / 10, k.value_i / 10, e7.value_i / 10)
            local eb = v3(e8.value_i, e9.value_i, ea.value_i)
            local cF = aR[1]
            local ec = aR[e4.value_i]
            if cF ~= nil and ec ~= nil then
                H.ctrl(cF)
                H.ctrl(ec)
                entity.attach_entity_to_entity(ec, cF, 0, bq, eb, false, false, false, 2, true)
            end
        end
    )
    e6.min_i = -500
    e6.max_i = 500
    e7 =
        bf(
        "Offset Z",
        "autoaction_value_i",
        aj["custom_veh_builder"].id,
        function(k)
            local bq = v3(e5.value_i / 10, e6.value_i / 10, k.value_i / 10)
            local eb = v3(e8.value_i, e9.value_i, ea.value_i)
            local cF = aR[1]
            local ec = aR[e4.value_i]
            if cF ~= nil and ec ~= nil then
                H.ctrl(cF)
                H.ctrl(ec)
                entity.attach_entity_to_entity(ec, cF, 0, bq, eb, false, false, false, 2, true)
            end
        end
    )
    e7.min_i = -500
    e7.max_i = 500
    e8 =
        bf(
        "Rotation X",
        "autoaction_value_i",
        aj["custom_veh_builder"].id,
        function(k)
            local bq = v3(e5.value_i / 10, e6.value_i / 10, e7.value_i / 10)
            local eb = v3(k.value_i, e9.value_i, ea.value_i)
            local cF = aR[1]
            local ec = aR[e4.value_i]
            if cF ~= nil and ec ~= nil then
                H.ctrl(cF)
                H.ctrl(ec)
                entity.attach_entity_to_entity(ec, cF, 0, bq, eb, false, false, false, 2, true)
            end
        end
    )
    e8.min_i = -360
    e8.max_i = 360
    e9 =
        bf(
        "Rotation Y",
        "autoaction_value_i",
        aj["custom_veh_builder"].id,
        function(k)
            local bq = v3(e5.value_i / 10, e6.value_i / 10, e7.value_i / 10)
            local eb = v3(e8.value_i, k.value_i, ea.value_i)
            local cF = aR[1]
            local ec = aR[e4.value_i]
            if cF ~= nil and ec ~= nil then
                H.ctrl(cF)
                H.ctrl(ec)
                entity.attach_entity_to_entity(ec, cF, 0, bq, eb, false, false, false, 2, true)
            end
        end
    )
    e9.min_i = -360
    e9.max_i = 360
    ea =
        bf(
        "Rotation Z",
        "autoaction_value_i",
        aj["custom_veh_builder"].id,
        function(k)
            local bq = v3(e5.value_i / 10, e6.value_i / 10, e7.value_i / 10)
            local eb = v3(e8.value_i, e9.value_i, k.value_i)
            local cF = aR[1]
            local ec = aR[e4.value_i]
            if cF ~= nil and ec ~= nil and cF ~= ec then
                H.ctrl(cF)
                H.ctrl(ec)
                entity.attach_entity_to_entity(ec, cF, 0, bq, eb, false, false, false, 2, true)
            end
        end
    )
    ea.min_i = -360
    ea.max_i = 360
    aj["exp_beam"] = b9("Explosive Beam on Horn", aj["parent"])
    aj["exp_beam"].hidden = l["explosive_beam_hidden"]
    aj["exp_beam"] = aj["exp_beam"].id
    ak["exp_beam"] =
        be(
        "Enable Beam on Horn",
        aj["exp_beam"],
        function(k)
            l["exp_beam"] = k.on
            if k.on then
                local ed = c.id()
                if K.scid(ak["exp_beam_other"].value_i) ~= -1 then
                    ed = ak["exp_beam_other"].value_i
                end
                local dE = c.ped(ed)
                local bt, bs, bS, ee, ef
                local eg = v3()
                local eh, ei, ej, ek, el, em
                if player.is_player_pressing_horn(ed) then
                    bt = ped.get_vehicle_ped_is_using(dE)
                    for i = 0, 5 do
                        bs = c.gcoords(bt)
                        c.wait(5)
                        if i > 0 then
                            bS = c.gcoords(bt)
                            eg.x = bS.x - bs.x
                            eg.y = bS.y - bs.y
                            eg.z = bS.z - bs.z
                            if eg.x ~= 0 and eg.y ~= 0 and eg.z ~= 0 then
                                ee = 1 / (eg.x * eg.x + eg.y * eg.y + eg.z * eg.z) ^ 0.5
                                ef = c.random(l["exp_beam_min"], l["exp_beam_max"])
                                bS.x = bS.x + ef * ee * eg.x
                                bS.y = bS.y + ef * ee * eg.y
                                bS.z = bS.z + ef * ee * eg.z
                                eh = math.floor(bS.x - l["exp_beam_radius"])
                                ei = math.floor(bS.x + l["exp_beam_radius"])
                                ej = math.floor(bS.y - l["exp_beam_radius"])
                                ek = math.floor(bS.y + l["exp_beam_radius"])
                                el = math.floor(bS.z - l["exp_beam_radius"])
                                em = math.floor(bS.z + l["exp_beam_radius"])
                                bS.x = c.random(eh, ei)
                                bS.y = c.random(ej, ek)
                                bS.z = c.random(el, em)
                                fire.add_explosion(bS, l["exp_beam_type"], true, false, 0.1, dE)
                                bS.x = c.random(eh, ei)
                                bS.y = c.random(ej, ek)
                                bS.z = c.random(el, em)
                                fire.add_explosion(bS, l["exp_beam_type_2"], true, false, 0.1, dE)
                            end
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    ak["exp_beam"].on = l["exp_beam"]
    ak["exp_beam_type"] =
        bf(
        "Select Explosion",
        "action_value_i",
        aj["exp_beam"],
        function()
            l["exp_beam_type"] = ak["exp_beam_type"].value_i
            o("Beam Explosion Type 1: " .. l["exp_beam_type"])
        end
    )
    ak["exp_beam_type"].max_i = 74
    ak["exp_beam_type"].min_i = 0
    ak["exp_beam_type"].value_i = l["exp_beam_type"]
    ak["exp_beam_type_2"] =
        bf(
        "Select Explosion 2",
        "action_value_i",
        aj["exp_beam"],
        function()
            l["exp_beam_type_2"] = ak["exp_beam_type_2"].value_i
            o("Beam Explosion Type 2: " .. l["exp_beam_type_2"])
        end
    )
    ak["exp_beam_type_2"].max_i = 74
    ak["exp_beam_type_2"].min_i = 0
    ak["exp_beam_type_2"].value_i = l["exp_beam_type_2"]
    ak["exp_beam_radius"] =
        bf(
        "Select Scattering",
        "action_value_i",
        aj["exp_beam"],
        function()
            l["exp_beam_radius"] = ak["exp_beam_radius"].value_i
            o("Beam Radius: " .. l["exp_beam_radius"])
        end
    )
    ak["exp_beam_radius"].max_i = 10
    ak["exp_beam_radius"].min_i = 1
    ak["exp_beam_radius"].value_i = l["exp_beam_radius"]
    ak["exp_beam_min"] =
        bf(
        "Select Min Range",
        "action_value_i",
        aj["exp_beam"],
        function()
            l["exp_beam_min"] = ak["exp_beam_min"].value_i
            o("Beam Min Range: " .. l["exp_beam_min"])
        end
    )
    ak["exp_beam_min"].max_i = 100
    ak["exp_beam_min"].min_i = 10
    ak["exp_beam_min"].value_i = l["exp_beam_min"]
    ak["exp_beam_min"].mod_i = 5
    ak["exp_beam_max"] =
        bf(
        "Select Max Range",
        "action_value_i",
        aj["exp_beam"],
        function()
            l["exp_beam_max"] = ak["exp_beam_max"].value_i
            o("Beam Max Range: " .. l["exp_beam_max"])
        end
    )
    ak["exp_beam_max"].max_i = 300
    ak["exp_beam_max"].min_i = 100
    ak["exp_beam_max"].value_i = l["exp_beam_max"]
    ak["exp_beam_max"].mod_i = 5
    ak["exp_beam_other"] =
        bf(
        "Enable Horn for Player",
        "action_value_i",
        aj["exp_beam"],
        function()
            if K.scid(ak["exp_beam_other"].value_i) ~= -1 then
                o("Selected Player: " .. K.name(ak["exp_beam_other"].value_i))
            else
                o("Not a valid Player.")
            end
        end
    )
    ak["exp_beam_other"].max_i = 31
    ak["exp_beam_other"].min_i = -1
    ak["exp_beam_other"].value_i = -1
    aj["bac"] = b9("Better Animal Changer", aj["parent"])
    aj["bac"].hidden = l["animal_changer_hidden"]
    aj["bac"] = aj["bac"].id
    aj["bac_ga"] = b9("Ground Animals", aj["bac"]).id
    bd(
        "Bigfoot",
        aj["bac_ga"],
        function()
            bA(0x61D4C771, nil, true, nil, true)
        end
    )
    bd(
        "Bigfoot 2",
        aj["bac_ga"],
        function()
            bA(0xAD340F5A, nil, true, nil, true)
        end
    )
    bd(
        "Boar",
        aj["bac_ga"],
        function()
            bA(0xCE5FF074)
        end
    )
    bd(
        "Cat",
        aj["bac_ga"],
        function()
            bA(0x573201B8)
        end
    )
    bd(
        "Chimp",
        aj["bac_ga"],
        function()
            bA(0xA8683715, nil, nil, true)
        end
    )
    bd(
        "Chop",
        aj["bac_ga"],
        function()
            bA(0x14EC17EA, nil, true)
        end
    )
    bd(
        "Cow",
        aj["bac_ga"],
        function()
            bA(0xFCFA9E1E)
        end
    )
    bd(
        "Coyote",
        aj["bac_ga"],
        function()
            bA(0x644AC75E)
        end
    )
    bd(
        "Deer",
        aj["bac_ga"],
        function()
            bA(0xD86B5A95)
        end
    )
    bd(
        "German Shepherd",
        aj["bac_ga"],
        function()
            bA(0x431FC24C, nil, true)
        end
    )
    bd(
        "Hen",
        aj["bac_ga"],
        function()
            bA(0x6AF51FAF)
        end
    )
    bd(
        "Husky",
        aj["bac_ga"],
        function()
            bA(0x4E8F95A2, nil, true)
        end
    )
    bd(
        "Mountain Lion",
        aj["bac_ga"],
        function()
            bA(0x1250D7BA, nil, true)
        end
    )
    bd(
        "Pig",
        aj["bac_ga"],
        function()
            bA(0xB11BAB56)
        end
    )
    bd(
        "Poodle",
        aj["bac_ga"],
        function()
            bA(0x431D501C)
        end
    )
    bd(
        "Pug",
        aj["bac_ga"],
        function()
            bA(0x6D362854)
        end
    )
    bd(
        "Rabbit",
        aj["bac_ga"],
        function()
            bA(0xDFB55C81)
        end
    )
    bd(
        "Rat",
        aj["bac_ga"],
        function()
            bA(0xC3B52966)
        end
    )
    bd(
        "Golden Retriever",
        aj["bac_ga"],
        function()
            bA(0x349F33E1, nil, true)
        end
    )
    bd(
        "Rhesus",
        aj["bac_ga"],
        function()
            bA(0xC2D06F53, nil, nil, true)
        end
    )
    bd(
        "Rottweiler",
        aj["bac_ga"],
        function()
            bA(0x9563221D, nil, true)
        end
    )
    bd(
        "Westy",
        aj["bac_ga"],
        function()
            bA(0xAD7844BB)
        end
    )
    aj["bac_wa"] =
        b9(
        "Water Animals",
        aj["bac"],
        function()
            o("Note that these Models will only work in Water!", 48)
        end
    ).id
    bd(
        "Dolphin",
        aj["bac_wa"],
        function()
            bA(0x8BBAB455, true)
        end
    )
    bd(
        "Fish",
        aj["bac_wa"],
        function()
            bA(0x2FD800B7, true)
        end
    )
    bd(
        "Hammershark",
        aj["bac_wa"],
        function()
            bA(0x3C831724, true)
        end
    )
    bd(
        "Humpback",
        aj["bac_wa"],
        function()
            bA(0x471BE4B2, true)
        end
    )
    bd(
        "Killerwhale",
        aj["bac_wa"],
        function()
            bA(0x8D8AC8B9, true)
        end
    )
    bd(
        "Shark",
        aj["bac_wa"],
        function()
            bA(0x06C3F072, true, true)
        end
    )
    bd(
        "Stingray",
        aj["bac_wa"],
        function()
            bA(0xA148614D, true)
        end
    )
    aj["bac_fa"] = b9("Flying Animals", aj["bac"]).id
    bd(
        "Cormorant",
        aj["bac_fa"],
        function()
            bA(0x56E29962)
        end
    )
    bd(
        "Chickenhawk",
        aj["bac_fa"],
        function()
            bA(0xAAB71F62)
        end
    )
    bd(
        "Crow",
        aj["bac_fa"],
        function()
            bA(0x18012A9F)
        end
    )
    bd(
        "Pigeon",
        aj["bac_fa"],
        function()
            bA(0x06A20728)
        end
    )
    bd(
        "Seagull",
        aj["bac_fa"],
        function()
            bA(0xD3939DFD)
        end
    )
    aj["bac_sm"] = b9("Standard Models", aj["bac"]).id
    bd(
        "Franklin",
        aj["bac_sm"],
        function()
            bA(0x9B22DBAF, nil, nil, nil, true)
        end
    )
    bd(
        "Michael",
        aj["bac_sm"],
        function()
            bA(0x0D7114C9, nil, nil, nil, true)
        end
    )
    bd(
        "Trevor",
        aj["bac_sm"],
        function()
            bA(0x9B810FA2, nil, nil, nil, true)
        end
    )
    bd(
        "MP Female",
        aj["bac_sm"],
        function()
            bA(0x9C9EFFD8, nil, true, nil, true)
        end
    )
    bd(
        "MP Male",
        aj["bac_sm"],
        function()
            bA(0x705E61F2, nil, true, nil, true)
        end
    )
    ak["bl_mdl_change"] =
        be(
        "Safe Model Change",
        aj["bac"],
        function(k)
            l["bl_mdl_change"] = k.on
        end
    )
    ak["bl_mdl_change"].on = l["bl_mdl_change"]
    bd(
        "Fix endless loading Screen",
        aj["bac"],
        function()
            bA(0x9B22DBAF, nil, nil, nil, true)
            c.wait(100)
            ped.set_ped_health(M.ped(), 0)
        end
    )
    aj["ptfx"] = b9("PTFX", aj["parent"])
    aj["ptfx"].hidden = l["ptfx_hidden"]
    aj["ptfx"] = aj["ptfx"].id
    ak["sparkling_ass"] =
        be(
        "Sparkling Ass",
        aj["ptfx"],
        function(k)
            if k.on then
                graphics.set_next_ptfx_asset("scr_indep_fireworks")
                while not graphics.has_named_ptfx_asset_loaded("scr_indep_fireworks") do
                    graphics.request_named_ptfx_asset("scr_indep_fireworks")
                    c.wait(0)
                end
                graphics.start_networked_particle_fx_non_looped_at_coord(
                    "scr_indep_firework_trail_spawn",
                    M.coords(),
                    v3(60, 0, 0),
                    0.33,
                    true,
                    true,
                    true
                )
                c.wait(25)
            end
            l["sparkling_ass"] = k.on
            return d.stop(k)
        end
    )
    ak["sparkling_ass"].on = l["sparkling_ass"]
    ak["sparkling_tires"] =
        be(
        "Sparkling Tires (WIP)",
        aj["ptfx"],
        function(k)
            if k.on then
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    local en = {"wheel_lf", "wheel_rf", "wheel_lr", "wheel_rr"}
                    for i = 1, #en do
                        H.model(1803116220)
                        local eo = object.create_object(1803116220, M.coords(), true, false)
                        entity.set_entity_collision(eo, false, false, false)
                        entity.set_entity_visible(eo, false)
                        local C = entity.get_entity_bone_index_by_name(bt, en[i])
                        entity.attach_entity_to_entity(eo, bt, C, v3(), v3(), true, true, false, 0, true)
                        graphics.set_next_ptfx_asset("scr_indep_fireworks")
                        while not graphics.has_named_ptfx_asset_loaded("scr_indep_fireworks") do
                            graphics.request_named_ptfx_asset("scr_indep_fireworks")
                            c.wait(0)
                        end
                        graphics.start_networked_particle_fx_non_looped_at_coord(
                            "scr_indep_firework_trail_spawn",
                            c.gcoords(eo),
                            v3(60, 0, 0),
                            0.5,
                            true,
                            true,
                            true
                        )
                        H.ctrl(eo, 5)
                        entity.detach_entity(eo)
                        entity.set_entity_velocity(eo, v3())
                        bl(eo, v3(8000, 8000, -1000))
                        entity.delete_entity(eo)
                    end
                    c.unload(1803116220)
                    c.wait(25)
                end
            end
            l["sparkling_tires"] = k.on
            return d.stop(k)
        end
    )
    ak["sparkling_tires"].on = l["sparkling_tires"]
    ak["smoke_area"] =
        be(
        "Smoke Area",
        aj["ptfx"],
        function(k)
            if k.on then
                for i = 1, 16 do
                    local bs = M.coords()
                    local ep = 2 * math.pi
                    ep = ep / 16
                    ep = ep * i
                    bs.x = bs.x + 18 * math.cos(ep)
                    bs.y = bs.y + 18 * math.sin(ep)
                    bs.z = bs.z - 2.5
                    graphics.set_next_ptfx_asset("scr_recartheft")
                    while not graphics.has_named_ptfx_asset_loaded("scr_recartheft") do
                        graphics.request_named_ptfx_asset("scr_recartheft")
                        c.wait(0)
                    end
                    graphics.start_networked_particle_fx_non_looped_at_coord(
                        "scr_wheel_burnout",
                        bs,
                        v3(),
                        2.5,
                        true,
                        true,
                        true
                    )
                    c.wait(40)
                end
            end
            l["smoke_area"] = k.on
            return d.stop(k)
        end
    )
    ak["smoke_area"].on = l["smoke_area"]
    ak["fire_circle"] =
        be(
        "Fire Circle",
        aj["ptfx"],
        function(k)
            if k.on then
                if b8["fire_balls"][1] == nil then
                    for i = 1, 48 do
                        H.model(1803116220)
                        b8["fire_balls"][i] = object.create_object(1803116220, M.coords(), true, false)
                        entity.set_entity_collision(b8["fire_balls"][i], false, false, false)
                        entity.set_entity_visible(b8["fire_balls"][i], false)
                    end
                    c.unload(1803116220)
                end
                for i = 1, 48 do
                    local bs = M.coords()
                    local ep = 2 * math.pi
                    ep = ep / 48
                    ep = ep * c.random(1, 64)
                    bs.x = bs.x + 10 * math.cos(ep)
                    bs.y = bs.y + 10 * math.sin(ep)
                    bs.z = bs.z - 1.5
                    bl(b8["fire_balls"][i], bs)
                end
                c.wait(10)
                if b8["fire_circle"][1] == nil then
                    for i = 1, 48 do
                        graphics.set_next_ptfx_asset("weap_xs_vehicle_weapons")
                        while not graphics.has_named_ptfx_asset_loaded("weap_xs_vehicle_weapons") do
                            graphics.request_named_ptfx_asset("weap_xs_vehicle_weapons")
                            c.wait(0)
                        end
                        b8["fire_circle"][i] =
                            graphics.start_ptfx_looped_on_entity(
                            "muz_xs_turret_flamethrower_looping",
                            b8["fire_balls"][i],
                            v3(),
                            v3(90, 0, 0),
                            1
                        )
                    end
                end
            end
            if not k.on then
                bn(b8["fire_balls"])
                b8["fire_balls"] = {}
                if b8["fire_circle"][1] ~= nil then
                    for i = 1, #b8["fire_circle"] do
                        graphics.remove_particle_fx(b8["fire_circle"][i], true)
                    end
                    b8["fire_circle"] = {}
                end
            end
            return d.stop(k)
        end
    )
    ak["fire_circle"].on = l["fire_circle"]
    ak["fire_fart"] =
        bf(
        "Fire Fart",
        "action_value_i",
        aj["ptfx"],
        function(k)
            l["fire_fart"] = ak["fire_fart"].value_i
            local bt = ped.get_vehicle_ped_is_using(M.ped())
            if bt ~= 0 then
                o("Fire Fart in a vehicle is too dangerous, get out!", 162)
            else
                local ci = 0x187D938D
                local eq = "weap_xs_vehicle_weapons"
                local er = "muz_xs_turret_flamethrower_looping"
                H.model(ci)
                local c2 = player.get_player_heading(c.id())
                local cj = vehicle.create_vehicle(ci, M.coords(), c2, true, false)
                H.ctrl(cj)
                entity.set_entity_visible(cj, false)
                c.unload(ci)
                decorator.decor_set_int(cj, "MPBitset", 1 << 10)
                ped.set_ped_into_vehicle(M.ped(), cj, -1)
                c.wait(500)
                graphics.set_next_ptfx_asset(eq)
                while not graphics.has_named_ptfx_asset_loaded(eq) do
                    graphics.request_named_ptfx_asset(eq)
                    c.wait(0)
                end
                local es = k.value_i
                local fire = graphics.start_ptfx_looped_on_entity(er, M.ped(), v3(), v3(180, 0, 0), es * 0.1)
                local bs = c.gcoords(cj)
                local c_ = entity.get_entity_rotation(cj)
                local dL = c_
                dL:transformRotToDir()
                dL = dL * 1 * es
                dL.z = bs.z + 0.6666666 * es
                local et = dL
                entity.set_entity_velocity(cj, et)
                c.wait(250 * es)
                graphics.remove_particle_fx(fire, true)
                while ped.is_ped_in_any_vehicle(M.ped()) do
                    ai.task_leave_vehicle(M.ped(), cj, 16)
                    c.wait(25)
                end
                bn({cj})
            end
        end
    )
    ak["fire_fart"].max_i = 16
    ak["fire_fart"].min_i = 4
    ak["fire_fart"].value_i = l["fire_fart"]
    ak["fire_ass"] =
        be(
        "Fire Ass",
        aj["ptfx"],
        function(k)
            l["fire_ass"] = k.on
            if k.on then
                if b8["fire_ass_ball"] == nil then
                    H.model(1803116220)
                    b8["fire_ass_ball"] = object.create_object(1803116220, M.coords(), true, false)
                    entity.set_entity_collision(b8["fire_ass_ball"], false, false, false)
                    entity.set_entity_visible(b8["fire_ass_ball"], false)
                    c.unload(1803116220)
                end
                if b8["fire_ass"] == nil then
                    local eq = "weap_xs_vehicle_weapons"
                    local er = "muz_xs_turret_flamethrower_looping"
                    graphics.set_next_ptfx_asset(eq)
                    while not graphics.has_named_ptfx_asset_loaded(eq) do
                        graphics.request_named_ptfx_asset(eq)
                        c.wait(0)
                    end
                    b8["fire_ass"] = graphics.start_ptfx_looped_on_entity(er, M.ped(), v3(), v3(180, 0, 0), 0.333)
                end
                local bs = M.coords()
                bl(b8["fire_ass_ball"], M.coords())
            end
            if not k.on then
                if b8["fire_ass"] ~= nil then
                    graphics.remove_particle_fx(b8["fire_ass"], true)
                    b8["fire_ass"] = nil
                end
                bn({b8["fire_ass_ball"]})
                b8["fire_ass_ball"] = nil
            end
            return d.stop(k)
        end
    )
    ak["fire_ass"].on = l["fire_ass"]
    aj["misc"] = b9("Miscellaneous", aj["parent"])
    aj["misc"].hidden = l["misc_hidden"]
    aj["misc"] = aj["misc"].id
    aj["weapon"] = b9("Weapon-Features", aj["misc"]).id
    ak["load_weapons"] =
        be(
        "Load Weapons",
        aj["weapon"],
        function(k)
            if k.on then
                local time = c.time() + 500
                while k.on do
                    c.wait(0)
                    if time < c.time() then
                        break
                    end
                end
                local eu = weapon.get_all_weapon_hashes()
                for i = 1, #eu do
                    if weapon.has_ped_got_weapon(M.ped(), eu[i]) then
                        local ev = false
                        for E = 1, #ag do
                            if eu[i] == ag[E][1] then
                                ev = true
                            end
                        end
                        if not ev then
                            weapon.remove_weapon_from_ped(M.ped(), eu[i])
                        end
                    end
                end
                for i = 1, #ag do
                    if not weapon.has_ped_got_weapon(M.ped(), ag[i][1]) then
                        weapon.give_delayed_weapon_to_ped(M.ped(), ag[i][1], 0, 0)
                    end
                end
                for i = 1, #ag do
                    for dh = 2, #ag[i] do
                        if not weapon.has_ped_got_weapon_component(M.ped(), ag[i][1], ag[i][dh]) then
                            for dr = 2, #ag[i] do
                                weapon.give_weapon_component_to_ped(M.ped(), ag[i][1], ag[i][dr])
                            end
                            weapon.set_ped_ammo(M.ped(), ag[i][1], 9999)
                        end
                    end
                end
            end
            l["load_weapons"] = k.on
            return d.stop(k)
        end
    )
    ak["load_weapons"].on = l["load_weapons"]
    aj["flamethrower"] = b9("Flamethrower", aj["weapon"]).id
    ak["flamethrower_scale"] =
        bf(
        "Scale",
        "autoaction_value_i",
        aj["flamethrower"],
        function()
            l["flamethrower_scale"] = ak["flamethrower_scale"].value_i
        end
    )
    ak["flamethrower_scale"].min_i = 1
    ak["flamethrower_scale"].max_i = 25
    ak["flamethrower_scale"].value_i = l["flamethrower_scale"]
    ak["flamethrower"] =
        be(
        "Flamethrower",
        aj["flamethrower"],
        function(k)
            if k.on then
                if player.is_player_free_aiming(c.id()) then
                    graphics.set_next_ptfx_asset("weap_xs_vehicle_weapons")
                    while not graphics.has_named_ptfx_asset_loaded("weap_xs_vehicle_weapons") do
                        graphics.request_named_ptfx_asset("weap_xs_vehicle_weapons")
                        c.wait(0)
                    end
                    if b8["alien"] == nil then
                        H.model(1803116220)
                        b8["alien"] = object.create_object(1803116220, M.coords(), true, false)
                        entity.set_entity_collision(b8["alien"], false, false, false)
                        entity.set_entity_visible(b8["alien"], false)
                        c.unload(1803116220)
                    end
                    local ew, ex = ped.get_ped_bone_coords(M.ped(), 0xdead, v3())
                    while not ew do
                        c.wait(0)
                        ew, ex = ped.get_ped_bone_coords(M.ped(), 0xdead, v3())
                    end
                    bl(b8["alien"], ex)
                    entity.set_entity_rotation(b8["alien"], cam.get_gameplay_cam_rot())
                    if b8["flamethrower"] == nil then
                        b8["flamethrower"] =
                            graphics.start_ptfx_looped_on_entity(
                            "muz_xs_turret_flamethrower_looping",
                            b8["alien"],
                            v3(),
                            v3(),
                            l["flamethrower_scale"]
                        )
                        graphics.set_particle_fx_looped_scale(b8["flamethrower"], l["flamethrower_scale"])
                    end
                else
                    if b8["flamethrower"] ~= nil then
                        graphics.remove_particle_fx(b8["flamethrower"], true)
                        b8["flamethrower"] = nil
                        bn({b8["alien"]})
                        b8["alien"] = nil
                    end
                end
            end
            if not k.on then
                if b8["flamethrower"] ~= nil then
                    graphics.remove_particle_fx(b8["flamethrower"], true)
                    b8["flamethrower"] = nil
                    bn({b8["alien"]})
                    b8["alien"] = nil
                end
            end
            l["flamethrower"] = k.on
            return d.stop(k)
        end
    )
    ak["flamethrower"].on = l["flamethrower"]
    ak["flamethrower_green"] =
        be(
        "Flamethrower - Green",
        aj["flamethrower"],
        function(k)
            if k.on then
                if player.is_player_free_aiming(c.id()) then
                    graphics.set_next_ptfx_asset("weap_xs_vehicle_weapons")
                    while not graphics.has_named_ptfx_asset_loaded("weap_xs_vehicle_weapons") do
                        graphics.request_named_ptfx_asset("weap_xs_vehicle_weapons")
                        c.wait(0)
                    end
                    if b8["alien"] == nil then
                        H.model(1803116220)
                        b8["alien"] = object.create_object(1803116220, M.coords(), true, false)
                        entity.set_entity_collision(b8["alien"], false, false, false)
                        entity.set_entity_visible(b8["alien"], false)
                        c.unload(1803116220)
                    end
                    local ew, ex = ped.get_ped_bone_coords(M.ped(), 0xdead, v3())
                    while not ew do
                        c.wait(0)
                        ew, ex = ped.get_ped_bone_coords(M.ped(), 0xdead, v3())
                    end
                    bl(b8["alien"], ex)
                    entity.set_entity_rotation(b8["alien"], cam.get_gameplay_cam_rot())
                    if b8["flamethrower_green"] == nil then
                        b8["flamethrower_green"] =
                            graphics.start_ptfx_looped_on_entity(
                            "muz_xs_turret_flamethrower_looping_sf",
                            b8["alien"],
                            v3(),
                            v3(),
                            l["flamethrower_scale"]
                        )
                    end
                else
                    if b8["flamethrower_green"] ~= nil then
                        graphics.remove_particle_fx(b8["flamethrower_green"], true)
                        b8["flamethrower_green"] = nil
                        bn({b8["alien"]})
                        b8["alien"] = nil
                    end
                end
            end
            if not k.on then
                if b8["flamethrower_green"] ~= nil then
                    graphics.remove_particle_fx(b8["flamethrower_green"], true)
                    b8["flamethrower_green"] = nil
                    bn({b8["alien"]})
                    b8["alien"] = nil
                end
            end
            l["flamethrower_green"] = k.on
            return d.stop(k)
        end
    )
    ak["flamethrower_green"].on = l["flamethrower_green"]
    aj["shoot"] = b9("Shoot Objects", aj["weapon"]).id
    ak["shoot"] =
        be(
        "Enable Object Shoot",
        aj["shoot"],
        function(k)
            if k.on then
                for i = 1, #S do
                    if l[S[i][1]] and ped.is_ped_shooting(M.ped()) then
                        if #a0["shooting"] > 128 then
                            bn(a0["shooting"])
                            a0["shooting"] = {}
                        end
                        H.model(S[i][2])
                        local bs = M.coords()
                        local dL = cam.get_gameplay_cam_rot()
                        dL:transformRotToDir()
                        dL = dL * 8
                        bs = bs + dL
                        if streaming.is_model_an_object(S[i][2]) then
                            a0["shooting"][#a0["shooting"] + 1] = object.create_object(S[i][2], bs, true, false)
                        end
                        dL = nil
                        local ey = M.coords()
                        dL = cam.get_gameplay_cam_rot()
                        dL:transformRotToDir()
                        dL = dL * 100
                        ey = ey + dL
                        local eg = ey - bs
                        entity.apply_force_to_entity(
                            a0["shooting"][#a0["shooting"]],
                            3,
                            eg.x,
                            eg.y,
                            eg.z,
                            0.0,
                            0.0,
                            0.0,
                            true,
                            true
                        )
                    end
                end
            end
            if not k.on then
                bn(a0["shooting"])
                a0["shooting"] = {}
            end
            l["shoot_entitys"] = k.on
            return d.stop(k)
        end
    )
    ak["shoot"].on = l["shoot_entitys"]
    bd(
        "Delete Objects",
        aj["shoot"],
        function()
            bn(a0["shooting"])
            a0["shooting"] = {}
        end
    )
    for i = 1, #S do
        ak[S[i][1]] =
            be(
            "Shoot " .. S[i][1],
            aj["shoot"],
            function(k)
                S[i][3] = k.on
                l[S[i][1]] = k.on
            end
        )
        ak[S[i][1]].on = l[S[i][1]]
    end
    ak["delete_gun"] =
        be(
        "Delete Gun",
        aj["weapon"],
        function(k)
            if k.on then
                if ped.is_ped_shooting(M.ped()) then
                    local ez = player.get_entity_player_is_aiming_at(c.id())
                    if ez ~= nil then
                        bn({ez})
                    end
                end
            end
            l["delete_gun"] = k.on
            return d.stop(k)
        end
    )
    ak["delete_gun"].on = l["delete_gun"]
    ak["kick_gun"] =
        be(
        "Kick Gun",
        aj["weapon"],
        function(k)
            if k.on then
                if ped.is_ped_shooting(M.ped()) then
                    local eA = player.get_entity_player_is_aiming_at(c.id())
                    if ped.is_ped_a_player(eA) then
                        o("Kick-Gun hit: " .. K.name(eA))
                        bJ(false, player.get_player_from_ped(eA))
                    end
                end
            end
            l["kick_gun"] = k.on
            return d.stop(k)
        end
    )
    ak["kick_gun"].on = l["kick_gun"]
    ak["demigod_gun"] =
        be(
        "Give Demi-God for Player",
        aj["weapon"],
        function(k)
            if k.on then
                if ped.is_ped_shooting(M.ped()) then
                    local eA = player.get_entity_player_is_aiming_at(c.id())
                    if ped.is_ped_a_player(eA) then
                        o("Attached Demi-God on Player: " .. K.name(eA))
                        bO(a7[1][2], player.get_player_from_ped(eA))
                    end
                end
            end
            l["demigod_gun"] = k.on
            return d.stop(k)
        end
    )
    ak["demigod_gun"].on = l["demigod_gun"]
    aj["model_gun"] = b9("Model Gun", aj["weapon"]).id
    ak["model_gun"] =
        be(
        "Standard Model Gun (PEDs)",
        aj["model_gun"],
        function(k)
            if k.on then
                if aQ then
                    entity.set_entity_visible(M.ped(), false)
                    if aP ~= nil then
                        entity.set_entity_visible(aP, true)
                    end
                else
                    entity.set_entity_visible(M.ped(), true)
                end
                if player.is_player_free_aiming(c.id()) then
                    local eB = player.get_entity_player_is_aiming_at(c.id())
                    if eB ~= 0 then
                        eB = entity.get_entity_model_hash(eB)
                        if streaming.is_model_a_ped(eB) then
                            if aP ~= nil then
                                bn({aP})
                                aP = nil
                            end
                            local eC = entity.get_entity_model_hash(M.ped())
                            if eB ~= eC then
                                aQ = false
                                c.wait(50)
                                local eD = ped.get_current_ped_weapon(M.ped())
                                bA(eB, nil, nil, nil, true)
                                c.wait(25)
                                weapon.give_delayed_weapon_to.ped(M.ped(), eD, 0, 1)
                            end
                        elseif streaming.is_model_a_vehicle(eB) and ak["model_gun_ext"].on then
                            bn({aP})
                            aP = nil
                            aQ = true
                            aP = vehicle.create_vehicle(eB, M.coords(), 0, true, false)
                            entity.attach_entity_to_entity(aP, M.ped(), 0, v3(), v3(), true, true, false, 0, true)
                        elseif streaming.is_model_an_object(eB) and ak["model_gun_ext"].on then
                            bn({aP})
                            aP = nil
                            H.model(eB)
                            aP = object.create_object(eB, M.coords(), true, false)
                            c.unload(eB)
                            aQ = true
                            entity.attach_entity_to_entity(aP, M.ped(), 0, v3(), v3(), true, true, false, 0, true)
                        end
                    end
                end
            end
            if not k.on then
                bn({aP})
                aP = nil
                entity.set_entity_visible(M.ped(), true)
            end
            l["model_gun"] = k.on
            return d.stop(k)
        end
    )
    ak["model_gun"].on = l["model_gun"]
    ak["model_gun_ext"] =
        be(
        "Add Objects and Vehicles to Model Gun",
        aj["model_gun"],
        function(k)
            l["model_gun_ext"] = k.on
        end
    )
    ak["model_gun_ext"].on = l["model_gun_ext"]
    ak["rapid_fire"] =
        be(
        "Rapid Fire",
        aj["weapon"],
        function(k)
            if k.on then
                if player.is_player_free_aiming(c.id()) then
                    if ped.is_ped_shooting(M.ped()) then
                        for i = 1, 20 do
                            local ew, eE = ped.get_ped_bone_coords(M.ped(), 0x67f2, v3())
                            while not ew do
                                ew, eE = ped.get_ped_bone_coords(M.ped(), 0x67f2, v3())
                                system.wait(0)
                            end
                            local dL = cam.get_gameplay_cam_rot()
                            dL:transformRotToDir()
                            dL = dL * 1.5
                            eE = eE + dL
                            dL = nil
                            local eF = M.coords()
                            dL = cam.get_gameplay_cam_rot()
                            dL:transformRotToDir()
                            dL = dL * 1500
                            eF = eF + dL
                            local eG = ped.get_current_ped_weapon(M.ped())
                            gameplay.shoot_single_bullet_between_coords(eE, eF, 1, eG, M.ped(), true, false, 1000)
                            c.wait(25)
                        end
                    end
                end
            end
            l["rapid_fire"] = k.on
            return d.stop(k)
        end
    )
    ak["rapid_fire"].on = l["rapid_fire"]
    ak["teleport_high_in_air"] =
        bd(
        "Teleport High in Air",
        aj["misc"],
        function()
            local bs = M.coords()
            while bs.z < 25000 do
                bs.z = bs.z + 500
                bp(bs)
                c.wait(50)
            end
        end
    )
    aj["vehicle"] = b9("Vehicle", aj["misc"]).id
    ak["tp_own_veh_to_me"] =
        bd(
        "Teleport Own Vehicle to me",
        aj["vehicle"],
        function()
            local bt = player.get_personal_vehicle()
            local eH = ped.get_vehicle_ped_is_using(M.ped())
            if bt ~= 0 and eH ~= bt then
                bl(bt, c1(M.coords(), M.heading(), 5))
                entity.set_entity_heading(bt, M.heading())
            end
        end
    )
    ak["tp_own_veh_to_me_drive"] =
        bd(
        "Teleport Own Vehicle to me and drive",
        aj["vehicle"],
        function()
            local bt = player.get_personal_vehicle()
            local eH = ped.get_vehicle_ped_is_using(M.ped())
            if bt ~= 0 and eH ~= bt then
                bl(bt, M.coords())
                entity.set_entity_heading(bt, M.heading())
                ped.set_ped_into_vehicle(M.ped(), bt, -1)
            end
        end
    )
    ak["drive_own_veh"] =
        bd(
        "Drive Own Vehicle",
        aj["vehicle"],
        function()
            local bt = player.get_personal_vehicle()
            local eH = ped.get_vehicle_ped_is_using(M.ped())
            if bt ~= 0 and eH ~= bt then
                ped.set_ped_into_vehicle(M.ped(), bt, -1)
            end
        end
    )
    ak["tp_to_own_veh"] =
        bd(
        "Teleport to Own Vehicle",
        aj["vehicle"],
        function()
            local bt = player.get_personal_vehicle()
            local eH = ped.get_vehicle_ped_is_using(M.ped())
            r(bt)
            r(eH)
            if bt ~= 0 and eH ~= bt then
                bp(c1(c.gcoords(bt), entity.get_entity_heading(bt), -5), 0, entity.get_entity_heading(bt))
            end
        end
    )
    aj["vehicle_colors"] = b9("Vehicle Colors", aj["vehicle"]).id
    ak["light_speed"] =
        bf(
        "Set Speed in Milliseconds",
        "autoaction_value_i",
        aj["vehicle_colors"],
        function(k)
            l["veh_lights_speed"] = k.value_i
        end
    )
    ak["light_speed"].min_i = 25
    ak["light_speed"].max_i = 2500
    ak["light_speed"].mod_i = 25
    ak["light_speed"].value_i = l["veh_lights_speed"]
    aj["random_col"] = b9("Random Colors", aj["vehicle_colors"]).id
    ak["random_primary"] =
        be(
        "Random Primary",
        aj["random_col"],
        function(k)
            if k.on then
                c9(an)
                c9({"rainbow_primary"})
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    H.ctrl(bt)
                    vehicle.set_vehicle_custom_primary_colour(bt, c.random(0, 0xffffff))
                    c.wait(ak["light_speed"].value_i)
                end
            end
            l["random_primary"] = k.on
            return d.stop(k)
        end
    )
    ak["random_primary"].on = l["random_primary"]
    ak["random_secondary"] =
        be(
        "Random Secondary",
        aj["random_col"],
        function(k)
            if k.on then
                c9(an)
                c9({"rainbow_secondary"})
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    H.ctrl(bt)
                    vehicle.set_vehicle_custom_secondary_colour(bt, c.random(0, 0xffffff))
                    c.wait(ak["light_speed"].value_i)
                end
            end
            l["random_secondary"] = k.on
            return d.stop(k)
        end
    )
    ak["random_secondary"].on = l["random_secondary"]
    ak["random_pearlescent"] =
        be(
        "Random Pearlescent",
        aj["random_col"],
        function(k)
            if k.on then
                c9(an)
                c9({"rainbow_pearlescent"})
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    H.ctrl(bt)
                    vehicle.set_vehicle_custom_pearlescent_colour(bt, c.random(0, 0xffffff))
                    c.wait(ak["light_speed"].value_i)
                end
            end
            l["random_pearlescent"] = k.on
            return d.stop(k)
        end
    )
    ak["random_pearlescent"].on = l["random_pearlescent"]
    ak["random_neon"] =
        be(
        "Random Neon Lights",
        aj["random_col"],
        function(k)
            if k.on then
                c9(an)
                c9({"rainbow_neon"})
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    H.ctrl(bt)
                    local p = c.random(0, 0xffffff)
                    vehicle.set_vehicle_neon_lights_color(bt, p)
                    c.wait(ak["light_speed"].value_i)
                end
            end
            l["random_neon"] = k.on
            return d.stop(k)
        end
    )
    ak["random_neon"].on = l["random_neon"]
    ak["random_smoke"] =
        be(
        "Random Smoke",
        aj["random_col"],
        function(k)
            if k.on then
                c9(an)
                c9({"rainbow_smoke"})
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    H.ctrl(bt)
                    local eI = c.random(0, 255)
                    local eJ = c.random(0, 255)
                    local eK = c.random(0, 255)
                    vehicle.set_vehicle_tire_smoke_color(bt, eI, eJ, eK)
                    c.wait(ak["light_speed"].value_i)
                end
            end
            l["random_smoke"] = k.on
            return d.stop(k)
        end
    )
    ak["random_smoke"].on = l["random_smoke"]
    ak["random_xenon"] =
        be(
        "Random Xenon",
        aj["random_col"],
        function(k)
            if k.on then
                c9(an)
                c9({"rainbow_xenon"})
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    H.ctrl(bt)
                    vehicle.set_vehicle_headlight_color(bt, c.random(0, 12))
                    c.wait(ak["light_speed"].value_i)
                end
            end
            l["random_xenon"] = k.on
            return d.stop(k)
        end
    )
    ak["random_xenon"].on = l["random_xenon"]
    aj["rainbow_col"] = b9("Rainbow Colors", aj["vehicle_colors"]).id
    ak["rainbow_primary"] =
        be(
        "Rainbow Primary",
        aj["rainbow_col"],
        function(k)
            if k.on then
                c9(an)
                c9({"random_primary"})
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    H.ctrl(bt)
                    for i = 1, #T do
                        vehicle.set_vehicle_custom_primary_colour(bt, c4({T[i][1], T[i][2], T[i][3]}))
                        c.wait(ak["light_speed"].value_i)
                    end
                end
            end
            l["rainbow_primary"] = k.on
            return d.stop(k)
        end
    )
    ak["rainbow_primary"].on = l["rainbow_primary"]
    ak["rainbow_secondary"] =
        be(
        "Rainbow Secondary",
        aj["rainbow_col"],
        function(k)
            if k.on then
                c9(an)
                c9({"random_secondary"})
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    H.ctrl(bt)
                    for i = 1, #T do
                        vehicle.set_vehicle_custom_secondary_colour(bt, c4({T[i][1], T[i][2], T[i][3]}))
                        c.wait(ak["light_speed"].value_i)
                    end
                end
            end
            l["rainbow_secondary"] = k.on
            return d.stop(k)
        end
    )
    ak["rainbow_secondary"].on = l["rainbow_secondary"]
    ak["rainbow_pearlescent"] =
        be(
        "Rainbow Pearlescent",
        aj["rainbow_col"],
        function(k)
            if k.on then
                c9(an)
                c9({"random_pearlescent"})
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    H.ctrl(bt)
                    for i = 1, #T do
                        vehicle.set_vehicle_custom_pearlescent_colour(bt, c4({T[i][1], T[i][2], T[i][3]}))
                        c.wait(ak["light_speed"].value_i)
                    end
                end
            end
            l["rainbow_pearlescent"] = k.on
            return d.stop(k)
        end
    )
    ak["rainbow_pearlescent"].on = l["rainbow_pearlescent"]
    ak["rainbow_neon"] =
        be(
        "Rainbow Neon Lights",
        aj["rainbow_col"],
        function(k)
            if k.on then
                c9(an)
                c9({"random_neon"})
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    H.ctrl(bt)
                    for i = 1, #T do
                        vehicle.set_vehicle_neon_lights_color(bt, c4({T[i][1], T[i][2], T[i][3]}))
                        c.wait(ak["light_speed"].value_i)
                    end
                end
            end
            l["rainbow_neon"] = k.on
            return d.stop(k)
        end
    )
    ak["rainbow_neon"].on = l["rainbow_neon"]
    ak["rainbow_smoke"] =
        be(
        "Rainbow Smoke",
        aj["rainbow_col"],
        function(k)
            if k.on then
                c9(an)
                c9({"random_smoke"})
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    H.ctrl(bt)
                    for i = 1, #T do
                        local bc = T[i]
                        vehicle.set_vehicle_tire_smoke_color(bt, bc[1], bc[2], bc[3])
                        c.wait(ak["light_speed"].value_i)
                    end
                end
            end
            l["rainbow_smoke"] = k.on
            return d.stop(k)
        end
    )
    ak["rainbow_smoke"].on = l["rainbow_smoke"]
    ak["rainbow_xenon"] =
        be(
        "Rainbow Xenon",
        aj["rainbow_col"],
        function(k)
            if k.on then
                c9(an)
                c9({"random_xenon"})
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    H.ctrl(bt)
                    for i = 0, 12 do
                        vehicle.set_vehicle_headlight_color(bt, i)
                        c.wait(ak["light_speed"].value_i)
                    end
                end
            end
            l["rainbow_xenon"] = k.on
            return d.stop(k)
        end
    )
    ak["rainbow_xenon"].on = l["rainbow_xenon"]
    ak["synced_random"] =
        be(
        "Synced Random Colors",
        aj["vehicle_colors"],
        function(k)
            if k.on then
                c9(am)
                c9(al)
                c9({"synced_rainbow_smooth", "synced_rainbow"})
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    cb(bt, {c.random(0, 255), c.random(0, 255), c.random(0, 255)})
                    c.wait(ak["light_speed"].value_i)
                end
            end
            l["synced_random"] = k.on
            return d.stop(k)
        end
    )
    ak["synced_random"].on = l["synced_random"]
    ak["synced_rainbow"] =
        be(
        "Synced Rainbow Colors",
        aj["vehicle_colors"],
        function(k)
            if k.on then
                c9(am)
                c9(al)
                c9({"synced_random", "synced_rainbow_smooth"})
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    for i = 1, #T do
                        local bc = T[i]
                        cb(bt, {bc[1], bc[2], bc[3]}, i)
                        c.wait(ak["light_speed"].value_i)
                    end
                end
            end
            l["synced_rainbow"] = k.on
            return d.stop(k)
        end
    )
    ak["synced_rainbow"].on = l["synced_rainbow"]
    ak["synced_rainbow_smooth"] =
        be(
        "Synced Smooth Rainbow",
        aj["vehicle_colors"],
        function(k)
            if k.on then
                c9(am)
                c9(al)
                c9({"synced_random", "synced_rainbow"})
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    local eL
                    eL = math.floor((101 - ak["light_speed"].value_i / 25) / 2)
                    if eL < 1 then
                        eL = 1
                    end
                    for i = 0, 255, eL do
                        cb(bt, {255, i, 0})
                    end
                    eL = math.floor((101 - ak["light_speed"].value_i / 25) / 2)
                    if eL < 1 then
                        eL = 1
                    end
                    for i = 255, 0, -eL do
                        cb(bt, {i, 255, 0})
                    end
                    eL = math.floor((101 - ak["light_speed"].value_i / 25) / 2)
                    if eL < 1 then
                        eL = 1
                    end
                    for i = 0, 255, eL do
                        cb(bt, {0, 255, i})
                    end
                    eL = math.floor((101 - ak["light_speed"].value_i / 25) / 2)
                    if eL < 1 then
                        eL = 1
                    end
                    for i = 255, 0, -eL do
                        cb(bt, {0, i, 255})
                    end
                    eL = math.floor((101 - ak["light_speed"].value_i / 25) / 2)
                    if eL < 1 then
                        eL = 1
                    end
                    for i = 0, 255, eL do
                        cb(bt, {i, 0, 255})
                    end
                    eL = math.floor((101 - ak["light_speed"].value_i / 25) / 2)
                    if eL < 1 then
                        eL = 1
                    end
                    for i = 255, 0, -eL do
                        cb(bt, {255, 0, i})
                    end
                end
            end
            l["synced_rainbow_smooth"] = k.on
            return d.stop(k)
        end
    )
    ak["synced_rainbow_smooth"].on = l["synced_rainbow_smooth"]
    bd(
        "100% Black",
        aj["vehicle_colors"],
        function()
            local bt = ped.get_vehicle_ped_is_using(M.ped())
            if bt ~= 0 then
                cb(bt, {0, 0, 0}, 0)
            else
                o("Get in a valid Vehicle!", 173)
            end
        end
    )
    ak["black_100"] =
        be(
        "100% Black",
        aj["vehicle_colors"],
        function(k)
            if k.on then
                c9(am)
                c9(al)
                c9(an)
                c9({"fade_black_red"})
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    cb(bt, {0, 0, 0}, 0)
                end
            end
            l["black_100"] = k.on
            return d.stop(k)
        end
    )
    ak["black_100"].on = l["black_100"]
    ak["fade_black_red"] =
        be(
        "Fade Black-Red",
        aj["vehicle_colors"],
        function(k)
            if k.on then
                c9(am)
                c9(al)
                c9(an)
                c9({"black_100"})
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    local eL
                    eL = math.floor((101 - ak["light_speed"].value_i / 25) / 2)
                    if eL < 1 then
                        eL = 1
                    end
                    for i = 0, 255, eL do
                        cb(bt, {i, 0, 0}, 0, 8)
                    end
                    eL = math.floor((101 - ak["light_speed"].value_i / 25) / 2)
                    if eL < 1 then
                        eL = 1
                    end
                    for i = 255, 0, -eL do
                        cb(bt, {i, 0, 0}, 0, 8)
                    end
                end
            end
            l["fade_black_red"] = k.on
            return d.stop(k)
        end
    )
    ak["fade_black_red"].on = l["fade_black_red"]
    ak["heli"] =
        bf(
        "Heli Blades Speed 0-100%",
        "value_i",
        aj["vehicle"],
        function(k)
            l["heli"] = k.on
            l["heli_i"] = ak["heli"].value_i
            local bt = ped.get_vehicle_ped_is_using(M.ped())
            if k.on then
                if bt ~= 0 then
                    H.ctrl(bt)
                    local dj = k.value_i / 100
                    vehicle.set_heli_blades_speed(bt, dj)
                end
            end
            return d.stop(k)
        end
    )
    ak["heli"].max_i = 100
    ak["heli"].min_i = 0
    ak["heli"].mod_i = 5
    ak["heli"].value_i = l["heli_i"]
    ak["heli"].on = l["heli"]
    ak["sel_boost_speed"] =
        bf(
        "Boost Vehicle",
        "value_i",
        aj["vehicle"],
        function(k)
            l["sel_boost_speed"] = k.on
            l["sel_boost_speed_speed"] = ak["sel_boost_speed"].value_i
            local bt = ped.get_vehicle_ped_is_using(M.ped())
            if k.on then
                if bt ~= 0 then
                    H.ctrl(bt)
                    entity.set_entity_max_speed(bt, ak["sel_boost_speed"].value_i)
                    vehicle.set_vehicle_forward_speed(bt, ak["sel_boost_speed"].value_i)
                end
            end
            if not k.on then
                entity.set_entity_max_speed(bt, 540)
            end
            return d.stop(k)
        end
    )
    ak["sel_boost_speed"].max_i = 50000
    ak["sel_boost_speed"].min_i = 0
    ak["sel_boost_speed"].mod_i = 50
    ak["sel_boost_speed"].value_i = l["sel_boost_speed_speed"]
    ak["sel_boost_speed"].on = l["sel_boost_speed"]
    ak["speedometer"] =
        bf(
        "License Plate Speedometer",
        "value_i",
        aj["vehicle"],
        function(k)
            l["speedometer"] = k.on
            l["speedometer_type"] = ak["speedometer"].value_i
            aA = ak["speedometer"].value_i
            if k.on then
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    if aA ~= aB then
                        o("Displaying Speed now with Unit:\n" .. ac[ak["speedometer"].value_i][3], 96)
                    end
                    local eM = entity.get_entity_speed(bt) * ac[ak["speedometer"].value_i][2]
                    if eM < 10 and eM > 0.01 then
                        eM = string.format("%.2f", eM)
                    elseif eM >= 10 and eM < 100 then
                        eM = string.format("%.1f", eM)
                    elseif eM < 0.01 and ak["speedometer"].value_i == 7 then
                        eM = string.format("%.5f", eM)
                    else
                        eM = math.floor(eM)
                    end
                    H.ctrl(bt)
                    vehicle.set_vehicle_number_plate_text(bt, tostring(eM) .. ac[ak["speedometer"].value_i][1])
                end
            end
            aB = ak["speedometer"].value_i
            return d.stop(k)
        end
    )
    ak["speedometer"].max_i = #ac
    ak["speedometer"].min_i = 1
    ak["speedometer"].value_i = l["speedometer_type"]
    ak["speedometer"].on = l["speedometer"]
    ak["veh_no_colision"] =
        be(
        "No collision",
        aj["vehicle"],
        function(k)
            if k.on then
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    local eN = ped.get_all_peds()
                    for i = 1, #eN do
                        entity.set_entity_no_collsion_entity(eN[i], bt, true)
                        entity.set_entity_no_collsion_entity(bt, eN[i], true)
                    end
                    eN = object.get_all_objects()
                    for i = 1, #eN do
                        entity.set_entity_no_collsion_entity(eN[i], bt, true)
                        entity.set_entity_no_collsion_entity(bt, eN[i], true)
                    end
                    eN = vehicle.get_all_vehicles()
                    for i = 1, #eN do
                        entity.set_entity_no_collsion_entity(eN[i], bt, true)
                        entity.set_entity_no_collsion_entity(bt, eN[i], true)
                    end
                end
            end
            l["veh_no_colision"] = k.on
            return d.stop(k)
        end
    )
    ak["veh_no_colision"].on = l["veh_no_colision"]
    ak["auto_repair"] =
        be(
        "Auto Repair Vehicle",
        aj["vehicle"],
        function(k)
            if k.on then
                local bt = ped.get_vehicle_ped_is_using(M.ped())
                if bt ~= 0 then
                    if vehicle.is_vehicle_damaged(bt) then
                        H.ctrl(bt)
                        vehicle.set_vehicle_fixed(bt)
                        vehicle.set_vehicle_deformation_fixed(bt)
                        vehicle.set_vehicle_engine_health(bt, 1000)
                        vehicle.set_vehicle_can_be_visibly_damaged(bt, false)
                    end
                end
            end
            l["auto_repair"] = k.on
            return d.stop(k)
        end
    )
    ak["auto_repair"].on = l["auto_repair"]
    ak["drive_on_ocean"] =
        be(
        "Drive / Walk on the Ocean",
        aj["misc"],
        function(k)
            if k.on then
                local bs = M.coords()
                if aK == nil then
                    H.model(1822550295)
                    aK = object.create_object(1822550295, v3(bs.x, bs.y, -4), true, false)
                    entity.set_entity_visible(aK, false)
                end
                water.set_waves_intensity(-100000000)
                bs.z = -4
                bl(aK, bs)
            end
            l["drive_on_ocean"] = k.on
            if not k.on and aK ~= nil then
                water.reset_waves_intensity()
                bn({aK})
                aK = nil
            end
            return d.stop(k)
        end
    )
    ak["drive_on_ocean"].on = l["drive_on_ocean"]
    ak["drive_this_height"] =
        be(
        "Drive / Walk this Height",
        aj["misc"],
        function(k)
            if k.on then
                local bs, bq
                if ped.is_ped_in_any_vehicle(M.ped()) then
                    local bt = ped.get_vehicle_ped_is_using(M.ped())
                    bs = c.gcoords(bt)
                    bq = 5.25
                else
                    bs = M.coords()
                    bq = 5.85
                end
                if aL == nil then
                    H.model(1822550295)
                    aM = bs.z - bq
                    aL = object.create_object(1822550295, v3(bs.x, bs.y, aM), true, false)
                    entity.set_entity_visible(aL, false)
                end
                water.set_waves_intensity(-100000000)
                bs.z = aM
                bl(aL, bs)
            end
            l["drive_this_height"] = k.on
            if not k.on and aL ~= nil then
                water.reset_waves_intensity()
                bn({aL})
                aL = nil
                aM = nil
            end
            return d.stop(k)
        end
    )
    ak["drive_this_height"].on = l["drive_this_height"]
    ak["weird_ent"] =
        be(
        "Weird Entity",
        aj["misc"],
        function(k)
            local bt = ped.get_vehicle_ped_is_using(M.ped())
            local dP = M.ped()
            if k.on then
                if bt ~= 0 and aN == nil then
                    local ci = entity.get_entity_model_hash(bt)
                    aN = vehicle.create_vehicle(ci, M.coords(), 0, true, false)
                    dP = bt
                elseif aN == nil then
                    aN = ped.clone_ped(M.ped())
                end
                entity.set_entity_visible(dP, false)
                entity.set_entity_collision(aN, false, false, false)
                entity.set_entity_rotation(aN, v3(c.random(-180, 180), c.random(-180, 180), c.random(-180, 180)))
                bl(aN, M.coords())
            end
            if not k.on then
                bn({aN})
                aN = nil
                entity.set_entity_visible(dP, true)
            end
            l["weird_ent"] = k.on
            return d.stop(k)
        end
    )
    ak["weird_ent"].on = l["weird_ent"]
    ak["real_time"] =
        be(
        "Real Time (Clientside)",
        aj["misc"],
        function(k)
            if k.on then
                local g = os.date("*t")
                time.set_clock_time(g.hour, g.min, g.sec)
                gameplay.clear_cloud_hat()
            end
            l["real_time"] = k.on
            return d.stop(k)
        end
    )
    ak["real_time"].on = l["real_time"]
    ak["random_clothes"] =
        be(
        "Random Clothes",
        aj["misc"],
        function(k)
            if k.on then
                c.wait(333)
                ped.set_ped_random_component_variation(M.ped())
            end
            l["random_clothes"] = k.on
            return d.stop(k)
        end
    )
    ak["random_clothes"].on = l["random_clothes"]
    ak["clear_area"] =
        be(
        "Gameplay Clear Area",
        aj["misc"],
        function(k)
            if k.on then
                local bs = M.coords()
                gameplay.clear_area_of_cops(bs, 10000, true)
                gameplay.clear_area_of_peds(bs, 10000, true)
                gameplay.clear_area_of_vehicles(bs, 10000, false, false, false, false, false)
                gameplay.clear_area_of_objects(bs, 10000, 0)
                gameplay.clear_area_of_objects(bs, 10000, 1)
                gameplay.clear_area_of_objects(bs, 10000, 2)
                gameplay.clear_area_of_objects(bs, 10000, 6)
                gameplay.clear_area_of_objects(bs, 10000, 16)
                gameplay.clear_area_of_objects(bs, 10000, 17)
            end
            l["clear_area"] = k.on
            return d.stop(k)
        end
    )
    ak["clear_area"].on = l["clear_area"]
    ak["clear_area_2"] =
        be(
        "Clear Area",
        aj["misc"],
        function(k)
            if k.on then
                local eO = ped.get_all_peds()
                for i = 1, #eO do
                    local eP = eO[i]
                    if not ped.is_ped_a_player(eP) and k.on then
                        H.ctrl(eP, 250)
                        entity.set_entity_velocity(eP, v3())
                        bl(eP, v3(8000, 8000, -1000))
                        entity.delete_entity(eP)
                    end
                end
                eO = object.get_all_objects()
                for i = 1, #eO do
                    local eP = eO[i]
                    if k.on then
                        H.ctrl(eP, 250)
                        entity.set_entity_velocity(eP, v3())
                        bl(eP, v3(8000, 8000, -1000))
                        entity.delete_entity(eP)
                        c.wait(0)
                    end
                end
                eO = vehicle.get_all_vehicles()
                local eQ = {}
                for E = 0, 31 do
                    if K.scid(E) ~= -1 then
                        local bt = ped.get_vehicle_ped_is_using(c.ped(E))
                        if bt ~= 0 then
                            eQ[#eQ + 1] = bt
                        end
                    end
                end
                for i = 1, #eO do
                    local eP = eO[i]
                    if k.on then
                        local ez = true
                        for cT = 1, #eQ do
                            if eP == eQ[cT] then
                                ez = false
                            end
                        end
                        if ez then
                            H.ctrl(eP, 250)
                            entity.set_entity_velocity(eP, v3())
                            bl(eP, v3(8000, 8000, -1000))
                            entity.delete_entity(eP)
                        end
                    end
                end
            end
            l["clear_area_2"] = k.on
            return d.stop(k)
        end
    )
    ak["clear_area_2"].on = l["clear_area_2"]
    ak["auto_tp_wp"] =
        be(
        "Auto Teleport to Waypoint",
        aj["misc"],
        function(k)
            if k.on then
                local dm = ui.get_waypoint_coord()
                if dm.x ~= 16000 then
                    local bs = M.coords()
                    local eR = v2()
                    eR.x = bs.x
                    eR.y = bs.y
                    if dm:magnitude(eR) > 35 then
                        o("Detected Waypoint, teleporting...", 172)
                        local eS = M.ped()
                        local eT = ped.get_vehicle_ped_is_using(eS)
                        if eT ~= 0 then
                            eS = eT
                        end
                        local eU = 850
                        local ew, eV = gameplay.get_ground_z(v3(dm.x, dm.y, eU))
                        while not ew do
                            eU = eU - 5
                            ew, eV = gameplay.get_ground_z(v3(dm.x, dm.y, eU))
                            if eU < -200 then
                                eU = -200
                                ew = true
                            end
                        end
                        bp(v3(dm.x, dm.y, eV))
                    end
                end
            end
            l["auto_tp_wp"] = k.on
            return d.stop(k)
        end
    )
    ak["auto_tp_wp"].on = l["auto_tp_wp"]
    ak["police_outfit"] =
        be(
        "Force Police Outfit",
        aj["misc"],
        function(k)
            if k.on then
                local K = "male"
                if player.is_player_female(c.id()) then
                    K = "female"
                end
                for i = 1, #a1[K]["clothes"] do
                    ped.set_ped_component_variation(M.ped(), i, a1[K]["clothes"][i][2], a1[K]["clothes"][i][1], 2)
                end
                for i = 1, #a1[K]["props"] do
                    ped.set_ped_prop_index(M.ped(), a1[K]["props"][i][1], a1[K]["props"][i][2], a1[K]["props"][i][3], 0)
                end
                c.wait(250)
            end
            l["police_outfit"] = k.on
            return d.stop(k)
        end
    )
    ak["police_outfit"].on = l["police_outfit"]
    ak["ban_screen"] =
        be(
        "You've Been Banned",
        aj["misc"],
        function(k)
            if k.on then
                local bs = v2()
                local bS = v2()
                local eW = v2()
                bs.x = 0.5
                bs.y = 0.325
                bS.x = 0.5
                bS.y = 0.5
                eW.x = 0.5
                eW.y = 0.54
                ui.set_text_scale(3.0)
                ui.set_text_font(7)
                ui.set_text_centre(0)
                ui.set_text_color(255, 206, 67, 255)
                ui.set_text_outline(true)
                ui.draw_text("alert", bs)
                ui.set_text_scale(0.5)
                ui.set_text_centre(0)
                ui.set_text_color(255, 255, 255, 255)
                ui.draw_text("You have been banned from Grand Theft Auto Online permanently", bS)
                ui.set_text_scale(0.5)
                ui.set_text_centre(0)
                ui.draw_text("Return to Grand Theft Auto V", eW)
                ui.draw_rect(.5, .5, 1, 1, 0, 0, 0, 255)
                ui.draw_rect(.5, .492, .52, .0019, 255, 255, 255, 255)
                ui.draw_rect(.5, .585, .52, .0019, 255, 255, 255, 255)
            end
            return d.stop(k)
        end
    )
    ak["swap_seats"] =
        bf(
        "Swap Vehicle Seat",
        "autoaction_value_i",
        aj["misc"],
        function()
            local eT = ped.get_vehicle_ped_is_using(M.ped())
            if eT ~= 0 then
                ped.set_ped_into_vehicle(M.ped(), eT, ak["swap_seats"].value_i)
            end
        end
    )
    ak["swap_seats"].min_i = -1
    ak["swap_seats"].value_i = -1
    ak["swap_seats"].max_i = 15
    bd(
        "Fill Snacks and Armor",
        aj["misc"],
        function()
            local eX = {
                {"NO_BOUGHT_YUM_SNACKS", 30},
                {"NO_BOUGHT_HEALTH_SNACKS", 15},
                {"NO_BOUGHT_EPIC_SNACKS", 5},
                {"NUMBER_OF_ORANGE_BOUGHT", 10},
                {"NUMBER_OF_BOURGE_BOUGHT", 10},
                {"NUMBER_OF_CHAMP_BOUGHT", 5},
                {"MP_CHAR_ARMOUR_1_COUNT", 10},
                {"MP_CHAR_ARMOUR_2_COUNT", 10},
                {"MP_CHAR_ARMOUR_3_COUNT", 10},
                {"MP_CHAR_ARMOUR_4_COUNT", 10},
                {"MP_CHAR_ARMOUR_5_COUNT", 10}
            }
            for i = 1, #eX do
                local ci = gameplay.get_hash_key("MP0_" .. eX[i][1])
                stats.stat_set_int(ci, eX[i][2], true)
                ci = gameplay.get_hash_key("MP1_" .. eX[i][1])
                stats.stat_set_int(ci, eX[i][2], true)
            end
        end
    )
    aj["player_history"] =
        b9(
        "Player History",
        aj["misc"],
        function(k)
            cI()
        end
    ).id
    aj["utils"] = b9("Utils", aj["misc"]).id
    aj["scripts"] =
        b9(
        "Load Scripts",
        aj["utils"],
        function()
            o("NOTHING TO SEE HERE!!! MAYBE COMING SOON", 208, "COMING SOON")
            local eY = os.getenv("APPDATA") .. "\\PopstarDevs\\2Take1Menu\\scripts\\"
            local b = utils.get_all_files_in_directory(eY, "lua")
            local eZ = aj["scripts"].children
            local e_ = d.file_name()
            for i = 1, #b do
                local db = true
                for E = 1, #eZ do
                    if eZ[E].name == b[i] then
                        db = false
                    end
                end
                if b[i] == e_ then
                    db = false
                end
                if db then
                    local f0
                    be(
                        b[i],
                        aj["scripts"].id,
                        function(k)
                            if k.on and not b5[b[i]] then
                                b5[b[i]] = {}
                                local f1, f2 = loadfile(eY .. b[i])
                                if f1 ~= nil then
                                else
                                    o("NO")
                                end
                            elseif not k.on and b5[b[i]] then
                                o("NOTHING TO SEE HERE!!! MAYBE COMING SOON", 208, "COMING SOON")
                            end
                        end
                    )
                end
            end
        end
    )
    ak["auto_load"] =
        be(
        "autoexec Scripts from folder 'autoload'",
        aj["utils"],
        function(k)
            l["auto_load"] = k.on
            if k.on then
                if utils.dir_exists(os.getenv("APPDATA") .. "\\PopstarDevs\\2Take1Menu\\scripts\\autoload") then
                    local b =
                        utils.get_all_files_in_directory(
                        os.getenv("APPDATA") .. "\\PopstarDevs\\2Take1Menu\\scripts\\autoload",
                        "lua"
                    )
                    if b ~= nil then
                        r("Found Scripts for autoexecuting!")
                        for i = 1, #b do
                            r(b[i])
                            local e_ = string.sub(b[i], 1, -5)
                            c.wait(5000)
                            if not require("\\autoload\\" .. e_) then
                                o("ERROR Loading Script " .. b[i] .. "!", 208)
                            else
                                o("Loaded Script " .. b[i] .. " succesfully!", 166)
                                r("Loaded Script " .. b[i] .. " succesfully!")
                            end
                        end
                    end
                else
                    o("No folder 'autoload' found, create a folder and place any script inside!", 174)
                end
            end
        end
    )
    ak["auto_load"].on = l["auto_load"]
    ak["leave_session"] =
        bd(
        "Leave-Session",
        aj["utils"],
        function()
            local time = c.time() + 8500
            while time > c.time() do
            end
        end
    )
    ak["crash_yourself"] =
        bd(
        "Crash Yourself",
        aj["utils"],
        function()
            c.exe("taskkill /F /IM GTA5.exe")
            while 1 do
            end
        end
    )
    be(
        "Auto-Hostkick-Yourself",
        aj["utils"],
        function(k)
            if k.on then
                if network.network_is_host() then
                    o("Hostkicking-Yourself!")
                    r("Hostkicking-Yourself!")
                    network.network_session_kick_player(c.id())
                end
            end
            return d.stop(k)
        end
    )
    bd(
        "Fuck You",
        aj["utils"],
        function()
            c.exe(
                "start https://steamuserimages-a.akamaihd.net/ugc/849342240392626653/882456A11C32E6548619159DCEE8BA0D1DDAEE35/?imw=1024&imh=1024&ima=fit&impolicy=Letterbox&imcolor=%23000000&letterbox=true"
            )
        end
    )
    aj["ipl_config"] =
        b9(
        "IPL-Loader",
        aj["misc"],
        function()
            if not utils.file_exists(b["IPLlist"]) then
                o("No IPL-List File found.")
                o(
                    "Download '2Take1IPLlist.txt' from #lua-script-share and place it in '2Take1Menu/scripts/2Take1Script/CustomFiles' folder."
                )
                aG["load_ipls"].hidden = true
                aG["range_start"].hidden = true
                aG["range_end"].hidden = true
                aG["remove_ipls"].hidden = true
            else
                aG["load_ipls"].hidden = false
                aG["range_start"].hidden = false
                aG["range_end"].hidden = false
                aG["remove_ipls"].hidden = false
            end
        end
    ).id
    aG["load_ipls"] =
        bd(
        "Load ALL IPLs from File",
        aj["ipl_config"],
        function()
            for f3 in io.lines(b["IPLlist"]) do
                streaming.request_ipl(f3)
            end
        end
    )
    aG["range_start"] =
        bf(
        "Select starting line for range",
        "action_value_i",
        aj["ipl_config"],
        function(k)
        end
    )
    aG["range_start"].max_i = 8550
    aG["range_start"].mod_i = 50
    aG["range_end"] =
        bf(
        "Select ending line for range",
        "action_value_i",
        aj["ipl_config"],
        function(k)
        end
    )
    aG["range_end"].max_i = 8550
    aG["range_end"].mod_i = 50
    aG["remove_ipls"] =
        bd(
        "Remove ALL IPLs between selected Range",
        aj["ipl_config"],
        function()
            local bG = 0
            local f4 = aG["range_start"].value_i
            for f3 in io.lines(b["IPLlist"]) do
                if bG == f4 then
                    f4 = f4 + 1
                    if f4 <= aG["range_end"].value_i then
                        streaming.remove_ipl(f3)
                    end
                end
                bG = bG + 1
            end
        end
    )
    aj["debug"] = b9("Dev Tools", aj["misc"]).id
    bd(
        "Delete Entity from Aim",
        aj["debug"],
        function()
            bn({player.get_entity_player_is_aiming_at(c.id())})
        end
    )
    bd(
        "Get input Hash Key",
        aj["debug"],
        function()
            local ci
            local I, f5 = input.get("Enter Name(PED, OBJECT, etc)", "", 64, 0)
            while I == 1 do
                c.wait(0)
                I, f5 = input.get("Enter Name(PED, OBJECT, etc)", "", 64, 0)
            end
            if I == 2 then
                return HANDLER_POP
            end
            r("")
            r("******************************")
            r("String: " .. f5)
            ci = tostring(gameplay.get_hash_key(f5))
            r("Hash: " .. ci)
            o(string.format("%s %s", f5, ci))
        end
    )
    bd(
        "Notify & Print String from file",
        aj["debug"],
        function()
            local f6 = "slod_small_quadped"
            local f7 = gameplay.get_hash_key(f6)
            r("")
            r("******************************")
            r("String: " .. f6)
            r("Hash: " .. f7)
            o("String: " .. f6)
            o("Hash: " .. f7)
        end
    )
    ak["print_info_from_entity"] =
        bd(
        "Print Info from Entity @Aim to file",
        aj["debug"],
        function()
            local dz = player.get_entity_player_is_aiming_at(c.id())
            local f8, bs, c_
            if dz ~= 0 then
                while dz ~= 0 do
                    f8 = entity.get_entity_model_hash(dz)
                    bs = entity.get_entity_coords(dz)
                    c_ = entity.get_entity_rotation(dz)
                    r("")
                    r("Printing infos about Entity:")
                    r("******************************")
                    r("Hash: " .. f8)
                    r("Entity Type: " .. entity.get_entity_type(dz))
                    r("Entity: " .. dz)
                    r("Coords X: " .. bs.x)
                    r("Coords Y: " .. bs.y)
                    r("Coords Z: " .. bs.z)
                    r("Rot X: " .. c_.x)
                    r("Rot Y: " .. c_.y)
                    r("Rot Z: " .. c_.z)
                    r("Heading: " .. entity.get_entity_heading(dz))
                    r("Entity population_type: " .. entity.get_entity_population_type(dz))
                    if entity.is_entity_static(dz) then
                        r("Entity is static")
                    end
                    if entity.does_entity_have_drawable(dz) then
                        r("Entity has a drawable")
                    end
                    if entity.is_entity_in_water(dz) then
                        r("Entity is in water")
                    end
                    if entity.is_entity_a_ped(dz) then
                        r("Entity is a PED")
                    elseif entity.is_entity_a_vehicle(dz) then
                        r("Entity is a VEHICLE")
                    elseif entity.is_entity_an_object(dz) then
                        r("Entity is a OBJECT")
                    end
                    if entity.is_entity_dead(dz) then
                        r("Entity is DEAD")
                    end
                    if entity.is_entity_on_fire(dz) then
                        r("Entity is ON FIRE")
                    end
                    if entity.is_entity_visible(dz) then
                        r("Entity is VISIBLE")
                    else
                        r("Entity is INvisible")
                    end
                    if entity.is_entity_attached(dz) then
                        dz = entity.get_entity_attached_to(dz)
                        r("")
                        r("Attached Entity found. Continue printing infos of Entity.")
                        r("Attached Entity Info:")
                    else
                        dz = 0
                        r("")
                        r("")
                        r("")
                    end
                end
                o("Printed Info about Entity to file.")
            else
                o("Nothing found for Info-Printing.")
            end
        end
    )
    bd(
        "Clear 2Take1Script.log",
        aj["debug"],
        function()
            local f9 = c.o(b["Log_file"], "w")
            io.close(f9)
            o("Cleared 2Take1Script.log", 204)
            r("Cleared 2Take1Script.log")
        end
    )
    bd(
        "Clear Menu Log-Files",
        aj["debug"],
        function()
            local f9 = c.o(b["Auth"], "w")
            io.close(f9)
            o("Cleared PopstarAuth.log", 204)
            r("Cleared PopstarAuth.log")
            f9 = c.o(b["Menu_log"], "w")
            io.close(f9)
            o("Cleared 2Take1Menu.log", 204)
            r("Cleared 2Take1Menu.log")
            f9 = c.o(b["Prep"], "w")
            io.close(f9)
            o("Cleared 2Take1Prep.log", 204)
            r("Cleared 2Take1Prep.log")
        end
    )
    bd(
        "Clear crashdumps",
        aj["debug"],
        function()
            local fa = utils.get_all_files_in_directory(a["dumps"], "dump")
            if fa[1] ~= nil then
                o("Found dumps, deleting...", 204)
                for i = 1, #fa do
                    os.remove(a["dumps"] .. "\\" .. fa[i])
                end
                o("Cleared crashdumps.", 204)
                r("Cleared crashdumps.")
            else
                o("No dumps found.", 204)
            end
        end
    )
    ak["log_modder_flags"] =
        be(
        "Log Modder Flags",
        aj["debug"],
        function(k)
            if k.on then
                local time = c.time() + 2500
                while time > c.time() do
                    c.wait(250)
                    l["log_modder_flags"] = k.on
                end
                for i = 0, 31 do
                    if c.valid(i) then
                        for E = 1, #u do
                            if player.is_player_modder(i, u[E]) then
                                local cU = u[E]
                                local f = player.get_modder_flag_text(cU)
                                if b3[K.scid(i)] then
                                    if not b3[K.scid(i)][cU] then
                                        b3[K.scid(i)][cU] = true
                                        r(K.scid(i) .. ":" .. K.name(i) .. " is a Modder with Tag: " .. f)
                                    end
                                else
                                    b3[K.scid(i)] = {}
                                end
                            end
                        end
                    end
                end
            end
            l["log_modder_flags"] = k.on
            return d.stop(k)
        end
    )
    ak["log_modder_flags"].on = l["log_modder_flags"]
    ak["logger"] =
        be(
        "Enable Log from this Lua-Script",
        aj["debug"],
        function(k)
            l["logger"] = k.on
        end
    )
    ak["logger"].on = l["logger"]
    aj["bodyguards"] = b9("Bodyguards", aj["parent"])
    aj["bodyguards"].hidden = l["bodyguards_hidden"]
    aj["bodyguards"] = aj["bodyguards"].id
    ak["bodyguards_god"] =
        be(
        "Godmode for Bodyguards",
        aj["bodyguards"],
        function(k)
            l["bodyguards_god"] = k.on
        end
    )
    ak["bodyguards_god"].on = l["bodyguards_god"]
    ak["bodyguards_health"] =
        bf(
        "Set Health of Bodyguards",
        "autoaction_value_i",
        aj["bodyguards"],
        function(k)
            o("Bodyguards Health set to: " .. k.value_i)
            l["bodyguards_health"] = k.value_i
        end
    )
    ak["bodyguards_health"].min_i = 5000
    ak["bodyguards_health"].max_i = 50000
    ak["bodyguards_health"].mod_i = 5000
    ak["bodyguards_health"].value_i = l["bodyguards_health"]
    ak["bodyguards_equip_weapon"] =
        be(
        "Equip Bodyguards with MG",
        aj["bodyguards"],
        function(k)
            l["bodyguards_equip_weapon"] = k.on
        end
    )
    ak["bodyguards_equip_weapon"].on = l["bodyguards_equip_weapon"]
    ak["bodyguards_formation"] =
        bf(
        "Set Formation",
        "autoaction_value_i",
        aj["bodyguards"],
        function(k)
            l["bodyguards_formation_type"] = k.value_i
        end
    )
    ak["bodyguards_formation"].min_i = 0
    ak["bodyguards_formation"].max_i = 3
    ak["bodyguards_formation"].value_i = l["bodyguards_formation_type"]
    ak["bodyguards"] =
        be(
        "Enable Bodyguards",
        aj["bodyguards"],
        function(k)
            if k.on then
                local fb = player.get_player_group(c.id())
                local ci = 0x613E626C
                for i = 1, 7 do
                    if a0["bodyguards"][i] == nil or entity.is_entity_dead(a0["bodyguards"][i]) then
                        if a0["bodyguards"][i] ~= nil and entity.is_entity_dead(a0["bodyguards"][i]) then
                            bn({a0["bodyguards"][i]})
                        end
                        H.model(ci)
                        a0["bodyguards"][i] = ped.create_ped(29, ci, c1(M.coords(), M.heading(), 4), 0, true, false)
                        c.unload(ci)
                        if ak["bodyguards_god"].on then
                            entity.set_entity_god_mode(a0["bodyguards"][i], true)
                        else
                            ped.set_ped_max_health(a0["bodyguards"][i], ak["bodyguards_health"].value_i)
                            ped.set_ped_health(a0["bodyguards"][i], ak["bodyguards_health"].value_i)
                        end
                        local fc = ui.add_blip_for_entity(a0["bodyguards"][i])
                        ui.set_blip_sprite(fc, 310)
                        ui.set_blip_colour(fc, 80)
                        if ak["bodyguards_equip_weapon"].on then
                            weapon.give_delayed_weapon_to.ped(a0["bodyguards"][i], 0x22D8FE39, 0, 1)
                            weapon.give_delayed_weapon_to.ped(a0["bodyguards"][i], 0xDBBD7280, 0, 1)
                        end
                        ped.set_ped_combat_ability(a0["bodyguards"][i], 100)
                        ped.set_ped_as_group_member(a0["bodyguards"][i], fb)
                        entity.set_entity_as_mission_entity(a0["bodyguards"][i], 1, 1)
                    end
                    if not entity.is_entity_dead(a0["bodyguards"][i]) then
                        H.ctrl(a0["bodyguards"][i])
                        ped.set_group_formation(fb, ak["bodyguards_formation"].value_i)
                        if player.is_player_free_aiming(c.id()) then
                            local cd = player.get_entity_player_is_aiming_at(c.id())
                            if cd ~= 0 then
                                ai.task_shoot_at_entity(a0["bodyguards"][i], cd, 100, 0xC6EE6B4C)
                            else
                                local bs = M.coords()
                                local dL = cam.get_gameplay_cam_rot()
                                dL:transformRotToDir()
                                dL = dL * c.random(1, 50)
                                bs = bs + dL
                                ai.task_shoot_gun_at_coord(a0["bodyguards"][i], bs, 100, 0xC6EE6B4C)
                            end
                        end
                        if M.coords():magnitude(c.gcoords(a0["bodyguards"][i])) > 50 then
                            bl(a0["bodyguards"][i], c1(M.coords(), M.heading(), -5))
                        end
                    end
                end
            end
            if not k.on then
                bn(a0["bodyguards"])
                a0["bodyguards"] = {}
            end
            return d.stop(k)
        end
    )
    aj["aim_protection"] = b9("Aim Protection", aj["parent"]).id
    ak["enable_aim_prot"] =
        be(
        "Enable Aim Protection",
        aj["aim_protection"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    if N.i(i) then
                        local cd = player.get_entity_player_is_aiming_at(i)
                        if cd ~= 0 then
                            if cd == M.ped() then
                                o(K.name(i) .. " is aiming at you!", 173)
                                local cg = M.ped()
                                if l["anonymous_punishment"] then
                                    cg = c.ped(i)
                                end
                                if l["aim_prot_ragdoll"] then
                                    o("Ragdolling " .. K.name(i) .. "!", 173)
                                    r("Ragdolling " .. K.name(i) .. "!")
                                    fire.add_explosion(c.gcoords(c.ped(i)), 70, true, false, 1, cg)
                                    c.wait(75)
                                end
                                if l["aim_prot_fire"] then
                                    o("Setting " .. K.name(i) .. " on fire!", 173)
                                    r("Setting " .. K.name(i) .. " on fire!")
                                    fire.add_explosion(c.gcoords(c.ped(i)), 3, true, false, 0, cg)
                                    c.wait(75)
                                end
                                if l["aim_prot_kill"] then
                                    o("Killing " .. K.name(i) .. "!", 173)
                                    r("Killing " .. K.name(i) .. "!")
                                    fire.add_explosion(c.gcoords(c.ped(i)), 8, false, true, 0, cg)
                                    c.wait(75)
                                end
                                if l["aim_prot_remove_weapon"] then
                                    o("Removing Weapon from " .. K.name(i) .. "!", 173)
                                    r("Removing Weapon from " .. K.name(i) .. "!")
                                    ped.set_ped_can_switch_weapons(c.ped(i), false)
                                    weapon.remove_weapon_from_ped(c.ped(i), ped.get_current_ped_weapon(c.ped(i)))
                                    ped.set_ped_can_switch_weapons(c.ped(i), false)
                                    c.wait(75)
                                end
                                if l["aim_prot_kick"] then
                                    bJ(false, i)
                                end
                            end
                        end
                    end
                end
            end
            l["enable_aim_prot"] = k.on
            return d.stop(k)
        end
    )
    ak["enable_aim_prot"].on = l["enable_aim_prot"]
    ak["anonymous_punishment"] =
        be(
        "Anonymous Punishment",
        aj["aim_protection"],
        function(k)
            l["anonymous_punishment"] = k.on
        end
    )
    ak["anonymous_punishment"].on = l["anonymous_punishment"]
    ak["aim_prot_ragdoll"] =
        be(
        "Ragdoll Player",
        aj["aim_protection"],
        function(k)
            l["aim_prot_ragdoll"] = k.on
        end
    )
    ak["aim_prot_ragdoll"].on = l["aim_prot_ragdoll"]
    ak["aim_prot_fire"] =
        be(
        "Set on Fire",
        aj["aim_protection"],
        function(k)
            l["aim_prot_fire"] = k.on
        end
    )
    ak["aim_prot_fire"].on = l["aim_prot_fire"]
    ak["aim_prot_kill"] =
        be(
        "Kill Player",
        aj["aim_protection"],
        function(k)
            l["aim_prot_kill"] = k.on
        end
    )
    ak["aim_prot_kill"].on = l["aim_prot_kill"]
    ak["aim_prot_remove_weapon"] =
        be(
        "Remove Current Weapon",
        aj["aim_protection"],
        function(k)
            l["aim_prot_remove_weapon"] = k.on
        end
    )
    ak["aim_prot_remove_weapon"].on = l["aim_prot_remove_weapon"]
    ak["aim_prot_kick"] =
        be(
        "Kick Player",
        aj["aim_protection"],
        function(k)
            l["aim_prot_kick"] = k.on
        end
    )
    ak["aim_prot_kick"].on = l["aim_prot_kick"]
    aj["opt"] = b9("Options", aj["parent"])
    aj["opt"].hidden = l["options_hidden"]
    aj["opt"] = aj["opt"].id
    aj["hotkeys"] = b9("Hotkey Settings", aj["opt"]).id
    ak["enable_hotkeys"] =
        be(
        "Enable Hotkeys",
        aj["hotkeys"],
        function(k)
            l["enable_hotkeys"] = k.on
            if k.on then
                if not utils.file_exists(b["Hotkeys"]) then
                    local fd = c.o(b["Hotkeys"], "w")
                    io.output(fd)
                    io.write("version=" .. l["version"] .. "\n")
                    for i = 1, #m[0] do
                        io.write(m[0][i] .. "=" .. tostring(m[m[0][i]]) .. "\n")
                    end
                    io.write("################################\n")
                    io.write(
                        "#There are more valid Keys, but i wont list them. Currently its not supported to push 2 Keys for 1 Hotkey.\n"
                    )
                    io.write("#Example valid Hotkeys:\n")
                    io.write("#F1-F12\n")
                    io.write("#A-Z\n")
                    io.write("#LCONTROL\n")
                    io.write("#RSHIFT\n")
                    io.write("#Insert\n")
                    io.write("#Down\n")
                    io.write("#PageDown\n")
                    io.close(fd)
                    o(
                        "Created 2Take1Hotkeys.ini file in folder '2Take1Script/Config'. Edit Hotkeys and reload Hotkeys.ini file.",
                        86
                    )
                end
                for i = 1, #m[0] do
                    local fe = m[0][i]
                    local ff = m[fe]
                    if ff ~= "none" then
                        local G = MenuKey()
                        G:push_str(ff)
                        if G:is_down() then
                            local cV = ak[fe]
                            local fg = cV.name
                            r(ff .. ":'" .. fg .. "' got pressed.")
                            if l["hotkey_notification"] then
                                o(ff .. ":'" .. fg .. "' got pressed.", 86)
                            end
                            if cV.type == 512 then
                                cV.on = true
                                c.wait(100)
                                cV.on = false
                            else
                                if cV.on then
                                    cV.on = false
                                else
                                    cV.on = true
                                end
                            end
                            c.wait(250)
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    ak["enable_hotkeys"].on = l["enable_hotkeys"]
    bd(
        "Reload 2Take1Hotkeys.ini",
        aj["hotkeys"],
        function()
            w.hotkeys()
            o("Reloaded Hotkeys.ini", 86)
        end
    )
    ak["hotkey_notification"] =
        be(
        "Hotkey Notifications",
        aj["hotkeys"],
        function(k)
            l["hotkey_notification"] = k.on
        end
    )
    ak["hotkey_notification"].on = l["hotkey_notification"]
    bd(
        "Print active Hotkeys",
        aj["hotkeys"],
        function()
            for i = 1, #m[0] do
                local G = m[0][i]
                if m[G] ~= "none" then
                    o(m[G] .. ': "' .. ak[G].name .. '"', 86)
                end
            end
        end
    )
    aj["mwh"] = b9("Menu-Wide-Hotkeys", aj["opt"]).id
    local fh = {}
    local fi = {}
    local fj = {}
    local fk = c.o(b["Exclude"], "r")
    if fk ~= nil then
        for fl in io.lines(b["Exclude"]) do
            if string.find(fl, ";", 1) == nil then
                fj[#fj + 1] = fl
            end
        end
        io.close(fk)
    end
    ak["mwh_notify"] =
        be(
        "Menu-Wide Hotkey Notifications",
        aj["mwh"],
        function(k)
            if k.on then
                if #fh == 0 then
                    local F = c.o(a["Menu"] .. "\\2Take1Menu.ini", "r")
                    if F ~= nil then
                        local i = 1
                        for fl in io.lines(a["Menu"] .. "\\2Take1Menu.ini") do
                            if i > 1 and i < 50 then
                                local C = ""
                                while string.find(fl, "=", 1) ~= nil do
                                    C = C .. string.sub(fl, 1, 1)
                                    fl = string.sub(fl, 2)
                                end
                                C = string.sub(C, 1, #C - 1)
                                if string.find(fl, "NOMOD+", 1) ~= nil then
                                    fl = string.gsub(fl, "NOMOD*+", "")
                                end
                                fh[i - 1] = fl
                                fi[i - 1] = C
                            end
                            i = i + 1
                        end
                        io.close(F)
                    end
                end
                for i = 1, #fh do
                    local ff = fh[i]
                    local fm = fi[i]
                    local P = ff ~= "none"
                    local fn = true
                    if l["mwh_exclude_navigation"] then
                        if string.find(fm, "Menu", 1) ~= nil then
                            fn = false
                        end
                    end
                    if l["mwh_exclude_noclip"] then
                        if string.find(fm, "NoClip", 1) ~= nil then
                            fn = false
                        end
                    end
                    if l["mwh_exclude_editorrot"] then
                        if string.find(fm, "EditorRot", 1) ~= nil then
                            fn = false
                        end
                    end
                    if l["mwh_exclude_file"] then
                        for E = 1, #fj do
                            if string.find(fm, fj[E], 1) ~= nil then
                                fn = false
                            end
                        end
                    end
                    if P and fn then
                        local G = MenuKey()
                        G:push_str(ff)
                        if G:is_down() then
                            o(ff .. ":'" .. fm .. "' got pressed.", 86)
                            c.wait(250)
                        end
                    end
                end
            end
            l["mwh_notify"] = k.on
            return d.stop(k)
        end
    )
    ak["mwh_notify"].on = l["mwh_notify"]
    ak["mwh_exclude_navigation"] =
        be(
        "Exclude Navigation Keys",
        aj["mwh"],
        function(k)
            l["mwh_exclude_navigation"] = k.on
        end
    )
    ak["mwh_exclude_navigation"].on = l["mwh_exclude_navigation"]
    ak["mwh_exclude_noclip"] =
        be(
        "Exclude NoClip Keys",
        aj["mwh"],
        function(k)
            l["mwh_exclude_noclip"] = k.on
        end
    )
    ak["mwh_exclude_noclip"].on = l["mwh_exclude_noclip"]
    ak["mwh_exclude_editorrot"] =
        be(
        "Exclude EditorRotation Keys",
        aj["mwh"],
        function(k)
            l["mwh_exclude_editorrot"] = k.on
        end
    )
    ak["mwh_exclude_editorrot"].on = l["mwh_exclude_editorrot"]
    ak["mwh_exclude_file"] =
        be(
        "Exclude Keys from File",
        aj["mwh"],
        function(k)
            if not utils.file_exists(b["Exclude"]) then
                local f9 = c.o(b["Exclude"], "a")
                io.output(f9)
                io.write(";Write down each Hotkey from 2Take1Menu.ini file which should not get a notify.\n")
                io.write(';Example, the "Exit" Hotkey should not get a notify, then just add it here.\n')
                io.write(";Each excluded hotkey gets a single line:\n")
                io.write("Exit")
                io.close(f9)
                o(
                    "Edit '2Take1Exclude.ini' to exclude specific hotkeys. The file is found in '2Take1Script/Config'",
                    86
                )
            end
            l["mwh_exclude_file"] = k.on
        end
    )
    ak["mwh_exclude_file"].on = l["mwh_exclude_file"]
    bd(
        "Reload 2Take1Exclude.ini",
        aj["mwh"],
        function()
            local fk = c.o(b["Exclude"], "r")
            if fk ~= nil then
                fj = {}
                for fl in io.lines(b["Exclude"]) do
                    if string.find(fl, ";", 1) == nil then
                        fj[#fj + 1] = fl
                    end
                end
                io.close(fk)
                o("Reloaded Exclude Hotkeys.", 86)
            end
        end
    )
    ak["exclude_friends"] =
        be(
        "Exclude Friends from Harmful Lobby Events",
        aj["opt"],
        function(k)
            l["exclude_friends"] = k.on
        end
    )
    ak["exclude_friends"].on = l["exclude_friends"]
    ak["attach_no_colision"] =
        be(
        "Attached Entitys No Collision",
        aj["opt"],
        function(k)
            l["attach_no_colision"] = k.on
        end
    )
    ak["attach_no_colision"].on = l["attach_no_colision"]
    ak["continuously_assassins"] =
        be(
        "Continuously Assassin Peds",
        aj["opt"],
        function(k)
            l["continuously_assassins"] = k.on
            if k.on and #a0["peds"] > 0 then
                if K.scid(aF) ~= -1 then
                    local cd = c.ped(aF)
                    for i = 1, #a0["peds"] do
                        ai.task_goto_entity(a0["peds"][i], cd, 10, 500, 500)
                        ai.task_combat_ped(a0["peds"][i], cd, 0, 16)
                    end
                end
            end
            return d.stop(k)
        end
    )
    ak["continuously_assassins"].on = l["continuously_assassins"]
    ak["disable_history"] =
        be(
        "Disable Player-History",
        aj["opt"],
        function(k)
            l["disable_history"] = k.on
        end
    )
    ak["override_notify_color"] =
        bf(
        "Force Notification Color",
        "value_i",
        aj["opt"],
        function(k)
            l["override_notify_color"] = k.on
            l["notify_color"] = k.value_i
        end
    )
    ak["override_notify_color"].max_i = 223
    ak["override_notify_color"].on = l["override_notify_color"]
    ak["override_notify_color"].value_i = l["notify_color"]
    bd(
        "Show Notification Color",
        aj["opt"],
        function()
            o("Example Text\nNotification color: " .. l["notify_color"])
        end
    )
    ak["2t1s_parent"] =
        be(
        "2Take1Script Parent",
        aj["opt"],
        function(k)
            l["2t1s_parent"] = k.on
        end
    )
    ak["2t1s_parent"].on = l["2t1s_parent"]
    ak["save_config"] =
        bd(
        "Save Configuration",
        aj["opt"],
        function()
            local F = c.o(b["Config"], "w+")
            io.output(F)
            for i = 1, #l[0] do
                local C = l[0][i]
                if string.find(C, "section", 1) == nil then
                    io.write(C .. "=" .. tostring(l[C]) .. "\n")
                else
                    io.write(tostring(l[C]) .. "\n")
                end
            end
            io.close(F)
            r("Saved Configuration to file.")
            o("Saved Configuration to file.", 25)
        end
    )
    r("")
    r("")
    r("Loaded 2Take1Script successfully. :)")
    r("")
    o("2Take1Script successfully loaded. :)", 210)
    _2t1s = true
end
d6()
