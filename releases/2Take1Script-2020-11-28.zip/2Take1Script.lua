local a = {}
a["PDevs"] = utils.get_appdata_path("PopstarDevs", "")
a["Menu"] = a["PDevs"] .. "\\2Take1Menu"
a["dumps"] = a["Menu"] .. "\\crashdump"
a["outfits"] = a["Menu"] .. "\\moddedOutfits"
a["vehicles"] = a["Menu"] .. "\\moddedVehicles"
a["scripts"] = a["Menu"] .. "\\scripts"
a["autoload"] = a["scripts"] .. "\\autoload"
a["2T1S"] = a["scripts"] .. "\\2Take1Script"
a["Config"] = a["2T1S"] .. "\\Config"
a["CustomFiles"] = a["2T1S"] .. "\\CustomFiles"
a["Event-Logger"] = a["2T1S"] .. "\\Event-Logger"
a["TEMP"] = "C:\\TEMP"
local b = {
    ["Auth"] = a["PDevs"] .. "\\PopstarAuth.log",
    ["Menu_log"] = a["Menu"] .. "\\2Take1Menu.log",
    ["Prep"] = a["Menu"] .. "\\2Take1Prep.log",
    ["Admin"] = a["scripts"] .. "\\2Take1Script-Admin.lua",
    ["Log_file"] = a["2T1S"] .. "\\2Take1Script.log",
    ["EXT_file"] = a["CustomFiles"] .. "\\2Take1ScriptEXT.lua",
    ["Blacklist"] = a["CustomFiles"] .. "\\2Take1Blacklist.cfg",
    ["Modders"] = a["CustomFiles"] .. "\\2Take1Modders.cfg",
    ["IPLlist"] = a["CustomFiles"] .. "\\2Take1IPLlist.txt",
    ["data"] = a["Config"] .. "\\offsets.data",
    ["Config"] = a["Config"] .. "\\2Take1Script.ini",
    ["Hotkeys"] = a["Config"] .. "\\2Take1Hotkeys.ini",
    ["Exclude"] = a["Config"] .. "\\2Take1Exclude.ini",
    ["vbs"] = a["TEMP"] .. "\\XX2T1SXX.vbs"
}
local c = {}
c.o = io.open
c.no = tonumber
c.exe = os.execute
c.wait = system.wait
c.time = utils.time_ms
c.random = math.random
c.id = player.player_id
c.d_exists = utils.dir_exists
c.ped = player.get_player_ped
c.f_exists = utils.file_exists
c.explode = fire.add_explosion
c.valid = player.is_player_valid
c.god = entity.set_entity_god_mode
c.gcoords = entity.get_entity_coords
c.visible = entity.set_entity_visible
c.script = script.trigger_script_event
c.navigate = menu.set_menu_can_navigate
c.vehicle = ped.get_vehicle_ped_is_using
c.attach = entity.attach_entity_to_entity
c.unload = streaming.set_model_as_no_longer_needed
local d = {}
d.write = function(e, f)
    if e ~= nil then
        io.output(e)
        io.write(f .. "\n")
        io.close(e)
    end
end
d.time_prefix = function()
    local g = os.date("*t")
    if g.month < 10 then
        g.month = "0" .. g.month
    end
    if g.day < 10 then
        g.day = "0" .. g.day
    end
    if g.hour < 10 then
        g.hour = "0" .. g.hour
    end
    if g.min < 10 then
        g.min = "0" .. g.min
    end
    if g.sec < 10 then
        g.sec = "0" .. g.sec
    end
    return "[" .. g.year .. "-" .. g.month .. "-" .. g.day .. " " .. g.hour .. ":" .. g.min .. ":" .. g.sec .. "]"
end
d.file_name = function()
    local h = debug.getinfo(2, "S")
    local j = h.source:sub(2) or h
    j = j:sub(#j - string.find(string.reverse(j), "\\", 1) + 2)
    return j
end
d.stop = function(k)
    if k.on then
        return 0
    end
    return 1
end
local l = {}
l[0] = {}
l[0][#l[0] + 1] = "section_1"
l["section_1"] = "[Main-Settings]"
l[0][#l[0] + 1] = "version"
l["version"] = 18
l[0][#l[0] + 1] = "2t1s_parent"
l["2t1s_parent"] = true
l[0][#l[0] + 1] = "exclude_friends"
l["exclude_friends"] = true
l[0][#l[0] + 1] = "logger"
l["logger"] = true
l[0][#l[0] + 1] = "load_admin"
l["load_admin"] = true
l[0][#l[0] + 1] = "section_2"
l["section_2"] = "[Blacklist]"
l[0][#l[0] + 1] = "bl_hidden"
l["bl_hidden"] = false
l[0][#l[0] + 1] = "blacklist_enabled"
l["blacklist_enabled"] = false
l[0][#l[0] + 1] = "auto_kick"
l["auto_kick"] = false
l[0][#l[0] + 1] = "mark_modder"
l["mark_modder"] = false
l[0][#l[0] + 1] = "admin_enabled"
l["admin_enabled"] = false
l[0][#l[0] + 1] = "kick_joining"
l["kick_joining"] = false
l[0][#l[0] + 1] = "section_3"
l["section_3"] = "[Modders]"
l[0][#l[0] + 1] = "modder_hidden"
l["modder_hidden"] = false
l[0][#l[0] + 1] = "remember_modder"
l["remember_modder"] = false
l[0][#l[0] + 1] = "unmark_friends"
l["unmark_friends"] = true
l[0][#l[0] + 1] = "speed_bypass"
l["speed_bypass"] = false
l[0][#l[0] + 1] = "name_bypass"
l["name_bypass"] = false
l[0][#l[0] + 1] = "modded_scid"
l["modded_scid"] = false
l[0][#l[0] + 1] = "modded_net_events"
l["modded_net_events"] = false
l[0][#l[0] + 1] = "modder_force_sh"
l["modder_force_sh"] = false
l[0][#l[0] + 1] = "modded_script_event"
l["modded_script_event"] = false
l[0][#l[0] + 1] = "section_4"
l["section_4"] = "[Lobby]"
l[0][#l[0] + 1] = "lobby_hidden"
l["lobby_hidden"] = false
l[0][#l[0] + 1] = "teleport_to_block"
l["teleport_to_block"] = false
l[0][#l[0] + 1] = "explode_lobby"
l["explode_lobby"] = false
l[0][#l[0] + 1] = "explode_lobby_value"
l["explode_lobby_value"] = 8
l[0][#l[0] + 1] = "explode_lobby_shake"
l["explode_lobby_shake"] = false
l[0][#l[0] + 1] = "sound_rape"
l["sound_rape"] = false
l[0][#l[0] + 1] = "kill_all_peds"
l["kill_all_peds"] = false
l[0][#l[0] + 1] = "disablecontrol"
l["disablecontrol"] = false
l[0][#l[0] + 1] = "bounty_after_death"
l["bounty_after_death"] = false
l[0][#l[0] + 1] = "bounty_after_death_value"
l["bounty_after_death_value"] = 0
l[0][#l[0] + 1] = "anonymous_bounty"
l["anonymous_bounty"] = false
l[0][#l[0] + 1] = "sms_spam"
l["sms_spam"] = false
l[0][#l[0] + 1] = "sms_spam_value"
l["sms_spam_value"] = 25
l[0][#l[0] + 1] = "karma_se"
l["karma_se"] = false
l[0][#l[0] + 1] = "punish_aliens"
l["punish_aliens"] = false
l[0][#l[0] + 1] = "force_host"
l["force_host"] = false
l[0][#l[0] + 1] = "modify_veh_speed"
l["modify_veh_speed"] = 0
l[0][#l[0] + 1] = "modify_veh_speed_include"
l["modify_veh_speed_include"] = false
l[0][#l[0] + 1] = "modify_veh_speed_overwrite"
l["modify_veh_speed_overwrite"] = false
l[0][#l[0] + 1] = "section_5"
l["section_5"] = "[Vehicle-Blacklist]"
l[0][#l[0] + 1] = "veh_blacklist"
l["veh_blacklist"] = false
l[0][#l[0] + 1] = "Oppressor"
l["Oppressor"] = false
l[0][#l[0] + 1] = "MK2_Oppressor"
l["MK2_Oppressor"] = false
l[0][#l[0] + 1] = "Lazer"
l["Lazer"] = false
l[0][#l[0] + 1] = "Hydra"
l["Hydra"] = false
l[0][#l[0] + 1] = "Deluxo"
l["Deluxo"] = false
l[0][#l[0] + 1] = "Akula"
l["Akula"] = false
l[0][#l[0] + 1] = "B_11_Strikforce"
l["B_11_Strikforce"] = false
l[0][#l[0] + 1] = "Tank"
l["Tank"] = false
l[0][#l[0] + 1] = "Khanjali"
l["Khanjali"] = false
l[0][#l[0] + 1] = "Stromberg"
l["Stromberg"] = false
l[0][#l[0] + 1] = "Buzzard"
l["Buzzard"] = false
l[0][#l[0] + 1] = "Hunter"
l["Hunter"] = false
l[0][#l[0] + 1] = "Avenger"
l["Avenger"] = false
l[0][#l[0] + 1] = "Insurgent_Pickup"
l["Insurgent_Pickup"] = false
l[0][#l[0] + 1] = "Insurgent_Pickup_Custom"
l["Insurgent_Pickup_Custom"] = false
l[0][#l[0] + 1] = "Halftrack"
l["Halftrack"] = false
l[0][#l[0] + 1] = "section_6"
l["section_6"] = "[Chat]"
l[0][#l[0] + 1] = "chat_hidden"
l["chat_hidden"] = false
l[0][#l[0] + 1] = "chat_cmd_friends"
l["chat_cmd_friends"] = true
l[0][#l[0] + 1] = "chat_cmd_all"
l["chat_cmd_all"] = false
l[0][#l[0] + 1] = "chat_log"
l["chat_log"] = false
l[0][#l[0] + 1] = "chat_russki"
l["chat_russki"] = false
l[0][#l[0] + 1] = "chat_begger"
l["chat_begger"] = false
l[0][#l[0] + 1] = "section_7"
l["section_7"] = "[Chat-Commands]"
l[0][#l[0] + 1] = "chat_cmd"
l["chat_cmd"] = false
l[0][#l[0] + 1] = "cmd_explode"
l["cmd_explode"] = false
l[0][#l[0] + 1] = "cmd_explode_all"
l["cmd_explode_all"] = false
l[0][#l[0] + 1] = "cmd_kick"
l["cmd_kick"] = false
l[0][#l[0] + 1] = "cmd_kick_all"
l["cmd_kick_all"] = false
l[0][#l[0] + 1] = "cmd_crash"
l["cmd_crash"] = false
l[0][#l[0] + 1] = "cmd_crash_all"
l["cmd_crash_all"] = false
l[0][#l[0] + 1] = "cmd_lag"
l["cmd_lag"] = false
l[0][#l[0] + 1] = "cmd_trap"
l["cmd_trap"] = false
l[0][#l[0] + 1] = "cmd_tp"
l["cmd_tp"] = false
l[0][#l[0] + 1] = "cmd_clearwanted"
l["cmd_clearwanted"] = false
l[0][#l[0] + 1] = "cmd_vehicle"
l["cmd_vehicle"] = false
l[0][#l[0] + 1] = "cmd_bigpp"
l["cmd_bigpp"] = false
l[0][#l[0] + 1] = "cmd_bigppall"
l["cmd_bigppall"] = false
l[0][#l[0] + 1] = "section_8"
l["section_8"] = "[Custom-Vehicles]"
l[0][#l[0] + 1] = "custom_vehicles_hidden"
l["custom_vehicles_hidden"] = false
l[0][#l[0] + 1] = "spawn_in_vehicle"
l["spawn_in_vehicle"] = true
l[0][#l[0] + 1] = "use_own_veh"
l["use_own_veh"] = true
l[0][#l[0] + 1] = "set_godmode"
l["set_godmode"] = false
l[0][#l[0] + 1] = "controllable_blasts"
l["controllable_blasts"] = false
l[0][#l[0] + 1] = "moveable_legs"
l["moveable_legs"] = false
l[0][#l[0] + 1] = "robot_collision"
l["robot_collision"] = false
l[0][#l[0] + 1] = "rocket_propulsion"
l["rocket_propulsion"] = false
l[0][#l[0] + 1] = "equip_weapons"
l["equip_weapons"] = false
l[0][#l[0] + 1] = "disable_tampa_notify"
l["disable_tampa_notify"] = false
l[0][#l[0] + 1] = "section_9"
l["section_9"] = "[Explosive-Beam]"
l[0][#l[0] + 1] = "explosive_beam_hidden"
l["explosive_beam_hidden"] = false
l[0][#l[0] + 1] = "exp_beam"
l["exp_beam"] = false
l[0][#l[0] + 1] = "exp_beam_type"
l["exp_beam_type"] = 59
l[0][#l[0] + 1] = "exp_beam_type_2"
l["exp_beam_type_2"] = 8
l[0][#l[0] + 1] = "exp_beam_radius"
l["exp_beam_radius"] = 10
l[0][#l[0] + 1] = "exp_beam_min"
l["exp_beam_min"] = 75
l[0][#l[0] + 1] = "exp_beam_max"
l["exp_beam_max"] = 225
l[0][#l[0] + 1] = "section_10"
l["section_10"] = "[Better-Animal-Changer]"
l[0][#l[0] + 1] = "animal_changer_hidden"
l["animal_changer_hidden"] = false
l[0][#l[0] + 1] = "bl_mdl_change"
l["bl_mdl_change"] = true
l[0][#l[0] + 1] = "revert_outfit"
l["revert_outfit"] = true
l[0][#l[0] + 1] = "section_11"
l["section_11"] = "[PTFX]"
l[0][#l[0] + 1] = "ptfx_hidden"
l["ptfx_hidden"] = false
l[0][#l[0] + 1] = "sparkling_ass"
l["sparkling_ass"] = false
l[0][#l[0] + 1] = "sparkling_tires"
l["sparkling_tires"] = false
l[0][#l[0] + 1] = "smoke_area"
l["smoke_area"] = false
l[0][#l[0] + 1] = "fire_circle"
l["fire_circle"] = false
l[0][#l[0] + 1] = "fire_fart"
l["fire_fart"] = 8
l[0][#l[0] + 1] = "fire_ass"
l["fire_ass"] = false
l[0][#l[0] + 1] = "section_12"
l["section_12"] = "[Miscellaneous]"
l[0][#l[0] + 1] = "misc_hidden"
l["misc_hidden"] = false
l[0][#l[0] + 1] = "drive_on_ocean"
l["drive_on_ocean"] = false
l[0][#l[0] + 1] = "drive_this_height"
l["drive_this_height"] = false
l[0][#l[0] + 1] = "weird_ent"
l["weird_ent"] = false
l[0][#l[0] + 1] = "real_time"
l["real_time"] = false
l[0][#l[0] + 1] = "random_clothes"
l["random_clothes"] = false
l[0][#l[0] + 1] = "clear_area"
l["clear_area"] = false
l[0][#l[0] + 1] = "clear_area_2"
l["clear_area_2"] = false
l[0][#l[0] + 1] = "auto_tp_wp"
l["auto_tp_wp"] = false
l[0][#l[0] + 1] = "police_outfit"
l["police_outfit"] = false
l[0][#l[0] + 1] = "auto_load"
l["auto_load"] = false
l[0][#l[0] + 1] = "log_modder_flags"
l["log_modder_flags"] = false
l[0][#l[0] + 1] = "section_13"
l["section_13"] = "[Weapons-Features]"
l[0][#l[0] + 1] = "load_weapons"
l["load_weapons"] = false
l[0][#l[0] + 1] = "flamethrower_scale"
l["flamethrower_scale"] = 1
l[0][#l[0] + 1] = "flamethrower"
l["flamethrower"] = false
l[0][#l[0] + 1] = "flamethrower_green"
l["flamethrower_green"] = false
l[0][#l[0] + 1] = "shoot_entitys"
l["shoot_entitys"] = false
l[0][#l[0] + 1] = "Boat"
l["Boat"] = false
l[0][#l[0] + 1] = "Bumper_Car"
l["Bumper_Car"] = false
l[0][#l[0] + 1] = "XMAS_Tree"
l["XMAS_Tree"] = false
l[0][#l[0] + 1] = "Orange_Ball"
l["Orange_Ball"] = false
l[0][#l[0] + 1] = "Stone"
l["Stone"] = false
l[0][#l[0] + 1] = "Money_Bag"
l["Money_Bag"] = false
l[0][#l[0] + 1] = "Cash_Pile"
l["Cash_Pile"] = false
l[0][#l[0] + 1] = "Trash"
l["Trash"] = false
l[0][#l[0] + 1] = "Roller_Car"
l["Roller_Car"] = false
l[0][#l[0] + 1] = "Cable_Car"
l["Cable_Car"] = false
l[0][#l[0] + 1] = "Big_Dildo"
l["Big_Dildo"] = false
l[0][#l[0] + 1] = "delete_gun"
l["delete_gun"] = false
l[0][#l[0] + 1] = "kick_gun"
l["kick_gun"] = false
l[0][#l[0] + 1] = "demigod_gun"
l["demigod_gun"] = false
l[0][#l[0] + 1] = "model_gun"
l["model_gun"] = false
l[0][#l[0] + 1] = "model_gun_ext"
l["model_gun_ext"] = false
l[0][#l[0] + 1] = "rapid_fire"
l["rapid_fire"] = false
l[0][#l[0] + 1] = "section_14"
l["section_14"] = "[Vehicle]"
l[0][#l[0] + 1] = "heli"
l["heli"] = false
l[0][#l[0] + 1] = "heli_i"
l["heli_i"] = 100
l[0][#l[0] + 1] = "sel_boost_speed"
l["sel_boost_speed"] = false
l[0][#l[0] + 1] = "sel_boost_speed_speed"
l["sel_boost_speed_speed"] = 100
l[0][#l[0] + 1] = "speedometer"
l["speedometer"] = false
l[0][#l[0] + 1] = "speedometer_type"
l["speedometer_type"] = 1
l[0][#l[0] + 1] = "veh_no_colision"
l["veh_no_colision"] = false
l[0][#l[0] + 1] = "auto_repair"
l["auto_repair"] = false
l[0][#l[0] + 1] = "section_15"
l["section_15"] = "[Vehicle-Colors]"
l[0][#l[0] + 1] = "veh_lights_speed"
l["veh_lights_speed"] = 125
l[0][#l[0] + 1] = "random_primary"
l["random_primary"] = false
l[0][#l[0] + 1] = "random_secondary"
l["random_secondary"] = false
l[0][#l[0] + 1] = "random_pearlescent"
l["random_pearlescent"] = false
l[0][#l[0] + 1] = "random_neon"
l["random_neon"] = false
l[0][#l[0] + 1] = "random_smoke"
l["random_smoke"] = false
l[0][#l[0] + 1] = "random_xenon"
l["random_xenon"] = false
l[0][#l[0] + 1] = "rainbow_primary"
l["rainbow_primary"] = false
l[0][#l[0] + 1] = "rainbow_secondary"
l["rainbow_secondary"] = false
l[0][#l[0] + 1] = "rainbow_pearlescent"
l["rainbow_pearlescent"] = false
l[0][#l[0] + 1] = "rainbow_neon"
l["rainbow_neon"] = false
l[0][#l[0] + 1] = "rainbow_smoke"
l["rainbow_smoke"] = false
l[0][#l[0] + 1] = "rainbow_xenon"
l["rainbow_xenon"] = false
l[0][#l[0] + 1] = "synced_random"
l["synced_random"] = false
l[0][#l[0] + 1] = "synced_rainbow"
l["synced_rainbow"] = false
l[0][#l[0] + 1] = "synced_rainbow_smooth"
l["synced_rainbow_smooth"] = false
l[0][#l[0] + 1] = "black_100"
l["black_100"] = false
l[0][#l[0] + 1] = "fade_black_red"
l["fade_black_red"] = false
l[0][#l[0] + 1] = "section_16"
l["section_16"] = "[Bodyguards]"
l[0][#l[0] + 1] = "bodyguards_hidden"
l["bodyguards_hidden"] = false
l[0][#l[0] + 1] = "bodyguards_god"
l["bodyguards_god"] = false
l[0][#l[0] + 1] = "bodyguards_health"
l["bodyguards_health"] = 5000
l[0][#l[0] + 1] = "bodyguards_equip_weapon"
l["bodyguards_equip_weapon"] = false
l[0][#l[0] + 1] = "bodyguards_formation_type"
l["bodyguards_formation_type"] = 0
l[0][#l[0] + 1] = "section_17"
l["section_17"] = "[Aim-Protection]"
l[0][#l[0] + 1] = "aim_prot_hidden"
l["aim_prot_hidden"] = false
l[0][#l[0] + 1] = "enable_aim_prot"
l["enable_aim_prot"] = false
l[0][#l[0] + 1] = "anonymous_punishment"
l["anonymous_punishment"] = true
l[0][#l[0] + 1] = "aim_prot_ragdoll"
l["aim_prot_ragdoll"] = false
l[0][#l[0] + 1] = "aim_prot_fire"
l["aim_prot_fire"] = false
l[0][#l[0] + 1] = "aim_prot_kill"
l["aim_prot_kill"] = false
l[0][#l[0] + 1] = "aim_prot_remove_weapon"
l["aim_prot_remove_weapon"] = false
l[0][#l[0] + 1] = "aim_prot_kick"
l["aim_prot_kick"] = false
l[0][#l[0] + 1] = "section_18"
l["section_18"] = "[Options]"
l[0][#l[0] + 1] = "options_hidden"
l["options_hidden"] = false
l[0][#l[0] + 1] = "attach_no_colision"
l["attach_no_colision"] = false
l[0][#l[0] + 1] = "continuously_assassins"
l["continuously_assassins"] = false
l[0][#l[0] + 1] = "override_notify_color"
l["override_notify_color"] = false
l[0][#l[0] + 1] = "notify_color"
l["notify_color"] = 0
l[0][#l[0] + 1] = "enable_hotkeys"
l["enable_hotkeys"] = false
l[0][#l[0] + 1] = "hotkey_notification"
l["hotkey_notification"] = false
l[0][#l[0] + 1] = "disable_history"
l["disable_history"] = false
l[0][#l[0] + 1] = "history_show_uuid"
l["history_show_uuid"] = false
l[0][#l[0] + 1] = "mwh_notify"
l["mwh_notify"] = false
l[0][#l[0] + 1] = "mwh_exclude_navigation"
l["mwh_exclude_navigation"] = true
l[0][#l[0] + 1] = "mwh_exclude_noclip"
l["mwh_exclude_noclip"] = true
l[0][#l[0] + 1] = "mwh_exclude_editorrot"
l["mwh_exclude_editorrot"] = true
l[0][#l[0] + 1] = "mwh_exclude_file"
l["mwh_exclude_file"] = false
local m = {}
m[0] = {}
m[0][#m[0] + 1] = "leave_session"
m["leave_session"] = "none"
m[0][#m[0] + 1] = "crash_yourself"
m["crash_yourself"] = "none"
m[0][#m[0] + 1] = "print_info_from_entity"
m["print_info_from_entity"] = "none"
m[0][#m[0] + 1] = "send_message_to_dc"
m["send_message_to_dc"] = "none"
m[0][#m[0] + 1] = "drive_this_height"
m["drive_this_height"] = "none"
m[0][#m[0] + 1] = "auto_tp_wp"
m["auto_tp_wp"] = "none"
m[0][#m[0] + 1] = "force_host"
m["force_host"] = "none"
m[0][#m[0] + 1] = "synced_rainbow"
m["synced_rainbow"] = "none"
m[0][#m[0] + 1] = "veh_blacklist"
m["veh_blacklist"] = "none"
m[0][#m[0] + 1] = "laser_beam_explode_waypoint"
m["laser_beam_explode_waypoint"] = "none"
m[0][#m[0] + 1] = "blacklist_enabled"
m["blacklist_enabled"] = "none"
m[0][#m[0] + 1] = "kick_joining"
m["kick_joining"] = "none"
m[0][#m[0] + 1] = "remember_modder"
m["remember_modder"] = "none"
m[0][#m[0] + 1] = "exclude_friends"
m["exclude_friends"] = "none"
m[0][#m[0] + 1] = "chat_cmd"
m["chat_cmd"] = "none"
m[0][#m[0] + 1] = "send_msg_to_script_users"
m["send_msg_to_script_users"] = "none"
m[0][#m[0] + 1] = "teleport_high_in_air"
m["teleport_high_in_air"] = "none"
m[0][#m[0] + 1] = "tp_own_veh_to_me"
m["tp_own_veh_to_me"] = "none"
m[0][#m[0] + 1] = "tp_own_veh_to_me_drive"
m["tp_own_veh_to_me_drive"] = "none"
m[0][#m[0] + 1] = "drive_own_veh"
m["drive_own_veh"] = "none"
m[0][#m[0] + 1] = "tp_to_own_veh"
m["tp_to_own_veh"] = "none"
m[0][#m[0] + 1] = "save_config"
m["save_config"] = "none"
local n = {}
n[0] = {}
n[0][#n[0] + 1] = "maxspeed"
n["maxspeed"] = {"Max-Speed-Bypass", nil}
n[0][#n[0] + 1] = "illegalname"
n["illegalname"] = {"Illegal-Name", nil}
n[0][#n[0] + 1] = "moddedscid"
n["moddedscid"] = {"Modded-SCID", nil}
n[0][#n[0] + 1] = "moddednetevent"
n["moddednetevent"] = {"Modded-Net-Event", nil}
n[0][#n[0] + 1] = "force_sh"
n["force_sh"] = {"Forced-Script-Host", nil}
n[0][#n[0] + 1] = "remembered"
n["remembered"] = {"Remembered", nil}
n[0][#n[0] + 1] = "blacklist"
n["blacklist"] = {"Blacklist", nil}
n[0][#n[0] + 1] = "script"
n["script"] = {"Modded-Script-Event", nil}
local function o(f, p, q)
    if f == nil then
        return
    end
    p = p or 140
    q = q or "2Take1Script"
    if l["override_notify_color"] then
        p = l["notify_color"]
    end
    ui.notify_above_map(f, q, p)
end
local function r(f, s)
    if l["logger"] then
        if f == nil then
            return
        end
        local t = d.time_prefix() .. " [2Take1Script] "
        if s ~= nil then
            t = t .. s .. " "
        end
        f = t .. f
        d.write(c.o(b["Log_file"], "a"), f)
    end
end
local u = {
    1,
    2,
    4,
    8,
    16,
    32,
    64,
    128,
    256,
    512,
    1024,
    2048,
    4096,
    8192,
    16384,
    32768,
    65536,
    131072,
    262144,
    524288,
    1048576,
    2097152,
    4194304,
    8388608,
    16777216,
    33554432,
    67108864,
    134217728,
    268435456,
    536870912,
    1073741824,
    2147483648,
    4294967296,
    8589934592,
    17179869184,
    34359738368,
    68719476736,
    137438953472,
    274877906944,
    549755813888,
    1099511627776,
    2199023255552,
    4398046511104,
    8796093022208,
    17592186044416,
    35184372088832,
    70368744177664,
    140737488355328,
    281474976710656,
    562949953421312,
    1125899906842624,
    2251799813685248,
    4503599627370496,
    9007199254740992,
    18014398509481984,
    36028797018963968,
    72057594037927936,
    144115188075855872,
    288230376151711744,
    576460752303423488,
    1152921504606846976,
    2305843009213693952,
    4611686018427387904
}
local v = {}
local w = {}
w.main = function()
    r("Loading Settings...")
    math.randomseed(c.time())
    if _2t1s then
        o("2Take1Script already loaded, stopping.", 208)
        return
    end
    if not c.d_exists(a["2T1S"]) then
        o("2Take1Script folder not found...", 208)
        o("Redownload the script and make sure you got all files!", 208)
        return
    else
        if c.f_exists(b["EXT_file"]) then
            _2t1sEXT = true
            local x, y = loadfile(b["EXT_file"])
            if x ~= nil then
                xpcall(x, debug.traceback)
                r("2Take1ScriptEXT successfully loaded.")
            else
                _2t1sEXT = false
                o("ERROR Loading Script EXT, returning!", 208)
                return
            end
        else
            o("2Take1ScriptEXT.lua not found!\nMake sure you have all important files!", 208)
            return
        end
        if not c.d_exists(a["Config"]) then
            o("2Take1Script/Config folder not found...", 208)
            o("Redownload the script and make sure you got all files!", 208)
            return
        end
        if not c.d_exists(a["CustomFiles"]) then
            o("2Take1Script/CustomFiles folder not found...", 208)
            o("Redownload the script and make sure you got all files!", 208)
            return
        end
    end
    local z = c.o(b["Config"], "r")
    if z ~= nil then
        for A in io.lines(b["Config"]) do
            if string.find(A, "]", 1) == nil then
                local B = ""
                while string.find(A, "=", 1) ~= nil do
                    B = B .. string.sub(A, 1, 1)
                    A = string.sub(A, 2)
                end
                B = string.sub(B, 1, #B - 1)
                if l[B] ~= nil then
                    if A == "true" then
                        l[B] = true
                    elseif A == "false" then
                        l[B] = false
                    elseif type(A) == "number" then
                        l[B] = c.no(A)
                    else
                        l[B] = A
                    end
                else
                    o("I found an outdated setting entry and cant read it, save settings to overwrite it.")
                end
            end
        end
        io.close(z)
    end
    z = nil
    z = c.o(b["data"], "r")
    if z ~= nil then
        for C in io.lines(b["data"]) do
            v[#v + 1] = C
        end
        io.close(z)
    else
        o("ERROR Loading Script, returning!", 208)
        o("Missing files! Redownload the .zip folder and make sure you have all included files!!!")
        return
    end
    if c.f_exists(b["Admin"]) then
        if not l_a and l["load_admin"] then
            local D, y = loadfile(b["Admin"])
            if D ~= nil then
                xpcall(D, debug.traceback)
                r("2Take1Script-Admin successfully loaded.")
            else
                o("ERROR Loading Script Admin!", 208)
            end
        end
    end
end
w.modder_flags = function()
    r("Loading Modder-Flags...")
    for i = 15, #u do
        if player.get_modder_flag_text(u[i]) == "" then
            break
        end
        for E = 1, #n[0] do
            if player.get_modder_flag_text(u[i]) == n[n[0][E]][1] then
                n[n[0][E]][2] = u[i]
            end
        end
    end
    for i = 1, #n[0] do
        if n[n[0][i]][2] == nil then
            n[n[0][i]][2] = player.add_modder_flag(n[n[0][i]][1])
        end
    end
end
w.hotkeys = function()
    r("Reading Hotkeys.")
    local F = c.o(b["Hotkeys"], "r")
    if F ~= nil then
        local i = 1
        for G in io.lines(b["Hotkeys"]) do
            if string.find(G, "#", 1) == nil and string.find(G, "version", 1) == nil then
                local B = ""
                while string.find(G, "=", 1) ~= nil do
                    B = B .. string.sub(G, 1, 1)
                    G = string.sub(G, 2)
                end
                B = string.sub(B, 1, #B - 1)
                if G ~= "none" and G ~= "nil" then
                    if m[B] ~= nil then
                        m[B] = G
                    else
                        o("I found an outdated hotkeys entry and cant read it, delete the file to create a new one.")
                    end
                end
            end
        end
        io.close(F)
    end
end
w.main()
w.hotkeys()
w.modder_flags()
local H = {}
H.ctrl = function(I, g)
    if entity.is_an_entity(I) then
        if not network.has_control_of_entity(I) then
            network.request_control_of_entity(I)
            g = g or 25
            local time = c.time() + g
            while not network.has_control_of_entity(I) and entity.is_an_entity(I) do
                c.wait(0)
                network.request_control_of_entity(I)
                if time < c.time() then
                    return false
                end
            end
        end
        return true
    end
    return false
end
H.model = function(J)
    if J ~= nil and not streaming.has_model_loaded(J) then
        streaming.request_model(J)
        local time = c.time() + 7500
        while not streaming.has_model_loaded(J) do
            c.wait(0)
            if time < c.time() then
                return false
            end
        end
    end
    return true
end
local K = {}
K.name = function(i)
    if c.valid(i) then
        return player.get_player_name(i)
    end
    return "Invalid Player"
end
K.scid = function(i)
    if c.valid(i) then
        local c = player.get_player_scid(i)
        if c ~= 4294967295 then
            return c
        end
    end
    return -1
end
K.ip = function(i)
    if c.valid(i) then
        local L = player.get_player_ip(i)
        return string.format("%i.%i.%i.%i", L >> 24 & 0xff, L >> 16 & 0xff, L >> 8 & 0xff, L & 0xff)
    end
    return -1
end
K.input = function(M, N, O, P)
    if not M then
        return nil
    end
    P = P or ""
    N = N or 64
    O = O or 0
    local Q, i = input.get(M, P, N, O)
    while Q == 1 do
        c.wait(0)
        Q, i = input.get(M, P, N, O)
    end
    if Q == 2 then
        return nil
    end
    return i
end
local R = {}
R.ped = function()
    return c.ped(c.id())
end
R.heading = function()
    return player.get_player_heading(c.id())
end
R.coords = function()
    return c.gcoords(R.ped())
end
local S = {}
S.i = function(i, T)
    local U = false
    if T == true then
        U = true
    end
    if c.valid(i) then
        if (U or i ~= c.id()) and K.scid(i) ~= -1 then
            if U or (l["exclude_friends"] and not player.is_player_friend(i) or not l["exclude_friends"]) then
                return true
            end
        end
    end
    return false
end
S.modder = function(i)
    if c.valid(i) then
        if K.scid(i) ~= -1 and i ~= c.id() and not player.is_player_modder(i, -1) then
            if l["exclude_friends"] and not player.is_player_friend(i) or not l["exclude_friends"] then
                return true
            end
        end
    end
    return false
end
local V = {}
V.p = {["parent"] = 0, ["opl_parent"] = 0}
V.t = {}
V.o = {}
V.add = {}
V.add.p = function(j, W, X)
    return menu.add_feature(j, "parent", W, X)
end
V.add.t = function(j, W, X)
    return menu.add_feature(j, "toggle", W, X)
end
V.add.a = function(j, W, X)
    return menu.add_feature(j, "action", W, X)
end
V.add.u = function(j, Y, W, X)
    return menu.add_feature(j, Y, W, X)
end
V.add.pp = function(j, W, X)
    return menu.add_player_feature(j, "parent", W, X)
end
V.add.pt = function(j, W, X)
    return menu.add_player_feature(j, "toggle", W, X)
end
V.add.pa = function(j, W, X)
    return menu.add_player_feature(j, "action", W, X)
end
V.add.pu = function(j, Y, W, X)
    return menu.add_player_feature(j, Y, W, X)
end
local Z = {}
Z[1] = true
local _ = {}
_.add_loop = 1
_.start_loop = 1
_.parents = {}
_.players = {}
_.event = nil
_.lobby = nil
_.tags = function(a0)
    for i = 2, #a0.children do
        local a1 = a0.children[i].name
        local a2 = string.sub(a0.children[i].children[2].name, 7)
        if a1 ~= a2 then
            a0.children[i].name = a2
        end
        local a3 = c.no(string.sub(a0.children[i].children[3].name, 7))
        local a4 = player.get_host()
        local a5 = script.get_host_of_this_script()
        for E = 0, 31 do
            if K.scid(E) == a3 then
                local a6 = ""
                if E == c.id() then
                    a6 = a6 .. "Y"
                end
                if player.is_player_friend(E) then
                    a6 = a6 .. "F"
                end
                if E == a4 then
                    a6 = a6 .. "H"
                end
                if E == a5 then
                    a6 = a6 .. "S"
                end
                if player.is_player_modder(E, -1) then
                    a6 = a6 .. "M"
                end
                if a6 ~= "" then
                    a2 = a2 .. " [" .. a6 .. "]"
                    a0.children[i].name = a2
                end
            end
        end
    end
end
_.add_players = function()
    if not l["disable_history"] then
        for i = _.add_loop, #_.players do
            local a7 = _.players[i]["uuid"]
            local U = _.players[i]["added"] == false
            local a8 = c.no(string.sub(_.lobby.name, 7, 8))
            local a9 = c.no(string.sub(a7, #a7 - 1, #a7))
            if a9 == nil then
                a9 = c.no(string.sub(a7, #a7, #a7))
            end
            local aa = a8 == a9
            if U and aa then
                _.add_loop = _.add_loop + 1
                _.players[i]["added"] = true
                local a3 = _.players[i]["scid"]
                local j = _.players[i]["name"]
                local ab = V.add.p(j, _.lobby.id).id
                V.add.a("UUID: " .. _.players[i]["uuid"], ab).hidden = not l["history_show_uuid"]
                V.add.a(
                    "NAME: " .. j,
                    ab,
                    function()
                        utils.to_clipboard(j)
                        o("Copied NAME to clipboard!", 21)
                    end
                )
                V.add.a(
                    "SCID: " .. a3,
                    ab,
                    function()
                        utils.to_clipboard(a3)
                        o("Copied SCID to clipboard!", 21)
                    end
                )
                V.add.a(
                    "IP: " .. _.players[i]["ip"],
                    ab,
                    function()
                        utils.to_clipboard(_.players[i]["ip"])
                        o("Copied IP to clipboard!", 21)
                    end
                )
                V.add.a("PlayerID: " .. _.players[i]["player_id"], ab)
                V.add.a("First seen: " .. _.players[i]["first_seen"], ab)
                V.add.a(
                    "Add Player to Blacklist",
                    ab,
                    function()
                        if a3 == K.scid(c.id()) or a3 == -1 then
                            o("Choose valid Player.")
                        else
                            d.write(c.o(b["Blacklist"], "a"), a3 .. " " .. j)
                            o("Player " .. j .. " added to Blocklist.", 48)
                            r("Player " .. j .. " with SCID: " .. a3 .. " added to Blacklist.")
                        end
                    end
                )
                V.add.a(
                    "Add Player to Remember-Modder",
                    ab,
                    function()
                        if a3 == K.scid(c.id()) or a3 == -1 then
                            o("Choose valid Player.")
                        else
                            d.write(c.o(b["Modders"], "a"), a3 .. " " .. j)
                            o("Modder " .. j .. " added to Remember-List.", 130)
                            r("Modder '" .. j .. "' added to Remember-List.")
                        end
                    end
                )
                V.add.a(
                    "Copy Outfit",
                    ab,
                    function()
                        local ac = player.is_player_female(c.id())
                        if ac == _.players[i]["is_female"] then
                            local ad = _.players[i]["h_clothes"]
                            local ae = _.players[i]["h_textures"]
                            for E = 1, 11 do
                                ped.set_ped_component_variation(R.ped(), E, ad[E], ae[E], 2)
                            end
                            local af = {0, 1, 2, 6, 7}
                            local ag = _.players[i]["h_prop_ind"]
                            local ah = _.players[i]["h_prop_text"]
                            for aj = 1, #af do
                                ped.set_ped_prop_index(R.ped(), af[aj], ag[aj], ah[aj], 0)
                            end
                        else
                            o("Unluckily, you have the wrong gender!", 21)
                        end
                    end
                )
                V.add.a(
                    "Is " .. j .. " in the current lobby?",
                    ab,
                    function()
                        for E = 0, 31 do
                            if K.scid(E) == a3 then
                                o(j .. " is in your lobby!", 18)
                                return HANDLER_POP
                            end
                        end
                        o(j .. " is ~h~NOT~h~ in your lobby!", 28)
                    end
                )
                V.add.a(
                    "Was he a modder?",
                    ab,
                    function()
                        local a3 = _.players[i]["scid"]
                        if not V.t["log_modder_flags"].on then
                            o("Enabel 'Log Modder Flags' in Misc -> Dev Tools", 39)
                        elseif not Z[a3] then
                            o("He was not flagged with any Modder-Flags", 21)
                        else
                            for E = 1, #u do
                                if Z[a3][u[E]] then
                                    local ak = u[E]
                                    local f = player.get_modder_flag_text(ak)
                                    o(j .. " had '" .. f .. "' as a Flag!", 21)
                                end
                            end
                        end
                    end
                )
            end
        end
    end
end
_.new_lobby = function(al)
    local N = #_.parents + 1
    _.parents[N] =
        V.add.p(
        "Lobby " .. al,
        V.p["player_history"],
        function()
            _.add_players()
            _.tags(_.parents[N])
        end
    )
    local am = #_.parents - 1
    local an = _.parents[am].children
    V.add.p("Lobby Information", _.parents[N].id).hidden = true
    _.lobby = _.parents[N]
    an[1].hidden = false
    V.add.a("Logged " .. #an - 1 .. " Players in this Lobby!", an[1].id)
    V.add.a(
        "Hide this lobby from History",
        an[1].id,
        function()
            _.parents[N - 1].hidden = true
        end
    )
end
local ao = {}
ao.ped = function(ap, aq, ar, as, at, au)
    if ap == nil then
        return
    end
    ar = ar or 6
    aq = aq or R.coords()
    as = as or 0.0
    at = at or true
    au = au or false
    return ped.create_ped(ar, ap, aq, as, at, au)
end
ao.object = function(ap, aq, av, aw)
    if ap == nil then
        return
    end
    aq = aq or v3()
    av = av or true
    aw = aw or false
    return object.create_object(ap, aq, av, aw)
end
ao.vehicle = function(ap, aq, as, av, au)
    if ap == nil then
        return
    end
    aq = aq or v3()
    as = as or 0.0
    av = av or true
    au = au or false
    return vehicle.create_vehicle(ap, aq, as, av, au)
end
local ax = {
    {"Severe Weather", {0}},
    {"Half Track", {0, 1}},
    {"Night Shark AAT", {0, 2}},
    {"APC Mission", {0, 3}},
    {"MOC Mission", {0, 4}},
    {"Tampa Mission", {0, 5}},
    {"Opressor Mission 1", {0, 6}},
    {"Opressor Mission 2", {0, 7}}
}
local ay = {
    {"Ban", 0xC2AD5FCE, {0, 1, 5, 0}, 0x96308401, {0, 1, 5, 0}},
    {"Dismiss", 0x96308401, {0, 1, 5}, 0x96308401, {0, 1, 5}},
    {"Terminate", 0x96308401, {1, 1, 6}, 0x96308401, {0, 1, 6, 0}}
}
local az = {
    {"Boat", -1685705098, false},
    {"Bumper_Car", -77393630, false},
    {"XMAS_Tree", 238789712, false},
    {"Orange_Ball", 148511758, false},
    {"Stone", 2042668880, false},
    {"Money_Bag", 289396019, false},
    {"Cash_Pile", -295781225, false},
    {"Trash", 1919238784, false},
    {"Roller_Car", 1543894721, false},
    {"Cable_Car", -733833763, false},
    {"Big_Dildo", 1333481871, false}
}
local aA = {
    {222, 222, 255},
    {2, 21, 255},
    {3, 83, 255},
    {0, 255, 140},
    {94, 255, 1},
    {255, 255, 0},
    {255, 150, 5},
    {255, 62, 0},
    {255, 1, 1},
    {255, 50, 100},
    {255, 5, 190},
    {35, 1, 255},
    {15, 3, 255}
}
local aB = {
    {"Oppressor", 0x34B82784},
    {"MK2_Oppressor", 0x7B54A9D3},
    {"Lazer", 0xB39B0AE6},
    {"Hydra", 0x39D6E83F},
    {"Deluxo", 0x586765FB},
    {"Akula", 0x46699F47},
    {"B_11_Strikforce", 0x64DE07A1},
    {"Tank", 0x2EA68690},
    {"Khanjali", 0xAA6F980A},
    {"Stromberg", 0x34DBA661},
    {"Buzzard", 0x2F03547B},
    {"Hunter", 0xFD707EDE},
    {"Avenger", 0x81BD2ED0},
    {"Insurgent_Pickup", 0x9114EADA},
    {"Insurgent_Pickup_Custom", 0x8D4B7A8A},
    {"Halftrack", 0xFE141DA6}
}
local aC = {
    {"cmd_explode", "!explode <playername>"},
    {"cmd_explode_all", "!explodeall	[SU]"},
    {"cmd_kick", "!kick <playername>"},
    {"cmd_kick_all", "!kickall	[SU]"},
    {"cmd_crash", "!crash <playername>	[SU]"},
    {"cmd_crash_all", "!crashall	[SU]"},
    {"cmd_lag", "!lag <playername>"},
    {"cmd_trap", "!trap <playername>"},
    {"cmd_tp", "!tp <playername>	[SU]"},
    {"cmd_clearwanted", "!clearwanted	[NOT SU]"},
    {"cmd_vehicle", "!vehicle <NAME>"},
    {"cmd_bigpp", "!bigpp <playername>"},
    {"cmd_bigppall", "!bigppall	[SU]"}
}
local aD = {
    {
        "Main LSC",
        {
            {3291218330, {-357.45132446289, -134.30920410156, 38.53914642334}, {0, 0, -20}, true, true},
            {false, {-370.4, -104.72, 47}, -110.83449554443}
        }
    },
    {
        "La Mesa LSC",
        {
            {3291218330, {722.9853515625, -1089.2061767578, 23.043445587158}, {0, 0, 0}, true, true},
            {false, {700, -1085, 24}, -100}
        }
    },
    {
        "LSIA LSC",
        {
            {3291218330, {-1145.7882080078, -1991.130859375, 13.163989067078}, {0, 0, 45}, true, true},
            {false, {-1117.1, -1983.3, 23}, 104.5}
        }
    },
    {
        "Desert LSC",
        {
            {3291218330, {1178.552734375, 2646.4377441406, 37.874099731445}, {0, 0, 90}, true, true},
            {false, {1182, 2673.2, 39}, 163.3}
        }
    },
    {
        "Paleto Bay LSC",
        {
            {3291218330, {112.54597473145, 6619.6850585938, 31.604303359985}, {0, 0, -45}, true, true},
            {false, {140.8, 6601.9, 32}, 57}
        }
    },
    {
        "Bennys LSC",
        {
            {3291218330, {-208.5591583252, -1308.7404785156, 31.718006134033}, {0, 0, 90}, true, true},
            {false, {-184.2, -1292.5, 34}, 124.3}
        }
    }
}
local aE = {
    {
        "Entrance",
        {
            {3291218330, {924.69201660156, 62.243091583252, 81.21053314209}, {0, 0, 80}, true, true},
            {3291218330, {910.31787109375, 36.022556304932, 80.59684753418}, {0, 0, 25}, true, true},
            {false, {920.8, 80.5, 80}, -177}
        }
    },
    {
        "Garage",
        {
            {3291218330, {932.78601074219, -2.0857257843018, 80.166107177734}, {0, 0, 60}, true, true},
            {false, {940, -21, 80}, 4.9}
        }
    },
    {
        "Roof",
        {
            {3291218330, {964.02569580078, 58.947933197021, 113.34354400635}, {0, 0, -30}, true, true},
            {false, {954.8, 63.34, 114}, -124.2}
        }
    }
}
local aF = {
    {
        "Entrance",
        {
            {3291218330, {-81.541351318359, -792.25347900391, 44.622947692871}, {0, 0, 100}, true, true},
            {3291218330, {-70.231819152832, -802.17694091797, 44.230716705322}, {0, 0, 0}, true, true},
            {false, {-55.1, -776.5, 46}, 125.4}
        }
    },
    {
        "Garage",
        {
            {3291218330, {-83.269706726074, -773.02490234375, 39.806701660156}, {0, -35, 105}, true, true},
            {false, {-86.2, -762.2, 44}, -165.7}
        }
    },
    {
        "Roof",
        {
            {3291218330, {-66.390617370605, -813.32702636719, 320.40509033203}, {0, 0, 60}, true, true},
            {3291218330, {-66.451454162598, -822.87298583984, 321.19717407227}, {0, 0, 100}, true, true},
            {3291218330, {-68.104598999023, -818.67510986328, 323.35980224609}, {0, 90, 0}, true, true},
            {false, {-76.6, -817.6, 328}}
        }
    },
    {
        "Arena War",
        {
            {3291218330, {-371.32809448242, -1859.2064208984, 21.246929168701}, {0, 15, -75}, true, true},
            {3291218330, {-396.87942504883, -1869.1518554688, 22.718107223511}, {0, 15, -60}, true, true},
            {false, {-379.6, -1850, 23}, -166.6}
        }
    }
}
local aG = {1057201338, 2238511874, 762327283}
local aH = {
    62409944,
    64074298,
    155527062,
    153219155,
    131037988,
    141884823,
    104432921,
    147111499,
    9284553,
    114982881,
    137663665,
    63457,
    137601710,
    138075198,
    123017343,
    130291511,
    137851207,
    137714280,
    127448079,
    137579070,
    134412628,
    133709045,
    64234321,
    131973478,
    103019313,
    103054099,
    104041189,
    110470958,
    119266383,
    119958356,
    121397532,
    121698158,
    123849404,
    121943600,
    129159629,
    18965281,
    216820,
    56778561,
    99453545,
    99453882,
    88435916,
    174875493
}
local aI = {
    ["bl_objects"] = {},
    ["peds"] = {},
    ["attach_obj"] = {},
    ["asteroids"] = {},
    ["lag_area"] = {},
    ["custom_veh"] = {},
    ["preview_veh"] = {},
    ["temp_veh"] = {},
    ["shooting"] = {},
    ["chat_veh"] = {},
    ["bodyguards"] = {},
    ["bodyguards_veh"] = {},
    ["robot_weapon_left"] = {},
    ["robot_weapon_right"] = {},
    ["vehicle_builder"] = {}
}
local aJ = {
    ["police_outfit"] = {
        ["female"] = {
            ["clothes"] = {{0, 0}, {0, 6}, {0, 14}, {0, 34}, {0, 0}, {0, 25}, {0, 0}, {0, 35}, {0, 0}, {0, 0}, {0, 48}},
            ["props"] = {{0, 45, 0}, {1, 11, 0}, {2, 4294967295, 0}, {6, 4294967295, -1}, {7, 4294967295, -1}}
        },
        ["male"] = {
            ["clothes"] = {{0, 0}, {0, 0}, {0, 0}, {0, 35}, {0, 0}, {0, 25}, {0, 0}, {0, 58}, {0, 0}, {0, 0}, {0, 55}},
            ["props"] = {{0, 46, 0}, {1, 13, 0}, {2, 4294967295, 0}, {6, 4294967295, -1}, {7, 4294967295, -1}}
        }
    },
    ["bac_outfit"] = {["textures"] = {}, ["clothes"] = {}, ["prop_text"] = {}, ["prop_ind"] = {}, ["gender"] = nil},
    ["session_crash"] = {["textures"] = {}, ["clothes"] = {}, ["prop_text"] = {}, ["prop_ind"] = {}}
}
local aK = {}
aK.hashes = {
    ["snacks_and_armor"] = {
        {"NO_BOUGHT_YUM_SNACKS", 30},
        {"NO_BOUGHT_HEALTH_SNACKS", 15},
        {"NO_BOUGHT_EPIC_SNACKS", 5},
        {"NUMBER_OF_ORANGE_BOUGHT", 10},
        {"NUMBER_OF_BOURGE_BOUGHT", 10},
        {"NUMBER_OF_CHAMP_BOUGHT", 5},
        {"CIGARETTES_BOUGHT", 20},
        {"MP_CHAR_ARMOUR_1_COUNT", 10},
        {"MP_CHAR_ARMOUR_2_COUNT", 10},
        {"MP_CHAR_ARMOUR_3_COUNT", 10},
        {"MP_CHAR_ARMOUR_4_COUNT", 10},
        {"MP_CHAR_ARMOUR_5_COUNT", 10}
    },
    ["kills_deaths"] = {"MPPLY_KILLS_PLAYERS", "MPPLY_DEATHS_PLAYER"},
    ["fast_run"] = {
        "CHAR_FM_ABILITY_1_UNLCK",
        "CHAR_FM_ABILITY_2_UNLCK",
        "CHAR_FM_ABILITY_3_UNLCK",
        "CHAR_ABILITY_1_UNLCK",
        "CHAR_ABILITY_2_UNLCK",
        "CHAR_ABILITY_3_UNLCK"
    },
    ["chc"] = {
        ["misc"] = {
            {"Remove Repeat Cooldown (-1)", "H3_COMPLETEDPOSIX", 0, -1},
            {"Last Approach Completed (1 2 3)", "H3_LAST_APPROACH", 0, 0, 3},
            {"Confirm First Board", "H3OPT_BITSET1", 0, -1},
            {"Confirm Second Board", "H3OPT_BITSET0", 0, -1}
        },
        ["board1"] = {
            {"1:Silent, 2:BigCon, 3:Aggressive", "H3OPT_APPROACH", 0, 1, 3, 1},
            {"Hard Difficulty Approach (1 2 3)", "H3_HARD_APPROACH", 0, 1, 3, 1},
            {"0:Money, 1:Gold, 2:Art, 3:Diamond", "H3OPT_TARGET", 0, 0, 3, 3},
            {"Unlock Points of Interests", "H3OPT_POI", 0, 1023},
            {"Unlock Access Points", "H3OPT_ACCESSPOINTS", 0, 2047}
        },
        ["board2"] = {
            {"1:5%, 2:9%, 3:7%, 4:10%, 5:10%", "H3OPT_CREWWEAP", 0, 1, 5, 1},
            {"1:5%, 2:7%, 3:9%, 4:6%, 5:10%", "H3OPT_CREWDRIVER", 0, 1, 5, 1},
            {"1:3%, 2:7%, 3:5%, 4:10%, 5:9%", "H3OPT_CREWHACKER", 0, 1, 5, 1},
            {"Weapon Variation (0 1)", "H3OPT_WEAPS", 0, 0, 1},
            {"Vehicle Variation (0 1 2 3)", "H3OPT_VEHS", 0, 0, 3},
            {"Remove Duggan Heavy Guards", "H3OPT_DISRUPTSHIP", 0, 3},
            {"Equip Heavy Armor", "H3OPT_BODYARMORLVL", 0, 3},
            {"Scan Card Level", "H3OPT_KEYLEVELS", 0, 2},
            {"Mask Variation (0 till 12)", "H3OPT_MASKS", 0, 0, 12}
        }
    }
}
aK.set = function(ap, t, A, aL)
    aL = aL or true
    local aM = ap
    if t then
        aM = "MP1_" .. ap
        ap = "MP0_" .. ap
    end
    ap = gameplay.get_hash_key(ap)
    stats.stat_set_int(ap, A, aL)
    if t then
        aM = gameplay.get_hash_key(aM)
        stats.stat_set_int(aM, A, aL)
    end
end
local aN = _2t1s_russki_chars
local aO = _2t1s_begger_texts
local aP = _2t1s_ped_assassins
local aQ = _2t1s_se_custom
local aR = _2t1s_block_custom
local aS = _2t1s_custom_attachments
local aT = _2t1s_custom_vehicles
local aU = _2t1s_vehicle_lag_area
local aV = _2t1s_modded_ips
local aW = _2t1s_speedometer_units
local aX = _2t1s_bounty_amount
local aY = _2t1s_sms_texts
local aZ = _2t1s_net_events
local a_ = _2t1s_weapons
local b0 = enable_rockstar_admin_kick_crash
local b1 = {"random_primary", "random_secondary", "random_pearlescent", "random_neon", "random_smoke", "random_xenon"}
local b2 = {
    "rainbow_primary",
    "rainbow_secondary",
    "rainbow_pearlescent",
    "rainbow_neon",
    "rainbow_smoke",
    "rainbow_xenon"
}
local b3 = {"synced_rainbow", "synced_random", "synced_rainbow_smooth"}
local b4, b5, b6 = 0, false, 0
local b7 = v3()
local b8, b9 = nil, false
local ba, bb = {}, {}
local bc = {}
local bd = {}
local be, bf
local bg
local bh
local bi = nil
local bj
local bk = {}
local bl = {}
local bm, bn, bo
local bp
local bq
local br, bs
local bt = {}
local bu = {}
local bv = {}
local bw = {}
local bx
local by
local bz = {12, 13, 14, 43, 74}
local bA
local bB
local bC = {0xedb42cd8, 0x231d58ee, 0xac07dc75, 0x58fabbdf, 0xd892c51c, 0xb3f248d0}
local bD = {}
local bE = nil
local bF = {
    ["flamethrower"] = nil,
    ["flamethrower_green"] = nil,
    ["alien"] = nil,
    ["fire_circle"] = {},
    ["fire_balls"] = {},
    ["fire_ass"] = nil,
    ["fire_ass_ball"] = nil
}
local function bG(i, bH)
    H.ctrl(i)
    entity.set_entity_velocity(i, v3())
    entity.set_entity_coords_no_offset(i, bH)
end
local function bI(bJ, time)
    if bJ ~= nil and bJ[1] ~= nil then
        if time == nil then
            time = 5
        end
        for i = 1, #bJ do
            if bJ[i] ~= R.ped() and bJ[i] ~= c.vehicle(R.ped()) then
                H.ctrl(bJ[i], time)
                entity.detach_entity(bJ[i])
                entity.set_entity_velocity(bJ[i], v3())
                bG(bJ[i], v3(8000, 8000, -1000))
                entity.delete_entity(bJ[i])
            end
        end
    end
end
event.add_event_listener(
    "exit",
    function()
        r("")
        r("2Take1Script got unloaded.")
        r("Cleaning up...")
        o("2Take1Script got unloaded.\nUnloading Script.. :(", 200)
        for i in pairs(bl) do
            bI({bl[i]})
        end
        for i in pairs(aI) do
            bI(aI[i])
        end
        bI({br})
        bI({bp})
        if bF["flamethrower"] ~= nil then
            graphics.remove_particle_fx(bF["flamethrower"], true)
        end
        if bF["flamethrower_green"] ~= nil then
            graphics.remove_particle_fx(bF["flamethrower_green"], true)
        end
        if bF["fire_circle"][1] ~= nil then
            for i = 1, #bF["fire_circle"] do
                graphics.remove_particle_fx(bF["fire_circle"][i], true)
            end
            bI(bF["fire_balls"])
        end
        if bF["fire_ass"] ~= nil then
            graphics.remove_particle_fx(bF["fire_ass"], true)
        end
        bI({bF["fire_ass_ball"]})
        for i = 1, 32 do
            if bv[i] ~= nil then
                hook.remove_script_event_hook(bv[i])
            end
        end
        for i = 1, 32 do
            if bw[i] ~= nil then
                hook.remove_net_event_hook(bw[i])
            end
        end
        r("Going to remove Chat-Listeners...")
        for i in pairs(bd) do
            event.remove_event_listener("chat", bd[i])
        end
        if _.event ~= nil then
            event.remove_event_listener("player_join", _.event)
        end
        r("Done.")
        _2t1s = false
        _2t1sEXT = false
    end
)
local function bK(g, bL, J)
    r("Teleporting to Target.")
    local bM, aq, bN, bO = R.ped()
    if type(g) == "number" then
        bO = c.vehicle(g)
        if bO ~= 0 then
            if ped.is_ped_in_any_vehicle(bM) then
                ped.clear_ped_tasks_immediately(bM)
                c.wait(10)
            end
        end
    end
    bN = c.vehicle(bM)
    if bN ~= 0 then
        H.ctrl(bN)
        entity.set_entity_velocity(bN, v3())
        bM = bN
    end
    if type(g) == "number" then
        aq = c.gcoords(g)
    else
        aq = g
    end
    if bL ~= nil then
        aq.z = aq.z + bL
    end
    bG(bM, aq)
    if J ~= nil then
        entity.set_entity_heading(bM, J)
    end
    if bO ~= nil then
        c.wait(1500)
        ped.set_ped_into_vehicle(R.ped(), bO, vehicle.get_free_seat(bO))
    end
    r("Done.")
end
local function bP(i)
    local bQ = script.get_global_i(2424073 + i * 421 + 235 + 1)
    local bR = interior.get_interior_from_entity(c.ped(i))
    if bQ ~= 0 and (bR ~= nil or bR ~= 0) then
        return true
    end
    return false
end
local function bS(water, bT)
    if
        not V.t["bl_mdl_change"].on or
            V.t["bl_mdl_change"].on and
                (not ped.is_ped_in_any_vehicle(R.ped()) and
                    (water and entity.is_entity_in_water(R.ped()) or
                        not water and not entity.is_entity_in_water(R.ped())) or
                    bT)
     then
        return true
    end
    o("Model Change not possible!", 125)
    return false
end
local function bU(J, water, bV, bW, bT)
    if bS(water, bT) then
        if bW then
            bK(R.coords(), 1.5)
        end
        H.model(J)
        player.set_player_model(J)
        c.unload(J)
        if bV then
            c.wait(0)
            ped.set_ped_component_variation(R.ped(), 4, 0, 0, 2)
        end
        if J == 0x9C9EFFD8 or J == 0x705E61F2 then
            local K = "male"
            if player.is_player_female(c.id()) then
                K = "female"
            end
            if aJ["bac_outfit"]["gender"] == K then
                local ad = aJ["bac_outfit"]["clothes"]
                local ae = aJ["bac_outfit"]["textures"]
                for E = 1, 11 do
                    ped.set_ped_component_variation(R.ped(), E, ad[E], ae[E], 2)
                end
                local af = {0, 1, 2, 6, 7}
                local ag = aJ["bac_outfit"]["prop_ind"]
                local ah = aJ["bac_outfit"]["prop_text"]
                for aj = 1, #af do
                    ped.set_ped_prop_index(R.ped(), af[aj], ag[aj], ah[aj], 0)
                end
            end
        end
    end
end
local function bX()
    local bY, bZ = {}, {}
    local b_
    if c.f_exists(b["Blacklist"]) then
        local F = c.o(b["Blacklist"], "r")
        if F ~= nil then
            for c0 in io.lines(b["Blacklist"]) do
                b_ = 1
                for c1 in string.gmatch(c0, "[^%s]+") do
                    if b_ == 1 then
                        table.insert(bY, c1)
                    else
                        if type(c1) == "string" then
                            table.insert(bZ, c1)
                        else
                            table.insert(bZ, "NoNameFound")
                        end
                    end
                    b_ = b_ + 1
                end
            end
        end
        io.close(F)
        ba = bY
        bb = bZ
    end
end
local function c2(an, id)
    local i = 0
    if an then
        r("Lobby Kick!")
    end
    while i < 32 do
        if an then
            id = i
        else
            i = 99
        end
        if S.i(id) then
            local c3, c4, c5
            for i = 1, c.random(15, 40) do
                c3 = c.random(0xd00000, 0xfeb00000)
                c4 = c.random(0, 31)
                c5 = c.random(-100, 5000)
                c.script(c3, id, {c4, c5})
            end
            c.wait(75)
            o("Attempting to Kick Player: " .. K.name(id), 65)
            r("Attempting to Kick Player.")
            r(K.name(id) .. ":" .. K.scid(id))
            if network.network_is_host() then
                r("Haha, got a hostkick.")
                network.network_session_kick_player(id)
            end
            c.script(0x8197eaf0, id, {id, script.get_global_i(1628955 + 1 + id * 614 + 532)})
            c.script(0x8197eaf0, id, {id, script.get_global_i(1628955 + 1 + id * 614 + 532)})
            c.script(0x8197eaf0, id, {id, script.get_global_i(1628955 + 2 + id * 614 + 532)})
            for i = 1, c.random(15, 40) do
                c3 = c.random(0xd00000, 0xfeb00000)
                c.script(c3, id, {})
            end
            c.wait(75)
            for i = 1, #v, 2 do
                c.script(c.no(v[i], 27) + c.no(v[i + 1], 36), id, {})
            end
            c.wait(75)
            for i = 1, c.random(15, 40) do
                c3 = c.random(0xd00000, 0xfeb00000)
                c.script(c3, id, {})
            end
            c.wait(75)
        end
        i = i + 1
    end
end
local function c6(c7, id, c8)
    for i = 1, #c7 do
        local c9 = v3(c7[i][3][1], c7[i][3][2], c7[i][3][3])
        local ca = v3(c7[i][4][1], c7[i][4][2], c7[i][4][3])
        local cb
        local cc = false
        if c8 then
            cb = c7[i][1]
        else
            H.model(c7[i][1])
            if streaming.is_model_an_object(c7[i][1]) then
                cb = ao.object(c7[i][1], c9)
            else
                cc = true
                cb = ao.ped(c7[i][1], c9)
                c.wait(0)
                ped.set_ped_can_ragdoll(cb, false)
                c.god(cb, true)
            end
            c.unload(c7[i][1])
        end
        aI["attach_obj"][#aI["attach_obj"] + 1] = cb
        if V.t["attach_no_colision"].on then
            entity.set_entity_collision(cb, false, false, false)
        end
        if c7[i][5] then
            c.visible(cb, false)
        end
        c.attach(cb, c.ped(id), c7[i][2], c9, ca, true, true, cc, 0, true)
    end
end
local function cd(id, J)
    r("Lagging Area @Player.")
    local aq = c.gcoords(c.ped(id))
    H.model(J)
    aq.z = aq.z + 5
    for i = 1, 50 do
        aI["lag_area"][#aI["lag_area"] + 1] = ao.vehicle(J, aq)
    end
    c.unload(J)
    r("Done.")
end
local function ce(id)
    if S.i(id) then
        c.navigate(false)
        local cf = {}
        while R.coords():magnitude(c.gcoords(c.ped(id))) < 5000 do
            local aq = R.coords()
            bK(v3(aq.x, aq.y, aq.z + 500))
        end
        r("Sending Crash Entitys...")
        r("Distance: " .. R.coords():magnitude(c.gcoords(c.ped(id))))
        for i = 1, #aG do
            local J = aG[i]
            H.model(J)
            local cg = c.gcoords(c.ped(id)) + v3(0, 0, 2.5)
            cf[i] = ao.ped(J, cg, 26)
            c.unload(J)
        end
        r("Waiting.")
        o("Waiting ~ 7.5 seconds...")
        local time = c.time() + 7500
        while time > c.time() do
            r("Distance: " .. R.coords():magnitude(c.gcoords(c.ped(id))))
            c.wait(125)
            while R.coords():magnitude(c.gcoords(c.ped(id))) < 5000 do
                local aq = R.coords()
                bK(v3(aq.x, aq.y, aq.z + 500))
            end
        end
        for i = 1, #cf do
            if not H.ctrl(cf[i], 5000) then
                o("Dont go near the player, there is a possibility that the crash peds still exist!")
            end
            bI({cf[i]}, 5000)
        end
        bI(cf[i], 5000)
        c.navigate(true)
    end
end
local function ch(bN)
    local ci = {11, 12, 13, 16, 18}
    local cj = {3, 2, 2, 4, 1}
    for i = 1, #ci do
        if vehicle.get_vehicle_mod(bN, ci[i]) ~= cj[i] then
            H.ctrl(bN)
            vehicle.set_vehicle_mod(bN, ci[i], cj[i])
        end
    end
    vehicle.set_vehicle_bulletproof_tires(bN, true)
end
local function ck(aq, as, cl)
    as = math.rad((as - 180) * -1)
    aq.x = aq.x + math.sin(as) * -cl
    aq.y = aq.y + math.cos(as) * -cl
    return aq
end
local function cm(cn)
    local co = "0X"
    for G, A in pairs(cn) do
        local cp = ""
        while A > 0 do
            local B = math.fmod(A, 16) + 1
            A = math.floor(A / 16)
            cp = string.sub("0123456789ABCDEF", B, B) .. cp
        end
        if string.len(cp) == 0 then
            cp = "00"
        elseif string.len(cp) == 1 then
            cp = "0" .. cp
        end
        co = co .. cp
    end
    return co
end
local function cq(id)
    id = string.lower(id)
    local j
    for i = 0, 31 do
        if K.scid(i) ~= -1 then
            j = string.lower(K.name(i))
            if j == id then
                return i
            end
        end
    end
    return -1
end
local function cr(cs)
    for i = 1, #cs do
        if V.t[cs[i]].on then
            V.t[cs[i]].on = false
        end
    end
end
local function ct(bN, cu, i, b_)
    H.ctrl(bN)
    c.wait(0)
    vehicle.set_vehicle_tire_smoke_color(bN, cu[1], cu[2], cu[3])
    vehicle.set_vehicle_custom_primary_colour(bN, cm({cu[1], cu[2], cu[3]}))
    vehicle.set_vehicle_custom_secondary_colour(bN, cm({cu[1], cu[2], cu[3]}))
    vehicle.set_vehicle_custom_pearlescent_colour(bN, cm({cu[1], cu[2], cu[3]}))
    vehicle.set_vehicle_neon_lights_color(bN, cm({cu[1], cu[2], cu[3]}))
    if i == nil then
        i = 0
    end
    if cu[1] > 200 and cu[1] < 256 and cu[2] > 200 and cu[2] < 256 and cu[3] > 220 and cu[3] < 256 then
        i = 0
    end
    if cu[1] >= 0 and cu[1] < 30 and cu[2] >= 0 and cu[2] < 50 and cu[3] > 220 and cu[3] < 256 then
        i = 1
    end
    if cu[1] >= 0 and cu[1] < 30 and cu[2] >= 50 and cu[2] < 110 and cu[3] > 220 and cu[3] < 256 then
        i = 2
    end
    if cu[1] >= 0 and cu[1] < 30 and cu[2] >= 110 and cu[2] < 256 and cu[3] > 100 and cu[3] <= 220 then
        i = 3
    end
    if cu[1] >= 30 and cu[1] < 120 and cu[2] >= 110 and cu[2] < 256 and cu[3] >= 0 and cu[3] <= 100 then
        i = 4
    end
    if cu[1] >= 120 and cu[1] < 256 and cu[2] >= 110 and cu[2] < 256 and cu[3] >= 0 and cu[3] < 100 then
        i = 5
    end
    if cu[1] >= 120 and cu[1] < 256 and cu[2] >= 110 and cu[2] < 200 and cu[3] >= 0 and cu[3] < 100 then
        i = 6
    end
    if cu[1] >= 120 and cu[1] < 256 and cu[2] > 45 and cu[2] < 109 and cu[3] >= 0 and cu[3] < 100 then
        i = 7
    end
    if cu[1] >= 120 and cu[1] < 256 and cu[2] >= 0 and cu[2] <= 45 and cu[3] >= 0 and cu[3] < 100 then
        i = 8
    end
    if cu[1] >= 120 and cu[1] < 256 and cu[2] > 45 and cu[2] < 100 and cu[3] >= 50 and cu[3] < 150 then
        i = 9
    end
    if cu[1] >= 120 and cu[1] < 256 and cu[2] >= 0 and cu[2] <= 45 and cu[3] >= 150 and cu[3] < 256 then
        i = 10
    end
    if cu[1] >= 0 and cu[1] < 120 and cu[2] >= 0 and cu[2] <= 45 and cu[3] >= 150 and cu[3] < 256 then
        i = 11
    end
    if cu[1] >= 0 and cu[1] < 30 and cu[2] >= 0 and cu[2] <= 45 and cu[3] >= 150 and cu[3] < 256 then
        i = 12
    end
    if b_ ~= nil then
        i = b_
    end
    vehicle.set_vehicle_headlight_color(bN, i)
end
local function cv(id, cw, cx)
    r("Detected Chat-Command!")
    r(K.name(id) .. ":" .. K.scid(id))
    r("Is trying to perform " .. cx .. " as a Chat-Command!")
    if V.t["chat_cmd_friends"] and player.is_player_friend(id) or id == c.id() or V.t["chat_cmd_all"] then
        local cy
        if cw ~= nil then
            cy = cq(cw)
        else
            r("User is entitled to perfrom Command! Executing...")
            o("Performing " .. cx .. " Command for Player: " .. K.name(id) .. " on: " .. K.name(id))
            return true, plid
        end
        if cy ~= -1 then
            if cy == c.id() or player.is_player_friend(cy) and V.t["exclude_friends"].on and cy ~= c.id() then
                o(K.name(id) .. " tried to perform a Command on you or a friend!")
                r("Blocked from Performing Command!")
                return false
            else
                r("User is entitled to perfrom Command! Executing...")
                o("Performing " .. cx .. " Command for Player: " .. K.name(id) .. " on: " .. K.name(cy))
                return true, cy
            end
        end
    end
    r("Command / format / player not found / entitled. Breaking up on performing it.")
    return false
end
local function cz()
    r("Loading Chat-Listeners...")
    bd["chat_log"] =
        event.add_event_listener(
        "chat",
        function(I)
            if V.t["chat_log"].on then
                r("[" .. K.scid(I.player) .. ":" .. K.name(I.player) .. "] " .. I.body, "[CHAT]")
            end
        end
    )
    bd["chat_russki"] =
        event.add_event_listener(
        "chat",
        function(I)
            local id = I.player
            if V.t["chat_russki"].on and S.i(id) then
                local f = I.body
                for i = 1, #aN do
                    if string.find(f, aN[i], 1) ~= nil then
                        r("Detected '" .. aN[i] .. "' as a Russki Char!")
                        r("Preparing to Kick " .. K.name(id) .. ".")
                        o("Detected " .. K.name(id) .. " typing forbidden Russki! Kicking Player...", 115)
                        c2(false, id)
                        f = ""
                    end
                end
            end
        end
    )
    bd["chat_begger"] =
        event.add_event_listener(
        "chat",
        function(I)
            local id = I.player
            if V.t["chat_begger"].on and S.i(id) then
                local f = I.body
                for i = 1, #aO do
                    if string.find(f, aO[i], 1) ~= nil then
                        r("Detected " .. K.name(id) .. " begging for Money! Punishing Player...")
                        o("Detected " .. K.name(id) .. " begging for Money! Punishing Player...", 115)
                        c6(aS[5][2], id)
                        c6(aS[8][2], id)
                        local aq = c.gcoords(c.ped(id))
                        local cA = c.ped(id)
                        c.explode(aq, 59, false, true, 1, cA)
                        c.explode(aq, 8, false, true, 1, cA)
                        c.explode(aq, 59, false, true, 1, cA)
                    end
                end
            end
        end
    )
    bd["chat_cmd"] =
        event.add_event_listener(
        "chat",
        function(I)
            if V.t["chat_cmd"].on then
                local id = I.player
                local f = I.body
                if V.t["cmd_explode"] and string.find(f, "!explode ", 1) ~= nil then
                    f = string.gsub(f, "!explode ", "")
                    local cB, cy = cv(id, f, "Explode")
                    if cB then
                        local aq = c.gcoords(c.ped(cy))
                        local cA = c.ped(id)
                        c.explode(aq, 59, false, true, 1, cA)
                        c.explode(aq, 8, false, true, 1, cA)
                        c.explode(aq, 59, false, true, 1, cA)
                    end
                end
                if V.t["cmd_explode_all"] and string.find(f, "!explodeall", 1) ~= nil and id == c.id() then
                    r("Detected !explodeall Command! Script-User is entitled, performing...")
                    for i = 0, 31 do
                        if S.i(i) then
                            c.explode(c.gcoords(c.ped(i)), 59, true, false, 1, c.ped(c.id()))
                        end
                    end
                end
                if V.t["cmd_kick"] and string.find(f, "!kick ", 1) ~= nil then
                    f = string.gsub(f, "!kick ", "")
                    local cB, cy = cv(id, f, "Kick")
                    if cB then
                        c2(false, cy)
                    end
                end
                if V.t["cmd_kick_all"] and string.find(f, "!kickall", 1) ~= nil and id == c.id() then
                    r("Detected !kickall Command! Script-User is entitled, performing...")
                    c2(true)
                end
                if V.t["cmd_crash"] and string.find(f, "!crash ", 1) ~= nil then
                    r("Detected !crash Command!")
                    f = string.gsub(f, "!crash ", "")
                    local cw = cq(f)
                    if cw ~= -1 then
                        if cw == c.id() then
                            ce(id)
                        elseif S.i(cw) then
                            ce(cw)
                        end
                    end
                end
                if V.t["cmd_crash_all"] and string.find(f, "!crashall", 1) ~= nil and id == c.id() then
                    r("Detected !crashall Command! Script-User is entitled, performing...")
                    for i = 0, 31 do
                        if S.i(i) then
                            ce(i)
                        end
                    end
                end
                if V.t["cmd_lag"] and string.find(f, "!lag ", 1) ~= nil then
                    f = string.gsub(f, "!lag ", "")
                    local cB, cy = cv(id, f, "Lag")
                    if cB and #aI["lag_area"] < 101 then
                        cd(cy, 0x15F27762)
                    end
                end
                if V.t["cmd_trap"] and string.find(f, "!trap ", 1) ~= nil then
                    f = string.gsub(f, "!trap ", "")
                    local cB, cy = cv(id, f, "Trap")
                    if cB then
                        local aq = c.gcoords(c.ped(cy))
                        entity.set_entity_rotation(ao.object(1125864094, v3(aq.x, aq.y, aq.z - 5)), v3(0, 90, 0))
                    end
                end
                if V.t["cmd_tp"] and string.find(f, "!tp ", 1) ~= nil and id == c.id() then
                    r("Detected !tp Command! Script-User is entitled, performing...")
                    f = string.gsub(f, "!tp ", "")
                    local cw = cq(f)
                    if cw ~= -1 then
                        local bL = 10
                        local aq = c.gcoords(c.ped(cw))
                        if aq.z < -50 then
                            bL = 150
                        end
                        bK(c.ped(cw), bL)
                    end
                end
                if V.t["cmd_clearwanted"] and string.find(f, "!clearwanted", 1) ~= nil then
                    local cB, cy = cv(id, nil, "Clearwanted")
                    if cB then
                        c.script(0xf63f672f, id, {id, script.get_global_i(1628955 + 1 + id * 614 + 532)})
                    end
                end
                if V.t["cmd_vehicle"] and string.find(f, "!vehicle ", 1) ~= nil then
                    f = string.gsub(f, "!vehicle ", "")
                    local cB, cy = cv(id, nil, "Vehicle")
                    if cB then
                        local ap = gameplay.get_hash_key(f)
                        if streaming.is_model_a_vehicle(ap) then
                            H.model(ap)
                            local as = player.get_player_heading(id)
                            local cC = ao.vehicle(ap, ck(c.gcoords(c.ped(id)), as, 10), as)
                            H.ctrl(cC)
                            c.unload(ap)
                            vehicle.set_vehicle_custom_primary_colour(cC, 0)
                            vehicle.set_vehicle_custom_secondary_colour(cC, 0)
                            vehicle.set_vehicle_custom_pearlescent_colour(cC, 0)
                            vehicle.set_vehicle_custom_wheel_colour(cC, 0)
                            vehicle.set_vehicle_window_tint(cC, 1)
                            decorator.decor_set_int(cC, "MPBitset", 1 << 10)
                            ch(cC)
                            ped.set_ped_into_vehicle(c.ped(id), cC, -1)
                        end
                    end
                end
                if V.t["cmd_bigpp"] and string.find(f, "!bigpp ", 1) ~= nil then
                    f = string.gsub(f, "!bigpp ", "")
                    local cB, cy = cv(id, f, "Bigpp")
                    if cB then
                        c6(aS[5][2], cy)
                    end
                end
                if V.t["cmd_bigppall"] and string.find(f, "!bigppall", 1) ~= nil and id == c.id() then
                    r("Detected !bigppall Command! Script-User is entitled, performing...")
                    for i = 0, 31 do
                        if S.i(i) then
                            c6(aS[5][2], id)
                        end
                    end
                end
            end
        end
    )
end
cz()
local function cD(c7)
    r("Blocking Area.")
    for i = 1, #c7 do
        if c7[i][1] ~= false then
            H.model(c7[i][1])
            aI["bl_objects"][#aI["bl_objects"] + 1] = ao.object(c7[i][1])
            c.unload(c7[i][1])
            local aq
            if c7[i][2][1] == nil then
                aq =
                    v3(
                    c.random(c7[i][2][2], c7[i][2][3]),
                    c.random(c7[i][2][4], c7[i][2][5]),
                    c.random(c7[i][2][6], c7[i][2][7])
                )
            else
                aq = v3(c7[i][2][1], c7[i][2][2], c7[i][2][3])
            end
            bG(aI["bl_objects"][#aI["bl_objects"]], aq)
            entity.set_entity_rotation(aI["bl_objects"][#aI["bl_objects"]], v3(c7[i][3][1], c7[i][3][2], c7[i][3][3]))
            if c7[i][4] then
                entity.freeze_entity(aI["bl_objects"][#aI["bl_objects"]], true)
            end
            if c7[i][5] then
                c.visible(aI["bl_objects"][#aI["bl_objects"]], false)
            end
        else
            if c7[i] ~= nil then
                if V.t["teleport_to_block"].on then
                    bK(v3(c7[i][2][1], c7[i][2][2], c7[i][2][3]), nil, c7[i][3])
                end
            end
        end
    end
    r("Blocking Done.")
end
local function cE(an, cF, cG, cH, cI, id)
    r("Sending Script Events to Player.")
    local i = 0
    while i < 32 do
        if an then
            id = i
        else
            i = 99
        end
        if S.i(id) then
            if cF ~= 0 and cF ~= nil then
                c.script(cF, id, cG)
                r("SE 1 : " .. cF)
                r("Sent to Player: " .. K.name(id))
            end
            if cH ~= 0 and cH ~= nil then
                c.script(cH, id, cI)
                r("SE 2 : " .. cH)
                r("Sent to Player: " .. K.name(id))
            end
        end
        i = i + 1
    end
    r("Done.")
end
local function cJ()
    if b9 then
        bU(b8, nil, nil, nil, true)
        c.wait(250)
        ped.set_ped_health(R.ped(), 0)
        c.wait(3500)
        local cK = aJ["session_crash"]["clothes"]
        local cL = aJ["session_crash"]["textures"]
        for i = 1, 11 do
            ped.set_ped_component_variation(R.ped(), i, cK[i], cL[i], 2)
        end
        local af = {0, 1, 2, 6, 7}
        local ag = aJ["session_crash"]["prop_ind"]
        local ah = aJ["session_crash"]["prop_text"]
        for aj = 1, #af do
            ped.set_ped_prop_index(R.ped(), af[aj], ag[aj], ah[aj], 0)
        end
    else
        o("First Crash Session.")
    end
end
local function cM(cN, cw, cO, cP)
    if type(cO) == "table" then
        if cO[1] == 0xfaaab4a3 then
            if cO[2] == 6666 then
                table.remove(cO, 1)
                table.remove(cO, 1)
                local cQ = utf8.char(table.unpack(cO))
                o(cQ, K.name(cN), 47)
                r(K.name(cN) .. ": " .. cQ)
            end
        end
        for i = 1, #bC do
            if bC[i] == cO[1] and #cO == 5 then
                local cR = bC[c.random(1, #bC)]
                local plid = c.id()
                local cS = c.random(-10, 100)
                c.script(cR, cN, {plid, cO[3], cO[4], cS})
            end
        end
    end
end
hook.register_script_event_hook(cM)
local function cT()
    local cU = bl["llbone"]
    local cV = bl["rlbone"]
    local cW = bl["tampa"]
    local cX = v3(-4.25, 0, 12.5)
    local cY = v3(4.25, 0, 12.5)
    if cU ~= nil and cV ~= nil and cW ~= nil then
        if entity.is_an_entity(cU) and entity.is_an_entity(cV) and entity.is_an_entity(cW) then
            H.ctrl(cU)
            H.ctrl(cV)
            H.ctrl(cW)
            c.attach(cU, cW, 0, cX, v3(), true, l["robot_collision"], false, 2, true)
            c.attach(cV, cW, 0, cY, v3(), true, l["robot_collision"], false, 2, true)
        end
    end
end
local function cZ(c7, W)
    r("Attempt to spawn Custom Vehicle.")
    c.navigate(false)
    temp_veh = {}
    local aq = v3()
    local c_ = v3()
    local d0 = 0
    local d1 = 0
    local as = 0
    local d2 = false
    local d3 = c.vehicle(R.ped())
    if V.t["spawn_preview"].on and aI["preview_veh"][1] ~= nil then
        bI(aI["preview_veh"])
        aI["preview_veh"] = {}
        b5 = false
        c.wait(250)
    end
    for i = 1, #c7[1] do
        H.model(c7[1][i], 7500)
    end
    for i = 2, #c7 do
        aq = R.coords()
        if c7[i][6] ~= nil and i == 2 then
            aq.z = aq.z + c7[i][6]
        end
        if i > 2 then
            aq.z = aq.z + 25
        end
        if
            V.t["use_own_veh"].on and i == 2 and entity.get_entity_model_hash(d3) == c7[i][1] or
                c7[2][1] == 0 and i == 2 and V.t["use_own_veh"].on and d3 ~= 0
         then
            r("Detected Own Vehicle, using it.")
            temp_veh[i - 1] = d3
            d2 = true
        elseif c7[2][1] == 0 and not V.t["use_own_veh"].on then
            r("Failed at spawning Custom Vehicle.")
            o("No Vehicle found, get in a valid Vehicle")
            c.navigate(true)
            return
        else
            if streaming.is_model_a_vehicle(c7[i][1]) then
                if i == 2 then
                    as = R.heading()
                    if c7[i][11] ~= nil then
                        b6 = c7[i][11]
                    else
                        b6 = 5
                    end
                    if c7[i][12] ~= nil then
                        b4 = c7[i][12]
                    else
                        b4 = 1
                    end
                    aq = ck(aq, as, b6)
                end
                temp_veh[i - 1] = ao.vehicle(c7[i][1], aq, as)
                decorator.decor_set_int(temp_veh[i - 1], "MPBitset", 1 << 10)
                local p = c.random(0, 16777215)
                if c7[i][4] ~= nil then
                    p = c7[i][4][1]
                end
                vehicle.set_vehicle_custom_primary_colour(temp_veh[i - 1], p)
                if c7[i][4] ~= nil then
                    p = c7[i][4][2]
                end
                vehicle.set_vehicle_custom_secondary_colour(temp_veh[i - 1], p)
                if c7[i][4] ~= nil then
                    p = c7[i][4][3]
                end
                vehicle.set_vehicle_custom_pearlescent_colour(temp_veh[i - 1], p)
                if c7[i][4] ~= nil then
                    p = c7[i][4][4]
                end
                vehicle.set_vehicle_custom_wheel_colour(temp_veh[i - 1], p)
                p = c.random(0, 4)
                if c7[i][4] ~= nil then
                    p = c7[i][4][5]
                end
                vehicle.set_vehicle_window_tint(temp_veh[i - 1], p)
                if streaming.is_model_a_plane(c7[i][1]) and i > 2 then
                    vehicle.control_landing_gear(temp_veh[i - 1], 3)
                end
            else
                temp_veh[i - 1] = ao.object(c7[i][1], aq)
            end
        end
        if i > 2 then
            aq.z = aq.z - 25
        end
        if V.t["set_godmode"].on then
            c.god(temp_veh[i - 1], true)
        end
        if c7[i][5] then
            c.visible(temp_veh[i - 1], false)
        end
        if c7[i][13] then
            entity.set_entity_alpha(temp_veh[i - 1], c7[i][13], false)
        end
        if i > 2 then
            d0 = 0
            if c7[i][7] ~= nil then
                d0 = c7[i][7]
            end
            d1 = temp_veh[1]
            if c7[i][8] ~= nil then
                d1 = temp_veh[c7[i][8]]
            end
            local d4 = c7[i][10]
            if d4 == true then
                entity.set_entity_collision(temp_veh[i - 1], false, false, false)
            else
                d4 = false
            end
            aq = v3()
            if c7[i][2] ~= nil then
                aq = v3(c7[i][2][1], c7[i][2][2], c7[i][2][3])
            end
            c_ = v3()
            if c7[i][3] ~= nil then
                c_ = v3(c7[i][3][1], c7[i][3][2], c7[i][3][3])
            end
            if c7[i][1] ~= 0 then
                c.attach(temp_veh[i - 1], d1, d0, aq, c_, false, not d4, false, 2, true)
            end
            if c7[i][9] ~= nil then
                local d5
                H.model(c7[i][9])
                aq = R.coords()
                d5 = ao.ped(c7[i][9], aq)
                c.wait(0)
                if V.t["set_godmode"].on then
                    ped.set_ped_max_health(d5, 25000000.0)
                    ped.set_ped_health(d5, 25000000.0)
                    ped.set_ped_can_ragdoll(d5, false)
                    c.god(d5, true)
                end
                c.unload(c7[i][9])
                if c7[i][1] ~= 0 then
                    ped.set_ped_into_vehicle(d5, temp_veh[i - 1], -1)
                    vehicle.set_vehicle_doors_locked(temp_veh[i - 1], 2)
                else
                    aq = v3()
                    if c7[i][2] ~= nil then
                        aq = v3(c7[i][2][1], c7[i][2][2], c7[i][2][3])
                    end
                    c_ = v3()
                    if c7[i][3] ~= nil then
                        c_ = v3(c7[i][3][1], c7[i][3][2], c7[i][3][3])
                    end
                    c.attach(d5, d1, d0, aq, c_, false, not d4, true, 2, true)
                end
            end
        end
        if V.t["spawn_preview"].on then
            aI["preview_veh"][#aI["preview_veh"] + 1] = temp_veh[i - 1]
        elseif W then
            aI[W][#aI[W] + 1] = temp_veh[i - 1]
        else
            aI["custom_veh"][#aI["custom_veh"] + 1] = temp_veh[i - 1]
        end
    end
    if not V.t["spawn_preview"].on then
        if V.t["auto_get_in"].on then
            ped.set_ped_into_vehicle(R.ped(), temp_veh[1], -1)
        end
    end
    if not d2 then
        ch(temp_veh[1])
    end
    for i = 1, #c7[1] do
        c.unload(c7[1][i])
    end
    c.navigate(true)
    r("Spawn Custom Vehicle Done.")
end
local function d6()
    r("Loading Features...")
    if l["2t1s_parent"] then
        V.p["parent"] = V.add.p("2Take1Script", 0).id
    end
    V.p["bl"] = V.add.p("Blacklist", V.p["parent"])
    V.p["bl"].hidden = l["bl_hidden"]
    V.p["bl"] = V.p["bl"].id
    V.t["blacklist_enabled"] =
        V.add.t(
        "Enable Blacklist",
        V.p["bl"],
        function(k)
            l["blacklist_enabled"] = k.on
            if k.on then
                c.wait(1000)
                bX()
                for i = 0, 31 do
                    if S.i(i) then
                        for d7 = 1, #ba do
                            if tostring(K.scid(i)) == ba[d7] then
                                local j = K.name(i)
                                o("Blocked player detected.", 27)
                                o("Current name: " .. j .. "\nReal name: " .. bb[d7], 27)
                                r("")
                                r("Blocked Player detected.")
                                r(j .. ":" .. ba[d7])
                                r("Real name:" .. bb[d7])
                                if V.t["mark_modder"].on then
                                    player.set_player_as_modder(i, n["blacklist"][2])
                                end
                                if V.t["auto_kick"].on then
                                    c2(false, i)
                                end
                            end
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    V.t["blacklist_enabled"].on = l["blacklist_enabled"]
    V.t["auto_kick"] =
        V.add.t(
        "Enable Auto-Kick",
        V.p["bl"],
        function(k)
            l["auto_kick"] = k.on
        end
    )
    V.t["auto_kick"].on = l["auto_kick"]
    V.t["mark_modder"] =
        V.add.t(
        "Mark as Modder",
        V.p["bl"],
        function(k)
            l["mark_modder"] = k.on
        end
    )
    V.t["mark_modder"].on = l["mark_modder"]
    V.add.a(
        "Add player by SCID",
        V.p["bl"],
        function()
            local a3 = K.input("Enter SCID", 12, 3)
            local j = K.input("Enter Name")
            if not a3 or not j then
                return HANDLER_POP
            end
            if j ~= "" and a3 ~= "0" and a3 ~= "-1" and a3 ~= tostring(K.scid(c.id())) then
                d.write(c.o(b["Blacklist"], "a"), a3 .. " " .. j)
                o("SCID with Name added to Blacklist.", 48)
                r("")
                r("Player added to Blacklist.")
                r(j .. ": " .. a3)
            end
        end
    )
    V.add.a(
        "Count Currently Blocked Players",
        V.p["bl"],
        function()
            bX()
            if ba ~= nil then
                o("Currently blocking " .. #ba .. " Players.")
            end
        end
    )
    V.t["enable_admin"] =
        V.add.t(
        "Notify on Rockstar Admin SCID",
        V.p["bl"],
        function(k)
            if k.on then
                c.wait(1000)
                for i = 0, 31 do
                    if S.i(i) then
                        for d7 = 1, #aH do
                            if tostring(K.scid(i)) == aH[d7] then
                                local j = K.name(i)
                                o("Rockstar Admin by SCID detected!\nName: " .. j, 27)
                                r("Rockstar Admin detected.")
                                r(j .. ":" .. K.scid(i))
                                if V.t["kick_admin"].on then
                                    c2(false, i)
                                end
                                if V.t["crash_admin"].on then
                                    ce(i)
                                end
                            end
                        end
                    end
                end
            end
            l["admin_enabled"] = k.on
            return d.stop(k)
        end
    )
    V.t["enable_admin"].on = l["admin_enabled"]
    V.t["kick_admin"] =
        V.add.t(
        "Enable Auto-Kick Rockstar Admin",
        V.p["bl"],
        function()
            o(
                "Thats the stupidest idea you ever had! Dont enable it, disable it!\nThis will get u banned for like 99%!",
                27
            )
        end
    )
    V.t["kick_admin"].hidden = not b0
    V.t["crash_admin"] =
        V.add.t(
        "Enable Auto-Crash Rockstar Admin",
        V.p["bl"],
        function()
            o(
                "Thats the stupidest idea you ever had! Dont enable it, disable it!\nThis will get u banned for like 99%!",
                27
            )
        end
    )
    V.t["crash_admin"].hidden = not b0
    V.t["kick_joining"] =
        V.add.t(
        "Kick new joining Players",
        V.p["bl"],
        function(k)
            if k.on then
                local time = c.time() + 2500
                while time > c.time() do
                    c.wait(250)
                    l["kick_joining"] = k.on
                end
                if bt[1] == nil then
                    for i = 0, 31 do
                        bt[i + 1] = K.scid(i)
                        bu[K.scid(i)] = 0
                    end
                end
                for i = 0, 31 do
                    if S.i(i) then
                        local C = true
                        for E = 1, #bt do
                            if bt[E] == K.scid(i) then
                                C = false
                            end
                        end
                        if C then
                            if bu[bt[i + 1]] <= 3 then
                                o(K.name(i) .. " is new here, sending greetings..!", 65)
                                r(K.name(i) .. " is new here, sending greetings..!")
                                c2(false, i)
                                bu[bt[i + 1]] = bu[bt[i + 1]] + 1
                            else
                                bu[bt[i + 1]] = bu[bt[i + 1]] + 1
                                if bu[bt[i + 1]] >= 17 then
                                    bu[bt[i + 1]] = 0
                                end
                            end
                        end
                    end
                end
            end
            if not k.on then
                bu = {}
                for i = 0, 31 do
                    bt[i + 1] = nil
                end
            end
            l["kick_joining"] = k.on
            return d.stop(k)
        end
    )
    V.t["kick_joining"].on = l["kick_joining"]
    V.p["modder"] = V.add.p("Modders", V.p["parent"])
    V.p["modder"].hidden = l["modder_hidden"]
    V.p["modder"] = V.p["modder"].id
    V.t["remember_modder"] =
        V.add.t(
        "Remember every Modder",
        V.p["modder"],
        function(k)
            if k.on then
                if c.f_exists(b["Modders"]) then
                    local F = c.o(b["Modders"], "r")
                    if F ~= nil then
                        local cb = {}
                        bc = {}
                        for d8 in io.lines(b["Modders"]) do
                            while string.find(d8, " ", 1) ~= nil do
                                d8 = d8:gsub("(.*)%s.*$", "%1")
                            end
                            cb[#cb + 1] = d8
                        end
                        bc = cb
                        io.close(F)
                    end
                end
                for i = 0, 31 do
                    if S.i(i) then
                        local a3 = K.scid(i)
                        local d9 = false
                        if bc[1] ~= nil then
                            for da = 1, #bc do
                                if tostring(a3) == bc[da] then
                                    d9 = true
                                    if not player.is_player_modder(i, -1) then
                                        o("Remembered " .. K.name(i) .. " as a Modder, remarking...", 130)
                                        r("Remembered '" .. K.name(i) .. "' as a Modder, remarking...")
                                        player.set_player_as_modder(i, n["remembered"][2])
                                    end
                                end
                            end
                        end
                        if player.is_player_modder(i, -1) and not d9 then
                            d.write(c.o(b["Modders"], "a"), a3 .. " " .. K.name(i))
                            o("Modder " .. K.name(i) .. " added to Remember-List.", 130)
                            r("Modder '" .. K.name(i) .. "' added to Remember-List.")
                        end
                    end
                end
            end
            l["remember_modder"] = k.on
            return d.stop(k)
        end
    )
    V.t["remember_modder"].on = l["remember_modder"]
    V.p["unmark_friends"] =
        V.add.t(
        "Unmark Friends",
        V.p["modder"],
        function(k)
            l["unmark_friends"] = k.on
            if k.on then
                for i = 0, 31 do
                    if c.valid(i) and player.is_player_friend(i) and player.is_player_modder(i, -1) then
                        player.unset_player_as_modder(i, -1)
                    end
                end
                c.wait(250)
            end
            return d.stop(k)
        end
    )
    V.p["unmark_friends"].on = l["unmark_friends"]
    V.add.a("Modder-Detection:", V.p["modder"])
    V.t["speed_bypass"] =
        V.add.t(
        "Max-Speed-Bypass",
        V.p["modder"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    local a3 = K.scid(i)
                    if
                        S.modder(i) and player.get_player_health(i) ~= 0 and
                            interior.get_interior_from_entity(c.ped(i)) == 0
                     then
                        local db = 45
                        local id = c.ped(i)
                        if
                            ai.is_task_active(id, 403) or ai.is_task_active(id, 408) or ai.is_task_active(id, 335) or
                                ai.is_task_active(id, 2) or
                                ai.is_task_active(id, 422)
                         then
                            db = 95
                        end
                        if ai.is_task_active(id, 97) or ai.is_task_active(id, 38) or ai.is_task_active(id, 160) then
                            db = 60
                        end
                        if ai.is_task_active(id, 50) or ai.is_task_active(id, 1) then
                            db = 100
                        end
                        local bN = c.vehicle(id)
                        if bN ~= 0 then
                            if id == vehicle.get_ped_in_vehicle_seat(bN, -1) then
                                id = bN
                                local ap = entity.get_entity_model_hash(bN)
                                if streaming.is_model_a_plane(ap) then
                                    db = 170
                                else
                                    db = 100
                                end
                            end
                        end
                        local dc = entity.get_entity_speed(id)
                        dc = math.floor(dc)
                        if dc > db then
                            o(
                                K.name(i) ..
                                    " bypassed Max-Speed-Limit of: " ..
                                        db .. " with a speed of: " .. dc .. "\nMarking him as a Modder...",
                                130
                            )
                            r(K.name(i) .. " bypassed Max-Speed-Limit of: " .. db .. " with a speed of: " .. dc)
                            r("Marking him as a Modder...")
                            for da = 0, 600 do
                                if ai.is_task_active(c.ped(i), da) then
                                    r("Current active Task: " .. da)
                                end
                            end
                            player.set_player_as_modder(i, n["maxspeed"][2])
                        end
                    end
                end
            end
            l["speed_bypass"] = k.on
            return d.stop(k)
        end
    )
    V.t["speed_bypass"].on = l["speed_bypass"]
    V.t["name_bypass"] =
        V.add.t(
        "Illegal Name",
        V.p["modder"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    local a3 = K.scid(i)
                    if S.modder(i) then
                        local j = K.name(i)
                        if string.len(j) < 6 or string.len(j) > 16 or not string.find(j, "^[%.%-%w_]+$") then
                            o(j .. " has an illegal name!\nMarking him as a Modder...", 130)
                            r(j .. " has an illegal name!")
                            r("Marking him as a Modder...")
                            player.set_player_as_modder(i, n["illegalname"][2])
                        end
                    end
                end
            end
            l["name_bypass"] = k.on
            return d.stop(k)
        end
    )
    V.t["name_bypass"].on = l["name_bypass"]
    V.t["modded_scid"] =
        V.add.t(
        "Modded SCID",
        V.p["modder"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    system.wait(25)
                    if S.modder(i) then
                        local a3 = K.scid(i)
                        if a3 < 10000 or a3 > 222222222 then
                            local j = K.name(i)
                            o(j .. " has an modded SCID!\nMarking him as a Modder...", 130)
                            r(j .. " has an modded SCID!")
                            r("Marking him as a Modder...")
                            player.set_player_as_modder(i, n["moddedscid"][2])
                        end
                    end
                end
            end
            l["modded_scid"] = k.on
            return d.stop(k)
        end
    )
    V.t["modded_scid"].on = l["modded_scid"]
    V.t["modded_net_events"] =
        V.add.t(
        "Modded Net-Events",
        V.p["modder"],
        function()
            if by == nil then
                by =
                    hook.register_net_event_hook(
                    function(cN, cw, dd)
                        if S.modder(cN) and cw == c.id() then
                            local de = false
                            for i = 1, #bz do
                                if dd == bz[i] then
                                    de = true
                                end
                            end
                            if dd == 9 and not player.is_player_host(cN) then
                                de = true
                            end
                            if dd == 10 and bA == nil then
                                bA = cN
                                bB = c.time()
                                de = true
                            end
                            if bB ~= nil then
                                if bB + 30000 < c.time() then
                                    bB = nil
                                    bA = nil
                                end
                            end
                            if de then
                                o(K.name(cN) .. " sent a Bad Net-Event: " .. dd, 130)
                                o("Marking him as a Modder!", 130)
                                r(K.name(cN) .. " sent a Bad Net-Event: " .. dd)
                                player.set_player_as_modder(cN, n["moddednetevent"][2])
                                return true
                            end
                        end
                    end
                )
            else
                hook.remove_net_event_hook(by)
                by = nil
            end
            l["modded_net_events"] = V.t["modded_net_events"].on
        end
    )
    V.t["modded_net_events"].on = l["modded_net_events"]
    V.t["modder_force_sh"] =
        V.add.t(
        "Forcing Script-Host",
        V.p["modder"],
        function(k)
            l["modder_force_sh"] = k.on
            if k.on then
                if bg == nil then
                    bg = script.get_host_of_this_script()
                end
                local time = c.time() + 17500
                while time > c.time() do
                    c.wait(250)
                    l["modder_force_sh"] = k.on
                end
                local df = script.get_host_of_this_script()
                if not c.valid(bg) or K.scid(bg) == -1 then
                    bg = nil
                end
                if bg ~= nil then
                    if bg ~= df then
                        if c.valid(bg) and c.valid(df) then
                            if K.scid(bg) ~= -1 and K.scid(df) ~= -1 then
                                r("Script-Host changed without previous SH leaving!")
                                r("SH changed from '" .. K.name(bg) .. "' to '" .. K.name(df) .. "'.")
                                o("Script-Host changed from '" .. K.name(bg) .. "' to '" .. K.name(df) .. "'.", 130)
                                player.set_player_as_modder(df, n["force_sh"][2])
                                bg = df
                            end
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    V.t["modder_force_sh"].on = l["modder_force_sh"]
    V.t["modded_script_event"] =
        V.add.t(
        "Modded Script Event",
        V.p["modder"],
        function(k)
            l["modded_script_event"] = k.on
            if k.on then
                if bx == nil then
                    bx =
                        hook.register_script_event_hook(
                        function(cN, cw, cO, cP)
                            local de = false
                            if #cO > 1 then
                                if cN ~= cO[2] then
                                    de = true
                                end
                            else
                                de = true
                            end
                            if de then
                                o("Detected '" .. K.name(cN) .. "' sending a modded Script Event!", 130)
                                r("Detected '" .. K.name(cN) .. "' sending a modded Script Event!")
                                local c3 = cO[1] .. ", {"
                                for i = 2, #cO do
                                    c3 = c3 .. cO[i]
                                    if i ~= #cO then
                                        c3 = c3 .. ", "
                                    end
                                end
                                c3 = c3 .. "}"
                                r(c3)
                                player.set_player_as_modder(cN, n["script"][2])
                            end
                        end
                    )
                end
            end
            if not k.on then
                if bx ~= nil then
                    hook.remove_script_event_hook(bx)
                    bx = nil
                end
            end
            return d.stop(k)
        end
    )
    V.t["modded_script_event"].on = l["modded_script_event"]
    V.p["lobby"] = V.add.p("Lobby", V.p["parent"])
    V.p["lobby"].hidden = l["lobby_hidden"]
    V.p["lobby"] = V.p["lobby"].id
    V.p["bl_veh"] = V.add.p("Block Vehicles in Session", V.p["lobby"]).id
    V.t["veh_blacklist"] =
        V.add.t(
        "Activate Block Vehicles",
        V.p["bl_veh"],
        function(k)
            l["veh_blacklist"] = k.on
            if k.on then
                local time = c.time() + 2000
                while time > c.time() do
                    c.wait(200)
                    l["veh_blacklist"] = k.on
                end
                for i = 0, 31 do
                    if S.i(i) then
                        local bN = c.vehicle(c.ped(i))
                        if bN ~= 0 then
                            bN = entity.get_entity_model_hash(bN)
                            for b_ = 1, #aB do
                                if V.t[aB[b_][1]].on and bN == aB[b_][2] then
                                    r("Detected Blacklisted Vehicle " .. aB[b_][1] .. " in Session!")
                                    bN = c.vehicle(c.ped(i))
                                    H.ctrl(bN, 100)
                                    if entity.get_entity_god_mode(bN) then
                                        H.ctrl(bN)
                                        c.god(bN, false)
                                    end
                                    if not entity.get_entity_god_mode(bN) then
                                        r("Exploding User: " .. K.name(i))
                                        o(
                                            "Detected Blacklisted Vehicle " ..
                                                aB[b_][1] .. " from user: " .. K.name(i) .. ", exploding it!",
                                            28
                                        )
                                        entity.set_entity_velocity(bN, v3())
                                        vehicle.set_vehicle_forward_speed(bN, 0)
                                        vehicle.set_vehicle_out_of_control(bN, false, true)
                                        c.explode(c.gcoords(c.ped(i)), 59, false, true, 1, c.ped(i))
                                    end
                                end
                            end
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    V.t["veh_blacklist"].on = l["veh_blacklist"]
    for i = 1, #aB do
        V.t[aB[i][1]] =
            V.add.t(
            "Block: " .. aB[i][1],
            V.p["bl_veh"],
            function(k)
                l[aB[i][1]] = k.on
            end
        )
        V.t[aB[i][1]].on = l[aB[i][1]]
    end
    V.p["bl_area"] = V.add.p("Block Areas", V.p["lobby"]).id
    V.t["teleport_to_block"] =
        V.add.t(
        "Teleport to Block",
        V.p["bl_area"],
        function(k)
            l["teleport_to_block"] = k.on
        end
    )
    V.t["teleport_to_block"].on = l["teleport_to_block"]
    V.add.a(
        "Clear blocking Objects",
        V.p["bl_area"],
        function()
            bI(aI["bl_objects"])
            aI["bl_objects"] = {}
        end
    )
    V.p["bl_area_lsc"] = V.add.p("Block LSCs", V.p["bl_area"]).id
    for i = 1, #aD do
        V.add.a(
            aD[i][1],
            V.p["bl_area_lsc"],
            function()
                cD(aD[i][2])
            end
        )
    end
    V.p["bl_area_casino"] = V.add.p("Block Casino", V.p["bl_area"]).id
    for i = 1, #aE do
        V.add.a(
            aE[i][1],
            V.p["bl_area_casino"],
            function()
                cD(aE[i][2])
            end
        )
    end
    V.p["bl_area_mazebank"] = V.add.p("Block Maze Bank", V.p["bl_area"]).id
    for i = 1, #aF do
        V.add.a(
            aF[i][1],
            V.p["bl_area_mazebank"],
            function()
                cD(aF[i][2])
            end
        )
    end
    V.p["bl_area_custom"] = V.add.p("Custom Areas", V.p["bl_area"]).id
    for i = 1, #aR do
        V.add.a(
            aR[i][1],
            V.p["bl_area_custom"],
            function()
                cD(aR[i][2])
            end
        )
    end
    V.p["explode"] = V.add.p("Explosion-Features", V.p["lobby"]).id
    V.t["laser_beam_explode_waypoint"] =
        V.add.a(
        "Laser Beam Explode Waypoint",
        V.p["explode"],
        function()
            local dg = ui.get_waypoint_coord()
            if dg.x ~= 16000 then
                local dh = c.gcoords(R.ped()).z + 175
                for i = dh, -50, -2 do
                    local aq = v3(dg.x, dg.y, i)
                    aq.x = math.floor(aq.x)
                    aq.y = math.floor(aq.y)
                    c.explode(aq, 59, true, false, 0, 0)
                    for b_ = 1, 2 do
                        aq.x = c.random(aq.x - 3, aq.x + 3)
                        aq.y = c.random(aq.y - 3, aq.y + 3)
                        c.explode(aq, 59, true, false, 0, 0)
                    end
                    aq.x = c.random(aq.x - 6, aq.x + 6)
                    aq.y = c.random(aq.y - 6, aq.y + 6)
                    c.explode(aq, 8, true, false, 0, 0)
                    c.wait(0)
                end
            else
                o("No Waypoint found, set a waypoint first!")
            end
        end
    )
    V.t["explode_lobby"] =
        V.add.u(
        "Random Explosions",
        "value_i",
        V.p["explode"],
        function(k)
            if k.on then
                for i = 1, 5 do
                    c.explode(
                        v3(c.random(-2700, 2700), c.random(-3300, 7500), c.random(30, 90)),
                        k.value_i,
                        true,
                        false,
                        0,
                        0
                    )
                end
            end
            l["explode_lobby_value"] = k.value_i
            l["explode_lobby"] = k.on
            return d.stop(k)
        end
    )
    V.t["explode_lobby"].max_i = 74
    V.t["explode_lobby"].min_i = 0
    V.t["explode_lobby"].value_i = l["explode_lobby_value"]
    V.t["explode_lobby"].on = l["explode_lobby"]
    V.t["explode_lobby_shake"] =
        V.add.t(
        "Shake Cam",
        V.p["explode"],
        function(k)
            if k.on then
                local aq = v3()
                for i = 1, 10 do
                    aq.x = c.random(-2700, 2700)
                    aq.y = c.random(-3300, 7500)
                    aq.z = c.random(30, 90)
                    c.explode(aq, 8, false, true, 20, 0)
                end
            end
            l["explode_lobby_shake"] = k.on
            return d.stop(k)
        end
    )
    V.t["explode_lobby_shake"].on = l["explode_lobby_shake"]
    V.p["sound"] = V.add.p("Sound-Features", V.p["lobby"]).id
    V.t["sound_rape"] =
        V.add.t(
        "Sound Rape",
        V.p["sound"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    if S.i(i) then
                        audio.play_sound_from_entity(2, "Wasted", c.ped(i), "DLC_IE_VV_General_Sounds")
                    end
                end
            end
            l["sound_rape"] = k.on
            return d.stop(k)
        end
    )
    V.t["sound_rape"].on = l["sound_rape"]
    V.add.a(
        "Garage-Door Sound - Infinite Time",
        V.p["sound"],
        function()
            for i = 0, 31 do
                if S.i(i) then
                    audio.play_sound_from_entity(2, "Garage_Door", c.ped(i), "DLC_HEISTS_GENERIC_SOUNDS")
                end
            end
        end
    )
    V.t["kill_all_peds"] =
        V.add.t(
        "Kill all PEDs",
        V.p["lobby"],
        function(k)
            if k.on then
                local di = ped.get_all_peds()
                for i = 1, #di do
                    if not ped.is_ped_a_player(di[i]) then
                        ped.set_ped_health(di[i], 0)
                    end
                end
            end
            l["kill_all_peds"] = k.on
            return d.stop(k)
        end
    )
    V.t["kill_all_peds"].on = l["kill_all_peds"]
    V.p["lobby_vehicle"] = V.add.p("Vehicles", V.p["lobby"]).id
    V.t["disablecontrol"] =
        V.add.t(
        "Disable Control from near Vehicles",
        V.p["lobby_vehicle"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    if S.i(i) then
                        local bN = c.vehicle(c.ped(i))
                        if bN ~= 0 then
                            H.ctrl(bN)
                            vehicle.set_vehicle_forward_speed(bN, 25)
                            vehicle.set_vehicle_out_of_control(bN, false, true)
                        end
                    end
                end
            end
            l["disablecontrol"] = k.on
            return d.stop(k)
        end
    )
    V.t["disablecontrol"].on = l["disablecontrol"]
    V.t["modify_veh_speed"] =
        V.add.u(
        "Modify Vehicle Speeds",
        "autoaction_value_i",
        V.p["lobby_vehicle"],
        function(k)
            l["modify_veh_speed"] = k.value_i
            local db = 540
            if l["modify_veh_speed_override"] then
                db = k.value_i
            end
            for i = 0, 31 do
                if S.i(i, l["modify_veh_speed_include"]) then
                    local bN = c.vehicle(c.ped(i))
                    if bN ~= 0 then
                        H.ctrl(bN)
                        entity.set_entity_max_speed(bN, db)
                        vehicle.modify_vehicle_top_speed(bN, k.value_i)
                    end
                end
            end
        end
    )
    V.t["modify_veh_speed"].min_i = -500
    V.t["modify_veh_speed"].max_i = 1000
    V.t["modify_veh_speed"].mod_i = 25
    V.t["modify_veh_speed"].value_i = l["modify_veh_speed"]
    V.add.a(
        "Reset Modifies",
        V.p["lobby_vehicle"],
        function()
            local db = 540
            for i = 0, 31 do
                if c.valid(i) then
                    local bN = c.vehicle(c.ped(i))
                    if bN ~= 0 then
                        H.ctrl(bN)
                        entity.set_entity_max_speed(bN, db)
                        vehicle.modify_vehicle_top_speed(bN, 0)
                    end
                end
            end
        end
    )
    V.t["modify_veh_speed_include"] =
        V.add.t(
        "Include Self & Friends",
        V.p["lobby_vehicle"],
        function(k)
            l["modify_veh_speed_include"] = k.on
        end
    )
    V.t["modify_veh_speed_include"].on = l["modify_veh_speed_include"]
    V.t["modify_veh_speed_overwrite"] =
        V.add.t(
        "Overwrite default Speedlimit",
        V.p["lobby_vehicle"],
        function(k)
            l["modify_veh_speed_overwrite"] = k.on
        end
    )
    V.t["modify_veh_speed_overwrite"].on = l["modify_veh_speed_overwrite"]
    V.p["lobby_bounty"] = V.add.p("Bounty", V.p["lobby"]).id
    V.t["bounty_after_death"] =
        V.add.u(
        "Set Bounty after Death",
        "value_i",
        V.p["lobby_bounty"],
        function(k)
            l["bounty_after_death"] = k.on
            l["bounty_after_death_value"] = k.value_i
            if k.on then
                local dj = 0
                if V.t["anonymous_bounty"].on then
                    dj = 1
                end
                for i = 0, 31 do
                    if S.i(i) then
                        if player.get_player_health(i) == 0 then
                            o(K.name(i) .. " is dead!\nSetting bounty...", 33)
                            r(K.name(i) .. " is dead!")
                            r("Setting bounty...")
                            for da = 0, 31 do
                                if K.scid(da) ~= -1 then
                                    c.script(
                                        544453591,
                                        da,
                                        {
                                            69,
                                            i,
                                            1,
                                            V.t["bounty_after_death"].value_i,
                                            0,
                                            dj,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            script.get_global_i(1650640 + 9),
                                            script.get_global_i(1650640 + 10)
                                        }
                                    )
                                end
                            end
                            c.wait(1500)
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    V.t["bounty_after_death"].min_i = 0
    V.t["bounty_after_death"].max_i = 10000
    V.t["bounty_after_death"].value_i = l["bounty_after_death_value"]
    V.t["bounty_after_death"].on = l["bounty_after_death"]
    V.t["anonymous_bounty"] =
        V.add.t(
        "Anonymous Bounty",
        V.p["lobby_bounty"],
        function(k)
            l["anonymous_bounty"] = k.on
        end
    )
    V.t["anonymous_bounty"].on = l["anonymous_bounty"]
    for i = 1, #aX do
        V.add.a(
            aX[i] .. "$",
            V.p["lobby_bounty"],
            function()
                local dj = 0
                if V.t["anonymous_bounty"].on then
                    dj = 1
                end
                for da = 0, 31 do
                    if K.scid(da) ~= -1 then
                        for dk = 0, 31 do
                            if K.scid(dk) ~= -1 then
                                c.script(
                                    544453591,
                                    dk,
                                    {
                                        69,
                                        da,
                                        1,
                                        aX[i],
                                        0,
                                        dj,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        script.get_global_i(1650640 + 9),
                                        script.get_global_i(1650640 + 10)
                                    }
                                )
                            end
                        end
                    end
                end
            end
        )
    end
    V.p["lobby_se"] = V.add.p("Script Events", V.p["lobby"]).id
    V.p["lobby_se_custom"] = V.add.p("Custom Script Events", V.p["lobby_se"]).id
    V.add.a(
        "Enter Custom Script Event with Parameters",
        V.p["lobby_se_custom"],
        function()
            local dl = {}
            local dm
            local dn = K.input("Enter Custom SE (DEC)", 32, 3)
            if not dn then
                o("Aborted sending Custom Event...", 100)
                return HANDLER_POP
            end
            while dm ~= "#" do
                dm = K.input("Enter Parameter (DEC), to EXIT and send, enter #", 32, 0)
                if not dm then
                    o("Aborted sending Custom Event...", 100)
                    return HANDLER_POP
                end
                if dm == "#" then
                    break
                end
                dm = c.no(dm)
                if type(dm) == "number" then
                    dl[#dl + 1] = dm
                else
                    o("Aborted sending Custom Event...", 100)
                    return HANDLER_POP
                end
            end
            for i = 0, 31 do
                if S.i(i) then
                    c.script(dn, i, dl)
                end
            end
            o("Sent Custom Script Event with Parameters to Players.", 100)
        end
    )
    for i = 1, #aQ do
        V.add.a(
            aQ[i][1],
            V.p["lobby_se_custom"],
            function()
                o("Sent Custom Script Event to Players.", 100)
                for E = 0, 31 do
                    if S.i(E) then
                        for b_ = 1, #aQ[i][2] do
                            c.script(aQ[i][2][b_][1], E, aQ[i][2][b_][2])
                        end
                    end
                end
            end
        )
    end
    V.p["lobby_send_2_mission"] = V.add.p("Send all to Mission", V.p["lobby_se"]).id
    for i = 1, #ax do
        V.add.a(
            "Send to " .. ax[i][1],
            V.p["lobby_send_2_mission"],
            function()
                cE(true, 0x692CC4BB, ax[i][2])
                o("Sent Session to Mission")
            end
        )
    end
    V.p["lobby_ceo"] = V.add.p("CEO all Player", V.p["lobby_se"]).id
    for i = 1, 3 do
        V.add.a(
            ay[i][1],
            V.p["lobby_ceo"],
            function()
                cE(true, ay[i][2], ay[i][3], ay[i][4], ay[i][5])
                o("Modified Players CEO")
            end
        )
    end
    V.add.a(
        "Block - Passive",
        V.p["lobby_se"],
        function()
            cE(true, 0x54BAD868, {1, 1})
            o("Blocked all Players from activating Passive.")
        end
    )
    V.add.a(
        "UN-Block - Passive",
        V.p["lobby_se"],
        function()
            cE(true, 0x54BAD868, {2, 0})
            o("UN-Blocked all Players from Passive.")
        end
    )
    V.p["lobby_sms"] =
        V.add.p(
        "Send SMSs to Lobby",
        V.p["lobby"],
        function()
            o("Players must have Voice-Chat enabled to recive SMS.")
            if V.t["sms_spam"] ~= nil then
                V.t["sms_spam"].value_i = l["sms_spam_value"]
                V.t["sms_spam"].on = l["sms_spam"]
            end
        end
    ).id
    V.t["sms_spam"] =
        V.add.u(
        "Spam SMS X times",
        "value_i",
        V.p["lobby_sms"],
        function(k)
            l["sms_spam_value"] = k.value_i
            l["sms_spam"] = k.on
        end
    )
    V.t["sms_spam"].min_i = 25
    V.t["sms_spam"].max_i = 5000
    V.t["sms_spam"].mod_i = 25
    V.t["sms_spam"].value_i = l["sms_spam_value"]
    V.t["sms_spam"].on = l["sms_spam"]
    V.add.a(
        "Custom SMS input",
        V.p["lobby_sms"],
        function()
            local dp = K.input("Enter Custom SMS", 128, 0)
            if not dp then
                return HANDLER_POP
            end
            for i = 0, 31 do
                if S.i(i) then
                    local A = 1
                    if V.t["sms_spam"].on then
                        A = V.t["sms_spam"].value_i
                    end
                    for E = 1, A do
                        player.send_player_sms(i, dp)
                        c.wait(10)
                    end
                end
            end
        end
    )
    V.add.a(
        "Send SCID & IP",
        V.p["lobby_sms"],
        function()
            for i = 0, 31 do
                if S.i(i) then
                    local a3 = tostring(K.scid(i))
                    local dq = K.ip(i)
                    local A = 1
                    if V.t["sms_spam"].on then
                        A = V.t["sms_spam"].value_i
                    end
                    for aj = 1, A do
                        player.send_player_sms(i, "R*SCID: " .. a3 .. "~n~IP: " .. dq)
                    end
                end
            end
        end
    )
    for i = 1, #aY do
        V.add.a(
            aY[i],
            V.p["lobby_sms"],
            function()
                for E = 0, 31 do
                    if S.i(E) then
                        local A = 1
                        if V.t["sms_spam"].on then
                            A = V.t["sms_spam"].value_i
                        end
                        for aj = 1, A do
                            player.send_player_sms(E, aY[i])
                            c.wait(20)
                        end
                    end
                end
            end
        )
    end
    V.p["lobby_malicious"] = V.add.p("Malicious", V.p["lobby"]).id
    V.t["karma_se"] =
        V.add.t(
        "Karma every Script Event",
        V.p["lobby_malicious"],
        function(k)
            if bE == nil then
                bE =
                    hook.register_script_event_hook(
                    function(cN, cw, cO, cP)
                        local cR = cO[1]
                        table.remove(cO, 1)
                        c.script(cR, cN, cO)
                    end
                )
            else
                hook.remove_script_event_hook(bE)
            end
            l["karma_se"] = k.on
        end
    )
    V.t["karma_se"].on = l["karma_se"]
    V.t["punish_aliens"] =
        V.add.t(
        "Punish Aliens in Lobby",
        V.p["lobby_malicious"],
        function(k)
            l["punish_aliens"] = k.on
            if k.on then
                local time = c.time() + 15000
                while time > c.time() do
                    l["punish_aliens"] = k.on
                    c.wait(150)
                end
                for i = 0, 31 do
                    if S.i(i) then
                        local de = 0
                        if player.is_player_female(i) then
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 1) == 134 and
                                    (ped.get_ped_texture_variation(c.ped(i), 1) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 1) == 9)
                             then
                                de = de + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 4) == 113 and
                                    (ped.get_ped_texture_variation(c.ped(i), 4) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 4) == 9)
                             then
                                de = de + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 6) == 87 and
                                    (ped.get_ped_texture_variation(c.ped(i), 6) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 6) == 9)
                             then
                                de = de + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 11) == 287 and
                                    (ped.get_ped_texture_variation(c.ped(i), 11) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 11) == 9)
                             then
                                de = de + 1
                            end
                        else
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 1) == 134 and
                                    (ped.get_ped_texture_variation(c.ped(i), 1) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 1) == 9)
                             then
                                de = de + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 4) == 106 and
                                    (ped.get_ped_texture_variation(c.ped(i), 4) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 4) == 9)
                             then
                                de = de + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 6) == 83 and
                                    (ped.get_ped_texture_variation(c.ped(i), 6) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 6) == 9)
                             then
                                de = de + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 11) == 274 and
                                    (ped.get_ped_texture_variation(c.ped(i), 11) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 11) == 9)
                             then
                                de = de + 1
                            end
                        end
                        if de > 1 then
                            r(K.name(i) .. " is a useless alien!")
                            r("Guilty Level: " .. de)
                            o(K.name(i) .. " is a useless alien! Punishing him!", 23)
                            player.send_player_sms(i, "Delete your stupid alien Outfit!")
                            c6(aS[5][2], i)
                            c6(aS[8][2], i)
                            c.explode(c.gcoords(c.ped(i)), 59, false, true, 1, c.ped(i))
                            c.explode(c.gcoords(c.ped(i)), 8, true, false, 1, c.ped(i))
                            c.explode(c.gcoords(c.ped(i)), 60, true, false, 1, c.ped(i))
                            c.explode(c.gcoords(c.ped(i)), 8, true, false, 1, c.ped(i))
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    V.t["punish_aliens"].on = l["punish_aliens"]
    V.add.a(
        "Kick all Players",
        V.p["lobby_malicious"],
        function()
            c2(true)
        end
    )
    V.add.a(
        "Host Kick All",
        V.p["lobby_malicious"],
        function()
            if network.network_is_host() then
                for i = 0, 31 do
                    if S.i(i) then
                        network.network_session_kick_player(i)
                    end
                end
            else
                o("You are not Session-Host!")
            end
        end
    )
    V.t["force_host"] =
        V.add.t(
        "Kick Hosts until You become Host",
        V.p["lobby_malicious"],
        function(k)
            if k.on then
                local time = c.time() + 7500
                while time > c.time() do
                    c.wait(250)
                    l["force_host"] = k.on
                end
                local a4 = player.get_host()
                if a4 ~= c.id() and K.scid(a4) ~= -1 then
                    r("You are not Host!")
                    r(K.name(a4) .. ":" .. K.scid(a4) .. " is Host!")
                    o(K.name(a4) .. " is Host!")
                    c2(false, a4)
                end
            end
            l["force_host"] = k.on
            return d.stop(k)
        end
    )
    V.t["force_host"].on = l["force_host"]
    V.add.a(
        "Crash Session",
        V.p["lobby_malicious"],
        function()
            r("Crashing Session...")
            c.navigate(false)
            b8 = entity.get_entity_model_hash(R.ped())
            for i = 1, 11 do
                aJ["session_crash"]["textures"][i] = ped.get_ped_texture_variation(R.ped(), i)
                aJ["session_crash"]["clothes"][i] = ped.get_ped_drawable_variation(R.ped(), i)
            end
            local af = {0, 1, 2, 6, 7}
            for aj = 1, #af do
                aJ["session_crash"]["prop_ind"][aj] = ped.get_ped_prop_index(R.ped(), af[aj])
                aJ["session_crash"]["prop_text"][aj] = ped.get_ped_prop_texture_index(R.ped(), af[aj])
            end
            bU(0x471BE4B2, nil, nil, nil, true)
            b9 = true
            c.wait(5000)
            cJ()
            c.navigate(true)
            r("Done.")
        end
    )
    V.add.a("Fix loading screen after Crash", V.p["lobby_malicious"], cJ)
    if l["2t1s_parent"] then
        V.p["opl_parent"] = V.add.pp("2Take1Script", 0).id
    end
    V.add.pt(
        "Unmark Modder",
        V.p["opl_parent"],
        function(k, id)
            if k.on then
                if player.is_player_modder(id, -1) then
                    player.unset_player_as_modder(id, -1)
                end
            end
            return d.stop(k)
        end
    )
    V.add.pt(
        "Remote Control Vehicle",
        V.p["opl_parent"],
        function(k, dr)
            local ds = menu.get_player_feature(k.id)
            if k.on then
                if bi ~= dr then
                    bi = dr
                    for i = 1, #ds.feats do
                        if i - 1 ~= dr and ds.feats[i].on then
                            ds.feats[i].on = false
                        end
                    end
                end
                local bN = c.vehicle(c.ped(dr))
                if bN ~= 0 then
                    if bh == nil then
                        local ap = entity.get_entity_model_hash(bN)
                        bh = ao.vehicle(ap, R.coords())
                        ped.set_ped_into_vehicle(R.ped(), bh, -1)
                        c.wait(50)
                    end
                    c.visible(bh, false)
                    if entity.get_entity_attached_to(bN) ~= bh then
                        H.ctrl(bh)
                        entity.set_entity_velocity(bh, v3())
                        bG(bh, c.gcoords(bN))
                        c.wait(0)
                        entity.set_entity_rotation(bh, entity.get_entity_rotation(bN))
                        H.ctrl(bN)
                        entity.set_entity_velocity(bN, v3())
                        entity.set_entity_max_speed(bN, 0)
                        vehicle.set_vehicle_out_of_control(bN, false, false)
                        c.attach(bN, bh, 0, v3(), v3(), true, false, false, 0, true)
                    end
                    return HANDLER_CONTINUE
                else
                    for i = 1, #ds.feats do
                        if ds.feats[i].on then
                            ds.feats[i].on = false
                        end
                    end
                    o("Target is not in a Vehicle!")
                    return HANDLER_POP
                end
            end
            if bh ~= nil then
                ped.clear_ped_tasks_immediately(R.ped())
                bI({bh})
                bh = nil
            end
            return HANDLER_POP
        end
    )
    V.add.pa(
        "Repair Vehicle",
        V.p["opl_parent"],
        function(k, dr)
            local bN = c.vehicle(c.ped(dr))
            if bN ~= 0 then
                H.ctrl(bN)
                vehicle.set_vehicle_fixed(bN)
                vehicle.set_vehicle_deformation_fixed(bN)
                vehicle.set_vehicle_can_be_visibly_damaged(bN, false)
                r("Repaired Vehicle.")
            end
        end
    )
    V.add.pt(
        "Waypoint Player",
        V.p["opl_parent"],
        function(k, dr)
            local ds = menu.get_player_feature(k.id)
            if k.on then
                if bq ~= dr then
                    bq = dr
                    for i = 1, #ds.feats do
                        if i - 1 ~= dr and ds.feats[i].on then
                            ds.feats[i].on = false
                        end
                    end
                end
                local aq = c.gcoords(c.ped(dr))
                ui.set_new_waypoint(v2(aq.x, aq.y))
                c.wait(500)
                return HANDLER_CONTINUE
            end
            c.wait(10)
            ui.set_waypoint_off()
            c.wait(10)
            return HANDLER_POP
        end
    )
    V.add.pa(
        "Modify Speed (0-500)",
        V.p["opl_parent"],
        function(k, dr)
            local bN = c.vehicle(c.ped(dr))
            if bN ~= 0 then
                local dc = K.input("Enter modified Speed (0-500)", 10, 3)
                if not dc then
                    return HANDLER_POP
                end
                dc = c.no(dc)
                if dc < 0 or dc > 500 then
                    o("Invalid Speed.")
                    return HANDLER_POP
                end
                o("Setting modified Speed.")
                H.ctrl(bN)
                entity.set_entity_max_speed(bN, dc)
                vehicle.modify_vehicle_top_speed(bN, dc)
            end
        end
    )
    V.p["attach"] = V.add.pp("Attach Objects", V.p["opl_parent"]).id
    V.add.pa(
        "Attach Entity from Aim",
        V.p["attach"],
        function(k, id)
            local dt = player.get_entity_player_is_aiming_at(c.id())
            if dt ~= 0 then
                c6({{dt, 0, {0, 0, 0}, {0, 0, 0}}}, id, true)
            else
                o("No Entity found. Aim @Entity to attach it to Player.")
            end
        end
    )
    V.add.pa(
        "Clear Entitys",
        V.p["attach"],
        function()
            r("Clearing Attachments.")
            bI(aI["attach_obj"])
            aI["attach_obj"] = {}
            o("Cleared all Attachment Entitys.")
        end
    )
    for i = 1, #aS do
        V.add.pa(
            aS[i][1],
            V.p["attach"],
            function(k, id)
                c6(aS[i][2], id)
            end
        )
    end
    V.p["opl_event_logger"] = V.add.pp("Log Events", V.p["opl_parent"]).id
    V.add.pt(
        "Log Script Events",
        V.p["opl_event_logger"],
        function(k, id)
            if k.on then
                if bv[id] == nil then
                    bv[id] =
                        hook.register_script_event_hook(
                        function(cN, cw, cO, cP)
                            if cN == id then
                                local a3 = K.scid(id)
                                local j = K.name(id)
                                local a7 = tostring(a3) .. "-" .. j
                                local e = a["Event-Logger"] .. "\\" .. a7 .. "\\" .. "Script-Events.log"
                                local t = d.time_prefix() .. " [Script-Event-Logger]"
                                local f = t
                                if not c.d_exists(a["Event-Logger"]) then
                                    utils.make_dir(a["Event-Logger"])
                                end
                                if not c.d_exists(a["Event-Logger"] .. "\\" .. a7) then
                                    utils.make_dir(a["Event-Logger"] .. "\\" .. a7)
                                end
                                if not c.f_exists(e) then
                                    o("Logging to folder '2Take1Script/Event-Logger/" .. a7, 14)
                                    f = "Starting to log Script-Events from Player: " .. j .. ":" .. a3 .. "\n" .. t
                                end
                                f = f .. "\n" .. cO[1] .. ", {"
                                for i = 2, #cO do
                                    f = f .. cO[i]
                                    if i ~= #cO then
                                        f = f .. ", "
                                    end
                                end
                                f = f .. "}\n"
                                f = f .. "Parameter count: " .. cP - 1 .. "\n"
                                d.write(c.o(e, "a"), f)
                            end
                        end
                    )
                end
                return HANDLER_CONTINUE
            end
            if not k.on and bv[id] ~= nil then
                hook.remove_script_event_hook(bv[id])
                bv[id] = nil
            end
        end
    )
    V.add.pa(
        "Reset Script Event Log",
        V.p["opl_event_logger"],
        function(k, id)
            local a3 = K.scid(id)
            local j = K.name(id)
            local a7 = tostring(a3) .. "-" .. j
            local e = a["Event-Logger"] .. "\\" .. a7 .. "\\" .. "Script-Events.log"
            if c.f_exists(e) then
                os.remove(e)
            else
                o("There was no log to reset.", 14)
            end
        end
    )
    V.add.pt(
        "Log Net Events",
        V.p["opl_event_logger"],
        function(k, id)
            if k.on then
                if bw[id] == nil then
                    bw[id] =
                        hook.register_net_event_hook(
                        function(cN, cw, dd)
                            if cN == id then
                                local a3 = K.scid(id)
                                local j = K.name(id)
                                local a7 = tostring(a3) .. "-" .. j
                                local e = a["Event-Logger"] .. "\\" .. a7 .. "\\" .. "Net-Events.log"
                                local t = d.time_prefix() .. " [Net-Event-Logger]"
                                local f = t
                                if not c.d_exists(a["Event-Logger"]) then
                                    utils.make_dir(a["Event-Logger"])
                                end
                                if not c.d_exists(a["Event-Logger"] .. "\\" .. a7) then
                                    utils.make_dir(a["Event-Logger"] .. "\\" .. a7)
                                end
                                if not c.f_exists(e) then
                                    o("Logging to folder '2Take1Script/Event-Logger/" .. a7, 14)
                                    f = "Starting to log Net-Events from Player: " .. j .. ":" .. a3 .. "\n" .. f
                                end
                                local du = "Unknown Net-Event"
                                if aZ[dd] ~= nil then
                                    du = aZ[dd]
                                end
                                f = f .. "\nEvent: " .. du .. "\nEvent ID: " .. dd .. "\n"
                                d.write(c.o(e, "a"), f)
                            end
                        end
                    )
                end
                return HANDLER_CONTINUE
            end
            if not k.on and bw[id] ~= nil then
                hook.remove_net_event_hook(bw[id])
                bw[id] = nil
            end
        end
    )
    V.add.pa(
        "Reset Net Event Log",
        V.p["opl_event_logger"],
        function(k, id)
            local a3 = K.scid(id)
            local j = K.name(id)
            local a7 = tostring(a3) .. "-" .. j
            local e = a["Event-Logger"] .. "\\" .. a7 .. "\\" .. "Net-Events.log"
            if c.f_exists(e) then
                os.remove(e)
            else
                o("There was no log to reset.", 14)
            end
        end
    )
    V.p["opl_se"] = V.add.pp("Script-Events", V.p["opl_parent"]).id
    V.p["opl_se_custom"] = V.add.pp("Custom Script Events", V.p["opl_se"]).id
    V.add.pa(
        "Enter Custom Script Event with Parameters",
        V.p["opl_se_custom"],
        function(k, id)
            local dm
            local dl = {}
            local dn = K.input("Enter Custom SE (DEC)", 32, 3)
            if not dn then
                o("Aborted sending Custom Event...", 93)
                return HANDLER_POP
            end
            while dm ~= "#" do
                dm = K.input("Enter Parameter (DEC), to EXIT and send, enter #", 32)
                if not dm then
                    o("Aborted sending Custom Event...", 93)
                    return HANDLER_POP
                end
                if dm == "#" then
                    break
                end
                dm = c.no(dm)
                if type(dm) == "number" then
                    dl[#dl + 1] = dm
                else
                    o("Aborted sending Custom Event...", 93)
                    return HANDLER_POP
                end
            end
            c.script(dn, id, dl)
            o("Sent Custom Script Event with Parameters to Player.", 93)
        end
    )
    for i = 1, #aQ do
        V.add.pa(
            aQ[i][1],
            V.p["opl_se_custom"],
            function(k, id)
                o("Sent Custom Script Event to Player.", 93)
                for b_ = 1, #aQ[i][2] do
                    c.script(aQ[i][2][b_][1], id, aQ[i][2][b_][2])
                end
            end
        )
    end
    V.add.pa(
        "Block - Passive",
        V.p["opl_se"],
        function(k, id)
            cE(false, 0x54BAD868, {1, 1}, nil, nil, id)
            o("Blocked Player from activating Passive.")
        end
    )
    V.add.pa(
        "UN-Block - Passive",
        V.p["opl_se"],
        function(k, id)
            cE(false, 0x54BAD868, {2, 0}, nil, nil, id)
            o("UN-Blocked Player from Passive.")
        end
    )
    V.p["opl_send_2_mission"] = V.add.pp("Send Player to Mission", V.p["opl_se"]).id
    for i = 1, #ax do
        V.add.pa(
            "Send to " .. ax[i][1],
            V.p["opl_send_2_mission"],
            function(k, id)
                cE(false, 0x692CC4BB, ax[i][2], nil, nil, id)
                o("Sent Player to Mission")
            end
        )
    end
    V.p["opl_ceo"] = V.add.pp("CEO", V.p["opl_se"]).id
    for i = 1, 3 do
        V.add.pa(
            ay[i][1],
            V.p["opl_ceo"],
            function(k, id)
                cE(false, ay[i][2], ay[i][3], ay[i][4], ay[i][5], id)
                o("Modified Players CEO")
            end
        )
    end
    V.p["opl_assassins_peds"] = V.add.pp("Send PEDs (Assassins)", V.p["opl_parent"]).id
    V.add.pa(
        "Clear PEDs",
        V.p["opl_assassins_peds"],
        function()
            bI(aI["peds"])
            aI["peds"] = {}
        end
    )
    for i = 1, #aP do
        V.add.pa(
            "Spawn " .. aP[i][1] .. " (3x)",
            V.p["opl_assassins_peds"],
            function(k, id)
                r("Spawning PEDs.")
                bj = id
                local ap = aP[i][2]
                local ar = aP[i][3]
                local aq = v3()
                H.model(ap)
                for i = 1, 3 do
                    aq = c.gcoords(c.ped(id))
                    aq.x = aq.x + c.random(-10, 10)
                    aq.y = aq.y + c.random(-10, 10)
                    aI["peds"][#aI["peds"] + 1] = ao.ped(ap, aq, ar)
                    if ar ~= 28 then
                        weapon.give_delayed_weapon_to_ped(aI["peds"][#aI["peds"]], 0xDBBD7280, 0, 0)
                    end
                    ped.set_ped_max_health(aI["peds"][#aI["peds"]], 25000000.0)
                    ped.set_ped_health(aI["peds"][#aI["peds"]], 25000000.0)
                    ped.set_ped_combat_attributes(aI["peds"][#aI["peds"]], 46, true)
                    ped.set_ped_combat_ability(aI["peds"][#aI["peds"]], 2)
                    ped.set_ped_config_flag(aI["peds"][#aI["peds"]], 187, 0)
                    ped.set_ped_can_ragdoll(aI["peds"][#aI["peds"]], false)
                    for da = 1, 26 do
                        ped.set_ped_ragdoll_blocking_flags(aI["peds"][#aI["peds"]], da)
                    end
                    ai.task_combat_ped(aI["peds"][#aI["peds"]], c.ped(id), 0, 16)
                end
                c.unload(ap)
                r("Done.")
            end
        )
    end
    V.add.pa(
        "TP to Player",
        V.p["opl_parent"],
        function(k, id)
            bK(c.gcoords(c.ped(id)), 3)
        end
    )
    V.add.pa(
        "TP Players Vehicle to me",
        V.p["opl_parent"],
        function(k, id)
            local bN = c.vehicle(c.ped(id))
            H.ctrl(bN)
            entity.set_entity_velocity(bN, v3())
            bG(bN, R.coords())
        end
    )
    V.add.pa(
        "Add Player to Blacklist",
        V.p["opl_parent"],
        function(k, id)
            local a3 = K.scid(id)
            if a3 == K.scid(c.id()) or a3 == -1 then
                o("Choose valid Player.")
            else
                d.write(c.o(b["Blacklist"], "a"), a3 .. " " .. K.name(id))
                o("Player " .. K.name(id) .. " added to Blocklist.", 48)
                r("Player " .. K.name(id) .. " with SCID: " .. a3 .. " added to Blacklist.")
            end
        end
    )
    V.p["opl_misc"] = V.add.pp("Miscellaneous", V.p["opl_parent"]).id
    r("Point 1")
    V.p["opl_sms"] =
        V.add.pp(
        "Send SMSs to Player",
        V.p["opl_misc"],
        function()
            o("Player must have Voice-Chat enabled to recive SMS.")
        end
    ).id
    V.t["sms_spam_opl"] =
        V.add.pu(
        "Spam SMS X times",
        "value_i",
        V.p["opl_sms"],
        function(k, id)
            local ds = menu.get_player_feature(k.id)
            for i = 1, #ds.feats do
                if ds.feats[i].max_i ~= 5000 then
                    ds.feats[i].max_i = 5000
                    ds.feats[i].min_i = 25
                    ds.feats[i].mod_i = 25
                    ds.feats[i].value_i = l["sms_spam_value"]
                    ds.feats[i].on = l["sms_spam"]
                end
            end
            l["sms_spam_value"] = k.value_i
            l["sms_spam"] = k.on
        end
    )
    V.t["sms_spam_opl"].feats[1].on = true
    V.t["sms_spam_opl"].feats[1].on = false
    V.add.pa(
        "Custom SMS input",
        V.p["opl_sms"],
        function(k, id)
            local dp = K.input("Enter Custom SMS", 128)
            if not dp then
                return HANDLER_POP
            end
            local A = 1
            if V.t["sms_spam_opl"].feats[1].on then
                A = V.t["sms_spam_opl"].feats[1].value_i
            end
            for i = 1, A do
                player.send_player_sms(id, dp)
                c.wait(20)
            end
        end
    )
    V.add.pa(
        "Send his SCID & IP",
        V.p["opl_sms"],
        function(k, id)
            local a3 = tostring(K.scid(id))
            local dq = K.ip(id)
            local A = 1
            if V.t["sms_spam_opl"].feats[1].on then
                A = V.t["sms_spam_opl"].feats[1].value_i
            end
            for i = 1, A do
                player.send_player_sms(id, "R*SCID: " .. a3 .. "~n~IP: " .. dq)
                c.wait(20)
            end
        end
    )
    for i = 1, #aY do
        V.add.pa(
            aY[i],
            V.p["opl_sms"],
            function(k, id)
                local A = 1
                if V.t["sms_spam_opl"].feats[1].on then
                    A = V.t["sms_spam_opl"].feats[1].value_i
                end
                for E = 1, A do
                    player.send_player_sms(id, aY[i])
                    c.wait(20)
                end
            end
        )
    end
    V.add.pa(
        "Falling Asteroids",
        V.p["opl_misc"],
        function(k, id)
            c.navigate(false)
            local aq = v3()
            local dv
            H.model(3751297495)
            for i = 1, 25 do
                aq = c.gcoords(c.ped(id))
                aq.x = c.random(math.floor(aq.x - 80), math.floor(aq.x + 80))
                aq.y = c.random(math.floor(aq.y - 80), math.floor(aq.y + 80))
                aq.z = aq.z + c.random(45, 90)
                dv = c.random(-125, 25)
                aI["asteroids"][#aI["asteroids"] + 1] = ao.object(3751297495, aq, true, true)
                entity.apply_force_to_entity(aI["asteroids"][#aI["asteroids"]], 3, 0, 0, dv, 0, 0, 0, true, true)
            end
            c.unload(3751297495)
            for i = 1, 5 do
                for i = 1, 25 do
                    aq = c.gcoords(aI["asteroids"][#aI["asteroids"] - 25 + i])
                    c.explode(aq, 8, true, false, 0, 0)
                    c.wait(50)
                end
            end
            c.navigate(true)
        end
    )
    V.add.pa(
        "Delete Asteroids",
        V.p["opl_misc"],
        function()
            r("Clearing Asteroids.")
            bI(aI["asteroids"])
            aI["asteroids"] = {}
            o("Cleared all Asteroids.")
        end
    )
    V.add.pa(
        "Apply random Force to Player",
        V.p["opl_misc"],
        function(k, id)
            local dw = c.ped(id)
            if ped.is_ped_in_any_vehicle(dw) then
                dw = c.vehicle(dw)
            else
                o("It works better, if target is in a Vehicle.")
            end
            H.ctrl(dw)
            local dx = entity.get_entity_velocity(dw)
            for i = 1, 5 do
                dx.x = c.random(math.floor(dx.x - 50), math.floor(dx.x + 50))
                dx.y = c.random(math.floor(dx.y - 50), math.floor(dx.y + 50))
                dx.z = c.random(math.floor(dx.z - 50), math.floor(dx.z + 50))
                entity.set_entity_velocity(dw, dx)
                c.wait(10)
            end
        end
    )
    V.add.pa(
        "Trap in Stunt Tube",
        V.p["opl_misc"],
        function(k, id)
            local aq = c.gcoords(c.ped(id))
            aq.z = aq.z - 5
            entity.set_entity_rotation(ao.object(1125864094, aq), v3(0, 90, 0))
        end
    )
    V.add.pa(
        "Trap in invisible Cage",
        V.p["opl_misc"],
        function(k, id)
            local aq = c.gcoords(c.ped(id))
            aq.x = aq.x + 1.24
            aq.y = aq.y + 0.24
            H.model(401136338)
            local dy = ao.object(401136338, aq)
            c.visible(dy, false)
            entity.set_entity_rotation(dy, v3(0, -90, 0))
            entity.freeze_entity(dy, true)
            aq = c.gcoords(c.ped(id))
            aq.x = aq.x + 0.02
            aq.y = aq.y + 0.82
            dy = ao.object(401136338, aq)
            c.visible(dy, false)
            entity.set_entity_rotation(dy, v3(90, -90, 0))
            entity.freeze_entity(dy, true)
            c.unload(401136338)
        end
    )
    V.p["opl_bounty"] = V.add.pp("Bounty", V.p["opl_parent"]).id
    for i = 1, #aX do
        V.add.pa(
            aX[i] .. "$",
            V.p["opl_bounty"],
            function()
                local dj = 0
                if V.t["anonymous_bounty"].on then
                    dj = 1
                end
                for da = 0, 31 do
                    if K.scid(da) ~= -1 then
                        c.script(
                            544453591,
                            da,
                            {
                                69,
                                id,
                                1,
                                aX[i],
                                0,
                                dj,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                script.get_global_i(1650640 + 9),
                                script.get_global_i(1650640 + 10)
                            }
                        )
                    end
                end
            end
        )
    end
    V.p["opl_lag_area"] =
        V.add.pp(
        "Lag Area with Vehicles",
        V.p["opl_parent"],
        function()
            o("DANGEROUS! ONLY USE WITH CAUTION!", 208)
        end
    ).id
    for i = 1, #aU do
        V.add.pa(
            "Lag / Rain Area with " .. aU[i][1],
            V.p["opl_lag_area"],
            function(k, id)
                cd(id, aU[i][2])
            end
        )
    end
    V.add.pa(
        "Delete Vehicles",
        V.p["opl_lag_area"],
        function()
            r("Clearing Vehicles.")
            bI(aI["lag_area"])
            aI["lag_area"] = {}
            o("Cleared Vehicles.")
        end
    )
    V.p["opl_malicious"] = V.add.pp("Malicious (Kick / Crash)", V.p["opl_parent"]).id
    V.add.pa(
        "Kick Player",
        V.p["opl_malicious"],
        function(k, id)
            c2(false, id)
        end
    )
    V.add.pa(
        "Host Kick Player",
        V.p["opl_malicious"],
        function(k, id)
            if network.network_is_host() then
                network.network_session_kick_player(id)
            else
                o("You are not Session-Host!")
            end
        end
    )
    V.add.pa(
        "Crash Player",
        V.p["opl_malicious"],
        function(k, id)
            ce(id)
        end
    )
    V.p["chat"] = V.add.p("Chat-Features", V.p["parent"])
    V.p["chat"].hidden = l["chat_hidden"]
    V.p["chat"] = V.p["chat"].id
    V.t["chat_log"] =
        V.add.t(
        "Chat-Log",
        V.p["chat"],
        function(k)
            l["chat_log"] = k.on
        end
    )
    V.t["chat_log"].on = l["chat_log"]
    V.t["chat_russki"] =
        V.add.t(
        "Kick if Russki Char is typed",
        V.p["chat"],
        function(k)
            l["chat_russki"] = k.on
        end
    )
    V.t["chat_russki"].on = l["chat_russki"]
    V.t["chat_begger"] =
        V.add.t(
        "Punish Money Beggers",
        V.p["chat"],
        function(k)
            l["chat_begger"] = k.on
        end
    )
    V.t["chat_begger"].on = l["chat_begger"]
    V.t["send_msg_to_script_users"] =
        V.add.a(
        "Send Message to 2Take1Script-Users",
        V.p["chat"],
        function()
            local cQ = K.input("Enter Message", 128)
            if not cQ then
                return HANDLER_POP
            end
            if cQ ~= "" then
                local cO = {}
                cO[1] = 6666
                for bH, cu in utf8.codes(cQ) do
                    cO[#cO + 1] = cu
                end
                for i = 0, 31 do
                    if c.valid(i) then
                        if i ~= c.id() and K.scid(i) ~= -1 then
                            c.script(0xfaaab4a3, i, cO)
                        end
                    end
                end
            end
        end
    )
    V.t["chat_cmd"] =
        V.add.t(
        "Enable Chat-Commands",
        V.p["chat"],
        function(k)
            l["chat_cmd"] = k.on
        end
    )
    V.t["chat_cmd"].on = l["chat_cmd"]
    V.p["chat_cmd"] = V.add.p("Chat-Commands", V.p["chat"]).id
    for i = 1, #aC do
        V.t[aC[i][1]] =
            V.add.t(
            aC[i][2],
            V.p["chat_cmd"],
            function(k)
                l[aC[i][1]] = k.on
            end
        )
        V.t[aC[i][1]].on = l[aC[i][1]]
    end
    V.add.a("[SU] = Script-User", V.p["chat_cmd"])
    V.add.a(
        "Delete Vehicles from !lag",
        V.p["chat"],
        function()
            bI(aI["lag_area"])
            aI["lag_area"] = {}
        end
    )
    V.t["chat_cmd_friends"] =
        V.add.t(
        "Chat Commands for Friends",
        V.p["chat"],
        function(k)
            l["chat_cmd_friends"] = k.on
        end
    )
    V.t["chat_cmd_friends"].on = l["chat_cmd_friends"]
    V.t["chat_cmd_all"] =
        V.add.t(
        "Chat Commands Everyone",
        V.p["chat"],
        function(k)
            l["chat_cmd_all"] = k.on
        end
    )
    V.t["chat_cmd_all"].on = l["chat_cmd_all"]
    V.t["send_message_to_dc"] =
        V.add.a(
        "Send Message to #general",
        V.p["chat"],
        function()
            o("It will take 8 seconds to sent the message, calm down and wait :)")
            local cQ = K.input("Enter Message", 128)
            if not cQ then
                return HANDLER_POP
            end
            cQ = cQ .. "\n\n*this message was sent by 2Take1Script*"
            utils.to_clipboard(cQ)
            c.exe("start https://discord.com/channels/570999086874886154/570999091320979486")
            c.wait(8000)
            local dz = b["vbs"]
            local dA = c.o(dz, "a")
            io.output(dA)
            io.write('set sendmsg = wscript.createobject("wscript.shell")\nwscript.sleep(1000)\n')
            io.write('sendmsg.sendkeys "^v"\nwscript.sleep(50)\n')
            io.write('sendmsg.sendkeys "{ENTER}"\nwscript.sleep(500)\n')
            io.write("wscript.quit")
            io.close(dA)
            c.exe("start " .. dz)
            c.wait(1000)
            os.remove(dz)
        end
    )
    V.p["custom_veh"] = V.add.p("Custom Vehicles", V.p["parent"])
    V.p["custom_veh"].hidden = l["custom_vehicles_hidden"]
    V.p["custom_veh"] = V.p["custom_veh"].id
    V.p["moveablerobot"] = V.add.p("Moveable Robot", V.p["custom_veh"]).id
    V.t["moveablerobot"] =
        V.add.t(
        "Enable Robot",
        V.p["moveablerobot"],
        function(k)
            if k.on then
                if bl["tampa"] == nil then
                    local dB = true
                    local bN = c.vehicle(R.ped())
                    if bN ~= 0 then
                        if 3084515313 == entity.get_entity_model_hash(bN) then
                            bl["tampa"] = bN
                            dB = false
                        end
                    end
                    if dB then
                        H.model(3084515313)
                        bl["tampa"] = ao.vehicle(3084515313, R.coords(), R.heading())
                        decorator.decor_set_int(bl["tampa"], "MPBitset", 1 << 10)
                        c.god(bl["tampa"], true)
                        ch(bN)
                        if V.t["auto_get_in"].on then
                            ped.set_ped_into_vehicle(R.ped(), bl["tampa"], -1)
                        end
                        if not l["disable_tampa_notify"] then
                            o(
                                "To get the best experience, upgrade the Tampa to use the Double Controllable Minigun!",
                                11
                            )
                            o("You can disable this message in Options.", 11)
                        end
                    end
                end
                if bl["ppdump"] == nil then
                    H.model(0x810369E2)
                    bl["ppdump"] = ao.vehicle(0x810369E2)
                    c.god(bl["ppdump"], true)
                    c.attach(
                        bl["ppdump"],
                        bl["tampa"],
                        0,
                        v3(0, 0, 12.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["llbone"] == nil then
                    H.model(1803116220)
                    bl["llbone"] = ao.object(1803116220)
                    c.attach(
                        bl["llbone"],
                        bl["tampa"],
                        0,
                        v3(-4.25, 0, 12.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["rlbone"] == nil then
                    H.model(1803116220)
                    bl["rlbone"] = ao.object(1803116220)
                    c.attach(
                        bl["rlbone"],
                        bl["tampa"],
                        0,
                        v3(4.25, 0, 12.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["lltrain"] == nil then
                    H.model(1030400667)
                    bl["lltrain"] = ao.vehicle(1030400667)
                    c.god(bl["lltrain"], true)
                    c.attach(
                        bl["lltrain"],
                        bl["llbone"],
                        0,
                        v3(0, 0, -5),
                        v3(90),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["lfoot"] == nil then
                    H.model(782665360)
                    bl["lfoot"] = ao.vehicle(782665360)
                    c.god(bl["lfoot"], true)
                    c.attach(
                        bl["lfoot"],
                        bl["llbone"],
                        0,
                        v3(0, 2, -12.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["rltrain"] == nil then
                    H.model(1030400667)
                    bl["rltrain"] = ao.vehicle(1030400667)
                    c.god(bl["rltrain"], true)
                    c.attach(
                        bl["rltrain"],
                        bl["rlbone"],
                        0,
                        v3(0, 0, -5),
                        v3(90),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["rfoot"] == nil then
                    H.model(782665360)
                    bl["rfoot"] = ao.vehicle(782665360)
                    c.god(bl["rfoot"], true)
                    c.attach(
                        bl["rfoot"],
                        bl["rlbone"],
                        0,
                        v3(0, 2, -12.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["body"] == nil then
                    H.model(1030400667)
                    bl["body"] = ao.vehicle(1030400667)
                    c.god(bl["body"], true)
                    c.attach(
                        bl["body"],
                        bl["tampa"],
                        0,
                        v3(0, 0, 22.5),
                        v3(90),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["shoulder"] == nil then
                    H.model(0x810369E2)
                    bl["shoulder"] = ao.vehicle(0x810369E2)
                    c.god(bl["shoulder"], true)
                    c.attach(
                        bl["shoulder"],
                        bl["tampa"],
                        0,
                        v3(0, 0, 27.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["lheadbone"] == nil then
                    H.model(1803116220)
                    bl["lheadbone"] = ao.object(1803116220)
                    c.attach(
                        bl["lheadbone"],
                        bl["tampa"],
                        0,
                        v3(-3.25, 0, 27.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["rheadbone"] == nil then
                    H.model(1803116220)
                    bl["rheadbone"] = ao.object(1803116220)
                    c.attach(
                        bl["rheadbone"],
                        bl["tampa"],
                        0,
                        v3(3.25, 0, 27.5),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["lheadtrain"] == nil then
                    H.model(1030400667)
                    bl["lheadtrain"] = ao.vehicle(1030400667)
                    c.god(bl["lheadtrain"], true)
                    c.attach(
                        bl["lheadtrain"],
                        bl["lheadbone"],
                        0,
                        v3(-3, 4, -5),
                        v3(325, 0, 45),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["lhand"] == nil then
                    H.model(782665360)
                    bl["lhand"] = ao.vehicle(782665360)
                    c.god(bl["lhand"], true)
                    c.attach(
                        bl["lhand"],
                        bl["lheadtrain"],
                        0,
                        v3(0, 7.5, 0),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["rheadtrain"] == nil then
                    H.model(1030400667)
                    bl["rheadtrain"] = ao.vehicle(1030400667)
                    c.god(bl["rheadtrain"], true)
                    c.attach(
                        bl["rheadtrain"],
                        bl["rheadbone"],
                        0,
                        v3(3, 4, -5),
                        v3(325, 0, 315),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["rhand"] == nil then
                    H.model(782665360)
                    bl["rhand"] = ao.vehicle(782665360)
                    c.god(bl["rhand"], true)
                    c.attach(
                        bl["rhand"],
                        bl["rheadtrain"],
                        0,
                        v3(0, 7.5, 0),
                        v3(),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["head"] == nil then
                    H.model(-543669801)
                    bl["head"] = ao.object(-543669801)
                    c.attach(bl["head"], bl["tampa"], 0, v3(0, 0, 35), v3(), true, l["robot_collision"], false, 2, true)
                end
                return HANDLER_CONTINUE
            end
            if not k.on then
                for i in pairs(bl) do
                    bI({bl[i]})
                    bl[i] = nil
                end
                if #aI["robot_weapon_left"] ~= 0 then
                    bI(aI["robot_weapon_left"])
                    aI["robot_weapon_left"] = {}
                end
                if #aI["robot_weapon_right"] ~= 0 then
                    bI(aI["robot_weapon_right"])
                    aI["robot_weapon_right"] = {}
                end
            end
        end
    )
    V.t["robot_shoot"] =
        V.add.t(
        "Controllable Blasts",
        V.p["moveablerobot"],
        function(k)
            if k.on then
                local dC = gameplay.get_hash_key("weapon_airstrike_rocket")
                local aq = R.coords()
                local dD = cam.get_gameplay_cam_rot()
                dD:transformRotToDir()
                dD = dD * 1000
                aq = aq + dD
                local dE, dF, dG, ap, dH = worldprobe.raycast(ck(R.coords(), R.heading(), 2) + v3(0, 0, 4), aq, -1, 0)
                while not dE do
                    aq = R.coords()
                    dD = cam.get_gameplay_cam_rot()
                    dD:transformRotToDir()
                    dD = dD * 1000
                    aq = aq + dD
                    dE, dF, dG, ap, dH = worldprobe.raycast(ck(R.coords(), R.heading(), 2) + v3(0, 0, 4), aq, -1, 0)
                    c.wait(0)
                end
                if ped.is_ped_shooting(R.ped()) and c.vehicle(R.ped()) == bl["tampa"] then
                    if V.t["equip_weapons"].on then
                        local dI = aI["robot_weapon_left"][1]
                        local dJ = entity.get_entity_heading(dI)
                        local dK = ck(c.gcoords(dI), dJ, 12) + v3(0, 0, 3)
                        gameplay.shoot_single_bullet_between_coords(dK, dF, 1000, dC, R.ped(), true, false, 50000)
                        local dL = aI["robot_weapon_right"][1]
                        local dM = entity.get_entity_heading(dL)
                        local dN = ck(c.gcoords(dL), dM, 12) + v3(0, 0, 3)
                        gameplay.shoot_single_bullet_between_coords(dN, dF, 1000, dC, R.ped(), true, false, 50000)
                        c.wait(100)
                    else
                        local dO = ck(R.coords(), R.heading(), 8) + v3(0, 0, 15)
                        gameplay.shoot_single_bullet_between_coords(dO, dF, 1000, dC, R.ped(), true, false, 10000)
                    end
                end
            end
            l["controllable_blasts"] = k.on
            return d.stop(k)
        end
    )
    V.t["robot_shoot"].on = l["controllable_blasts"]
    V.t["moveablelegs"] =
        V.add.t(
        "Moveable Legs",
        V.p["moveablerobot"],
        function(k)
            l["moveable_legs"] = k.on
            if k.on then
                if bl["llbone"] and bl["rlbone"] and bl["tampa"] then
                    local dc
                    local cU = bl["llbone"]
                    local cV = bl["rlbone"]
                    local cW = bl["tampa"]
                    local cX = v3(-4.25, 0, 12.5)
                    local cY = v3(4.25, 0, 12.5)
                    for i = 0, 50 do
                        if bl["tampa"] then
                            dc = entity.get_entity_speed(bl["tampa"])
                            if not k.on or dc < 2.5 then
                                cT()
                                return HANDLER_CONTINUE
                            end
                            H.ctrl(cU)
                            H.ctrl(cV)
                            H.ctrl(cW)
                            c.attach(cU, cW, 0, cX, v3(i, 0, 0), true, l["robot_collision"], false, 2, true)
                            c.attach(cV, cW, 0, cY, v3(360 - i, 0, 0), true, l["robot_collision"], false, 2, true)
                            local dP = math.floor(51 - dc / 1)
                            if dP < 1 then
                                dP = 0
                            end
                            c.wait(dP)
                        end
                    end
                    for i = 50, -50, -1 do
                        if bl["tampa"] then
                            dc = entity.get_entity_speed(bl["tampa"])
                            if not k.on or dc < 2.5 then
                                cT()
                                return HANDLER_CONTINUE
                            end
                            H.ctrl(cU)
                            H.ctrl(cV)
                            H.ctrl(cW)
                            c.attach(cU, cW, 0, cX, v3(i, 0, 0), true, l["robot_collision"], false, 2, true)
                            c.attach(cV, cW, 0, cY, v3(360 - i, 0, 0), true, l["robot_collision"], false, 2, true)
                            local dP = math.floor(51 - dc / 1)
                            if dP < 1 then
                                dP = 0
                            end
                            c.wait(dP)
                        end
                    end
                    for i = -50, 0 do
                        if bl["tampa"] then
                            dc = entity.get_entity_speed(bl["tampa"])
                            if not k.on or dc < 2.5 then
                                cT()
                                return HANDLER_CONTINUE
                            end
                            H.ctrl(cU)
                            H.ctrl(cV)
                            H.ctrl(cW)
                            c.attach(cU, cW, 0, cX, v3(i, 0, 0), true, l["robot_collision"], false, 2, true)
                            c.attach(cV, cW, 0, cY, v3(360 - i, 0, 0), true, l["robot_collision"], false, 2, true)
                            local dP = math.floor(51 - dc / 1)
                            if dP < 1 then
                                dP = 0
                            end
                            c.wait(dP)
                        end
                    end
                end
                return HANDLER_CONTINUE
            end
            if not k.on then
                cT()
            end
        end
    )
    V.t["moveablelegs"].on = l["moveable_legs"]
    V.t["robot_collision"] =
        V.add.t(
        "Collision",
        V.p["moveablerobot"],
        function(k)
            l["robot_collision"] = k.on
            if c.vehicle(R.ped()) == bl["tampa"] then
                o("Re-enable Robot to take effect of collision!", 11)
            end
        end
    )
    V.t["robot_collision"].on = l["robot_collision"]
    V.t["rocket_propulsion"] =
        V.add.t(
        "Rocket Propulsion (Visual)",
        V.p["moveablerobot"],
        function(k)
            if k.on and bl["body"] then
                if bl["spinning_1"] == nil then
                    H.model(0xFB133A17)
                    bl["spinning_1"] = ao.vehicle(0xFB133A17, R.coords())
                    c.god(bl["spinning_1"], true)
                    c.visible(bl["spinning_1"], false)
                    c.attach(
                        bl["spinning_1"],
                        bl["body"],
                        0,
                        v3(0, -5, 0),
                        v3(-180, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                vehicle.set_heli_blades_speed(bl["spinning_1"], 100)
                if bl["spinning_middle"] == nil then
                    H.model(94602826)
                    bl["spinning_middle"] = ao.object(94602826)
                    c.god(bl["spinning_middle"], true)
                    c.attach(
                        bl["spinning_middle"],
                        bl["spinning_1"],
                        0,
                        v3(0, 0, 0),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["spinning_middle2"] == nil then
                    H.model(94602826)
                    bl["spinning_middle2"] = ao.object(94602826)
                    c.god(bl["spinning_middle2"], true)
                    c.attach(
                        bl["spinning_middle2"],
                        bl["spinning_1"],
                        0,
                        v3(0, 0, 1.5),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["spinning_middle3"] == nil then
                    H.model(94602826)
                    bl["spinning_middle3"] = ao.object(94602826)
                    c.god(bl["spinning_middle3"], true)
                    c.attach(
                        bl["spinning_middle3"],
                        bl["spinning_1"],
                        0,
                        v3(0, 0, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                local B = entity.get_entity_bone_index_by_name(bl["spinning_1"], "rotor_main")
                if bl["glow_1"] == nil then
                    H.model(2655881418)
                    bl["glow_1"] = ao.object(2655881418)
                    c.god(bl["glow_1"], true)
                    c.attach(
                        bl["glow_1"],
                        bl["spinning_1"],
                        B,
                        v3(2, 3, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["glow_2"] == nil then
                    H.model(2655881418)
                    bl["glow_2"] = ao.object(2655881418)
                    c.god(bl["glow_2"], true)
                    c.attach(
                        bl["glow_2"],
                        bl["spinning_1"],
                        B,
                        v3(2, -3, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["glow_3"] == nil then
                    H.model(2655881418)
                    bl["glow_3"] = ao.object(2655881418)
                    c.god(bl["glow_3"], true)
                    c.attach(
                        bl["glow_3"],
                        bl["spinning_1"],
                        B,
                        v3(4, 0, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["glow_4"] == nil then
                    H.model(2655881418)
                    bl["glow_4"] = ao.object(2655881418)
                    c.god(bl["glow_4"], true)
                    c.attach(
                        bl["glow_4"],
                        bl["spinning_1"],
                        B,
                        v3(-2, 3, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["glow_5"] == nil then
                    H.model(2655881418)
                    bl["glow_5"] = ao.object(2655881418)
                    c.god(bl["glow_5"], true)
                    c.attach(
                        bl["glow_5"],
                        bl["spinning_1"],
                        B,
                        v3(-2, -3, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bl["glow_6"] == nil then
                    H.model(2655881418)
                    bl["glow_6"] = ao.object(2655881418)
                    c.god(bl["glow_6"], true)
                    c.attach(
                        bl["glow_6"],
                        bl["spinning_1"],
                        B,
                        v3(-4, 0, 3),
                        v3(0, 0, 0),
                        true,
                        l["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
            end
            if not k.on then
                local dQ = {
                    "spinning_1",
                    "glow_1",
                    "glow_2",
                    "glow_3",
                    "glow_4",
                    "glow_5",
                    "glow_6",
                    "spinning_middle",
                    "spinning_middle2",
                    "spinning_middle3"
                }
                for i = 1, #dQ do
                    if bl[dQ[i]] then
                        bI({bl[dQ[i]]})
                        bl[dQ[i]] = nil
                    end
                end
                return HANDLER_POP
            end
            l["rocket_propulsion"] = k.on
            return HANDLER_CONTINUE
        end
    )
    V.t["rocket_propulsion"].on = l["rocket_propulsion"]
    V.t["equip_weapons"] =
        V.add.t(
        "Equip Miniguns on hands",
        V.p["moveablerobot"],
        function(k)
            l["equip_weapons"] = k.on
            if k.on and bl["lheadtrain"] and bl["rheadtrain"] then
                if #aI["robot_weapon_left"] == 0 and #aI["robot_weapon_right"] == 0 then
                    local dR = false
                    if V.t["spawn_preview"].on then
                        dR = true
                        V.t["spawn_preview"].on = false
                    end
                    local dS = false
                    if V.t["auto_get_in"].on then
                        dS = true
                        V.t["auto_get_in"].on = false
                    end
                    local c7 = aT[1][2]
                    cZ(c7, "robot_weapon_left")
                    cZ(c7, "robot_weapon_right")
                    local dT = aI["robot_weapon_left"][1]
                    local dU = aI["robot_weapon_right"][1]
                    local dV = bl["lheadtrain"]
                    local dW = bl["rheadtrain"]
                    H.ctrl(dT)
                    H.ctrl(dU)
                    H.ctrl(dV)
                    H.ctrl(dW)
                    c.attach(dT, dV, 0, v3(0, 5, 0), v3(), true, l["robot_collision"], false, 2, true)
                    c.attach(dU, dW, 0, v3(0, 5, 0), v3(), true, l["robot_collision"], false, 2, true)
                    if dR then
                        V.t["spawn_preview"].on = true
                    end
                    if dS then
                        V.t["auto_get_in"].on = true
                    end
                end
            end
            if not k.on then
                if #aI["robot_weapon_left"] ~= 0 then
                    bI(aI["robot_weapon_left"])
                    aI["robot_weapon_left"] = {}
                end
                if #aI["robot_weapon_right"] ~= 0 then
                    bI(aI["robot_weapon_right"])
                    aI["robot_weapon_right"] = {}
                end
                return HANDLER_POP
            end
            return HANDLER_CONTINUE
        end
    )
    V.t["equip_weapons"].on = l["equip_weapons"]
    V.add.a(
        "Drive Robot",
        V.p["moveablerobot"],
        function()
            if bl["tampa"] then
                ped.set_ped_into_vehicle(R.ped(), bl["tampa"], -1)
            end
        end
    )
    V.add.a(
        "Self Destruction",
        V.p["moveablerobot"],
        function()
            if bl["tampa"] then
                for i = 1, #aI["robot_weapon_left"] do
                    entity.detach_entity(aI["robot_weapon_left"][i])
                    entity.freeze_entity(aI["robot_weapon_left"][i], false)
                    c.god(aI["robot_weapon_left"][i], false)
                end
                for i = 1, #aI["robot_weapon_right"] do
                    entity.detach_entity(aI["robot_weapon_right"][i])
                    entity.freeze_entity(aI["robot_weapon_right"][i], false)
                    c.god(aI["robot_weapon_right"][i], false)
                end
                for i in pairs(bl) do
                    entity.detach_entity(bl[i])
                    entity.freeze_entity(bl[i], false)
                    c.god(bl[i], false)
                end
                for i = 1, #aI["robot_weapon_left"] do
                    c.explode(c.gcoords(aI["robot_weapon_left"][i]), 8, true, false, 0, 0)
                    c.wait(33)
                end
                for i = 1, #aI["robot_weapon_right"] do
                    c.explode(c.gcoords(aI["robot_weapon_right"][i]), 8, true, false, 0, 0)
                    c.wait(33)
                end
                for i in pairs(bl) do
                    c.explode(c.gcoords(bl[i]), 8, true, false, 0, 0)
                    c.wait(33)
                end
                aI["robot_weapon_left"] = {}
                aI["robot_weapon_right"] = {}
                bl = {}
                V.t["moveablerobot"].on = false
            end
        end
    )
    V.p["custom_spawner"] = V.add.p("Custom Vehicles", V.p["custom_veh"]).id
    V.t["spawn_preview"] =
        V.add.t(
        "Preview Custom Vehicles",
        V.p["custom_spawner"],
        function(k)
            if #aI["preview_veh"] > 0 and k.on then
                if ped.is_ped_in_any_vehicle(R.ped()) then
                    ped.clear_ped_tasks_immediately(R.ped())
                end
                local aq = R.coords()
                if not b5 then
                    for i = 1, #aI["preview_veh"] do
                        entity.set_entity_no_collsion_entity(aI["preview_veh"][i], R.ped(), true)
                    end
                    b5 = true
                end
                aq.z = aq.z + b4
                local as = R.heading()
                aq = ck(aq, as, b6)
                bG(aI["preview_veh"][1], aq)
                entity.set_entity_rotation(aI["preview_veh"][1], b7)
                b7.z = b7.z + 1
                if b7.z > 360 then
                    b7.z = 0
                end
            end
            if not k.on then
                bI(aI["preview_veh"])
                aI["preview_veh"] = {}
                b5 = false
                return HANDLER_POP
            end
            return d.stop(k)
        end
    )
    V.add.a(
        "Delete Custom Vehicles",
        V.p["custom_spawner"],
        function()
            r("Clearing Custom Vehicles.")
            bI(aI["custom_veh"])
            aI["custom_veh"] = {}
            bI(aI["preview_veh"])
            aI["preview_veh"] = {}
            b5 = false
            o("Cleared Custom Vehicles.")
        end
    )
    for i = 1, #aT do
        V.add.a(
            aT[i][1],
            V.p["custom_spawner"],
            function()
                local c7 = aT[i][2]
                cZ(c7)
            end
        )
    end
    V.p["custom_veh_opt"] = V.add.p("Options", V.p["custom_veh"]).id
    V.t["auto_get_in"] =
        V.add.t(
        "Spawn in Custom Vehicle",
        V.p["custom_veh_opt"],
        function(k)
            l["spawn_in_vehicle"] = k.on
        end
    )
    V.t["auto_get_in"].on = l["spawn_in_vehicle"]
    V.t["use_own_veh"] =
        V.add.t(
        "Use Own Vehicle for Custom ones",
        V.p["custom_veh_opt"],
        function(k)
            l["use_own_veh"] = k.on
        end
    )
    V.t["use_own_veh"].on = l["use_own_veh"]
    V.t["set_godmode"] =
        V.add.t(
        "Godmode on Custom Vehicles",
        V.p["custom_veh_opt"],
        function(k)
            l["set_godmode"] = k.on
        end
    )
    V.t["set_godmode"].on = l["set_godmode"]
    V.t["disable_tampa_notify"] =
        V.add.t(
        "Disable Moveable Robot Tampa Notify",
        V.p["custom_veh_opt"],
        function(k)
            l["disable_tampa_notify"] = k.on
        end
    )
    V.t["disable_tampa_notify"].on = l["disable_tampa_notify"]
    V.p["custom_veh_builder"] = V.add.p("Custom Vehicle Creator", V.p["custom_veh"])
    V.p["custom_veh_builder"].hidden = true
    local dX = {
        {
            "WarMachine",
            {
                {0x9dae1398, 1030400667, 0x2F03547B, 2971578861, 3871829598, 3229200997, 0x187D938D, 782665360},
                {0x9dae1398, nil, nil, {0, 0, 0, 0, 1}, nil, nil, nil, nil, nil, nil, 15},
                {1030400667, {0, -4, 0}, nil, {0, 0, 0, 0, 1}},
                {0x2F03547B, {0, -8, 4}, {-90, 0, 0}, {0, 0, 0, 0, 1}, true, nil, nil, nil, 0x97F5FE8D, true},
                {2971578861, {-0.3, -0.6, 9.8}, {-90, 0, 0}, nil, nil, nil, 16, 3},
                {3229200997, {0, 0, 9.8}, {-90, 0, 0}, nil, nil, nil, 16, 3},
                {0x187D938D, {0, -8.25, 5.3}, nil, {0, 0, 0, 0, 1}},
                {782665360, {0, -8, 3.1}, nil, {0, 0, 0, 0, 1}}
            }
        },
        {
            "Deer Rider",
            {
                {0xE5BA6858},
                {0xE5BA6858, nil, nil, {0, 0, 0, 0, 1}, true, nil, nil, nil, nil, nil, 3},
                {0, {0, -0.225, 0.225}, nil, nil, nil, nil, nil, nil, 0xD86B5A95}
            }
        },
        {"Attach Tree", {{3015194288}, {0}, {3015194288, {0, 0, -0.3}}}}
    }
    V.add.a(
        "Delete Custom Vehicles",
        V.p["custom_veh_builder"].id,
        function()
            r("Clearing Custom Vehicles.")
            bI(aI["vehicle_builder"])
            aI["vehicle_builder"] = {}
            o("Cleared Custom Vehicles.")
        end
    )
    for i = 1, #dX do
        V.add.a(
            dX[i][1],
            V.p["custom_veh_builder"].id,
            function()
                local c7 = dX[i][2]
                cZ(c7, "vehicle_builder")
            end
        )
    end
    local dY = V.add.u("Select Vehicle", "autoaction_value_i", V.p["custom_veh_builder"].id)
    dY.min_i = 2
    dY.max_i = 250
    local dZ, d_, e0, e1, e2, e3
    dZ =
        V.add.u(
        "Offset X",
        "autoaction_value_i",
        V.p["custom_veh_builder"].id,
        function(k)
            local bL = v3(k.value_i / 10, d_.value_i / 10, e0.value_i / 10)
            local e4 = v3(e1.value_i, e2.value_i, e3.value_i)
            local cW = aI["vehicle_builder"][1]
            local e5 = aI["vehicle_builder"][dY.value_i]
            if cW ~= nil and e5 ~= nil then
                H.ctrl(cW)
                H.ctrl(e5)
                c.attach(e5, cW, 0, bL, e4, false, false, false, 2, true)
            end
        end
    )
    dZ.min_i = -500
    dZ.max_i = 500
    d_ =
        V.add.u(
        "Offset Y",
        "autoaction_value_i",
        V.p["custom_veh_builder"].id,
        function(k)
            local bL = v3(dZ.value_i / 10, k.value_i / 10, e0.value_i / 10)
            local e4 = v3(e1.value_i, e2.value_i, e3.value_i)
            local cW = aI["vehicle_builder"][1]
            local e5 = aI["vehicle_builder"][dY.value_i]
            if cW ~= nil and e5 ~= nil then
                H.ctrl(cW)
                H.ctrl(e5)
                c.attach(e5, cW, 0, bL, e4, false, false, false, 2, true)
            end
        end
    )
    d_.min_i = -500
    d_.max_i = 500
    e0 =
        V.add.u(
        "Offset Z",
        "autoaction_value_i",
        V.p["custom_veh_builder"].id,
        function(k)
            local bL = v3(dZ.value_i / 10, d_.value_i / 10, k.value_i / 10)
            local e4 = v3(e1.value_i, e2.value_i, e3.value_i)
            local cW = aI["vehicle_builder"][1]
            local e5 = aI["vehicle_builder"][dY.value_i]
            if cW ~= nil and e5 ~= nil then
                H.ctrl(cW)
                H.ctrl(e5)
                c.attach(e5, cW, 0, bL, e4, false, false, false, 2, true)
            end
        end
    )
    e0.min_i = -500
    e0.max_i = 500
    e1 =
        V.add.u(
        "Rotation X",
        "autoaction_value_i",
        V.p["custom_veh_builder"].id,
        function(k)
            local bL = v3(dZ.value_i / 10, d_.value_i / 10, e0.value_i / 10)
            local e4 = v3(k.value_i, e2.value_i, e3.value_i)
            local cW = aI["vehicle_builder"][1]
            local e5 = aI["vehicle_builder"][dY.value_i]
            if cW ~= nil and e5 ~= nil then
                H.ctrl(cW)
                H.ctrl(e5)
                c.attach(e5, cW, 0, bL, e4, false, false, false, 2, true)
            end
        end
    )
    e1.min_i = -360
    e1.max_i = 360
    e2 =
        V.add.u(
        "Rotation Y",
        "autoaction_value_i",
        V.p["custom_veh_builder"].id,
        function(k)
            local bL = v3(dZ.value_i / 10, d_.value_i / 10, e0.value_i / 10)
            local e4 = v3(e1.value_i, k.value_i, e3.value_i)
            local cW = aI["vehicle_builder"][1]
            local e5 = aI["vehicle_builder"][dY.value_i]
            if cW ~= nil and e5 ~= nil then
                H.ctrl(cW)
                H.ctrl(e5)
                c.attach(e5, cW, 0, bL, e4, false, false, false, 2, true)
            end
        end
    )
    e2.min_i = -360
    e2.max_i = 360
    e3 =
        V.add.u(
        "Rotation Z",
        "autoaction_value_i",
        V.p["custom_veh_builder"].id,
        function(k)
            local bL = v3(dZ.value_i / 10, d_.value_i / 10, e0.value_i / 10)
            local e4 = v3(e1.value_i, e2.value_i, k.value_i)
            local cW = aI["vehicle_builder"][1]
            local e5 = aI["vehicle_builder"][dY.value_i]
            if cW ~= nil and e5 ~= nil and cW ~= e5 then
                H.ctrl(cW)
                H.ctrl(e5)
                c.attach(e5, cW, 0, bL, e4, false, false, false, 2, true)
            end
        end
    )
    e3.min_i = -360
    e3.max_i = 360
    V.p["exp_beam"] = V.add.p("Explosive Beam on Horn", V.p["parent"])
    V.p["exp_beam"].hidden = l["explosive_beam_hidden"]
    V.p["exp_beam"] = V.p["exp_beam"].id
    V.t["exp_beam"] =
        V.add.t(
        "Enable Beam on Horn",
        V.p["exp_beam"],
        function(k)
            l["exp_beam"] = k.on
            if k.on then
                local e6 = c.id()
                if K.scid(V.t["exp_beam_other"].value_i) ~= -1 then
                    e6 = V.t["exp_beam_other"].value_i
                end
                local dw = c.ped(e6)
                local bN, aq, ca, e7, e8
                local e9 = v3()
                local ea, eb, ec, ed, ee, ef
                if player.is_player_pressing_horn(e6) then
                    bN = c.vehicle(dw)
                    for i = 0, 5 do
                        aq = c.gcoords(bN)
                        c.wait(5)
                        if i > 0 then
                            ca = c.gcoords(bN)
                            e9.x = ca.x - aq.x
                            e9.y = ca.y - aq.y
                            e9.z = ca.z - aq.z
                            if e9.x ~= 0 and e9.y ~= 0 and e9.z ~= 0 then
                                e7 = 1 / (e9.x * e9.x + e9.y * e9.y + e9.z * e9.z) ^ 0.5
                                e8 = c.random(l["exp_beam_min"], l["exp_beam_max"])
                                ca.x = ca.x + e8 * e7 * e9.x
                                ca.y = ca.y + e8 * e7 * e9.y
                                ca.z = ca.z + e8 * e7 * e9.z
                                ea = math.floor(ca.x - l["exp_beam_radius"])
                                eb = math.floor(ca.x + l["exp_beam_radius"])
                                ec = math.floor(ca.y - l["exp_beam_radius"])
                                ed = math.floor(ca.y + l["exp_beam_radius"])
                                ee = math.floor(ca.z - l["exp_beam_radius"])
                                ef = math.floor(ca.z + l["exp_beam_radius"])
                                ca.x = c.random(ea, eb)
                                ca.y = c.random(ec, ed)
                                ca.z = c.random(ee, ef)
                                c.explode(ca, l["exp_beam_type"], true, false, 0.1, dw)
                                ca.x = c.random(ea, eb)
                                ca.y = c.random(ec, ed)
                                ca.z = c.random(ee, ef)
                                c.explode(ca, l["exp_beam_type_2"], true, false, 0.1, dw)
                            end
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    V.t["exp_beam"].on = l["exp_beam"]
    V.t["exp_beam_type"] =
        V.add.u(
        "Select Explosion",
        "action_value_i",
        V.p["exp_beam"],
        function()
            l["exp_beam_type"] = V.t["exp_beam_type"].value_i
            o("Beam Explosion Type 1: " .. l["exp_beam_type"])
        end
    )
    V.t["exp_beam_type"].max_i = 74
    V.t["exp_beam_type"].min_i = 0
    V.t["exp_beam_type"].value_i = l["exp_beam_type"]
    V.t["exp_beam_type_2"] =
        V.add.u(
        "Select Explosion 2",
        "action_value_i",
        V.p["exp_beam"],
        function()
            l["exp_beam_type_2"] = V.t["exp_beam_type_2"].value_i
            o("Beam Explosion Type 2: " .. l["exp_beam_type_2"])
        end
    )
    V.t["exp_beam_type_2"].max_i = 74
    V.t["exp_beam_type_2"].min_i = 0
    V.t["exp_beam_type_2"].value_i = l["exp_beam_type_2"]
    V.t["exp_beam_radius"] =
        V.add.u(
        "Select Scattering",
        "action_value_i",
        V.p["exp_beam"],
        function()
            l["exp_beam_radius"] = V.t["exp_beam_radius"].value_i
            o("Beam Radius: " .. l["exp_beam_radius"])
        end
    )
    V.t["exp_beam_radius"].max_i = 10
    V.t["exp_beam_radius"].min_i = 1
    V.t["exp_beam_radius"].value_i = l["exp_beam_radius"]
    V.t["exp_beam_min"] =
        V.add.u(
        "Select Min Range",
        "action_value_i",
        V.p["exp_beam"],
        function()
            l["exp_beam_min"] = V.t["exp_beam_min"].value_i
            o("Beam Min Range: " .. l["exp_beam_min"])
        end
    )
    V.t["exp_beam_min"].max_i = 100
    V.t["exp_beam_min"].min_i = 10
    V.t["exp_beam_min"].value_i = l["exp_beam_min"]
    V.t["exp_beam_min"].mod_i = 5
    V.t["exp_beam_max"] =
        V.add.u(
        "Select Max Range",
        "action_value_i",
        V.p["exp_beam"],
        function()
            l["exp_beam_max"] = V.t["exp_beam_max"].value_i
            o("Beam Max Range: " .. l["exp_beam_max"])
        end
    )
    V.t["exp_beam_max"].max_i = 300
    V.t["exp_beam_max"].min_i = 100
    V.t["exp_beam_max"].value_i = l["exp_beam_max"]
    V.t["exp_beam_max"].mod_i = 5
    V.t["exp_beam_other"] =
        V.add.u(
        "Enable Horn for Player",
        "action_value_i",
        V.p["exp_beam"],
        function()
            if K.scid(V.t["exp_beam_other"].value_i) ~= -1 then
                o("Selected Player: " .. K.name(V.t["exp_beam_other"].value_i))
            else
                o("Not a valid Player.")
            end
        end
    )
    V.t["exp_beam_other"].max_i = 31
    V.t["exp_beam_other"].min_i = -1
    V.t["exp_beam_other"].value_i = -1
    V.p["bac"] =
        V.add.p(
        "Better Animal Changer",
        V.p["parent"],
        function()
            if V.t["revert_outfit"].on then
                if #aJ["bac_outfit"]["clothes"] < 1 then
                    if player.get_player_model(c.id()) == 0x9C9EFFD8 or player.get_player_model(c.id()) == 0x705E61F2 then
                        for i = 1, 11 do
                            aJ["bac_outfit"]["textures"][i] = ped.get_ped_texture_variation(R.ped(), i)
                            aJ["bac_outfit"]["clothes"][i] = ped.get_ped_drawable_variation(R.ped(), i)
                        end
                        local af = {0, 1, 2, 6, 7}
                        for aj = 1, #af do
                            aJ["bac_outfit"]["prop_ind"][aj] = ped.get_ped_prop_index(R.ped(), af[aj])
                            aJ["bac_outfit"]["prop_text"][aj] = ped.get_ped_prop_texture_index(R.ped(), af[aj])
                        end
                        local K = "male"
                        if player.is_player_female(c.id()) then
                            K = "female"
                        end
                        aJ["bac_outfit"]["gender"] = K
                    end
                end
            end
        end
    )
    V.p["bac"].hidden = l["animal_changer_hidden"]
    V.p["bac"] = V.p["bac"].id
    V.p["bac_ga"] = V.add.p("Ground Animals", V.p["bac"]).id
    V.add.a(
        "Bigfoot",
        V.p["bac_ga"],
        function()
            bU(0x61D4C771, nil, true, nil, true)
        end
    )
    V.add.a(
        "Bigfoot 2",
        V.p["bac_ga"],
        function()
            bU(0xAD340F5A, nil, true, nil, true)
        end
    )
    V.add.a(
        "Boar",
        V.p["bac_ga"],
        function()
            bU(0xCE5FF074)
        end
    )
    V.add.a(
        "Cat",
        V.p["bac_ga"],
        function()
            bU(0x573201B8)
        end
    )
    V.add.a(
        "Chimp",
        V.p["bac_ga"],
        function()
            bU(0xA8683715, nil, nil, true)
        end
    )
    V.add.a(
        "Chop",
        V.p["bac_ga"],
        function()
            bU(0x14EC17EA, nil, true)
        end
    )
    V.add.a(
        "Cow",
        V.p["bac_ga"],
        function()
            bU(0xFCFA9E1E)
        end
    )
    V.add.a(
        "Coyote",
        V.p["bac_ga"],
        function()
            bU(0x644AC75E)
        end
    )
    V.add.a(
        "Deer",
        V.p["bac_ga"],
        function()
            bU(0xD86B5A95)
        end
    )
    V.add.a(
        "German Shepherd",
        V.p["bac_ga"],
        function()
            bU(0x431FC24C, nil, true)
        end
    )
    V.add.a(
        "Hen",
        V.p["bac_ga"],
        function()
            bU(0x6AF51FAF)
        end
    )
    V.add.a(
        "Husky",
        V.p["bac_ga"],
        function()
            bU(0x4E8F95A2, nil, true)
        end
    )
    V.add.a(
        "Mountain Lion",
        V.p["bac_ga"],
        function()
            bU(0x1250D7BA, nil, true)
        end
    )
    V.add.a(
        "Pig",
        V.p["bac_ga"],
        function()
            bU(0xB11BAB56)
        end
    )
    V.add.a(
        "Poodle",
        V.p["bac_ga"],
        function()
            bU(0x431D501C)
        end
    )
    V.add.a(
        "Pug",
        V.p["bac_ga"],
        function()
            bU(0x6D362854)
        end
    )
    V.add.a(
        "Rabbit",
        V.p["bac_ga"],
        function()
            bU(0xDFB55C81)
        end
    )
    V.add.a(
        "Rat",
        V.p["bac_ga"],
        function()
            bU(0xC3B52966)
        end
    )
    V.add.a(
        "Golden Retriever",
        V.p["bac_ga"],
        function()
            bU(0x349F33E1, nil, true)
        end
    )
    V.add.a(
        "Rhesus",
        V.p["bac_ga"],
        function()
            bU(0xC2D06F53, nil, nil, true)
        end
    )
    V.add.a(
        "Rottweiler",
        V.p["bac_ga"],
        function()
            bU(0x9563221D, nil, true)
        end
    )
    V.add.a(
        "Westy",
        V.p["bac_ga"],
        function()
            bU(0xAD7844BB)
        end
    )
    V.p["bac_wa"] =
        V.add.p(
        "Water Animals",
        V.p["bac"],
        function()
            o("Note that these Models will only work in Water!", 48)
        end
    ).id
    V.add.a(
        "Dolphin",
        V.p["bac_wa"],
        function()
            bU(0x8BBAB455, true)
        end
    )
    V.add.a(
        "Fish",
        V.p["bac_wa"],
        function()
            bU(0x2FD800B7, true)
        end
    )
    V.add.a(
        "Hammershark",
        V.p["bac_wa"],
        function()
            bU(0x3C831724, true)
        end
    )
    V.add.a(
        "Humpback",
        V.p["bac_wa"],
        function()
            bU(0x471BE4B2, true)
        end
    )
    V.add.a(
        "Killerwhale",
        V.p["bac_wa"],
        function()
            bU(0x8D8AC8B9, true)
        end
    )
    V.add.a(
        "Shark",
        V.p["bac_wa"],
        function()
            bU(0x06C3F072, true, true)
        end
    )
    V.add.a(
        "Stingray",
        V.p["bac_wa"],
        function()
            bU(0xA148614D, true)
        end
    )
    V.p["bac_fa"] = V.add.p("Flying Animals", V.p["bac"]).id
    V.add.a(
        "Cormorant",
        V.p["bac_fa"],
        function()
            bU(0x56E29962)
        end
    )
    V.add.a(
        "Chickenhawk",
        V.p["bac_fa"],
        function()
            bU(0xAAB71F62)
        end
    )
    V.add.a(
        "Crow",
        V.p["bac_fa"],
        function()
            bU(0x18012A9F)
        end
    )
    V.add.a(
        "Pigeon",
        V.p["bac_fa"],
        function()
            bU(0x06A20728)
        end
    )
    V.add.a(
        "Seagull",
        V.p["bac_fa"],
        function()
            bU(0xD3939DFD)
        end
    )
    V.p["bac_sm"] = V.add.p("Standard Models", V.p["bac"]).id
    V.add.a(
        "Franklin",
        V.p["bac_sm"],
        function()
            bU(0x9B22DBAF, nil, nil, nil, true)
        end
    )
    V.add.a(
        "Michael",
        V.p["bac_sm"],
        function()
            bU(0x0D7114C9, nil, nil, nil, true)
        end
    )
    V.add.a(
        "Trevor",
        V.p["bac_sm"],
        function()
            bU(0x9B810FA2, nil, nil, nil, true)
        end
    )
    V.add.a(
        "MP Female",
        V.p["bac_sm"],
        function()
            bU(0x9C9EFFD8, nil, true, nil, true)
        end
    )
    V.add.a(
        "MP Male",
        V.p["bac_sm"],
        function()
            bU(0x705E61F2, nil, true, nil, true)
        end
    )
    V.t["bl_mdl_change"] =
        V.add.t(
        "Safe Model Change",
        V.p["bac"],
        function(k)
            l["bl_mdl_change"] = k.on
        end
    )
    V.t["bl_mdl_change"].on = l["bl_mdl_change"]
    V.t["revert_outfit"] =
        V.add.t(
        "Revert back Outfit",
        V.p["bac"],
        function(k)
            l["revert_outfit"] = k.on
        end
    )
    V.t["revert_outfit"].on = l["revert_outfit"]
    V.add.a(
        "Fix endless loading Screen",
        V.p["bac"],
        function()
            bU(0x9B22DBAF, nil, nil, nil, true)
            c.wait(100)
            ped.set_ped_health(R.ped(), 0)
        end
    )
    V.p["ptfx"] = V.add.p("PTFX", V.p["parent"])
    V.p["ptfx"].hidden = l["ptfx_hidden"]
    V.p["ptfx"] = V.p["ptfx"].id
    V.t["sparkling_ass"] =
        V.add.t(
        "Sparkling Ass",
        V.p["ptfx"],
        function(k)
            if k.on then
                graphics.set_next_ptfx_asset("scr_indep_fireworks")
                while not graphics.has_named_ptfx_asset_loaded("scr_indep_fireworks") do
                    graphics.request_named_ptfx_asset("scr_indep_fireworks")
                    c.wait(0)
                end
                graphics.start_networked_particle_fx_non_looped_at_coord(
                    "scr_indep_firework_trail_spawn",
                    R.coords(),
                    v3(60, 0, 0),
                    0.33,
                    true,
                    true,
                    true
                )
                c.wait(25)
            end
            l["sparkling_ass"] = k.on
            return d.stop(k)
        end
    )
    V.t["sparkling_ass"].on = l["sparkling_ass"]
    V.t["sparkling_tires"] =
        V.add.t(
        "Sparkling Tires",
        V.p["ptfx"],
        function(k)
            if k.on then
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    local eg = {"wheel_lf", "wheel_rf", "wheel_lr", "wheel_rr"}
                    for i = 1, #eg do
                        H.model(1803116220)
                        local eh = ao.object(1803116220, R.coords())
                        entity.set_entity_collision(eh, false, false, false)
                        c.visible(eh, false)
                        local B = entity.get_entity_bone_index_by_name(bN, eg[i])
                        c.attach(eh, bN, B, v3(), v3(), true, true, false, 0, true)
                        graphics.set_next_ptfx_asset("scr_indep_fireworks")
                        while not graphics.has_named_ptfx_asset_loaded("scr_indep_fireworks") do
                            graphics.request_named_ptfx_asset("scr_indep_fireworks")
                            c.wait(0)
                        end
                        graphics.start_networked_particle_fx_non_looped_at_coord(
                            "scr_indep_firework_trail_spawn",
                            c.gcoords(eh),
                            v3(60, 0, 0),
                            0.5,
                            true,
                            true,
                            true
                        )
                        H.ctrl(eh, 5)
                        entity.detach_entity(eh)
                        entity.set_entity_velocity(eh, v3())
                        bG(eh, v3(8000, 8000, -1000))
                        entity.delete_entity(eh)
                    end
                    c.unload(1803116220)
                    c.wait(25)
                end
            end
            l["sparkling_tires"] = k.on
            return d.stop(k)
        end
    )
    V.t["sparkling_tires"].on = l["sparkling_tires"]
    V.t["smoke_area"] =
        V.add.t(
        "Smoke Area",
        V.p["ptfx"],
        function(k)
            if k.on then
                for i = 1, 16 do
                    local aq = R.coords()
                    local ei = 2 * math.pi
                    ei = ei / 16
                    ei = ei * i
                    aq.x = aq.x + 18 * math.cos(ei)
                    aq.y = aq.y + 18 * math.sin(ei)
                    aq.z = aq.z - 2.5
                    graphics.set_next_ptfx_asset("scr_recartheft")
                    while not graphics.has_named_ptfx_asset_loaded("scr_recartheft") do
                        graphics.request_named_ptfx_asset("scr_recartheft")
                        c.wait(0)
                    end
                    graphics.start_networked_particle_fx_non_looped_at_coord(
                        "scr_wheel_burnout",
                        aq,
                        v3(),
                        2.5,
                        true,
                        true,
                        true
                    )
                    c.wait(40)
                end
            end
            l["smoke_area"] = k.on
            return d.stop(k)
        end
    )
    V.t["smoke_area"].on = l["smoke_area"]
    V.t["fire_circle"] =
        V.add.t(
        "Fire Circle",
        V.p["ptfx"],
        function(k)
            if k.on then
                if bF["fire_balls"][1] == nil then
                    for i = 1, 48 do
                        H.model(1803116220)
                        bF["fire_balls"][i] = ao.object(1803116220, R.coords())
                        entity.set_entity_collision(bF["fire_balls"][i], false, false, false)
                        c.visible(bF["fire_balls"][i], false)
                    end
                    c.unload(1803116220)
                end
                for i = 1, 48 do
                    local aq = R.coords()
                    local ei = 2 * math.pi
                    ei = ei / 48
                    ei = ei * c.random(1, 64)
                    aq.x = aq.x + 10 * math.cos(ei)
                    aq.y = aq.y + 10 * math.sin(ei)
                    aq.z = aq.z - 1.5
                    bG(bF["fire_balls"][i], aq)
                end
                c.wait(10)
                if bF["fire_circle"][1] == nil then
                    for i = 1, 48 do
                        graphics.set_next_ptfx_asset("weap_xs_vehicle_weapons")
                        while not graphics.has_named_ptfx_asset_loaded("weap_xs_vehicle_weapons") do
                            graphics.request_named_ptfx_asset("weap_xs_vehicle_weapons")
                            c.wait(0)
                        end
                        bF["fire_circle"][i] =
                            graphics.start_ptfx_looped_on_entity(
                            "muz_xs_turret_flamethrower_looping",
                            bF["fire_balls"][i],
                            v3(),
                            v3(90, 0, 0),
                            1
                        )
                    end
                end
            end
            if not k.on then
                bI(bF["fire_balls"])
                bF["fire_balls"] = {}
                if bF["fire_circle"][1] ~= nil then
                    for i = 1, #bF["fire_circle"] do
                        graphics.remove_particle_fx(bF["fire_circle"][i], true)
                    end
                    bF["fire_circle"] = {}
                end
            end
            return d.stop(k)
        end
    )
    V.t["fire_circle"].on = l["fire_circle"]
    V.t["fire_fart"] =
        V.add.u(
        "Fire Fart",
        "action_value_i",
        V.p["ptfx"],
        function(k)
            l["fire_fart"] = V.t["fire_fart"].value_i
            local bN = c.vehicle(R.ped())
            if bN ~= 0 then
                o("Fire Fart in a vehicle is too dangerous, get out!", 162)
            else
                local ap = 0x187D938D
                local ej = "weap_xs_vehicle_weapons"
                local ek = "muz_xs_turret_flamethrower_looping"
                H.model(ap)
                local as = R.heading()
                local cC = ao.vehicle(ap, R.coords(), as)
                H.ctrl(cC)
                c.visible(cC, false)
                c.unload(ap)
                decorator.decor_set_int(cC, "MPBitset", 1 << 10)
                ped.set_ped_into_vehicle(R.ped(), cC, -1)
                c.wait(500)
                graphics.set_next_ptfx_asset(ej)
                while not graphics.has_named_ptfx_asset_loaded(ej) do
                    graphics.request_named_ptfx_asset(ej)
                    c.wait(0)
                end
                local el = k.value_i
                local fire = graphics.start_ptfx_looped_on_entity(ek, R.ped(), v3(), v3(180, 0, 0), el * 0.1)
                local aq = c.gcoords(cC)
                local c_ = entity.get_entity_rotation(cC)
                local dD = c_
                dD:transformRotToDir()
                dD = dD * 1 * el
                dD.z = aq.z + 0.6666666 * el
                local em = dD
                entity.set_entity_velocity(cC, em)
                c.wait(250 * el)
                graphics.remove_particle_fx(fire, true)
                while ped.is_ped_in_any_vehicle(R.ped()) do
                    ai.task_leave_vehicle(R.ped(), cC, 16)
                    c.wait(25)
                end
                bI({cC})
            end
        end
    )
    V.t["fire_fart"].max_i = 16
    V.t["fire_fart"].min_i = 4
    V.t["fire_fart"].value_i = l["fire_fart"]
    V.t["fire_ass"] =
        V.add.t(
        "Fire Ass",
        V.p["ptfx"],
        function(k)
            l["fire_ass"] = k.on
            if k.on then
                if bF["fire_ass_ball"] == nil then
                    H.model(1803116220)
                    bF["fire_ass_ball"] = ao.object(1803116220, R.coords())
                    entity.set_entity_collision(bF["fire_ass_ball"], false, false, false)
                    c.visible(bF["fire_ass_ball"], false)
                    c.unload(1803116220)
                end
                if bF["fire_ass"] == nil then
                    local ej = "weap_xs_vehicle_weapons"
                    local ek = "muz_xs_turret_flamethrower_looping"
                    graphics.set_next_ptfx_asset(ej)
                    while not graphics.has_named_ptfx_asset_loaded(ej) do
                        graphics.request_named_ptfx_asset(ej)
                        c.wait(0)
                    end
                    bF["fire_ass"] = graphics.start_ptfx_looped_on_entity(ek, R.ped(), v3(), v3(180, 0, 0), 0.333)
                end
                local aq = R.coords()
                bG(bF["fire_ass_ball"], R.coords())
            end
            if not k.on then
                if bF["fire_ass"] ~= nil then
                    graphics.remove_particle_fx(bF["fire_ass"], true)
                    bF["fire_ass"] = nil
                end
                bI({bF["fire_ass_ball"]})
                bF["fire_ass_ball"] = nil
            end
            return d.stop(k)
        end
    )
    V.t["fire_ass"].on = l["fire_ass"]
    V.p["misc"] = V.add.p("Miscellaneous", V.p["parent"])
    V.p["misc"].hidden = l["misc_hidden"]
    V.p["misc"] = V.p["misc"].id
    V.p["weapon"] = V.add.p("Weapon-Features", V.p["misc"]).id
    V.t["load_weapons"] =
        V.add.t(
        "Load Weapons",
        V.p["weapon"],
        function(k)
            if k.on then
                local time = c.time() + 500
                while k.on do
                    c.wait(0)
                    if time < c.time() then
                        break
                    end
                end
                local en = weapon.get_all_weapon_hashes()
                for i = 1, #en do
                    if weapon.has_ped_got_weapon(R.ped(), en[i]) then
                        local eo = false
                        for E = 1, #a_ do
                            if en[i] == a_[E][1] then
                                eo = true
                            end
                        end
                        if not eo then
                            weapon.remove_weapon_from_ped(R.ped(), en[i])
                        end
                    end
                end
                for i = 1, #a_ do
                    if not weapon.has_ped_got_weapon(R.ped(), a_[i][1]) then
                        weapon.give_delayed_weapon_to_ped(R.ped(), a_[i][1], 0, 0)
                    end
                end
                for i = 1, #a_ do
                    for da = 2, #a_[i] do
                        if not weapon.has_ped_got_weapon_component(R.ped(), a_[i][1], a_[i][da]) then
                            for dk = 2, #a_[i] do
                                weapon.give_weapon_component_to_ped(R.ped(), a_[i][1], a_[i][dk])
                            end
                            weapon.set_ped_ammo(R.ped(), a_[i][1], 9999)
                        end
                    end
                end
            end
            l["load_weapons"] = k.on
            return d.stop(k)
        end
    )
    V.t["load_weapons"].on = l["load_weapons"]
    V.p["flamethrower"] = V.add.p("Flamethrower", V.p["weapon"]).id
    V.t["flamethrower_scale"] =
        V.add.u(
        "Scale",
        "autoaction_value_i",
        V.p["flamethrower"],
        function()
            l["flamethrower_scale"] = V.t["flamethrower_scale"].value_i
        end
    )
    V.t["flamethrower_scale"].min_i = 1
    V.t["flamethrower_scale"].max_i = 25
    V.t["flamethrower_scale"].value_i = l["flamethrower_scale"]
    V.t["flamethrower"] =
        V.add.t(
        "Flamethrower",
        V.p["flamethrower"],
        function(k)
            if k.on then
                if player.is_player_free_aiming(c.id()) then
                    graphics.set_next_ptfx_asset("weap_xs_vehicle_weapons")
                    while not graphics.has_named_ptfx_asset_loaded("weap_xs_vehicle_weapons") do
                        graphics.request_named_ptfx_asset("weap_xs_vehicle_weapons")
                        c.wait(0)
                    end
                    if bF["alien"] == nil then
                        H.model(1803116220)
                        bF["alien"] = ao.object(1803116220, R.coords())
                        entity.set_entity_collision(bF["alien"], false, false, false)
                        c.visible(bF["alien"], false)
                        c.unload(1803116220)
                    end
                    local ep, eq = ped.get_ped_bone_coords(R.ped(), 0xdead, v3())
                    while not ep do
                        c.wait(0)
                        ep, eq = ped.get_ped_bone_coords(R.ped(), 0xdead, v3())
                    end
                    bG(bF["alien"], eq)
                    entity.set_entity_rotation(bF["alien"], cam.get_gameplay_cam_rot())
                    if bF["flamethrower"] == nil then
                        bF["flamethrower"] =
                            graphics.start_ptfx_looped_on_entity(
                            "muz_xs_turret_flamethrower_looping",
                            bF["alien"],
                            v3(),
                            v3(),
                            l["flamethrower_scale"]
                        )
                        graphics.set_particle_fx_looped_scale(bF["flamethrower"], l["flamethrower_scale"])
                    end
                else
                    if bF["flamethrower"] ~= nil then
                        graphics.remove_particle_fx(bF["flamethrower"], true)
                        bF["flamethrower"] = nil
                        bI({bF["alien"]})
                        bF["alien"] = nil
                    end
                end
            end
            if not k.on then
                if bF["flamethrower"] ~= nil then
                    graphics.remove_particle_fx(bF["flamethrower"], true)
                    bF["flamethrower"] = nil
                    bI({bF["alien"]})
                    bF["alien"] = nil
                end
            end
            l["flamethrower"] = k.on
            return d.stop(k)
        end
    )
    V.t["flamethrower"].on = l["flamethrower"]
    V.t["flamethrower_green"] =
        V.add.t(
        "Flamethrower - Green",
        V.p["flamethrower"],
        function(k)
            if k.on then
                if player.is_player_free_aiming(c.id()) then
                    graphics.set_next_ptfx_asset("weap_xs_vehicle_weapons")
                    while not graphics.has_named_ptfx_asset_loaded("weap_xs_vehicle_weapons") do
                        graphics.request_named_ptfx_asset("weap_xs_vehicle_weapons")
                        c.wait(0)
                    end
                    if bF["alien"] == nil then
                        H.model(1803116220)
                        bF["alien"] = ao.object(1803116220, R.coords())
                        entity.set_entity_collision(bF["alien"], false, false, false)
                        c.visible(bF["alien"], false)
                        c.unload(1803116220)
                    end
                    local ep, eq = ped.get_ped_bone_coords(R.ped(), 0xdead, v3())
                    while not ep do
                        c.wait(0)
                        ep, eq = ped.get_ped_bone_coords(R.ped(), 0xdead, v3())
                    end
                    bG(bF["alien"], eq)
                    entity.set_entity_rotation(bF["alien"], cam.get_gameplay_cam_rot())
                    if bF["flamethrower_green"] == nil then
                        bF["flamethrower_green"] =
                            graphics.start_ptfx_looped_on_entity(
                            "muz_xs_turret_flamethrower_looping_sf",
                            bF["alien"],
                            v3(),
                            v3(),
                            l["flamethrower_scale"]
                        )
                    end
                else
                    if bF["flamethrower_green"] ~= nil then
                        graphics.remove_particle_fx(bF["flamethrower_green"], true)
                        bF["flamethrower_green"] = nil
                        bI({bF["alien"]})
                        bF["alien"] = nil
                    end
                end
            end
            if not k.on then
                if bF["flamethrower_green"] ~= nil then
                    graphics.remove_particle_fx(bF["flamethrower_green"], true)
                    bF["flamethrower_green"] = nil
                    bI({bF["alien"]})
                    bF["alien"] = nil
                end
            end
            l["flamethrower_green"] = k.on
            return d.stop(k)
        end
    )
    V.t["flamethrower_green"].on = l["flamethrower_green"]
    V.p["shoot"] = V.add.p("Shoot Objects", V.p["weapon"]).id
    V.t["shoot"] =
        V.add.t(
        "Enable Object Shoot",
        V.p["shoot"],
        function(k)
            if k.on then
                for i = 1, #az do
                    if l[az[i][1]] and ped.is_ped_shooting(R.ped()) then
                        if #aI["shooting"] > 128 then
                            bI(aI["shooting"])
                            aI["shooting"] = {}
                        end
                        H.model(az[i][2])
                        local aq = R.coords()
                        local dD = cam.get_gameplay_cam_rot()
                        dD:transformRotToDir()
                        dD = dD * 8
                        aq = aq + dD
                        if streaming.is_model_an_object(az[i][2]) then
                            aI["shooting"][#aI["shooting"] + 1] = ao.object(az[i][2], aq)
                        end
                        dD = nil
                        local er = R.coords()
                        dD = cam.get_gameplay_cam_rot()
                        dD:transformRotToDir()
                        dD = dD * 100
                        er = er + dD
                        local e9 = er - aq
                        entity.apply_force_to_entity(
                            aI["shooting"][#aI["shooting"]],
                            3,
                            e9.x,
                            e9.y,
                            e9.z,
                            0.0,
                            0.0,
                            0.0,
                            true,
                            true
                        )
                    end
                end
            end
            if not k.on then
                bI(aI["shooting"])
                aI["shooting"] = {}
            end
            l["shoot_entitys"] = k.on
            return d.stop(k)
        end
    )
    V.t["shoot"].on = l["shoot_entitys"]
    V.add.a(
        "Delete Objects",
        V.p["shoot"],
        function()
            bI(aI["shooting"])
            aI["shooting"] = {}
        end
    )
    for i = 1, #az do
        V.t[az[i][1]] =
            V.add.t(
            "Shoot " .. az[i][1],
            V.p["shoot"],
            function(k)
                az[i][3] = k.on
                l[az[i][1]] = k.on
            end
        )
        V.t[az[i][1]].on = l[az[i][1]]
    end
    V.t["delete_gun"] =
        V.add.t(
        "Delete Gun",
        V.p["weapon"],
        function(k)
            if k.on then
                if ped.is_ped_shooting(R.ped()) then
                    local es = player.get_entity_player_is_aiming_at(c.id())
                    if es ~= nil then
                        bI({es})
                    end
                end
            end
            l["delete_gun"] = k.on
            return d.stop(k)
        end
    )
    V.t["delete_gun"].on = l["delete_gun"]
    V.t["kick_gun"] =
        V.add.t(
        "Kick Gun",
        V.p["weapon"],
        function(k)
            if k.on then
                if ped.is_ped_shooting(R.ped()) then
                    local et = player.get_entity_player_is_aiming_at(c.id())
                    if ped.is_ped_a_player(et) then
                        o("Kick-Gun hit: " .. K.name(et))
                        c2(false, player.get_player_from_ped(et))
                    end
                end
            end
            l["kick_gun"] = k.on
            return d.stop(k)
        end
    )
    V.t["kick_gun"].on = l["kick_gun"]
    V.t["demigod_gun"] =
        V.add.t(
        "Give Demi-God for Player",
        V.p["weapon"],
        function(k)
            if k.on then
                if ped.is_ped_shooting(R.ped()) then
                    local et = player.get_entity_player_is_aiming_at(c.id())
                    if ped.is_ped_a_player(et) then
                        o("Attached Demi-God on Player: " .. K.name(et))
                        c6(aS[1][2], player.get_player_from_ped(et))
                    end
                end
            end
            l["demigod_gun"] = k.on
            return d.stop(k)
        end
    )
    V.t["demigod_gun"].on = l["demigod_gun"]
    V.p["model_gun"] = V.add.p("Model Gun", V.p["weapon"]).id
    V.t["model_gun"] =
        V.add.t(
        "Standard Model Gun (PEDs)",
        V.p["model_gun"],
        function(k)
            if k.on then
                if bs then
                    c.visible(R.ped(), false)
                    if br ~= nil then
                        c.visible(br, true)
                    end
                else
                    c.visible(R.ped(), true)
                end
                if player.is_player_free_aiming(c.id()) then
                    local eu = player.get_entity_player_is_aiming_at(c.id())
                    if eu ~= 0 then
                        eu = entity.get_entity_model_hash(eu)
                        if streaming.is_model_a_ped(eu) then
                            if br ~= nil then
                                bI({br})
                                br = nil
                            end
                            local ev = entity.get_entity_model_hash(R.ped())
                            if eu ~= ev then
                                bs = false
                                c.wait(50)
                                local ew = ped.get_current_ped_weapon(R.ped())
                                bU(eu, nil, nil, nil, true)
                                c.wait(25)
                                weapon.give_delayed_weapon_to_ped(R.ped(), ew, 0, 1)
                            end
                        elseif streaming.is_model_a_vehicle(eu) and V.t["model_gun_ext"].on then
                            bI({br})
                            br = nil
                            bs = true
                            br = ao.vehicle(eu, R.coords())
                            c.attach(br, R.ped(), 0, v3(), v3(), true, true, false, 0, true)
                        elseif streaming.is_model_an_object(eu) and V.t["model_gun_ext"].on then
                            bI({br})
                            br = nil
                            H.model(eu)
                            br = ao.object(eu, R.coords())
                            c.unload(eu)
                            bs = true
                            c.attach(br, R.ped(), 0, v3(), v3(), true, true, false, 0, true)
                        end
                    end
                end
            end
            if not k.on then
                bI({br})
                br = nil
                c.visible(R.ped(), true)
            end
            l["model_gun"] = k.on
            return d.stop(k)
        end
    )
    V.t["model_gun"].on = l["model_gun"]
    V.t["model_gun_ext"] =
        V.add.t(
        "Add Objects and Vehicles to Model Gun",
        V.p["model_gun"],
        function(k)
            l["model_gun_ext"] = k.on
        end
    )
    V.t["model_gun_ext"].on = l["model_gun_ext"]
    V.t["rapid_fire"] =
        V.add.t(
        "Rapid Fire",
        V.p["weapon"],
        function(k)
            if k.on then
                if player.is_player_free_aiming(c.id()) then
                    if ped.is_ped_shooting(R.ped()) then
                        for i = 1, 20 do
                            local ep, ex = ped.get_ped_bone_coords(R.ped(), 0x67f2, v3())
                            while not ep do
                                ep, ex = ped.get_ped_bone_coords(R.ped(), 0x67f2, v3())
                                c.wait(0)
                            end
                            local dD = cam.get_gameplay_cam_rot()
                            dD:transformRotToDir()
                            dD = dD * 1.5
                            ex = ex + dD
                            dD = nil
                            local ey = R.coords()
                            dD = cam.get_gameplay_cam_rot()
                            dD:transformRotToDir()
                            dD = dD * 1500
                            ey = ey + dD
                            local ez = ped.get_current_ped_weapon(R.ped())
                            gameplay.shoot_single_bullet_between_coords(ex, ey, 1, ez, R.ped(), true, false, 1000)
                            c.wait(25)
                        end
                    end
                end
            end
            l["rapid_fire"] = k.on
            return d.stop(k)
        end
    )
    V.t["rapid_fire"].on = l["rapid_fire"]
    V.t["teleport_high_in_air"] =
        V.add.a(
        "Teleport High in Air",
        V.p["misc"],
        function()
            local aq = R.coords()
            while aq.z < 25000 do
                aq.z = aq.z + 500
                bK(aq)
                c.wait(50)
            end
        end
    )
    V.p["vehicle"] = V.add.p("Vehicle", V.p["misc"]).id
    V.t["tp_own_veh_to_me"] =
        V.add.a(
        "Teleport Own Vehicle to me",
        V.p["vehicle"],
        function()
            local bN = player.get_personal_vehicle()
            local eA = c.vehicle(R.ped())
            if bN ~= 0 and eA ~= bN then
                bG(bN, ck(R.coords(), R.heading(), 5))
                entity.set_entity_heading(bN, R.heading())
            end
        end
    )
    V.t["tp_own_veh_to_me_drive"] =
        V.add.a(
        "Teleport Own Vehicle to me and drive",
        V.p["vehicle"],
        function()
            local bN = player.get_personal_vehicle()
            local eA = c.vehicle(R.ped())
            if bN ~= 0 and eA ~= bN then
                bG(bN, R.coords())
                entity.set_entity_heading(bN, R.heading())
                ped.set_ped_into_vehicle(R.ped(), bN, -1)
            end
        end
    )
    V.t["drive_own_veh"] =
        V.add.a(
        "Drive Own Vehicle",
        V.p["vehicle"],
        function()
            local bN = player.get_personal_vehicle()
            local eA = c.vehicle(R.ped())
            if bN ~= 0 and eA ~= bN then
                ped.set_ped_into_vehicle(R.ped(), bN, -1)
            end
        end
    )
    V.t["tp_to_own_veh"] =
        V.add.a(
        "Teleport to Own Vehicle",
        V.p["vehicle"],
        function()
            local bN = player.get_personal_vehicle()
            local eA = c.vehicle(R.ped())
            r(bN)
            r(eA)
            if bN ~= 0 and eA ~= bN then
                bK(ck(c.gcoords(bN), entity.get_entity_heading(bN), -5), 0, entity.get_entity_heading(bN))
            end
        end
    )
    V.p["vehicle_colors"] = V.add.p("Vehicle Colors", V.p["vehicle"]).id
    V.t["light_speed"] =
        V.add.u(
        "Set Speed in Milliseconds",
        "autoaction_value_i",
        V.p["vehicle_colors"],
        function(k)
            l["veh_lights_speed"] = k.value_i
        end
    )
    V.t["light_speed"].min_i = 25
    V.t["light_speed"].max_i = 2500
    V.t["light_speed"].mod_i = 25
    V.t["light_speed"].value_i = l["veh_lights_speed"]
    V.p["random_col"] = V.add.p("Random Colors", V.p["vehicle_colors"]).id
    V.t["random_primary"] =
        V.add.t(
        "Random Primary",
        V.p["random_col"],
        function(k)
            if k.on then
                cr(b3)
                cr({"rainbow_primary"})
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    H.ctrl(bN)
                    vehicle.set_vehicle_custom_primary_colour(bN, c.random(0, 0xffffff))
                    c.wait(V.t["light_speed"].value_i)
                end
            end
            l["random_primary"] = k.on
            return d.stop(k)
        end
    )
    V.t["random_primary"].on = l["random_primary"]
    V.t["random_secondary"] =
        V.add.t(
        "Random Secondary",
        V.p["random_col"],
        function(k)
            if k.on then
                cr(b3)
                cr({"rainbow_secondary"})
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    H.ctrl(bN)
                    vehicle.set_vehicle_custom_secondary_colour(bN, c.random(0, 0xffffff))
                    c.wait(V.t["light_speed"].value_i)
                end
            end
            l["random_secondary"] = k.on
            return d.stop(k)
        end
    )
    V.t["random_secondary"].on = l["random_secondary"]
    V.t["random_pearlescent"] =
        V.add.t(
        "Random Pearlescent",
        V.p["random_col"],
        function(k)
            if k.on then
                cr(b3)
                cr({"rainbow_pearlescent"})
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    H.ctrl(bN)
                    vehicle.set_vehicle_custom_pearlescent_colour(bN, c.random(0, 0xffffff))
                    c.wait(V.t["light_speed"].value_i)
                end
            end
            l["random_pearlescent"] = k.on
            return d.stop(k)
        end
    )
    V.t["random_pearlescent"].on = l["random_pearlescent"]
    V.t["random_neon"] =
        V.add.t(
        "Random Neon Lights",
        V.p["random_col"],
        function(k)
            if k.on then
                cr(b3)
                cr({"rainbow_neon"})
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    H.ctrl(bN)
                    local p = c.random(0, 0xffffff)
                    vehicle.set_vehicle_neon_lights_color(bN, p)
                    c.wait(V.t["light_speed"].value_i)
                end
            end
            l["random_neon"] = k.on
            return d.stop(k)
        end
    )
    V.t["random_neon"].on = l["random_neon"]
    V.t["random_smoke"] =
        V.add.t(
        "Random Smoke",
        V.p["random_col"],
        function(k)
            if k.on then
                cr(b3)
                cr({"rainbow_smoke"})
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    H.ctrl(bN)
                    local eB = c.random(0, 255)
                    local eC = c.random(0, 255)
                    local eD = c.random(0, 255)
                    vehicle.set_vehicle_tire_smoke_color(bN, eB, eC, eD)
                    c.wait(V.t["light_speed"].value_i)
                end
            end
            l["random_smoke"] = k.on
            return d.stop(k)
        end
    )
    V.t["random_smoke"].on = l["random_smoke"]
    V.t["random_xenon"] =
        V.add.t(
        "Random Xenon",
        V.p["random_col"],
        function(k)
            if k.on then
                cr(b3)
                cr({"rainbow_xenon"})
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    H.ctrl(bN)
                    vehicle.set_vehicle_headlight_color(bN, c.random(0, 12))
                    c.wait(V.t["light_speed"].value_i)
                end
            end
            l["random_xenon"] = k.on
            return d.stop(k)
        end
    )
    V.t["random_xenon"].on = l["random_xenon"]
    V.p["rainbow_col"] = V.add.p("Rainbow Colors", V.p["vehicle_colors"]).id
    V.t["rainbow_primary"] =
        V.add.t(
        "Rainbow Primary",
        V.p["rainbow_col"],
        function(k)
            if k.on then
                cr(b3)
                cr({"random_primary"})
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    H.ctrl(bN)
                    for i = 1, #aA do
                        vehicle.set_vehicle_custom_primary_colour(bN, cm({aA[i][1], aA[i][2], aA[i][3]}))
                        c.wait(V.t["light_speed"].value_i)
                    end
                end
            end
            l["rainbow_primary"] = k.on
            return d.stop(k)
        end
    )
    V.t["rainbow_primary"].on = l["rainbow_primary"]
    V.t["rainbow_secondary"] =
        V.add.t(
        "Rainbow Secondary",
        V.p["rainbow_col"],
        function(k)
            if k.on then
                cr(b3)
                cr({"random_secondary"})
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    H.ctrl(bN)
                    for i = 1, #aA do
                        vehicle.set_vehicle_custom_secondary_colour(bN, cm({aA[i][1], aA[i][2], aA[i][3]}))
                        c.wait(V.t["light_speed"].value_i)
                    end
                end
            end
            l["rainbow_secondary"] = k.on
            return d.stop(k)
        end
    )
    V.t["rainbow_secondary"].on = l["rainbow_secondary"]
    V.t["rainbow_pearlescent"] =
        V.add.t(
        "Rainbow Pearlescent",
        V.p["rainbow_col"],
        function(k)
            if k.on then
                cr(b3)
                cr({"random_pearlescent"})
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    H.ctrl(bN)
                    for i = 1, #aA do
                        vehicle.set_vehicle_custom_pearlescent_colour(bN, cm({aA[i][1], aA[i][2], aA[i][3]}))
                        c.wait(V.t["light_speed"].value_i)
                    end
                end
            end
            l["rainbow_pearlescent"] = k.on
            return d.stop(k)
        end
    )
    V.t["rainbow_pearlescent"].on = l["rainbow_pearlescent"]
    V.t["rainbow_neon"] =
        V.add.t(
        "Rainbow Neon Lights",
        V.p["rainbow_col"],
        function(k)
            if k.on then
                cr(b3)
                cr({"random_neon"})
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    H.ctrl(bN)
                    for i = 1, #aA do
                        vehicle.set_vehicle_neon_lights_color(bN, cm({aA[i][1], aA[i][2], aA[i][3]}))
                        c.wait(V.t["light_speed"].value_i)
                    end
                end
            end
            l["rainbow_neon"] = k.on
            return d.stop(k)
        end
    )
    V.t["rainbow_neon"].on = l["rainbow_neon"]
    V.t["rainbow_smoke"] =
        V.add.t(
        "Rainbow Smoke",
        V.p["rainbow_col"],
        function(k)
            if k.on then
                cr(b3)
                cr({"random_smoke"})
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    H.ctrl(bN)
                    for i = 1, #aA do
                        local cu = aA[i]
                        vehicle.set_vehicle_tire_smoke_color(bN, cu[1], cu[2], cu[3])
                        c.wait(V.t["light_speed"].value_i)
                    end
                end
            end
            l["rainbow_smoke"] = k.on
            return d.stop(k)
        end
    )
    V.t["rainbow_smoke"].on = l["rainbow_smoke"]
    V.t["rainbow_xenon"] =
        V.add.t(
        "Rainbow Xenon",
        V.p["rainbow_col"],
        function(k)
            if k.on then
                cr(b3)
                cr({"random_xenon"})
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    H.ctrl(bN)
                    for i = 0, 12 do
                        vehicle.set_vehicle_headlight_color(bN, i)
                        c.wait(V.t["light_speed"].value_i)
                    end
                end
            end
            l["rainbow_xenon"] = k.on
            return d.stop(k)
        end
    )
    V.t["rainbow_xenon"].on = l["rainbow_xenon"]
    V.t["synced_random"] =
        V.add.t(
        "Synced Random Colors",
        V.p["vehicle_colors"],
        function(k)
            if k.on then
                cr(b2)
                cr(b1)
                cr({"synced_rainbow_smooth", "synced_rainbow"})
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    ct(bN, {c.random(0, 255), c.random(0, 255), c.random(0, 255)})
                    c.wait(V.t["light_speed"].value_i)
                end
            end
            l["synced_random"] = k.on
            return d.stop(k)
        end
    )
    V.t["synced_random"].on = l["synced_random"]
    V.t["synced_rainbow"] =
        V.add.t(
        "Synced Rainbow Colors",
        V.p["vehicle_colors"],
        function(k)
            if k.on then
                cr(b2)
                cr(b1)
                cr({"synced_random", "synced_rainbow_smooth"})
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    for i = 1, #aA do
                        local cu = aA[i]
                        ct(bN, {cu[1], cu[2], cu[3]}, i)
                        c.wait(V.t["light_speed"].value_i)
                    end
                end
            end
            l["synced_rainbow"] = k.on
            return d.stop(k)
        end
    )
    V.t["synced_rainbow"].on = l["synced_rainbow"]
    V.t["synced_rainbow_smooth"] =
        V.add.t(
        "Synced Smooth Rainbow",
        V.p["vehicle_colors"],
        function(k)
            if k.on then
                cr(b2)
                cr(b1)
                cr({"synced_random", "synced_rainbow"})
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    local eE
                    eE = math.floor((101 - V.t["light_speed"].value_i / 25) / 2)
                    if eE < 1 then
                        eE = 1
                    end
                    for i = 0, 255, eE do
                        ct(bN, {255, i, 0})
                    end
                    eE = math.floor((101 - V.t["light_speed"].value_i / 25) / 2)
                    if eE < 1 then
                        eE = 1
                    end
                    for i = 255, 0, -eE do
                        ct(bN, {i, 255, 0})
                    end
                    eE = math.floor((101 - V.t["light_speed"].value_i / 25) / 2)
                    if eE < 1 then
                        eE = 1
                    end
                    for i = 0, 255, eE do
                        ct(bN, {0, 255, i})
                    end
                    eE = math.floor((101 - V.t["light_speed"].value_i / 25) / 2)
                    if eE < 1 then
                        eE = 1
                    end
                    for i = 255, 0, -eE do
                        ct(bN, {0, i, 255})
                    end
                    eE = math.floor((101 - V.t["light_speed"].value_i / 25) / 2)
                    if eE < 1 then
                        eE = 1
                    end
                    for i = 0, 255, eE do
                        ct(bN, {i, 0, 255})
                    end
                    eE = math.floor((101 - V.t["light_speed"].value_i / 25) / 2)
                    if eE < 1 then
                        eE = 1
                    end
                    for i = 255, 0, -eE do
                        ct(bN, {255, 0, i})
                    end
                end
            end
            l["synced_rainbow_smooth"] = k.on
            return d.stop(k)
        end
    )
    V.t["synced_rainbow_smooth"].on = l["synced_rainbow_smooth"]
    V.add.a(
        "100% Black",
        V.p["vehicle_colors"],
        function()
            local bN = c.vehicle(R.ped())
            if bN ~= 0 then
                ct(bN, {0, 0, 0}, 0)
            else
                o("Get in a valid Vehicle!", 173)
            end
        end
    )
    V.t["black_100"] =
        V.add.t(
        "100% Black",
        V.p["vehicle_colors"],
        function(k)
            if k.on then
                cr(b2)
                cr(b1)
                cr(b3)
                cr({"fade_black_red"})
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    ct(bN, {0, 0, 0}, 0)
                end
            end
            l["black_100"] = k.on
            return d.stop(k)
        end
    )
    V.t["black_100"].on = l["black_100"]
    V.t["fade_black_red"] =
        V.add.t(
        "Fade Black-Red",
        V.p["vehicle_colors"],
        function(k)
            if k.on then
                cr(b2)
                cr(b1)
                cr(b3)
                cr({"black_100"})
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    local eE
                    eE = math.floor((101 - V.t["light_speed"].value_i / 25) / 2)
                    if eE < 1 then
                        eE = 1
                    end
                    for i = 0, 255, eE do
                        ct(bN, {i, 0, 0}, 0, 8)
                    end
                    eE = math.floor((101 - V.t["light_speed"].value_i / 25) / 2)
                    if eE < 1 then
                        eE = 1
                    end
                    for i = 255, 0, -eE do
                        ct(bN, {i, 0, 0}, 0, 8)
                    end
                end
            end
            l["fade_black_red"] = k.on
            return d.stop(k)
        end
    )
    V.t["fade_black_red"].on = l["fade_black_red"]
    V.t["heli"] =
        V.add.u(
        "Heli Blades Speed 0-100%",
        "value_i",
        V.p["vehicle"],
        function(k)
            l["heli"] = k.on
            l["heli_i"] = k.value_i
            local bN = c.vehicle(R.ped())
            if k.on then
                if bN ~= 0 then
                    H.ctrl(bN)
                    local dc = k.value_i / 100
                    vehicle.set_heli_blades_speed(bN, dc)
                end
            end
            return d.stop(k)
        end
    )
    V.t["heli"].max_i = 100
    V.t["heli"].min_i = 0
    V.t["heli"].mod_i = 5
    V.t["heli"].value_i = l["heli_i"]
    V.t["heli"].on = l["heli"]
    V.t["sel_boost_speed"] =
        V.add.u(
        "Boost Vehicle",
        "value_i",
        V.p["vehicle"],
        function(k)
            l["sel_boost_speed"] = k.on
            l["sel_boost_speed_speed"] = k.value_i
            local bN = c.vehicle(R.ped())
            if k.on then
                if bN ~= 0 then
                    H.ctrl(bN)
                    entity.set_entity_max_speed(bN, k.value_i)
                    vehicle.set_vehicle_forward_speed(bN, k.value_i)
                end
            end
            if not k.on then
                entity.set_entity_max_speed(bN, 540)
            end
            return d.stop(k)
        end
    )
    V.t["sel_boost_speed"].max_i = 50000
    V.t["sel_boost_speed"].min_i = 0
    V.t["sel_boost_speed"].mod_i = 50
    V.t["sel_boost_speed"].value_i = l["sel_boost_speed_speed"]
    V.t["sel_boost_speed"].on = l["sel_boost_speed"]
    V.t["speedometer"] =
        V.add.u(
        "License Plate Speedometer",
        "value_i",
        V.p["vehicle"],
        function(k)
            l["speedometer"] = k.on
            l["speedometer_type"] = k.value_i
            be = k.value_i
            if k.on then
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    if be ~= bf then
                        o("Displaying Speed now with Unit:\n" .. aW[k.value_i][3], 96)
                    end
                    local eF = entity.get_entity_speed(bN) * aW[k.value_i][2]
                    if eF < 10 and eF > 0.01 then
                        eF = string.format("%.2f", eF)
                    elseif eF >= 10 and eF < 100 then
                        eF = string.format("%.1f", eF)
                    elseif eF < 0.01 and k.value_i == 7 then
                        eF = string.format("%.5f", eF)
                    else
                        eF = math.floor(eF)
                    end
                    H.ctrl(bN)
                    vehicle.set_vehicle_number_plate_text(bN, tostring(eF) .. aW[k.value_i][1])
                end
            end
            bf = k.value_i
            return d.stop(k)
        end
    )
    V.t["speedometer"].max_i = #aW
    V.t["speedometer"].min_i = 1
    V.t["speedometer"].value_i = l["speedometer_type"]
    V.t["speedometer"].on = l["speedometer"]
    V.t["veh_no_colision"] =
        V.add.t(
        "No collision",
        V.p["vehicle"],
        function(k)
            if k.on then
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    local eG = ped.get_all_peds()
                    for i = 1, #eG do
                        entity.set_entity_no_collsion_entity(eG[i], bN, true)
                        entity.set_entity_no_collsion_entity(bN, eG[i], true)
                    end
                    eG = object.get_all_objects()
                    for i = 1, #eG do
                        entity.set_entity_no_collsion_entity(eG[i], bN, true)
                        entity.set_entity_no_collsion_entity(bN, eG[i], true)
                    end
                    eG = vehicle.get_all_vehicles()
                    for i = 1, #eG do
                        entity.set_entity_no_collsion_entity(eG[i], bN, true)
                        entity.set_entity_no_collsion_entity(bN, eG[i], true)
                    end
                end
            end
            l["veh_no_colision"] = k.on
            return d.stop(k)
        end
    )
    V.t["veh_no_colision"].on = l["veh_no_colision"]
    V.t["auto_repair"] =
        V.add.t(
        "Auto Repair Vehicle",
        V.p["vehicle"],
        function(k)
            if k.on then
                local bN = c.vehicle(R.ped())
                if bN ~= 0 then
                    if vehicle.is_vehicle_damaged(bN) then
                        H.ctrl(bN)
                        vehicle.set_vehicle_fixed(bN)
                        vehicle.set_vehicle_deformation_fixed(bN)
                        vehicle.set_vehicle_engine_health(bN, 1000)
                        vehicle.set_vehicle_can_be_visibly_damaged(bN, false)
                    end
                end
            end
            l["auto_repair"] = k.on
            return d.stop(k)
        end
    )
    V.t["auto_repair"].on = l["auto_repair"]
    V.t["drive_on_ocean"] =
        V.add.t(
        "Drive / Walk on the Ocean",
        V.p["misc"],
        function(k)
            if k.on then
                local aq = R.coords()
                if bm == nil then
                    H.model(1822550295)
                    bm = ao.object(1822550295, v3(aq.x, aq.y, -4))
                    c.visible(bm, false)
                end
                water.set_waves_intensity(-100000000)
                aq.z = -4
                bG(bm, aq)
            end
            l["drive_on_ocean"] = k.on
            if not k.on and bm ~= nil then
                water.reset_waves_intensity()
                bI({bm})
                bm = nil
            end
            return d.stop(k)
        end
    )
    V.t["drive_on_ocean"].on = l["drive_on_ocean"]
    V.t["drive_this_height"] =
        V.add.t(
        "Drive / Walk this Height",
        V.p["misc"],
        function(k)
            if k.on then
                local aq, bL
                if ped.is_ped_in_any_vehicle(R.ped()) then
                    local bN = c.vehicle(R.ped())
                    aq = c.gcoords(bN)
                    bL = 5.25
                else
                    aq = R.coords()
                    bL = 5.85
                end
                if bn == nil then
                    H.model(1822550295)
                    bo = aq.z - bL
                    bn = ao.object(1822550295, v3(aq.x, aq.y, bo))
                    c.visible(bn, false)
                end
                water.set_waves_intensity(-100000000)
                aq.z = bo
                bG(bn, aq)
            end
            l["drive_this_height"] = k.on
            if not k.on and bn ~= nil then
                water.reset_waves_intensity()
                bI({bn})
                bn = nil
                bo = nil
            end
            return d.stop(k)
        end
    )
    V.t["drive_this_height"].on = l["drive_this_height"]
    V.t["weird_ent"] =
        V.add.t(
        "Weird Entity",
        V.p["misc"],
        function(k)
            local bN = c.vehicle(R.ped())
            local dH = R.ped()
            if k.on then
                if bN ~= 0 and bp == nil then
                    local ap = entity.get_entity_model_hash(bN)
                    bp = ao.vehicle(ap, R.coords())
                    dH = bN
                elseif bp == nil then
                    bp = ped.clone_ped(R.ped())
                end
                c.visible(dH, false)
                entity.set_entity_collision(bp, false, false, false)
                entity.set_entity_rotation(bp, v3(c.random(-180, 180), c.random(-180, 180), c.random(-180, 180)))
                bG(bp, R.coords())
            end
            if not k.on then
                bI({bp})
                bp = nil
                c.visible(dH, true)
            end
            l["weird_ent"] = k.on
            return d.stop(k)
        end
    )
    V.t["weird_ent"].on = l["weird_ent"]
    V.t["real_time"] =
        V.add.t(
        "Real Time (Clientside)",
        V.p["misc"],
        function(k)
            if k.on then
                local g = os.date("*t")
                time.set_clock_time(g.hour, g.min, g.sec)
                gameplay.clear_cloud_hat()
            end
            l["real_time"] = k.on
            return d.stop(k)
        end
    )
    V.t["real_time"].on = l["real_time"]
    V.t["random_clothes"] =
        V.add.t(
        "Random Clothes",
        V.p["misc"],
        function(k)
            if k.on then
                c.wait(333)
                ped.set_ped_random_component_variation(R.ped())
            end
            l["random_clothes"] = k.on
            return d.stop(k)
        end
    )
    V.t["random_clothes"].on = l["random_clothes"]
    V.t["clear_area"] =
        V.add.t(
        "Gameplay Clear Area",
        V.p["misc"],
        function(k)
            if k.on then
                local aq = R.coords()
                gameplay.clear_area_of_cops(aq, 10000, true)
                gameplay.clear_area_of_peds(aq, 10000, true)
                gameplay.clear_area_of_vehicles(aq, 10000, false, false, false, false, false)
                gameplay.clear_area_of_objects(aq, 10000, 0)
                gameplay.clear_area_of_objects(aq, 10000, 1)
                gameplay.clear_area_of_objects(aq, 10000, 2)
                gameplay.clear_area_of_objects(aq, 10000, 6)
                gameplay.clear_area_of_objects(aq, 10000, 16)
                gameplay.clear_area_of_objects(aq, 10000, 17)
            end
            l["clear_area"] = k.on
            return d.stop(k)
        end
    )
    V.t["clear_area"].on = l["clear_area"]
    V.t["clear_area_2"] =
        V.add.t(
        "Clear Area",
        V.p["misc"],
        function(k)
            if k.on then
                local eH = ped.get_all_peds()
                for i = 1, #eH do
                    local eI = eH[i]
                    if not ped.is_ped_a_player(eI) and k.on then
                        H.ctrl(eI, 250)
                        entity.set_entity_velocity(eI, v3())
                        bG(eI, v3(8000, 8000, -1000))
                        entity.delete_entity(eI)
                    end
                end
                eH = object.get_all_objects()
                for i = 1, #eH do
                    local eI = eH[i]
                    if k.on then
                        H.ctrl(eI, 250)
                        entity.set_entity_velocity(eI, v3())
                        bG(eI, v3(8000, 8000, -1000))
                        entity.delete_entity(eI)
                        c.wait(0)
                    end
                end
                eH = vehicle.get_all_vehicles()
                local eJ = {}
                for E = 0, 31 do
                    if K.scid(E) ~= -1 then
                        local bN = c.vehicle(c.ped(E))
                        if bN ~= 0 then
                            eJ[#eJ + 1] = bN
                        end
                    end
                end
                for i = 1, #eH do
                    local eI = eH[i]
                    if k.on then
                        local es = true
                        for aj = 1, #eJ do
                            if eI == eJ[aj] then
                                es = false
                            end
                        end
                        if es then
                            H.ctrl(eI, 250)
                            entity.set_entity_velocity(eI, v3())
                            bG(eI, v3(8000, 8000, -1000))
                            entity.delete_entity(eI)
                        end
                    end
                end
            end
            l["clear_area_2"] = k.on
            return d.stop(k)
        end
    )
    V.t["clear_area_2"].on = l["clear_area_2"]
    V.t["auto_tp_wp"] =
        V.add.t(
        "Auto Teleport to Waypoint",
        V.p["misc"],
        function(k)
            if k.on then
                local dg = ui.get_waypoint_coord()
                if dg.x ~= 16000 then
                    local aq = R.coords()
                    local eK = v2()
                    eK.x = aq.x
                    eK.y = aq.y
                    if dg:magnitude(eK) > 35 then
                        o("Detected Waypoint, teleporting...", 172)
                        local V = R.ped()
                        local eL = c.vehicle(V)
                        if eL ~= 0 then
                            V = eL
                        end
                        local eM = 850
                        local ep, eN = gameplay.get_ground_z(v3(dg.x, dg.y, eM))
                        while not ep do
                            eM = eM - 5
                            ep, eN = gameplay.get_ground_z(v3(dg.x, dg.y, eM))
                            if eM < -200 then
                                eM = -200
                                ep = true
                            end
                        end
                        bK(v3(dg.x, dg.y, eN))
                    end
                end
            end
            l["auto_tp_wp"] = k.on
            return d.stop(k)
        end
    )
    V.t["auto_tp_wp"].on = l["auto_tp_wp"]
    V.t["police_outfit"] =
        V.add.t(
        "Force Police Outfit",
        V.p["misc"],
        function(k)
            if k.on then
                local K = "male"
                if player.is_player_female(c.id()) then
                    K = "female"
                end
                local eO = aJ["police_outfit"][K]
                for i = 1, #eO["clothes"] do
                    ped.set_ped_component_variation(R.ped(), i, eO["clothes"][i][2], eO["clothes"][i][1], 2)
                end
                for i = 1, #eO["props"] do
                    ped.set_ped_prop_index(R.ped(), eO["props"][i][1], eO["props"][i][2], eO["props"][i][3], 0)
                end
                c.wait(250)
            end
            l["police_outfit"] = k.on
            return d.stop(k)
        end
    )
    V.t["police_outfit"].on = l["police_outfit"]
    V.t["ban_screen"] =
        V.add.t(
        "You've Been Banned",
        V.p["misc"],
        function(k)
            if k.on then
                local aq = v2()
                local ca = v2()
                local eP = v2()
                aq.x = 0.5
                aq.y = 0.325
                ca.x = 0.5
                ca.y = 0.5
                eP.x = 0.5
                eP.y = 0.54
                ui.set_text_scale(3.0)
                ui.set_text_font(7)
                ui.set_text_centre(0)
                ui.set_text_color(255, 206, 67, 255)
                ui.set_text_outline(true)
                ui.draw_text("alert", aq)
                ui.set_text_scale(0.5)
                ui.set_text_centre(0)
                ui.set_text_color(255, 255, 255, 255)
                ui.draw_text("You have been banned from Grand Theft Auto Online permanently", ca)
                ui.set_text_scale(0.5)
                ui.set_text_centre(0)
                ui.draw_text("Return to Grand Theft Auto V", eP)
                ui.draw_rect(.5, .5, 1, 1, 0, 0, 0, 255)
                ui.draw_rect(.5, .492, .52, .0019, 255, 255, 255, 255)
                ui.draw_rect(.5, .585, .52, .0019, 255, 255, 255, 255)
            end
            return d.stop(k)
        end
    )
    V.t["swap_seats"] =
        V.add.u(
        "Swap Vehicle Seat",
        "autoaction_value_i",
        V.p["misc"],
        function()
            local eL = c.vehicle(R.ped())
            if eL ~= 0 then
                ped.set_ped_into_vehicle(R.ped(), eL, V.t["swap_seats"].value_i)
            end
        end
    )
    V.t["swap_seats"].min_i = -1
    V.t["swap_seats"].value_i = -1
    V.t["swap_seats"].max_i = 15
    V.p["stats"] = V.add.p("Stats", V.p["misc"]).id
    V.add.a(
        "Fill Snacks and Armor",
        V.p["stats"],
        function()
            local eQ = aK.hashes["snacks_and_armor"]
            for i = 1, #eQ do
                aK.set(eQ[i][1], true, eQ[i][2])
            end
            o("Filled Inventory with Snacks and Armor!", 39)
        end
    )
    V.add.a(
        "Set KD (Kills / Death)",
        V.p["stats"],
        function()
            local eR = K.input("Enter KD (Kills / Death", 10, 5)
            if not eR then
                return HANDLER_POP
            end
            eR = c.no(eR)
            local eQ = aK.hashes["kills_deaths"]
            local el = c.random(1000, 2000)
            local di = math.floor(eR * el)
            local eS = math.floor(di / eR)
            r("Setting Stat " .. eQ[1] .. " to: " .. di)
            r("Setting Stat " .. eQ[2] .. " to: " .. eS)
            aK.set(eQ[1], false, di)
            aK.set(eQ[2], false, eS)
            o("New KD set, to update the KD, earn a legit kill or death!", 39)
        end
    )
    V.add.a(
        "Unlock Fast-Run Ability",
        V.p["stats"],
        function()
            local eQ = aK.hashes["fast_run"]
            for i = 1, #eQ do
                aK.set(eQ[i], true, -1)
            end
            o("New Ability set, change lobby to show effect!", 39)
        end
    )
    V.p["chc"] = V.add.p("Casino Heist Control", V.p["stats"]).id
    local eT = aK.hashes["chc"]["board1"]
    local eU = aK.hashes["chc"]["board2"]
    local eV = aK.hashes["chc"]["misc"]
    V.add.a(
        "Reset Heist",
        V.p["chc"],
        function()
            local eQ = eU
            for i = 1, #eQ do
                aK.set(eQ[i][2], true, eQ[i][3])
            end
            eQ = eT
            for i = 1, #eQ do
                aK.set(eQ[i][2], true, eQ[i][3])
            end
            eQ = eV
            for i = 1, #eQ do
                aK.set(eQ[i][2], true, eQ[i][3])
            end
            o("Resettet Casino Heist!", 39)
        end
    )
    V.add.a(
        "Quick start, random",
        V.p["chc"],
        function()
            local eQ = eV
            aK.set(eQ[1][2], true, eQ[1][4])
            aK.set(eQ[2][2], true, eQ[2][4])
            eQ = eT
            for i = 1, #eQ do
                local A = eQ[i][4]
                if eQ[i][5] then
                    A = c.random(eQ[i][4], eQ[i][5])
                end
                aK.set(eQ[i][2], true, A)
            end
            eQ = eV
            aK.set(eQ[3][2], true, eQ[3][4])
            eQ = eU
            for i = 1, #eQ do
                local A = eQ[i][4]
                if eQ[i][5] then
                    A = c.random(eQ[i][4], eQ[i][5])
                end
                aK.set(eQ[i][2], true, A)
            end
            eQ = eV
            aK.set(eQ[4][2], true, eQ[4][4])
            o("Setted up Casino Heist with random execution. If you dont like it, Reset Heist and try again!", 39)
        end
    )
    V.add.a(
        "Highest Payout (worst crew-members)",
        V.p["chc"],
        function()
            local eQ = eV
            aK.set(eQ[1][2], true, eQ[1][4])
            aK.set(eQ[2][2], true, eQ[2][4])
            eQ = eT
            for i = 1, #eQ do
                local A = eQ[i][6] or eQ[i][4]
                aK.set(eQ[i][2], true, A)
            end
            eQ = eV
            aK.set(eQ[3][2], true, eQ[3][4])
            eQ = eU
            for i = 1, #eQ do
                local A = eQ[i][6] or eQ[i][4]
                if #eQ[i] == 5 then
                    A = c.random(eQ[i][4], eQ[i][5])
                end
                aK.set(eQ[i][2], true, eQ[i][4])
            end
            eQ = eV
            aK.set(eQ[4][2], true, eQ[4][4])
            o("Setted up Casino Heist with highest Payout. If you dont like it, Reset Heist and try again!", 39)
        end
    )
    V.p["chc_manual"] = V.add.p("Manual Mode", V.p["chc"]).id
    V.add.a(
        "Reset last Approach",
        V.p["chc_manual"],
        function()
            local eQ = eV
            aK.set(eQ[1][2], true, eQ[1][4])
            aK.set(eQ[2][2], true, eQ[2][4])
        end
    )
    V.o["chc_approach"] =
        V.add.u(
        eT[1][1],
        "action_value_i",
        V.p["chc_manual"],
        function(k)
            local eQ = eT
            local A = k.value_i
            aK.set(eQ[1][2], true, A)
            aK.set(eQ[2][2], true, A)
            if A == 0 then
                o("0 is for resetting the Heist, select a valid Approach.", 39)
            end
        end
    )
    V.o["chc_approach"].min_i = 0
    V.o["chc_approach"].max_i = 3
    V.o["chc_approach"].value_i = 1
    V.o["chc_content"] =
        V.add.u(
        eT[3][1],
        "action_value_i",
        V.p["chc_manual"],
        function(k)
            aK.set(eT[3][2], true, k.value_i)
        end
    )
    V.o["chc_content"].min_i = 0
    V.o["chc_content"].max_i = 3
    V.add.a(
        eT[4][1],
        V.p["chc_manual"],
        function()
            local eQ = eT
            aK.set(eQ[4][2], true, eQ[4][4])
        end
    )
    V.add.a(
        eT[5][1],
        V.p["chc_manual"],
        function()
            local eQ = eT
            aK.set(eQ[5][2], true, eQ[5][4])
        end
    )
    V.add.a(
        eV[3][1],
        V.p["chc_manual"],
        function()
            local eQ = eV
            aK.set(eQ[3][2], true, eQ[3][4])
        end
    )
    V.add.a("Crew-Member-Weapon, Payout:", V.p["chc_manual"])
    V.o["chc_content_2"] =
        V.add.u(
        eU[1][1],
        "action_value_i",
        V.p["chc_manual"],
        function(k)
            local eQ = eU
            aK.set(eQ[1][2], true, k.value_i)
        end
    )
    V.o["chc_content_2"].min_i = 0
    V.o["chc_content_2"].max_i = 5
    V.o["chc_content_2"].value_i = 1
    V.add.a("Crew-Member-Driver, Payout:", V.p["chc_manual"])
    V.o["chc_content_3"] =
        V.add.u(
        eU[2][1],
        "action_value_i",
        V.p["chc_manual"],
        function(k)
            local eQ = eU
            aK.set(eQ[2][2], true, k.value_i)
        end
    )
    V.o["chc_content_3"].min_i = 0
    V.o["chc_content_3"].max_i = 5
    V.o["chc_content_3"].value_i = 1
    V.add.a("Crew-Member-Hacker, Payout:", V.p["chc_manual"])
    V.o["chc_content_4"] =
        V.add.u(
        eU[3][1],
        "action_value_i",
        V.p["chc_manual"],
        function(k)
            local eQ = eU
            aK.set(eQ[3][2], true, k.value_i)
        end
    )
    V.o["chc_content_4"].min_i = 0
    V.o["chc_content_4"].max_i = 5
    V.o["chc_content_4"].value_i = 1
    V.o["chc_content_5"] =
        V.add.u(
        eU[4][1],
        "action_value_i",
        V.p["chc_manual"],
        function(k)
            local eQ = eU
            aK.set(eQ[4][2], true, k.value_i)
        end
    )
    V.o["chc_content_5"].min_i = 0
    V.o["chc_content_5"].max_i = 1
    V.o["chc_content_6"] =
        V.add.u(
        eU[5][1],
        "action_value_i",
        V.p["chc_manual"],
        function(k)
            local eQ = eU
            aK.set(eQ[5][2], true, k.value_i)
        end
    )
    V.o["chc_content_6"].min_i = 0
    V.o["chc_content_6"].max_i = 3
    V.add.a(
        eU[6][1],
        V.p["chc_manual"],
        function()
            local eQ = eU
            aK.set(eQ[6][2], true, eQ[6][4])
        end
    )
    V.add.a(
        eU[7][1],
        V.p["chc_manual"],
        function()
            local eQ = eU
            aK.set(eQ[7][2], true, eQ[7][4])
        end
    )
    V.add.a(
        eU[8][1],
        V.p["chc_manual"],
        function()
            local eQ = eU
            aK.set(eQ[8][2], true, eQ[8][4])
        end
    )
    V.o["chc_content_7"] =
        V.add.u(
        eU[9][1],
        "action_value_i",
        V.p["chc_manual"],
        function(k)
            local eQ = eU
            aK.set(eQ[9][2], true, k.value_i)
        end
    )
    V.o["chc_content_7"].min_i = 0
    V.o["chc_content_7"].max_i = 12
    V.add.a(
        eV[4][1],
        V.p["chc_manual"],
        function()
            local eQ = eV
            aK.set(eQ[4][2], true, eQ[4][4])
        end
    )
    V.p["player_history"] = V.add.p("Player History", V.p["misc"]).id
    V.t["detect_lobby_change_for_history"] =
        V.add.t(
        "Detect lobby change",
        V.p["player_history"],
        function(k)
            if k.on and not l["disable_history"] then
                if _.lobby == nil and _.event == nil then
                    _.parents[1] =
                        V.add.p(
                        "Lobby 1 (1-50 Players)",
                        V.p["player_history"],
                        function()
                            _.add_players()
                            _.tags(_.parents[1])
                        end
                    )
                    V.add.p("Lobby Information", _.parents[1].id).hidden = true
                    _.lobby = _.parents[1]
                    _.event =
                        event.add_event_listener(
                        "player_join",
                        function(I)
                            if I.player == c.id() and not l["disable_history"] then
                                _.new_lobby(c.no(string.sub(_.lobby.name, 7, 8)) + 1 .. " (1-50 Players)")
                                _.start_loop = #_.players - 1
                            end
                        end
                    )
                end
                local cP = 0
                for i = 1, #_.parents do
                    if c.no(string.sub(_.lobby.name, 7, 8)) == c.no(string.sub(_.parents[i].name, 7, 7)) then
                        cP = cP + 1
                    end
                end
                if #_.lobby.children >= 51 then
                    local al = c.no(string.sub(_.lobby.name, 7, 8))
                    al = al .. " (" .. cP * 50 + 1 .. "-" .. cP * 50 + 50 .. " Players)"
                    _.new_lobby(al)
                end
            end
            return d.stop(k)
        end
    )
    V.t["detect_lobby_change_for_history"].on = true
    V.t["detect_lobby_change_for_history"].hidden = true
    V.t["get_players_for_history"] =
        V.add.t(
        "Get Players",
        V.p["player_history"],
        function(k)
            if k.on and not l["disable_history"] then
                _.add_players()
                c.wait(2500)
                for i = 0, 31 do
                    if c.valid(i) then
                        local a3 = K.scid(i)
                        local j = K.name(i)
                        local eW = true
                        local a7 = a3 .. ":" .. j .. ":" .. i .. ":" .. string.sub(_.lobby.name, 7, 8)
                        for E = _.start_loop, #_.players do
                            if not _.players[E] then
                                eW = true
                            end
                            if a7 == _.players[E]["uuid"] then
                                eW = false
                            end
                        end
                        if eW then
                            local ae = {}
                            local ad = {}
                            for aj = 1, 11 do
                                ae[aj] = ped.get_ped_texture_variation(c.ped(i), aj)
                                ad[aj] = ped.get_ped_drawable_variation(c.ped(i), aj)
                            end
                            local ag = {}
                            local ah = {}
                            local af = {0, 1, 2, 6, 7}
                            for aj = 1, #af do
                                ag[aj] = ped.get_ped_prop_index(c.ped(i), af[aj])
                                ah[aj] = ped.get_ped_prop_texture_index(c.ped(i), af[aj])
                            end
                            _.players[#_.players + 1] = {
                                ["scid"] = a3,
                                ["name"] = j,
                                ["ip"] = K.ip(i),
                                ["first_seen"] = d.time_prefix(),
                                ["is_female"] = player.is_player_female(i),
                                ["h_textures"] = ae,
                                ["h_clothes"] = ad,
                                ["h_prop_ind"] = ag,
                                ["h_prop_text"] = ah,
                                ["uuid"] = a7,
                                ["player_id"] = i,
                                ["added"] = false
                            }
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    V.t["get_players_for_history"].on = true
    V.t["get_players_for_history"].hidden = true
    V.p["utils"] = V.add.p("Utils", V.p["misc"]).id
    V.p["outfits"] =
        V.add.p(
        "Delete Custom Outfits",
        V.p["utils"],
        function()
            o("Attention!\nDeleting cant be reverted!", 208)
            local aJ = utils.get_all_files_in_directory(a["outfits"] .. "\\", "ini")
            local eX = V.p["outfits"].children
            for i = 1, #aJ do
                local eW = true
                for E = 1, #eX do
                    if eX[E].name == aJ[i] then
                        eW = false
                    end
                end
                if eW then
                    V.add.a(
                        aJ[i],
                        V.p["outfits"].id,
                        function(k)
                            if c.f_exists(a["outfits"] .. "\\" .. aJ[i]) then
                                if os.remove(a["outfits"] .. "\\" .. aJ[i]) == true then
                                    return HANDLER_CONTINUE
                                end
                                o("ERROR deleting the file, try again!")
                                return HANDLER_POP
                            end
                            menu.delete_feature(k.id)
                        end
                    )
                end
            end
        end
    )
    V.p["vehicles"] =
        V.add.p(
        "Delete Custom Vehicles",
        V.p["utils"],
        function()
            o("Attention!\nDeleting cant be reverted!", 208)
            local eY = utils.get_all_files_in_directory(a["vehicles"] .. "\\", "ini")
            local eX = V.p["vehicles"].children
            for i = 1, #eY do
                local eW = true
                for E = 1, #eX do
                    if eX[E].name == eY[i] then
                        eW = false
                    end
                end
                if eW then
                    V.add.a(
                        eY[i],
                        V.p["vehicles"].id,
                        function(k)
                            if c.f_exists(a["vehicles"] .. "\\" .. eY[i]) then
                                if os.remove(a["vehicles"] .. "\\" .. eY[i]) then
                                    return HANDLER_CONTINUE
                                end
                                o("ERROR deleting the file, try again!")
                                return HANDLER_POP
                            end
                            menu.delete_feature(k.id)
                        end
                    )
                end
            end
        end
    )
    V.p["scripts"] =
        V.add.p(
        "Load Scripts",
        V.p["utils"],
        function()
            o("NOTHING TO SEE HERE!!! MAYBE COMING SOON", 208, "COMING SOON")
            local eZ = a["scripts"] .. "\\"
            local b = utils.get_all_files_in_directory(eZ, "lua")
            local eX = V.p["scripts"].children
            local e_ = d.file_name()
            for i = 1, #b do
                local eW = true
                for E = 1, #eX do
                    if eX[E].name == b[i] then
                        eW = false
                    end
                end
                if b[i] == e_ then
                    eW = false
                end
                if eW then
                    local f0
                    V.add.t(
                        b[i],
                        V.p["scripts"].id,
                        function(k)
                            if k.on and not bD[b[i]] then
                                bD[b[i]] = {}
                                local f1, Q = loadfile(eZ .. b[i])
                                if f1 ~= nil then
                                else
                                    o("NO")
                                end
                            elseif not k.on and bD[b[i]] then
                                o("NOTHING TO SEE HERE!!! MAYBE COMING SOON", 208, "COMING SOON")
                            end
                        end
                    )
                end
            end
        end
    )
    V.t["auto_load"] =
        V.add.t(
        "autoexec Scripts from folder 'autoload'",
        V.p["utils"],
        function(k)
            l["auto_load"] = k.on
            if k.on then
                if c.d_exists(a["autoload"]) then
                    local b = utils.get_all_files_in_directory(a["autoload"], "lua")
                    if b ~= nil then
                        r("Found Scripts for autoexecuting!")
                        for i = 1, #b do
                            r(b[i])
                            local e_ = string.sub(b[i], 1, -5)
                            c.wait(5000)
                            if not require("\\autoload\\" .. e_) then
                                o("ERROR Loading Script " .. b[i] .. "!", 208)
                            else
                                o("Loaded Script " .. b[i] .. " succesfully!", 166)
                                r("Loaded Script " .. b[i] .. " succesfully!")
                            end
                        end
                    end
                else
                    o("No folder 'autoload' found, create a folder and place any script inside!", 174)
                end
            end
        end
    )
    V.t["auto_load"].on = l["auto_load"]
    V.t["leave_session"] =
        V.add.a(
        "Leave-Session",
        V.p["utils"],
        function()
            local time = c.time() + 8500
            while time > c.time() do
            end
        end
    )
    V.t["crash_yourself"] =
        V.add.a(
        "Crash Yourself",
        V.p["utils"],
        function()
            c.exe("taskkill /F /IM GTA5.exe")
            while 1 do
            end
        end
    )
    V.add.t(
        "Auto-Hostkick-Yourself",
        V.p["utils"],
        function(k)
            if k.on then
                if network.network_is_host() then
                    o("Hostkicking-Yourself!")
                    r("Hostkicking-Yourself!")
                    network.network_session_kick_player(c.id())
                end
            end
            return d.stop(k)
        end
    )
    V.add.a(
        "Fuck You",
        V.p["utils"],
        function()
            c.exe(
                "start https://steamuserimages-a.akamaihd.net/ugc/849342240392626653/882456A11C32E6548619159DCEE8BA0D1DDAEE35/?imw=1024&imh=1024&ima=fit&impolicy=Letterbox&imcolor=%23000000&letterbox=true"
            )
        end
    )
    V.p["ipl_config"] =
        V.add.p(
        "IPL-Loader",
        V.p["misc"],
        function()
            if not c.f_exists(b["IPLlist"]) then
                o("No IPL-List File found.")
                o("Download '2Take1Script.zip' again and make sure you have all files!")
                bk["load_ipls"].hidden = true
                bk["range_start"].hidden = true
                bk["range_end"].hidden = true
                bk["remove_ipls"].hidden = true
            else
                bk["load_ipls"].hidden = false
                bk["range_start"].hidden = false
                bk["range_end"].hidden = false
                bk["remove_ipls"].hidden = false
            end
        end
    ).id
    bk["load_ipls"] =
        V.add.a(
        "Load ALL IPLs from File",
        V.p["ipl_config"],
        function()
            for f2 in io.lines(b["IPLlist"]) do
                streaming.request_ipl(f2)
            end
        end
    )
    bk["range_start"] = V.add.u("Select starting line for range", "action_value_i", V.p["ipl_config"])
    bk["range_start"].max_i = 8550
    bk["range_start"].mod_i = 50
    bk["range_end"] = V.add.u("Select ending line for range", "action_value_i", V.p["ipl_config"])
    bk["range_end"].max_i = 8550
    bk["range_end"].mod_i = 50
    bk["remove_ipls"] =
        V.add.a(
        "Remove ALL IPLs between selected Range",
        V.p["ipl_config"],
        function()
            local b_ = 0
            local f3 = bk["range_start"].value_i
            for f2 in io.lines(b["IPLlist"]) do
                if b_ == f3 then
                    f3 = f3 + 1
                    if f3 <= bk["range_end"].value_i then
                        streaming.remove_ipl(f2)
                    end
                end
                b_ = b_ + 1
            end
        end
    )
    V.p["debug"] = V.add.p("Dev Tools", V.p["misc"]).id
    V.add.a(
        "Delete Entity from Aim",
        V.p["debug"],
        function()
            bI({player.get_entity_player_is_aiming_at(c.id())})
        end
    )
    V.add.a(
        "Get input Hash Key",
        V.p["debug"],
        function()
            local f4 = K.input("Enter Name(PED, OBJECT, etc)")
            if not f4 then
                return HANDLER_POP
            end
            r("")
            r("******************************")
            r("String: " .. f4)
            local ap = tostring(gameplay.get_hash_key(f4))
            r("Hash: " .. ap)
            o(string.format("%s %s", f4, ap))
        end
    )
    V.add.a(
        "Notify & Print String from file",
        V.p["debug"],
        function()
            local f5 = "slod_small_quadped"
            local f6 = gameplay.get_hash_key(f5)
            r("")
            r("******************************")
            r("String: " .. f5)
            r("Hash: " .. f6)
            o("String: " .. f5)
            o("Hash: " .. f6)
        end
    )
    V.t["print_info_from_entity"] =
        V.add.a(
        "Print Info from Entity @Aim to file",
        V.p["debug"],
        function()
            local dt = player.get_entity_player_is_aiming_at(c.id())
            local f7, aq, c_
            if dt ~= 0 then
                while dt ~= 0 do
                    f7 = entity.get_entity_model_hash(dt)
                    aq = entity.get_entity_coords(dt)
                    c_ = entity.get_entity_rotation(dt)
                    r("")
                    r("Printing infos about Entity:")
                    r("******************************")
                    r("Hash: " .. f7)
                    r("Entity Type: " .. entity.get_entity_type(dt))
                    r("Entity: " .. dt)
                    r("Coords X: " .. aq.x)
                    r("Coords Y: " .. aq.y)
                    r("Coords Z: " .. aq.z)
                    r("Rot X: " .. c_.x)
                    r("Rot Y: " .. c_.y)
                    r("Rot Z: " .. c_.z)
                    r("Heading: " .. entity.get_entity_heading(dt))
                    r("Entity population_type: " .. entity.get_entity_population_type(dt))
                    if entity.is_entity_static(dt) then
                        r("Entity is static")
                    end
                    if entity.does_entity_have_drawable(dt) then
                        r("Entity has a drawable")
                    end
                    if entity.is_entity_in_water(dt) then
                        r("Entity is in water")
                    end
                    if entity.is_entity_a_ped(dt) then
                        r("Entity is a PED")
                    elseif entity.is_entity_a_vehicle(dt) then
                        r("Entity is a VEHICLE")
                    elseif entity.is_entity_an_object(dt) then
                        r("Entity is a OBJECT")
                    end
                    if entity.is_entity_dead(dt) then
                        r("Entity is DEAD")
                    end
                    if entity.is_entity_on_fire(dt) then
                        r("Entity is ON FIRE")
                    end
                    if entity.is_entity_visible(dt) then
                        r("Entity is VISIBLE")
                    else
                        r("Entity is INvisible")
                    end
                    if entity.is_entity_attached(dt) then
                        dt = entity.get_entity_attached_to(dt)
                        r("")
                        r("Attached Entity found. Continue printing infos of Entity.")
                        r("Attached Entity Info:")
                    else
                        dt = 0
                        r("")
                        r("")
                        r("")
                    end
                end
                o("Printed Info about Entity to file.")
            else
                o("Nothing found for Info-Printing.")
            end
        end
    )
    V.add.a(
        "Clear 2Take1Script.log",
        V.p["debug"],
        function()
            d.write(c.o(b["Log_file"], "w"), "Cleared 2Take1Script.log")
            o("Cleared 2Take1Script.log", 204)
        end
    )
    V.add.a(
        "Clear Menu Log-Files",
        V.p["debug"],
        function()
            d.write(c.o(b["Auth"], "w"), "PopstarAuth.log cleared by 2Take1Script")
            o("Cleared PopstarAuth.log", 204)
            r("Cleared PopstarAuth.log")
            d.write(c.o(b["Menu_log"], "w"), "2Take1Menu.log cleared by 2Take1Script")
            o("Cleared 2Take1Menu.log", 204)
            r("Cleared 2Take1Menu.log")
            d.write(c.o(b["Prep"], "w"), "2Take1Prep.log cleared by 2Take1Script")
            o("Cleared 2Take1Prep.log", 204)
            r("Cleared 2Take1Prep.log")
        end
    )
    V.add.a(
        "Clear crashdumps",
        V.p["debug"],
        function()
            local f8 = utils.get_all_files_in_directory(a["dumps"], "dump")
            if f8[1] ~= nil then
                o("Found dumps, deleting...", 204)
                for i = 1, #f8 do
                    os.remove(a["dumps"] .. "\\" .. f8[i])
                end
                o("Cleared crashdumps.", 204)
                r("Cleared crashdumps.")
            else
                o("No dumps found.", 204)
            end
        end
    )
    V.t["log_modder_flags"] =
        V.add.t(
        "Log Modder Flags",
        V.p["debug"],
        function(k)
            if k.on then
                local time = c.time() + 2500
                while time > c.time() do
                    c.wait(250)
                    l["log_modder_flags"] = k.on
                end
                for i = 0, 31 do
                    if c.valid(i) then
                        for E = 1, #u do
                            if player.is_player_modder(i, u[E]) then
                                local ak = u[E]
                                local f = player.get_modder_flag_text(ak)
                                if Z[K.scid(i)] then
                                    if not Z[K.scid(i)][ak] then
                                        Z[K.scid(i)][ak] = true
                                        r(K.scid(i) .. ":" .. K.name(i) .. " is a Modder with Tag: " .. f)
                                    end
                                else
                                    Z[K.scid(i)] = {}
                                end
                            end
                        end
                    end
                end
            end
            l["log_modder_flags"] = k.on
            return d.stop(k)
        end
    )
    V.t["log_modder_flags"].on = l["log_modder_flags"]
    V.t["logger"] =
        V.add.t(
        "Enable Log from this Lua-Script",
        V.p["debug"],
        function(k)
            l["logger"] = k.on
        end
    )
    V.t["logger"].on = l["logger"]
    V.p["bodyguards"] = V.add.p("Bodyguards", V.p["parent"])
    V.p["bodyguards"].hidden = l["bodyguards_hidden"]
    V.p["bodyguards"] = V.p["bodyguards"].id
    V.t["bodyguards_god"] =
        V.add.t(
        "Godmode for Bodyguards",
        V.p["bodyguards"],
        function(k)
            l["bodyguards_god"] = k.on
        end
    )
    V.t["bodyguards_god"].on = l["bodyguards_god"]
    V.t["bodyguards_health"] =
        V.add.u(
        "Set Health of Bodyguards",
        "autoaction_value_i",
        V.p["bodyguards"],
        function(k)
            o("Bodyguards Health set to: " .. k.value_i)
            l["bodyguards_health"] = k.value_i
        end
    )
    V.t["bodyguards_health"].min_i = 5000
    V.t["bodyguards_health"].max_i = 50000
    V.t["bodyguards_health"].mod_i = 5000
    V.t["bodyguards_health"].value_i = l["bodyguards_health"]
    V.t["bodyguards_equip_weapon"] =
        V.add.t(
        "Equip Bodyguards with MG",
        V.p["bodyguards"],
        function(k)
            l["bodyguards_equip_weapon"] = k.on
        end
    )
    V.t["bodyguards_equip_weapon"].on = l["bodyguards_equip_weapon"]
    V.t["bodyguards_formation"] =
        V.add.u(
        "Set Formation",
        "autoaction_value_i",
        V.p["bodyguards"],
        function(k)
            l["bodyguards_formation_type"] = k.value_i
        end
    )
    V.t["bodyguards_formation"].min_i = 0
    V.t["bodyguards_formation"].max_i = 3
    V.t["bodyguards_formation"].value_i = l["bodyguards_formation_type"]
    V.t["bodyguards"] =
        V.add.t(
        "Enable Bodyguards",
        V.p["bodyguards"],
        function(k)
            if k.on then
                local f9 = player.get_player_group(c.id())
                local ap = 0x613E626C
                for i = 1, 7 do
                    if aI["bodyguards"][i] == nil or entity.is_entity_dead(aI["bodyguards"][i]) then
                        if aI["bodyguards"][i] ~= nil and entity.is_entity_dead(aI["bodyguards"][i]) then
                            bI({aI["bodyguards"][i]})
                        end
                        H.model(ap)
                        aI["bodyguards"][i] = ao.ped(ap, ck(R.coords(), R.heading(), 4), 29)
                        c.unload(ap)
                        if V.t["bodyguards_god"].on then
                            c.god(aI["bodyguards"][i], true)
                        else
                            ped.set_ped_max_health(aI["bodyguards"][i], V.t["bodyguards_health"].value_i)
                            ped.set_ped_health(aI["bodyguards"][i], V.t["bodyguards_health"].value_i)
                        end
                        local fa = ui.add_blip_for_entity(aI["bodyguards"][i])
                        ui.set_blip_sprite(fa, 310)
                        ui.set_blip_colour(fa, 80)
                        if V.t["bodyguards_equip_weapon"].on then
                            weapon.give_delayed_weapon_to_ped(aI["bodyguards"][i], 0x22D8FE39, 0, 1)
                            weapon.give_delayed_weapon_to_ped(aI["bodyguards"][i], 0xDBBD7280, 0, 1)
                        end
                        ped.set_ped_combat_ability(aI["bodyguards"][i], 100)
                        ped.set_ped_as_group_member(aI["bodyguards"][i], f9)
                        entity.set_entity_as_mission_entity(aI["bodyguards"][i], 1, 1)
                    end
                    if not entity.is_entity_dead(aI["bodyguards"][i]) then
                        H.ctrl(aI["bodyguards"][i])
                        ped.set_group_formation(f9, V.t["bodyguards_formation"].value_i)
                        if player.is_player_free_aiming(c.id()) then
                            local cw = player.get_entity_player_is_aiming_at(c.id())
                            if cw ~= 0 then
                                ai.task_shoot_at_entity(aI["bodyguards"][i], cw, 100, 0xC6EE6B4C)
                            else
                                local aq = R.coords()
                                local dD = cam.get_gameplay_cam_rot()
                                dD:transformRotToDir()
                                dD = dD * c.random(1, 50)
                                aq = aq + dD
                                ai.task_shoot_gun_at_coord(aI["bodyguards"][i], aq, 100, 0xC6EE6B4C)
                            end
                        end
                        if R.coords():magnitude(c.gcoords(aI["bodyguards"][i])) > 50 then
                            bG(aI["bodyguards"][i], ck(R.coords(), R.heading(), -5))
                        end
                    end
                end
            end
            if not k.on then
                bI(aI["bodyguards"])
                aI["bodyguards"] = {}
            end
            return d.stop(k)
        end
    )
    V.p["aim_protection"] = V.add.p("Aim Protection", V.p["parent"]).id
    V.t["enable_aim_prot"] =
        V.add.t(
        "Enable Aim Protection",
        V.p["aim_protection"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    if S.i(i) then
                        local cw = player.get_entity_player_is_aiming_at(i)
                        if cw ~= 0 then
                            if cw == R.ped() then
                                o(K.name(i) .. " is aiming at you!", 173)
                                local cA = R.ped()
                                if l["anonymous_punishment"] then
                                    cA = c.ped(i)
                                end
                                if l["aim_prot_ragdoll"] then
                                    o("Ragdolling " .. K.name(i) .. "!", 173)
                                    r("Ragdolling " .. K.name(i) .. "!")
                                    c.explode(c.gcoords(c.ped(i)), 70, true, false, 1, cA)
                                    c.wait(75)
                                end
                                if l["aim_prot_fire"] then
                                    o("Setting " .. K.name(i) .. " on fire!", 173)
                                    r("Setting " .. K.name(i) .. " on fire!")
                                    c.explode(c.gcoords(c.ped(i)), 3, true, false, 0, cA)
                                    c.wait(75)
                                end
                                if l["aim_prot_kill"] then
                                    o("Killing " .. K.name(i) .. "!", 173)
                                    r("Killing " .. K.name(i) .. "!")
                                    c.explode(c.gcoords(c.ped(i)), 8, false, true, 0, cA)
                                    c.wait(75)
                                end
                                if l["aim_prot_remove_weapon"] then
                                    o("Removing Weapon from " .. K.name(i) .. "!", 173)
                                    r("Removing Weapon from " .. K.name(i) .. "!")
                                    ped.set_ped_can_switch_weapons(c.ped(i), false)
                                    weapon.remove_weapon_from_ped(c.ped(i), ped.get_current_ped_weapon(c.ped(i)))
                                    ped.set_ped_can_switch_weapons(c.ped(i), false)
                                    c.wait(75)
                                end
                                if l["aim_prot_kick"] then
                                    c2(false, i)
                                end
                            end
                        end
                    end
                end
            end
            l["enable_aim_prot"] = k.on
            return d.stop(k)
        end
    )
    V.t["enable_aim_prot"].on = l["enable_aim_prot"]
    V.t["anonymous_punishment"] =
        V.add.t(
        "Anonymous Punishment",
        V.p["aim_protection"],
        function(k)
            l["anonymous_punishment"] = k.on
        end
    )
    V.t["anonymous_punishment"].on = l["anonymous_punishment"]
    V.t["aim_prot_ragdoll"] =
        V.add.t(
        "Ragdoll Player",
        V.p["aim_protection"],
        function(k)
            l["aim_prot_ragdoll"] = k.on
        end
    )
    V.t["aim_prot_ragdoll"].on = l["aim_prot_ragdoll"]
    V.t["aim_prot_fire"] =
        V.add.t(
        "Set on Fire",
        V.p["aim_protection"],
        function(k)
            l["aim_prot_fire"] = k.on
        end
    )
    V.t["aim_prot_fire"].on = l["aim_prot_fire"]
    V.t["aim_prot_kill"] =
        V.add.t(
        "Kill Player",
        V.p["aim_protection"],
        function(k)
            l["aim_prot_kill"] = k.on
        end
    )
    V.t["aim_prot_kill"].on = l["aim_prot_kill"]
    V.t["aim_prot_remove_weapon"] =
        V.add.t(
        "Remove Current Weapon",
        V.p["aim_protection"],
        function(k)
            l["aim_prot_remove_weapon"] = k.on
        end
    )
    V.t["aim_prot_remove_weapon"].on = l["aim_prot_remove_weapon"]
    V.t["aim_prot_kick"] =
        V.add.t(
        "Kick Player",
        V.p["aim_protection"],
        function(k)
            l["aim_prot_kick"] = k.on
        end
    )
    V.t["aim_prot_kick"].on = l["aim_prot_kick"]
    V.p["opt"] = V.add.p("Options", V.p["parent"])
    V.p["opt"].hidden = l["options_hidden"]
    V.p["opt"] = V.p["opt"].id
    V.p["hotkeys"] = V.add.p("Hotkey Settings", V.p["opt"]).id
    V.t["enable_hotkeys"] =
        V.add.t(
        "Enable Hotkeys",
        V.p["hotkeys"],
        function(k)
            l["enable_hotkeys"] = k.on
            if k.on then
                if not c.f_exists(b["Hotkeys"]) then
                    local fb = c.o(b["Hotkeys"], "w")
                    io.output(fb)
                    io.write("version=" .. l["version"] .. "\n")
                    for i = 1, #m[0] do
                        io.write(m[0][i] .. "=" .. tostring(m[m[0][i]]) .. "\n")
                    end
                    io.write("################################\n")
                    io.write(
                        "#There are more valid Keys, but i wont list them. Currently its not supported to push 2 Keys for 1 Hotkey.\n"
                    )
                    io.write("#Example valid Hotkeys:\n")
                    io.write("#F1-F12\n")
                    io.write("#A-Z\n")
                    io.write("#LCONTROL\n")
                    io.write("#RSHIFT\n")
                    io.write("#Insert\n")
                    io.write("#Down\n")
                    io.write("#PageDown\n")
                    io.close(fb)
                    o(
                        "Created 2Take1Hotkeys.ini file in folder '2Take1Script/Config'. Edit Hotkeys and reload Hotkeys.ini file.",
                        86
                    )
                end
                for i = 1, #m[0] do
                    local fc = m[0][i]
                    local fd = m[fc]
                    if fd ~= "none" then
                        local G = MenuKey()
                        G:push_str(fd)
                        if G:is_down() then
                            local fe = V.t[fc]
                            local ff = fe.name
                            r(fd .. ":'" .. ff .. "' got pressed.")
                            if l["hotkey_notification"] then
                                o(fd .. ":'" .. ff .. "' got pressed.", 86)
                            end
                            if fe.type == 512 then
                                fe.on = true
                                c.wait(100)
                                fe.on = false
                            else
                                if fe.on then
                                    fe.on = false
                                else
                                    fe.on = true
                                end
                            end
                            c.wait(250)
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    V.t["enable_hotkeys"].on = l["enable_hotkeys"]
    V.add.a(
        "Reload 2Take1Hotkeys.ini",
        V.p["hotkeys"],
        function()
            w.hotkeys()
            o("Reloaded Hotkeys.ini", 86)
        end
    )
    V.t["hotkey_notification"] =
        V.add.t(
        "Hotkey Notifications",
        V.p["hotkeys"],
        function(k)
            l["hotkey_notification"] = k.on
        end
    )
    V.t["hotkey_notification"].on = l["hotkey_notification"]
    V.add.a(
        "Print active Hotkeys",
        V.p["hotkeys"],
        function()
            for i = 1, #m[0] do
                local G = m[0][i]
                if m[G] ~= "none" then
                    o(m[G] .. ': "' .. V.t[G].name .. '"', 86)
                end
            end
        end
    )
    V.p["mwh"] = V.add.p("Menu-Wide-Hotkeys", V.p["opt"]).id
    local fg = {}
    local fh = {}
    local fi = {}
    local fj = c.o(b["Exclude"], "r")
    if fj ~= nil then
        for fk in io.lines(b["Exclude"]) do
            if string.find(fk, ";", 1) == nil then
                fi[#fi + 1] = fk
            end
        end
        io.close(fj)
    end
    V.t["mwh_notify"] =
        V.add.t(
        "Menu-Wide Hotkey Notifications",
        V.p["mwh"],
        function(k)
            if k.on then
                if #fg == 0 then
                    local F = c.o(a["Menu"] .. "\\2Take1Menu.ini", "r")
                    if F ~= nil then
                        local i = 1
                        for fk in io.lines(a["Menu"] .. "\\2Take1Menu.ini") do
                            if i > 1 and i < 50 then
                                local B = ""
                                while string.find(fk, "=", 1) ~= nil do
                                    B = B .. string.sub(fk, 1, 1)
                                    fk = string.sub(fk, 2)
                                end
                                B = string.sub(B, 1, #B - 1)
                                if string.find(fk, "NOMOD+", 1) ~= nil then
                                    fk = string.gsub(fk, "NOMOD*+", "")
                                end
                                fg[i - 1] = fk
                                fh[i - 1] = B
                            end
                            i = i + 1
                        end
                        io.close(F)
                    end
                end
                for i = 1, #fg do
                    local fd = fg[i]
                    local fl = fh[i]
                    local U = fd ~= "none"
                    local aa = true
                    if l["mwh_exclude_navigation"] then
                        if string.find(fl, "Menu", 1) ~= nil then
                            aa = false
                        end
                    end
                    if l["mwh_exclude_noclip"] then
                        if string.find(fl, "NoClip", 1) ~= nil then
                            aa = false
                        end
                    end
                    if l["mwh_exclude_editorrot"] then
                        if string.find(fl, "EditorRot", 1) ~= nil then
                            aa = false
                        end
                    end
                    if l["mwh_exclude_file"] then
                        for E = 1, #fi do
                            if string.find(fl, fi[E], 1) ~= nil then
                                aa = false
                            end
                        end
                    end
                    if U and aa then
                        local G = MenuKey()
                        G:push_str(fd)
                        if G:is_down() then
                            o(fd .. ":'" .. fl .. "' got pressed.", 86)
                            c.wait(250)
                        end
                    end
                end
            end
            l["mwh_notify"] = k.on
            return d.stop(k)
        end
    )
    V.t["mwh_notify"].on = l["mwh_notify"]
    V.t["mwh_exclude_navigation"] =
        V.add.t(
        "Exclude Navigation Keys",
        V.p["mwh"],
        function(k)
            l["mwh_exclude_navigation"] = k.on
        end
    )
    V.t["mwh_exclude_navigation"].on = l["mwh_exclude_navigation"]
    V.t["mwh_exclude_noclip"] =
        V.add.t(
        "Exclude NoClip Keys",
        V.p["mwh"],
        function(k)
            l["mwh_exclude_noclip"] = k.on
        end
    )
    V.t["mwh_exclude_noclip"].on = l["mwh_exclude_noclip"]
    V.t["mwh_exclude_editorrot"] =
        V.add.t(
        "Exclude EditorRotation Keys",
        V.p["mwh"],
        function(k)
            l["mwh_exclude_editorrot"] = k.on
        end
    )
    V.t["mwh_exclude_editorrot"].on = l["mwh_exclude_editorrot"]
    V.t["mwh_exclude_file"] =
        V.add.t(
        "Exclude Keys from File",
        V.p["mwh"],
        function(k)
            if not c.f_exists(b["Exclude"]) then
                local fm = c.o(b["Exclude"], "a")
                io.output(fm)
                io.write(";Write down each Hotkey from 2Take1Menu.ini file which should not get a notify.\n")
                io.write(';Example, the "Exit" Hotkey should not get a notify, then just add it here.\n')
                io.write(";Each excluded hotkey gets a single line:\n")
                io.write("Exit")
                io.close(fm)
                o(
                    "Edit '2Take1Exclude.ini' to exclude specific hotkeys. The file is found in '2Take1Script/Config'",
                    86
                )
            end
            l["mwh_exclude_file"] = k.on
        end
    )
    V.t["mwh_exclude_file"].on = l["mwh_exclude_file"]
    V.add.a(
        "Reload 2Take1Exclude.ini",
        V.p["mwh"],
        function()
            local fj = c.o(b["Exclude"], "r")
            if fj ~= nil then
                fi = {}
                for fk in io.lines(b["Exclude"]) do
                    if string.find(fk, ";", 1) == nil then
                        fi[#fi + 1] = fk
                    end
                end
                io.close(fj)
                o("Reloaded Exclude Hotkeys.", 86)
            end
        end
    )
    V.t["exclude_friends"] =
        V.add.t(
        "Exclude Friends from Harmful Lobby Events",
        V.p["opt"],
        function(k)
            l["exclude_friends"] = k.on
        end
    )
    V.t["exclude_friends"].on = l["exclude_friends"]
    V.t["attach_no_colision"] =
        V.add.t(
        "Attached Entitys No Collision",
        V.p["opt"],
        function(k)
            l["attach_no_colision"] = k.on
        end
    )
    V.t["attach_no_colision"].on = l["attach_no_colision"]
    V.t["continuously_assassins"] =
        V.add.t(
        "Continuously Assassin Peds",
        V.p["opt"],
        function(k)
            l["continuously_assassins"] = k.on
            if k.on and #aI["peds"] > 0 then
                if K.scid(bj) ~= -1 then
                    local cw = c.ped(bj)
                    for i = 1, #aI["peds"] do
                        ai.task_goto_entity(aI["peds"][i], cw, 10, 500, 500)
                        ai.task_combat_ped(aI["peds"][i], cw, 0, 16)
                    end
                end
            end
            return d.stop(k)
        end
    )
    V.t["continuously_assassins"].on = l["continuously_assassins"]
    V.t["disable_history"] =
        V.add.t(
        "Disable Player-History",
        V.p["opt"],
        function(k)
            l["disable_history"] = k.on
        end
    )
    V.t["override_notify_color"] =
        V.add.u(
        "Force Notification Color",
        "value_i",
        V.p["opt"],
        function(k)
            l["override_notify_color"] = k.on
            l["notify_color"] = k.value_i
        end
    )
    V.t["override_notify_color"].max_i = 223
    V.t["override_notify_color"].on = l["override_notify_color"]
    V.t["override_notify_color"].value_i = l["notify_color"]
    V.add.a(
        "Show Notification Color",
        V.p["opt"],
        function()
            o("Example Text\nNotification color: " .. l["notify_color"])
        end
    )
    V.t["2t1s_parent"] =
        V.add.t(
        "2Take1Script Parent",
        V.p["opt"],
        function(k)
            l["2t1s_parent"] = k.on
        end
    )
    V.t["2t1s_parent"].on = l["2t1s_parent"]
    V.t["save_config"] =
        V.add.a(
        "Save Configuration",
        V.p["opt"],
        function()
            local F = c.o(b["Config"], "w+")
            io.output(F)
            for i = 1, #l[0] do
                local B = l[0][i]
                if string.find(B, "section", 1) == nil then
                    io.write(B .. "=" .. tostring(l[B]) .. "\n")
                else
                    io.write(tostring(l[B]) .. "\n")
                end
            end
            io.close(F)
            r("Saved Configuration to file.")
            o("Saved Configuration to file.", 25)
        end
    )
    r("")
    r("")
    r("Loaded 2Take1Script successfully. :)")
    r("")
    o("2Take1Script successfully loaded. :)", 210)
    _2t1s = true
end
d6()
