local a = {}
a["PDevs"] = utils.get_appdata_path("PopstarDevs", "")
a["Menu"] = a["PDevs"] .. "\\2Take1Menu"
a["dumps"] = a["Menu"] .. "\\crashdump"
a["outfits"] = a["Menu"] .. "\\moddedOutfits"
a["vehicles"] = a["Menu"] .. "\\moddedVehicles"
a["scripts"] = a["Menu"] .. "\\scripts"
a["autoload"] = a["scripts"] .. "\\autoload"
a["2T1S"] = a["scripts"] .. "\\2Take1Script"
a["Config"] = a["2T1S"] .. "\\Config"
a["CustomFiles"] = a["2T1S"] .. "\\CustomFiles"
a["Event-Logger"] = a["2T1S"] .. "\\Event-Logger"
local b = {
    ["Auth"] = a["PDevs"] .. "\\PopstarAuth.log",
    ["Menu_log"] = a["Menu"] .. "\\2Take1Menu.log",
    ["Prep"] = a["Menu"] .. "\\2Take1Prep.log",
    ["Admin"] = a["scripts"] .. "\\2Take1Script-Admin.lua",
    ["Log_file"] = a["2T1S"] .. "\\2Take1Script.log",
    ["EXT_file"] = a["CustomFiles"] .. "\\2Take1ScriptEXT.lua",
    ["Blacklist"] = a["CustomFiles"] .. "\\2Take1Blacklist.cfg",
    ["Modders"] = a["CustomFiles"] .. "\\2Take1Modders.cfg",
    ["IPLlist"] = a["CustomFiles"] .. "\\2Take1IPLlist.txt",
    ["data"] = a["Config"] .. "\\offsets.data",
    ["Config"] = a["Config"] .. "\\2Take1Script.ini",
    ["Hotkeys"] = a["Config"] .. "\\2Take1Hotkeys.ini",
    ["Exclude"] = a["Config"] .. "\\2Take1Exclude.ini"
}
local c = {}
c.o = io.open
c.no = tonumber
c.wait = system.wait
c.time = utils.time_ms
c.random = math.random
c.id = player.player_id
c.d_exists = utils.dir_exists
c.ped = player.get_player_ped
c.f_exists = utils.file_exists
c.explode = fire.add_explosion
c.valid = player.is_player_valid
c.god = entity.set_entity_god_mode
c.gcoords = entity.get_entity_coords
c.visible = entity.set_entity_visible
c.script = script.trigger_script_event
c.navigate = menu.set_menu_can_navigate
c.vehicle = ped.get_vehicle_ped_is_using
c.attach = entity.attach_entity_to_entity
c.unload = streaming.set_model_as_no_longer_needed
local d = {}
d.write = function(e, f)
    if e then
        io.output(e)
        io.write(f .. "\n")
        io.close(e)
    end
end
d.time_prefix = function()
    local g = os.date("*t")
    if g.month < 10 then
        g.month = "0" .. g.month
    end
    if g.day < 10 then
        g.day = "0" .. g.day
    end
    if g.hour < 10 then
        g.hour = "0" .. g.hour
    end
    if g.min < 10 then
        g.min = "0" .. g.min
    end
    if g.sec < 10 then
        g.sec = "0" .. g.sec
    end
    return "[" .. g.year .. "-" .. g.month .. "-" .. g.day .. " " .. g.hour .. ":" .. g.min .. ":" .. g.sec .. "]"
end
d.file_name = function()
    local h = debug.getinfo(2, "S")
    local j = h.source:sub(2) or h
    j = j:sub(#j - string.find(string.reverse(j), "\\", 1) + 2)
    return j
end
d.stop = function(k)
    if k.on then
        return 0
    end
    return 1
end
d.rgbtohex = function(l)
    local m = "0X"
    for n, o in pairs(l) do
        local p = ""
        while o > 0 do
            local q = math.fmod(o, 16) + 1
            o = math.floor(o / 16)
            p = string.sub("0123456789ABCDEF", q, q) .. p
        end
        if string.len(p) == 0 then
            p = "00"
        elseif string.len(p) == 1 then
            p = "0" .. p
        end
        m = m .. p
    end
    return m
end
local r = {}
r[0] = {}
r[0][#r[0] + 1] = "section_1"
r["section_1"] = "[Main-Settings]"
r[0][#r[0] + 1] = "version"
r["version"] = 19
r[0][#r[0] + 1] = "2t1s_parent"
r["2t1s_parent"] = true
r[0][#r[0] + 1] = "exclude_friends"
r["exclude_friends"] = true
r[0][#r[0] + 1] = "logger"
r["logger"] = true
r[0][#r[0] + 1] = "load_admin"
r["load_admin"] = true
r[0][#r[0] + 1] = "section_2"
r["section_2"] = "[Blacklist]"
r[0][#r[0] + 1] = "bl_hidden"
r["bl_hidden"] = false
r[0][#r[0] + 1] = "blacklist_enabled"
r["blacklist_enabled"] = false
r[0][#r[0] + 1] = "auto_kick"
r["auto_kick"] = false
r[0][#r[0] + 1] = "mark_modder"
r["mark_modder"] = false
r[0][#r[0] + 1] = "admin_enabled"
r["admin_enabled"] = false
r[0][#r[0] + 1] = "kick_joining"
r["kick_joining"] = false
r[0][#r[0] + 1] = "section_3"
r["section_3"] = "[Modders]"
r[0][#r[0] + 1] = "modder_hidden"
r["modder_hidden"] = false
r[0][#r[0] + 1] = "remember_modder"
r["remember_modder"] = false
r[0][#r[0] + 1] = "karma_modder_scripts"
r["karma_modder_scripts"] = false
r[0][#r[0] + 1] = "unmark_friends"
r["unmark_friends"] = true
r[0][#r[0] + 1] = "speed_bypass"
r["speed_bypass"] = false
r[0][#r[0] + 1] = "name_bypass"
r["name_bypass"] = false
r[0][#r[0] + 1] = "modded_scid"
r["modded_scid"] = false
r[0][#r[0] + 1] = "modded_net_events"
r["modded_net_events"] = false
r[0][#r[0] + 1] = "modder_force_sh"
r["modder_force_sh"] = false
r[0][#r[0] + 1] = "modded_script_event"
r["modded_script_event"] = false
r[0][#r[0] + 1] = "section_4"
r["section_4"] = "[Lobby]"
r[0][#r[0] + 1] = "lobby_hidden"
r["lobby_hidden"] = false
r[0][#r[0] + 1] = "teleport_to_block"
r["teleport_to_block"] = false
r[0][#r[0] + 1] = "explode_lobby"
r["explode_lobby"] = false
r[0][#r[0] + 1] = "explode_lobby_value"
r["explode_lobby_value"] = 8
r[0][#r[0] + 1] = "explode_lobby_shake"
r["explode_lobby_shake"] = false
r[0][#r[0] + 1] = "sound_rape"
r["sound_rape"] = false
r[0][#r[0] + 1] = "kill_all_peds"
r["kill_all_peds"] = false
r[0][#r[0] + 1] = "disablecontrol"
r["disablecontrol"] = false
r[0][#r[0] + 1] = "bounty_after_death"
r["bounty_after_death"] = false
r[0][#r[0] + 1] = "bounty_after_death_value"
r["bounty_after_death_value"] = 0
r[0][#r[0] + 1] = "anonymous_bounty"
r["anonymous_bounty"] = false
r[0][#r[0] + 1] = "sms_spam"
r["sms_spam"] = false
r[0][#r[0] + 1] = "sms_spam_value"
r["sms_spam_value"] = 25
r[0][#r[0] + 1] = "karma_se"
r["karma_se"] = false
r[0][#r[0] + 1] = "punish_aliens"
r["punish_aliens"] = false
r[0][#r[0] + 1] = "force_host"
r["force_host"] = false
r[0][#r[0] + 1] = "modify_veh_speed"
r["modify_veh_speed"] = 0
r[0][#r[0] + 1] = "modify_veh_speed_include"
r["modify_veh_speed_include"] = false
r[0][#r[0] + 1] = "modify_veh_speed_overwrite"
r["modify_veh_speed_overwrite"] = false
r[0][#r[0] + 1] = "section_5"
r["section_5"] = "[Vehicle-Blacklist]"
r[0][#r[0] + 1] = "veh_blacklist"
r["veh_blacklist"] = false
r[0][#r[0] + 1] = "Oppressor"
r["Oppressor"] = false
r[0][#r[0] + 1] = "MK2_Oppressor"
r["MK2_Oppressor"] = false
r[0][#r[0] + 1] = "Lazer"
r["Lazer"] = false
r[0][#r[0] + 1] = "Hydra"
r["Hydra"] = false
r[0][#r[0] + 1] = "Deluxo"
r["Deluxo"] = false
r[0][#r[0] + 1] = "Akula"
r["Akula"] = false
r[0][#r[0] + 1] = "B_11_Strikforce"
r["B_11_Strikforce"] = false
r[0][#r[0] + 1] = "Tank"
r["Tank"] = false
r[0][#r[0] + 1] = "Khanjali"
r["Khanjali"] = false
r[0][#r[0] + 1] = "Stromberg"
r["Stromberg"] = false
r[0][#r[0] + 1] = "Buzzard"
r["Buzzard"] = false
r[0][#r[0] + 1] = "Hunter"
r["Hunter"] = false
r[0][#r[0] + 1] = "Avenger"
r["Avenger"] = false
r[0][#r[0] + 1] = "Insurgent_Pickup"
r["Insurgent_Pickup"] = false
r[0][#r[0] + 1] = "Insurgent_Pickup_Custom"
r["Insurgent_Pickup_Custom"] = false
r[0][#r[0] + 1] = "Halftrack"
r["Halftrack"] = false
r[0][#r[0] + 1] = "section_6"
r["section_6"] = "[Chat]"
r[0][#r[0] + 1] = "chat_hidden"
r["chat_hidden"] = false
r[0][#r[0] + 1] = "chat_cmd_friends"
r["chat_cmd_friends"] = true
r[0][#r[0] + 1] = "chat_cmd_all"
r["chat_cmd_all"] = false
r[0][#r[0] + 1] = "chat_log"
r["chat_log"] = false
r[0][#r[0] + 1] = "chat_russki"
r["chat_russki"] = false
r[0][#r[0] + 1] = "chat_begger"
r["chat_begger"] = false
r[0][#r[0] + 1] = "section_7"
r["section_7"] = "[Chat-Commands]"
r[0][#r[0] + 1] = "chat_cmd"
r["chat_cmd"] = false
r[0][#r[0] + 1] = "cmd_explode"
r["cmd_explode"] = false
r[0][#r[0] + 1] = "cmd_explode_all"
r["cmd_explode_all"] = false
r[0][#r[0] + 1] = "cmd_kick"
r["cmd_kick"] = false
r[0][#r[0] + 1] = "cmd_kick_all"
r["cmd_kick_all"] = false
r[0][#r[0] + 1] = "cmd_crash"
r["cmd_crash"] = false
r[0][#r[0] + 1] = "cmd_crash_all"
r["cmd_crash_all"] = false
r[0][#r[0] + 1] = "cmd_lag"
r["cmd_lag"] = false
r[0][#r[0] + 1] = "cmd_trap"
r["cmd_trap"] = false
r[0][#r[0] + 1] = "cmd_tp"
r["cmd_tp"] = false
r[0][#r[0] + 1] = "cmd_clearwanted"
r["cmd_clearwanted"] = false
r[0][#r[0] + 1] = "cmd_vehicle"
r["cmd_vehicle"] = false
r[0][#r[0] + 1] = "cmd_bigpp"
r["cmd_bigpp"] = false
r[0][#r[0] + 1] = "cmd_bigppall"
r["cmd_bigppall"] = false
r[0][#r[0] + 1] = "section_8"
r["section_8"] = "[Custom-Vehicles]"
r[0][#r[0] + 1] = "custom_vehicles_hidden"
r["custom_vehicles_hidden"] = false
r[0][#r[0] + 1] = "spawn_in_vehicle"
r["spawn_in_vehicle"] = true
r[0][#r[0] + 1] = "use_own_veh"
r["use_own_veh"] = true
r[0][#r[0] + 1] = "set_godmode"
r["set_godmode"] = false
r[0][#r[0] + 1] = "controllable_blasts"
r["controllable_blasts"] = false
r[0][#r[0] + 1] = "moveable_legs"
r["moveable_legs"] = false
r[0][#r[0] + 1] = "robot_collision"
r["robot_collision"] = false
r[0][#r[0] + 1] = "rocket_propulsion"
r["rocket_propulsion"] = false
r[0][#r[0] + 1] = "equip_weapons"
r["equip_weapons"] = false
r[0][#r[0] + 1] = "disable_tampa_notify"
r["disable_tampa_notify"] = false
r[0][#r[0] + 1] = "section_9"
r["section_9"] = "[Explosive-Beam]"
r[0][#r[0] + 1] = "explosive_beam_hidden"
r["explosive_beam_hidden"] = false
r[0][#r[0] + 1] = "exp_beam"
r["exp_beam"] = false
r[0][#r[0] + 1] = "exp_beam_type"
r["exp_beam_type"] = 59
r[0][#r[0] + 1] = "exp_beam_type_2"
r["exp_beam_type_2"] = 8
r[0][#r[0] + 1] = "exp_beam_radius"
r["exp_beam_radius"] = 10
r[0][#r[0] + 1] = "exp_beam_min"
r["exp_beam_min"] = 75
r[0][#r[0] + 1] = "exp_beam_max"
r["exp_beam_max"] = 225
r[0][#r[0] + 1] = "section_10"
r["section_10"] = "[Better-Animal-Changer]"
r[0][#r[0] + 1] = "animal_changer_hidden"
r["animal_changer_hidden"] = false
r[0][#r[0] + 1] = "bl_mdl_change"
r["bl_mdl_change"] = true
r[0][#r[0] + 1] = "revert_outfit"
r["revert_outfit"] = true
r[0][#r[0] + 1] = "section_11"
r["section_11"] = "[PTFX]"
r[0][#r[0] + 1] = "ptfx_hidden"
r["ptfx_hidden"] = false
r[0][#r[0] + 1] = "sparkling_ass"
r["sparkling_ass"] = false
r[0][#r[0] + 1] = "sparkling_tires"
r["sparkling_tires"] = false
r[0][#r[0] + 1] = "smoke_area"
r["smoke_area"] = false
r[0][#r[0] + 1] = "fire_circle"
r["fire_circle"] = false
r[0][#r[0] + 1] = "fire_fart"
r["fire_fart"] = 8
r[0][#r[0] + 1] = "fire_ass"
r["fire_ass"] = false
r[0][#r[0] + 1] = "section_12"
r["section_12"] = "[Miscellaneous]"
r[0][#r[0] + 1] = "misc_hidden"
r["misc_hidden"] = false
r[0][#r[0] + 1] = "drive_on_ocean"
r["drive_on_ocean"] = false
r[0][#r[0] + 1] = "drive_this_height"
r["drive_this_height"] = false
r[0][#r[0] + 1] = "weird_ent"
r["weird_ent"] = false
r[0][#r[0] + 1] = "real_time"
r["real_time"] = false
r[0][#r[0] + 1] = "clear_area"
r["clear_area"] = false
r[0][#r[0] + 1] = "clear_area_2"
r["clear_area_2"] = false
r[0][#r[0] + 1] = "auto_tp_wp"
r["auto_tp_wp"] = false
r[0][#r[0] + 1] = "auto_load"
r["auto_load"] = false
r[0][#r[0] + 1] = "log_modder_flags"
r["log_modder_flags"] = false
r[0][#r[0] + 1] = "section_13"
r["section_13"] = "[Weapons-Features]"
r[0][#r[0] + 1] = "load_weapons"
r["load_weapons"] = false
r[0][#r[0] + 1] = "flamethrower_scale"
r["flamethrower_scale"] = 1
r[0][#r[0] + 1] = "flamethrower"
r["flamethrower"] = false
r[0][#r[0] + 1] = "flamethrower_green"
r["flamethrower_green"] = false
r[0][#r[0] + 1] = "shoot_entitys"
r["shoot_entitys"] = false
r[0][#r[0] + 1] = "Boat"
r["Boat"] = false
r[0][#r[0] + 1] = "Bumper_Car"
r["Bumper_Car"] = false
r[0][#r[0] + 1] = "XMAS_Tree"
r["XMAS_Tree"] = false
r[0][#r[0] + 1] = "Orange_Ball"
r["Orange_Ball"] = false
r[0][#r[0] + 1] = "Stone"
r["Stone"] = false
r[0][#r[0] + 1] = "Money_Bag"
r["Money_Bag"] = false
r[0][#r[0] + 1] = "Cash_Pile"
r["Cash_Pile"] = false
r[0][#r[0] + 1] = "Trash"
r["Trash"] = false
r[0][#r[0] + 1] = "Roller_Car"
r["Roller_Car"] = false
r[0][#r[0] + 1] = "Cable_Car"
r["Cable_Car"] = false
r[0][#r[0] + 1] = "Big_Dildo"
r["Big_Dildo"] = false
r[0][#r[0] + 1] = "delete_gun"
r["delete_gun"] = false
r[0][#r[0] + 1] = "kick_gun"
r["kick_gun"] = false
r[0][#r[0] + 1] = "demigod_gun"
r["demigod_gun"] = false
r[0][#r[0] + 1] = "model_gun"
r["model_gun"] = false
r[0][#r[0] + 1] = "model_gun_ext"
r["model_gun_ext"] = false
r[0][#r[0] + 1] = "rapid_fire"
r["rapid_fire"] = false
r[0][#r[0] + 1] = "section_14"
r["section_14"] = "[Vehicle]"
r[0][#r[0] + 1] = "always_apply_mods"
r["always_apply_mods"] = false
r[0][#r[0] + 1] = "heli"
r["heli"] = false
r[0][#r[0] + 1] = "heli_i"
r["heli_i"] = 100
r[0][#r[0] + 1] = "sel_boost_speed"
r["sel_boost_speed"] = false
r[0][#r[0] + 1] = "sel_boost_speed_speed"
r["sel_boost_speed_speed"] = 100
r[0][#r[0] + 1] = "speedometer"
r["speedometer"] = false
r[0][#r[0] + 1] = "speedometer_type"
r["speedometer_type"] = 1
r[0][#r[0] + 1] = "veh_no_colision"
r["veh_no_colision"] = false
r[0][#r[0] + 1] = "auto_repair"
r["auto_repair"] = false
r[0][#r[0] + 1] = "section_15"
r["section_15"] = "[Vehicle-Colors]"
r[0][#r[0] + 1] = "veh_lights_speed"
r["veh_lights_speed"] = 125
r[0][#r[0] + 1] = "random_primary"
r["random_primary"] = false
r[0][#r[0] + 1] = "random_secondary"
r["random_secondary"] = false
r[0][#r[0] + 1] = "random_pearlescent"
r["random_pearlescent"] = false
r[0][#r[0] + 1] = "random_neon"
r["random_neon"] = false
r[0][#r[0] + 1] = "random_smoke"
r["random_smoke"] = false
r[0][#r[0] + 1] = "random_xenon"
r["random_xenon"] = false
r[0][#r[0] + 1] = "rainbow_primary"
r["rainbow_primary"] = false
r[0][#r[0] + 1] = "rainbow_secondary"
r["rainbow_secondary"] = false
r[0][#r[0] + 1] = "rainbow_pearlescent"
r["rainbow_pearlescent"] = false
r[0][#r[0] + 1] = "rainbow_neon"
r["rainbow_neon"] = false
r[0][#r[0] + 1] = "rainbow_smoke"
r["rainbow_smoke"] = false
r[0][#r[0] + 1] = "rainbow_xenon"
r["rainbow_xenon"] = false
r[0][#r[0] + 1] = "synced_random"
r["synced_random"] = false
r[0][#r[0] + 1] = "synced_rainbow"
r["synced_rainbow"] = false
r[0][#r[0] + 1] = "synced_rainbow_smooth"
r["synced_rainbow_smooth"] = false
r[0][#r[0] + 1] = "black_100"
r["black_100"] = false
r[0][#r[0] + 1] = "fade_black_red"
r["fade_black_red"] = false
r[0][#r[0] + 1] = "section_16"
r["section_16"] = "[Bodyguards]"
r[0][#r[0] + 1] = "bodyguards_hidden"
r["bodyguards_hidden"] = false
r[0][#r[0] + 1] = "bodyguards_god"
r["bodyguards_god"] = false
r[0][#r[0] + 1] = "bodyguards_health"
r["bodyguards_health"] = 5000
r[0][#r[0] + 1] = "bodyguards_equip_weapon"
r["bodyguards_equip_weapon"] = false
r[0][#r[0] + 1] = "bodyguards_formation_type"
r["bodyguards_formation_type"] = 0
r[0][#r[0] + 1] = "section_17"
r["section_17"] = "[Self]"
r[0][#r[0] + 1] = "self_hidden"
r["self_hidden"] = false
r[0][#r[0] + 1] = "random_clothes"
r["random_clothes"] = false
r[0][#r[0] + 1] = "police_outfit"
r["police_outfit"] = false
r[0][#r[0] + 1] = "random_clothes_value"
r["random_clothes_value"] = 5
r[0][#r[0] + 1] = "undead_otr"
r["undead_otr"] = false
r[0][#r[0] + 1] = "quick_regen"
r["quick_regen"] = false
r[0][#r[0] + 1] = "unlimited_regen"
r["unlimited_regen"] = false
r[0][#r[0] + 1] = "revert_health"
r["revert_health"] = false
r[0][#r[0] + 1] = "ragdoll"
r["ragdoll"] = false
r[0][#r[0] + 1] = "section_18"
r["section_18"] = "[Aim-Protection]"
r[0][#r[0] + 1] = "enable_aim_prot"
r["enable_aim_prot"] = false
r[0][#r[0] + 1] = "anonymous_punishment"
r["anonymous_punishment"] = true
r[0][#r[0] + 1] = "aim_prot_ragdoll"
r["aim_prot_ragdoll"] = false
r[0][#r[0] + 1] = "aim_prot_fire"
r["aim_prot_fire"] = false
r[0][#r[0] + 1] = "aim_prot_kill"
r["aim_prot_kill"] = false
r[0][#r[0] + 1] = "aim_prot_remove_weapon"
r["aim_prot_remove_weapon"] = false
r[0][#r[0] + 1] = "aim_prot_kick"
r["aim_prot_kick"] = false
r[0][#r[0] + 1] = "section_19"
r["section_19"] = "[Options]"
r[0][#r[0] + 1] = "options_hidden"
r["options_hidden"] = false
r[0][#r[0] + 1] = "attach_no_colision"
r["attach_no_colision"] = false
r[0][#r[0] + 1] = "continuously_assassins"
r["continuously_assassins"] = false
r[0][#r[0] + 1] = "override_notify_color"
r["override_notify_color"] = false
r[0][#r[0] + 1] = "notify_color"
r["notify_color"] = 0
r[0][#r[0] + 1] = "enable_hotkeys"
r["enable_hotkeys"] = false
r[0][#r[0] + 1] = "hotkey_notification"
r["hotkey_notification"] = false
r[0][#r[0] + 1] = "disable_history"
r["disable_history"] = false
r[0][#r[0] + 1] = "history_show_uuid"
r["history_show_uuid"] = false
r[0][#r[0] + 1] = "mwh_notify"
r["mwh_notify"] = false
r[0][#r[0] + 1] = "mwh_exclude_navigation"
r["mwh_exclude_navigation"] = true
r[0][#r[0] + 1] = "mwh_exclude_noclip"
r["mwh_exclude_noclip"] = true
r[0][#r[0] + 1] = "mwh_exclude_editorrot"
r["mwh_exclude_editorrot"] = true
r[0][#r[0] + 1] = "mwh_exclude_file"
r["mwh_exclude_file"] = false
local s = {}
s[0] = {}
s[0][#s[0] + 1] = "leave_session"
s["leave_session"] = "none"
s[0][#s[0] + 1] = "undead_otr"
s["undead_otr"] = "none"
s[0][#s[0] + 1] = "do_ragdoll"
s["do_ragdoll"] = "none"
s[0][#s[0] + 1] = "print_info_from_entity"
s["print_info_from_entity"] = "none"
s[0][#s[0] + 1] = "drive_this_height"
s["drive_this_height"] = "none"
s[0][#s[0] + 1] = "auto_tp_wp"
s["auto_tp_wp"] = "none"
s[0][#s[0] + 1] = "force_host"
s["force_host"] = "none"
s[0][#s[0] + 1] = "synced_rainbow"
s["synced_rainbow"] = "none"
s[0][#s[0] + 1] = "veh_blacklist"
s["veh_blacklist"] = "none"
s[0][#s[0] + 1] = "laser_beam_explode_waypoint"
s["laser_beam_explode_waypoint"] = "none"
s[0][#s[0] + 1] = "blacklist_enabled"
s["blacklist_enabled"] = "none"
s[0][#s[0] + 1] = "kick_joining"
s["kick_joining"] = "none"
s[0][#s[0] + 1] = "remember_modder"
s["remember_modder"] = "none"
s[0][#s[0] + 1] = "exclude_friends"
s["exclude_friends"] = "none"
s[0][#s[0] + 1] = "chat_cmd"
s["chat_cmd"] = "none"
s[0][#s[0] + 1] = "send_msg_to_script_users"
s["send_msg_to_script_users"] = "none"
s[0][#s[0] + 1] = "teleport_high_in_air"
s["teleport_high_in_air"] = "none"
s[0][#s[0] + 1] = "tp_own_veh_to_me"
s["tp_own_veh_to_me"] = "none"
s[0][#s[0] + 1] = "tp_own_veh_to_me_drive"
s["tp_own_veh_to_me_drive"] = "none"
s[0][#s[0] + 1] = "drive_own_veh"
s["drive_own_veh"] = "none"
s[0][#s[0] + 1] = "tp_to_own_veh"
s["tp_to_own_veh"] = "none"
s[0][#s[0] + 1] = "save_config"
s["save_config"] = "none"
local t = {}
t[0] = {}
t[0][#t[0] + 1] = "maxspeed"
t["maxspeed"] = {"Max-Speed-Bypass", nil}
t[0][#t[0] + 1] = "illegalname"
t["illegalname"] = {"Illegal-Name", nil}
t[0][#t[0] + 1] = "moddedscid"
t["moddedscid"] = {"Modded-SCID", nil}
t[0][#t[0] + 1] = "moddednetevent"
t["moddednetevent"] = {"Modded-Net-Event", nil}
t[0][#t[0] + 1] = "force_sh"
t["force_sh"] = {"Forced-Script-Host", nil}
t[0][#t[0] + 1] = "remembered"
t["remembered"] = {"Remembered", nil}
t[0][#t[0] + 1] = "blacklist"
t["blacklist"] = {"Blacklist", nil}
t[0][#t[0] + 1] = "script"
t["script"] = {"Modded-Script-Event", nil}
local function u(f, v, w)
    if not f then
        return
    end
    v = v or 140
    w = w or "2Take1Script"
    if r["override_notify_color"] then
        v = r["notify_color"]
    end
    ui.notify_above_map(f, w, v)
end
local function x(f, y)
    if r["logger"] then
        if not f then
            return
        end
        local z = d.time_prefix() .. " [2Take1Script] "
        if y then
            z = z .. y .. " "
        end
        f = z .. f
        d.write(c.o(b["Log_file"], "a"), f)
    end
end
local A = {
    1,
    2,
    4,
    8,
    16,
    32,
    64,
    128,
    256,
    512,
    1024,
    2048,
    4096,
    8192,
    16384,
    32768,
    65536,
    131072,
    262144,
    524288,
    1048576,
    2097152,
    4194304,
    8388608,
    16777216,
    33554432,
    67108864,
    134217728,
    268435456,
    536870912,
    1073741824,
    2147483648,
    4294967296,
    8589934592,
    17179869184,
    34359738368,
    68719476736,
    137438953472,
    274877906944,
    549755813888,
    1099511627776,
    2199023255552,
    4398046511104,
    8796093022208,
    17592186044416,
    35184372088832,
    70368744177664,
    140737488355328,
    281474976710656,
    562949953421312,
    1125899906842624,
    2251799813685248,
    4503599627370496,
    9007199254740992,
    18014398509481984,
    36028797018963968,
    72057594037927936,
    144115188075855872,
    288230376151711744,
    576460752303423488,
    1152921504606846976,
    2305843009213693952,
    4611686018427387904
}
local B = {}
local C = {}
local D = {}
D.name = function(i)
    if c.valid(i) then
        return player.get_player_name(i)
    end
    return "Invalid Player"
end
D.scid = function(i)
    if c.valid(i) then
        local c = player.get_player_scid(i)
        if c ~= 4294967295 then
            return c
        end
    end
    return -1
end
D.ip = function(i)
    if c.valid(i) then
        local E = player.get_player_ip(i)
        return string.format("%i.%i.%i.%i", E >> 24 & 0xff, E >> 16 & 0xff, E >> 8 & 0xff, E & 0xff)
    end
    return -1
end
D.input = function(F, G, H, I)
    if not F then
        return nil
    end
    I = I or ""
    G = G or 64
    H = H or 0
    local J, i = input.get(F, I, G, H)
    while J == 1 do
        c.wait(0)
        J, i = input.get(F, I, G, H)
    end
    if J == 2 then
        return nil
    end
    return i
end
local K = {}
K.main = function()
    x("Loading Settings...")
    math.randomseed(c.time())
    if _2t1s then
        u("2Take1Script already loaded, stopping.", 208)
        return
    end
    if not c.d_exists(a["2T1S"]) then
        u("2Take1Script folder not found...", 208)
        u("Redownload the script and make sure you got all files!", 208)
        return
    else
        if c.f_exists(b["EXT_file"]) then
            _2t1sEXT = true
            local L, M = loadfile(b["EXT_file"])
            if L then
                local N
                N,
                    C.custom_se,
                    C.ped_assassins,
                    C.russki_chars,
                    C.begger_texts,
                    C.speedometer_units,
                    C.block_custom,
                    C.custom_attachments,
                    C.custom_vehicles,
                    C.vehicle_lag_area,
                    C.bounty_amount,
                    C.sms_texts,
                    C.weapons,
                    C.net_events,
                    C.enable_admin = xpcall(L, debug.traceback)
                x("2Take1ScriptEXT successfully loaded.")
            else
                _2t1sEXT = false
                u("ERROR Loading Script EXT, returning!", 208)
                return
            end
        else
            u("2Take1ScriptEXT.lua not found!\nMake sure you have all important files!", 208)
            return
        end
        if not c.d_exists(a["Config"]) then
            u("2Take1Script/Config folder not found...", 208)
            u("Redownload the script and make sure you got all files!", 208)
            return
        end
        if not c.d_exists(a["CustomFiles"]) then
            u("2Take1Script/CustomFiles folder not found...", 208)
            u("Redownload the script and make sure you got all files!", 208)
            return
        end
    end
    local O = c.o(b["Config"], "r")
    if O then
        for o in io.lines(b["Config"]) do
            if not string.find(o, "]", 1) and not string.find(o, "version", 1) then
                local q = ""
                while string.find(o, "=", 1) do
                    q = q .. string.sub(o, 1, 1)
                    o = string.sub(o, 2)
                end
                q = string.sub(q, 1, #q - 1)
                if r[q] ~= nil then
                    if o == "true" then
                        r[q] = true
                    elseif o == "false" then
                        r[q] = false
                    elseif type(o) == "number" then
                        r[q] = c.no(o)
                    else
                        r[q] = o
                    end
                else
                    u("I found an outdated settings entry and cant read it, save settings to overwrite it.")
                    u("Setting: '" .. q .. "' is invalid. Delete this entry or save settings.")
                end
            end
        end
        io.close(O)
    end
    O = nil
    O = c.o(b["data"], "r")
    if O then
        for P in io.lines(b["data"]) do
            B[#B + 1] = P
        end
        io.close(O)
    else
        u("ERROR Loading Script, returning!", 208)
        u("Missing files! Redownload the .zip folder and make sure you have all included files!!!")
        return
    end
    if c.f_exists(b["Admin"]) then
        if not l_a and r["load_admin"] then
            local Q, M = loadfile(b["Admin"])
            if Q then
                xpcall(Q, debug.traceback)
                x("2Take1Script-Admin successfully loaded.")
            else
                u("ERROR Loading Script Admin!", 208)
            end
        end
    end
    local R = {0xedb42cd8, 0x231d58ee, 0xac07dc75, 0x58fabbdf, 0xd892c51c, 0xb3f248d0}
    hook.register_script_event_hook(
        function(S, T, U, V)
            if type(U) == "table" then
                if U[1] == 0xfaaab4a3 then
                    if U[2] == 6666 then
                        table.remove(U, 1)
                        table.remove(U, 1)
                        local W = utf8.char(table.unpack(U))
                        u(W, D.name(S), 47)
                        x(D.name(S) .. ": " .. W)
                    end
                end
                for i = 1, #R do
                    if R[i] == U[1] and #U == 5 then
                        local X = R[c.random(1, #R)]
                        local plid = c.id()
                        local Y = c.random(-10, 100)
                        c.script(X, S, {plid, U[3], U[4], Y})
                    end
                end
            end
        end
    )
    return true
end
K.modder_flags = function()
    x("Loading Modder-Flags...")
    for i = 18, #A do
        if player.get_modder_flag_text(A[i]) == "" then
            break
        end
        for Z = 1, #t[0] do
            if player.get_modder_flag_text(A[i]) == t[t[0][Z]][1] then
                t[t[0][Z]][2] = A[i]
            end
        end
    end
    for i = 1, #t[0] do
        if not t[t[0][i]][2] then
            t[t[0][i]][2] = player.add_modder_flag(t[t[0][i]][1])
        end
    end
end
K.hotkeys = function()
    x("Reading Hotkeys.")
    local _ = c.o(b["Hotkeys"], "r")
    if _ then
        for n in io.lines(b["Hotkeys"]) do
            if string.find(n, "version", 1) then
                local a0 = string.gsub(n, "version=", "")
                a0 = c.no(a0)
                if a0 ~= r["version"] then
                    u("Old Hotkeys-File detected. Delete the file or use the overwrite in the Hotkey-Options!", 86)
                end
            end
            if not string.find(n, "#", 1) and not string.find(n, "version", 1) then
                local q = ""
                while string.find(n, "=", 1) do
                    q = q .. string.sub(n, 1, 1)
                    n = string.sub(n, 2)
                end
                q = string.sub(q, 1, #q - 1)
                if n ~= "none" and n ~= "nil" then
                    if s[q] then
                        s[q] = n
                    else
                        u(
                            "Outdated Hotkeys entry found. Delete the file or use the overwrite in the Hotkey-Options!",
                            86
                        )
                        u("Hotkey: '" .. n .. "' with action: '" .. q .. "' is invalid. Delete this entry.", 86)
                    end
                end
            end
        end
        io.close(_)
    end
end
K.overwrite_hotkeys = function()
    local a1 = c.o(b["Hotkeys"], "w")
    io.output(a1)
    io.write("version=" .. r["version"] .. "\n")
    for i = 1, #s[0] do
        io.write(s[0][i] .. "=" .. tostring(s[s[0][i]]) .. "\n")
    end
    io.write("################################\n")
    io.write(
        "#There are more valid Keys, but i wont list them. Currently its not supported to push 2 Keys for 1 Hotkey.\n"
    )
    io.write("#Example valid Hotkeys:\n")
    io.write("#F1-F12\n")
    io.write("#A-Z\n")
    io.write("#LCONTROL\n")
    io.write("#RSHIFT\n")
    io.write("#Insert\n")
    io.write("#Down\n")
    io.write("#PageDown\n")
    io.close(a1)
    u("Created 2Take1Hotkeys.ini file in folder '2Take1Script/Config'. Edit Hotkeys and reload Hotkeys.ini file.", 86)
end
if not K.main() then
    return
end
K.hotkeys()
K.modder_flags()
local a2 = {}
a2.ctrl = function(N, g)
    if entity.is_an_entity(N) then
        if not network.has_control_of_entity(N) then
            network.request_control_of_entity(N)
            g = g or 25
            local time = c.time() + g
            while entity.is_an_entity(N) and not network.has_control_of_entity(N) do
                c.wait(0)
                network.request_control_of_entity(N)
                if time < c.time() then
                    return false
                end
            end
        end
        return network.has_control_of_entity(N)
    end
    return false
end
a2.model = function(a3)
    if a3 and not streaming.has_model_loaded(a3) then
        streaming.request_model(a3)
        local time = c.time() + 7500
        while not streaming.has_model_loaded(a3) do
            c.wait(0)
            if time < c.time() then
                return false
            end
        end
    end
    return true
end
local a4 = {}
a4.ped = function()
    return c.ped(c.id())
end
a4.heading = function()
    return player.get_player_heading(c.id())
end
a4.coords = function()
    return c.gcoords(a4.ped())
end
local a5 = {}
a5.p = {["parent"] = 0, ["opl_parent"] = 0}
a5.t = {}
a5.o = {}
a5.add = {}
a5.add.p = function(j, a6, a7)
    return menu.add_feature(j, "parent", a6, a7)
end
a5.add.t = function(j, a6, a7)
    return menu.add_feature(j, "toggle", a6, a7)
end
a5.add.a = function(j, a6, a7)
    return menu.add_feature(j, "action", a6, a7)
end
a5.add.u = function(j, a8, a6, a7)
    return menu.add_feature(j, a8, a6, a7)
end
a5.add.pp = function(j, a6, a7)
    return menu.add_player_feature(j, "parent", a6, a7)
end
a5.add.pt = function(j, a6, a7)
    return menu.add_player_feature(j, "toggle", a6, a7)
end
a5.add.pa = function(j, a6, a7)
    return menu.add_player_feature(j, "action", a6, a7)
end
a5.add.pu = function(j, a8, a6, a7)
    return menu.add_player_feature(j, a8, a6, a7)
end
local a9 = {}
a9.i = function(i, aa)
    local ab = false
    if aa == true then
        ab = true
    end
    if c.valid(i) then
        if (ab or i ~= c.id()) and D.scid(i) ~= -1 then
            if ab or (r["exclude_friends"] and not player.is_player_friend(i) or not r["exclude_friends"]) then
                return true
            end
        end
    end
    return false
end
a9.modder = function(i)
    if c.valid(i) then
        if D.scid(i) ~= -1 and i ~= c.id() and not player.is_player_modder(i, -1) then
            if r["exclude_friends"] and not player.is_player_friend(i) or not r["exclude_friends"] then
                return true
            end
        end
    end
    return false
end
a9.vehicle = function(ac)
    if not ac then
        return
    end
    if ac ~= 0 and (vehicle.get_ped_in_vehicle_seat(ac, -1) == a4.ped() or a5.t["always_apply_mods"].on) then
        return true
    end
    return
end
local ad = {}
ad[1] = true
local ae = {}
ae.add_loop = 1
ae.start_loop = 1
ae.parents = {}
ae.players = {}
ae.event = nil
ae.lobby = nil
ae.tags = function(af)
    for i = 2, #af.children do
        local ag = af.children[i].name
        local ah = string.sub(af.children[i].children[2].name, 7)
        if ag ~= ah then
            af.children[i].name = ah
        end
        local aj = c.no(string.sub(af.children[i].children[3].name, 7))
        local ak = player.get_host()
        local al = script.get_host_of_this_script()
        for Z = 0, 31 do
            if D.scid(Z) == aj then
                local am = ""
                if Z == c.id() then
                    am = am .. "Y"
                end
                if player.is_player_friend(Z) then
                    am = am .. "F"
                end
                if Z == ak then
                    am = am .. "H"
                end
                if Z == al then
                    am = am .. "S"
                end
                if player.is_player_modder(Z, -1) then
                    am = am .. "M"
                end
                if am ~= "" then
                    ah = ah .. " [" .. am .. "]"
                    af.children[i].name = ah
                end
            end
        end
    end
end
ae.add_players = function()
    if not r["disable_history"] then
        for i = ae.add_loop, #ae.players do
            local an = ae.players[i]["uuid"]
            local ab = ae.players[i]["added"] == false
            local ao = c.no(string.sub(ae.lobby.name, 7, 8))
            local ap = c.no(string.sub(an, #an - 1, #an))
            if not ap then
                ap = c.no(string.sub(an, #an, #an))
            end
            local aq = ao == ap
            if ab and aq then
                ae.add_loop = ae.add_loop + 1
                ae.players[i]["added"] = true
                local aj = ae.players[i]["scid"]
                local j = ae.players[i]["name"]
                local ar = a5.add.p(j, ae.lobby.id).id
                a5.add.a("UUID: " .. ae.players[i]["uuid"], ar).hidden = not r["history_show_uuid"]
                a5.add.a(
                    "NAME: " .. j,
                    ar,
                    function()
                        utils.to_clipboard(j)
                        u("Copied NAME to clipboard!", 21)
                    end
                )
                a5.add.a(
                    "SCID: " .. aj,
                    ar,
                    function()
                        utils.to_clipboard(aj)
                        u("Copied SCID to clipboard!", 21)
                    end
                )
                a5.add.a(
                    "IP: " .. ae.players[i]["ip"],
                    ar,
                    function()
                        utils.to_clipboard(ae.players[i]["ip"])
                        u("Copied IP to clipboard!", 21)
                    end
                )
                a5.add.a("PlayerID: " .. ae.players[i]["player_id"], ar)
                a5.add.a("First seen: " .. ae.players[i]["first_seen"], ar)
                a5.add.a(
                    "Add Player to Blacklist",
                    ar,
                    function()
                        if aj == D.scid(c.id()) or aj == -1 then
                            u("Choose valid Player.")
                        else
                            d.write(c.o(b["Blacklist"], "a"), aj .. " " .. j)
                            u("Player " .. j .. " added to Blocklist.", 48)
                            x("Player " .. j .. " with SCID: " .. aj .. " added to Blacklist.")
                        end
                    end
                )
                a5.add.a(
                    "Add Player to Remember-Modder",
                    ar,
                    function()
                        if aj == D.scid(c.id()) or aj == -1 then
                            u("Choose valid Player.")
                        else
                            d.write(c.o(b["Modders"], "a"), aj .. " " .. j)
                            u("Modder " .. j .. " added to Remember-List.", 130)
                            x("Modder '" .. j .. "' added to Remember-List.")
                        end
                    end
                )
                a5.add.a(
                    "Copy Outfit",
                    ar,
                    function()
                        local as = player.is_player_female(c.id())
                        if as == ae.players[i]["is_female"] then
                            local at = ae.players[i]["h_clothes"]
                            local au = ae.players[i]["h_textures"]
                            for Z = 1, 11 do
                                ped.set_ped_component_variation(a4.ped(), Z, at[Z], au[Z], 2)
                            end
                            local av = {0, 1, 2, 6, 7}
                            local aw = ae.players[i]["h_prop_ind"]
                            local ax = ae.players[i]["h_prop_text"]
                            for ay = 1, #av do
                                ped.set_ped_prop_index(a4.ped(), av[ay], aw[ay], ax[ay], 0)
                            end
                        else
                            u("Unluckily, you have the wrong gender!", 21)
                        end
                    end
                )
                a5.add.a(
                    "Is " .. j .. " in the current lobby?",
                    ar,
                    function()
                        for Z = 0, 31 do
                            if D.scid(Z) == aj then
                                u(j .. " is in your lobby!", 18)
                                return HANDLER_POP
                            end
                        end
                        u(j .. " is ~h~NOT~h~ in your lobby!", 28)
                    end
                )
                a5.add.a(
                    "Was he a modder?",
                    ar,
                    function()
                        local aj = ae.players[i]["scid"]
                        if not a5.t["log_modder_flags"].on then
                            u("Enabel 'Log Modder Flags' in Misc -> Dev Tools", 39)
                        elseif not ad[aj] then
                            u("He was not flagged with any Modder-Flags", 21)
                        else
                            for Z = 1, #A do
                                if ad[aj][A[Z]] then
                                    local az = A[Z]
                                    local f = player.get_modder_flag_text(az)
                                    u(j .. " had '" .. f .. "' as a Flag!", 21)
                                end
                            end
                        end
                    end
                )
            end
        end
    end
end
ae.new_lobby = function(aA)
    local G = #ae.parents + 1
    ae.parents[G] =
        a5.add.p(
        "Lobby " .. aA,
        a5.p["player_history"],
        function()
            ae.add_players()
            ae.tags(ae.parents[G])
        end
    )
    local aB = #ae.parents - 1
    local aC = ae.parents[aB].children
    a5.add.p("Lobby Information", ae.parents[G].id).hidden = true
    ae.lobby = ae.parents[G]
    aC[1].hidden = false
    a5.add.a("Logged " .. #aC - 1 .. " Players in this Lobby!", aC[1].id)
    a5.add.a(
        "Hide this lobby from History",
        aC[1].id,
        function()
            ae.parents[G - 1].hidden = true
        end
    )
end
local aD = {}
aD.ped = function(aE, aF, aG, aH, aI, aJ)
    if not aE then
        return
    end
    aG = aG or 6
    aF = aF or a4.coords()
    aH = aH or 0.0
    aI = aI or true
    aJ = aJ or false
    return ped.create_ped(aG, aE, aF, aH, aI, aJ)
end
aD.object = function(aE, aF, aK, aL)
    if not aE then
        return
    end
    aF = aF or v3()
    aK = aK or true
    aL = aL or false
    return object.create_object(aE, aF, aK, aL)
end
aD.vehicle = function(aE, aF, aH, aK, aJ)
    if not aE then
        return
    end
    aF = aF or v3()
    aH = aH or 0.0
    aK = aK or true
    aJ = aJ or false
    return vehicle.create_vehicle(aE, aF, aH, aK, aJ)
end
local aM = {
    {"Severe Weather", {0}},
    {"Half Track", {0, 1}},
    {"Night Shark AAT", {0, 2}},
    {"APC Mission", {0, 3}},
    {"MOC Mission", {0, 4}},
    {"Tampa Mission", {0, 5}},
    {"Opressor Mission 1", {0, 6}},
    {"Opressor Mission 2", {0, 7}}
}
local aN = {
    {"Ban", 0xC2AD5FCE, {0, 1, 5, 0}, 0x96308401, {0, 1, 5, 0}},
    {"Dismiss", 0x96308401, {0, 1, 5}, 0x96308401, {0, 1, 5}},
    {"Terminate", 0x96308401, {1, 1, 6}, 0x96308401, {0, 1, 6, 0}}
}
local aO = {
    {"Boat", -1685705098, false},
    {"Bumper_Car", -77393630, false},
    {"XMAS_Tree", 238789712, false},
    {"Orange_Ball", 148511758, false},
    {"Stone", 2042668880, false},
    {"Money_Bag", 289396019, false},
    {"Cash_Pile", -295781225, false},
    {"Trash", 1919238784, false},
    {"Roller_Car", 1543894721, false},
    {"Cable_Car", -733833763, false},
    {"Big_Dildo", 1333481871, false}
}
local aP = {
    {222, 222, 255},
    {2, 21, 255},
    {3, 83, 255},
    {0, 255, 140},
    {94, 255, 1},
    {255, 255, 0},
    {255, 150, 5},
    {255, 62, 0},
    {255, 1, 1},
    {255, 50, 100},
    {255, 5, 190},
    {35, 1, 255},
    {15, 3, 255}
}
local aQ = {
    {"Oppressor", 0x34B82784},
    {"MK2_Oppressor", 0x7B54A9D3},
    {"Lazer", 0xB39B0AE6},
    {"Hydra", 0x39D6E83F},
    {"Deluxo", 0x586765FB},
    {"Akula", 0x46699F47},
    {"B_11_Strikforce", 0x64DE07A1},
    {"Tank", 0x2EA68690},
    {"Khanjali", 0xAA6F980A},
    {"Stromberg", 0x34DBA661},
    {"Buzzard", 0x2F03547B},
    {"Hunter", 0xFD707EDE},
    {"Avenger", 0x81BD2ED0},
    {"Insurgent_Pickup", 0x9114EADA},
    {"Insurgent_Pickup_Custom", 0x8D4B7A8A},
    {"Halftrack", 0xFE141DA6}
}
local aR = {
    {"cmd_explode", "!explode <playername>"},
    {"cmd_explode_all", "!explodeall	[SU]"},
    {"cmd_kick", "!kick <playername>"},
    {"cmd_kick_all", "!kickall	[SU]"},
    {"cmd_crash", "!crash <playername>	[SU]"},
    {"cmd_crash_all", "!crashall	[SU]"},
    {"cmd_lag", "!lag <playername>"},
    {"cmd_trap", "!trap <playername>"},
    {"cmd_tp", "!tp <playername>	[SU]"},
    {"cmd_clearwanted", "!clearwanted	[NOT SU]"},
    {"cmd_vehicle", "!vehicle <NAME>"},
    {"cmd_bigpp", "!bigpp <playername>"},
    {"cmd_bigppall", "!bigppall	[SU]"}
}
local aS = {
    ["lscs"] = {
        {
            "Main LSC",
            {
                {3291218330, {-357.45132446289, -134.30920410156, 38.53914642334}, {0, 0, -20}, true, true},
                {false, {-370.4, -104.72, 47}, -110.83449554443}
            }
        },
        {
            "La Mesa LSC",
            {
                {3291218330, {722.9853515625, -1089.2061767578, 23.043445587158}, {0, 0, 0}, true, true},
                {false, {700, -1085, 24}, -100}
            }
        },
        {
            "LSIA LSC",
            {
                {3291218330, {-1145.7882080078, -1991.130859375, 13.163989067078}, {0, 0, 45}, true, true},
                {false, {-1117.1, -1983.3, 23}, 104.5}
            }
        },
        {
            "Desert LSC",
            {
                {3291218330, {1178.552734375, 2646.4377441406, 37.874099731445}, {0, 0, 90}, true, true},
                {false, {1182, 2673.2, 39}, 163.3}
            }
        },
        {
            "Paleto Bay LSC",
            {
                {3291218330, {112.54597473145, 6619.6850585938, 31.604303359985}, {0, 0, -45}, true, true},
                {false, {140.8, 6601.9, 32}, 57}
            }
        },
        {
            "Bennys LSC",
            {
                {3291218330, {-208.5591583252, -1308.7404785156, 31.718006134033}, {0, 0, 90}, true, true},
                {false, {-184.2, -1292.5, 34}, 124.3}
            }
        }
    },
    ["casino"] = {
        {
            "Entrance",
            {
                {3291218330, {924.69201660156, 62.243091583252, 81.21053314209}, {0, 0, 80}, true, true},
                {3291218330, {910.31787109375, 36.022556304932, 80.59684753418}, {0, 0, 25}, true, true},
                {false, {920.8, 80.5, 80}, -177}
            }
        },
        {
            "Garage",
            {
                {3291218330, {932.78601074219, -2.0857257843018, 80.166107177734}, {0, 0, 60}, true, true},
                {false, {940, -21, 80}, 4.9}
            }
        },
        {
            "Roof",
            {
                {3291218330, {964.02569580078, 58.947933197021, 113.34354400635}, {0, 0, -30}, true, true},
                {false, {954.8, 63.34, 114}, -124.2}
            }
        }
    },
    ["mazebank"] = {
        {
            "Entrance",
            {
                {3291218330, {-81.541351318359, -792.25347900391, 44.622947692871}, {0, 0, 100}, true, true},
                {3291218330, {-70.231819152832, -802.17694091797, 44.230716705322}, {0, 0, 0}, true, true},
                {false, {-55.1, -776.5, 46}, 125.4}
            }
        },
        {
            "Garage",
            {
                {3291218330, {-83.269706726074, -773.02490234375, 39.806701660156}, {0, -35, 105}, true, true},
                {false, {-86.2, -762.2, 44}, -165.7}
            }
        },
        {
            "Roof",
            {
                {3291218330, {-66.390617370605, -813.32702636719, 320.40509033203}, {0, 0, 60}, true, true},
                {3291218330, {-66.451454162598, -822.87298583984, 321.19717407227}, {0, 0, 100}, true, true},
                {3291218330, {-68.104598999023, -818.67510986328, 323.35980224609}, {0, 90, 0}, true, true},
                {false, {-76.6, -817.6, 328}}
            }
        },
        {
            "Arena War",
            {
                {3291218330, {-371.32809448242, -1859.2064208984, 21.246929168701}, {0, 15, -75}, true, true},
                {3291218330, {-396.87942504883, -1869.1518554688, 22.718107223511}, {0, 15, -60}, true, true},
                {false, {-379.6, -1850, 23}, -166.6}
            }
        }
    },
    ["custom"] = C.block_custom
}
local aT = {1057201338, 2238511874, 762327283}
local aU = {
    62409944,
    64074298,
    155527062,
    153219155,
    131037988,
    141884823,
    104432921,
    147111499,
    9284553,
    114982881,
    137663665,
    63457,
    137601710,
    138075198,
    123017343,
    130291511,
    137851207,
    137714280,
    127448079,
    137579070,
    134412628,
    133709045,
    64234321,
    131973478,
    103019313,
    103054099,
    104041189,
    110470958,
    119266383,
    119958356,
    121397532,
    121698158,
    123849404,
    121943600,
    129159629,
    18965281,
    216820,
    56778561,
    99453545,
    99453882,
    88435916,
    174875493
}
local aV = {
    ["bl_objects"] = {},
    ["peds"] = {},
    ["attach_obj"] = {},
    ["asteroids"] = {},
    ["lag_area"] = {},
    ["custom_veh"] = {},
    ["preview_veh"] = {},
    ["temp_veh"] = {},
    ["shooting"] = {},
    ["chat_veh"] = {},
    ["bodyguards"] = {},
    ["bodyguards_veh"] = {},
    ["robot_weapon_left"] = {},
    ["robot_weapon_right"] = {},
    ["vehicle_builder"] = {}
}
local aW = {
    ["police_outfit"] = {
        ["female"] = {
            ["clothes"] = {{0, 0}, {0, 6}, {0, 14}, {0, 34}, {0, 0}, {0, 25}, {0, 0}, {0, 35}, {0, 0}, {0, 0}, {0, 48}},
            ["props"] = {{0, 45, 0}, {1, 11, 0}, {2, 4294967295, 0}, {6, 4294967295, -1}, {7, 4294967295, -1}}
        },
        ["male"] = {
            ["clothes"] = {{0, 0}, {0, 0}, {0, 0}, {0, 35}, {0, 0}, {0, 25}, {0, 0}, {0, 58}, {0, 0}, {0, 0}, {0, 55}},
            ["props"] = {{0, 46, 0}, {1, 13, 0}, {2, 4294967295, 0}, {6, 4294967295, -1}, {7, 4294967295, -1}}
        }
    },
    ["bac_outfit"] = {["textures"] = {}, ["clothes"] = {}, ["prop_text"] = {}, ["prop_ind"] = {}, ["gender"] = nil},
    ["session_crash"] = {["textures"] = {}, ["clothes"] = {}, ["prop_text"] = {}, ["prop_ind"] = {}}
}
local aX = {}
aX.hashes = {
    ["snacks_and_armor"] = {
        {"NO_BOUGHT_YUM_SNACKS", 30},
        {"NO_BOUGHT_HEALTH_SNACKS", 15},
        {"NO_BOUGHT_EPIC_SNACKS", 5},
        {"NUMBER_OF_ORANGE_BOUGHT", 10},
        {"NUMBER_OF_BOURGE_BOUGHT", 10},
        {"NUMBER_OF_CHAMP_BOUGHT", 5},
        {"CIGARETTES_BOUGHT", 20},
        {"MP_CHAR_ARMOUR_1_COUNT", 10},
        {"MP_CHAR_ARMOUR_2_COUNT", 10},
        {"MP_CHAR_ARMOUR_3_COUNT", 10},
        {"MP_CHAR_ARMOUR_4_COUNT", 10},
        {"MP_CHAR_ARMOUR_5_COUNT", 10}
    },
    ["kills_deaths"] = {"MPPLY_KILLS_PLAYERS", "MPPLY_DEATHS_PLAYER"},
    ["fast_run"] = {
        "CHAR_FM_ABILITY_1_UNLCK",
        "CHAR_FM_ABILITY_2_UNLCK",
        "CHAR_FM_ABILITY_3_UNLCK",
        "CHAR_ABILITY_1_UNLCK",
        "CHAR_ABILITY_2_UNLCK",
        "CHAR_ABILITY_3_UNLCK"
    },
    ["chc"] = {
        ["misc"] = {
            {"Remove Repeat Cooldown (-1)", "H3_COMPLETEDPOSIX", 0, -1},
            {"Last Approach Completed (1 2 3)", "H3_LAST_APPROACH", 0, 0, 3},
            {"Confirm First Board", "H3OPT_BITSET1", 0, -1},
            {"Confirm Second Board", "H3OPT_BITSET0", 0, -1}
        },
        ["board1"] = {
            {"1:Silent, 2:BigCon, 3:Aggressive", "H3OPT_APPROACH", 0, 1, 3, 1},
            {"1:Hard, 2:Difficulty, 3:Approach", "H3_HARD_APPROACH", 0, 1, 3, 1},
            {"0:Money, 1:Gold, 2:Art, 3:Diamond", "H3OPT_TARGET", 0, 0, 3, 3},
            {"Unlock Points of Interests", "H3OPT_POI", 0, 1023},
            {"Unlock Access Points", "H3OPT_ACCESSPOINTS", 0, 2047}
        },
        ["board2"] = {
            {"1:5%, 2:9%, 3:7%, 4:10%, 5:10%", "H3OPT_CREWWEAP", 0, 1, 5, 1},
            {"1:5%, 2:7%, 3:9%, 4:6%, 5:10%", "H3OPT_CREWDRIVER", 0, 1, 5, 1},
            {"1:3%, 2:7%, 3:5%, 4:10%, 5:9%", "H3OPT_CREWHACKER", 0, 1, 5, 1},
            {"Weapon Variation (0 1)", "H3OPT_WEAPS", 0, 0, 1},
            {"Vehicle Variation (0 1 2 3)", "H3OPT_VEHS", 0, 0, 3},
            {"Remove Duggan Heavy Guards", "H3OPT_DISRUPTSHIP", 0, 3},
            {"Equip Heavy Armor", "H3OPT_BODYARMORLVL", 0, 3},
            {"Scan Card Level", "H3OPT_KEYLEVELS", 0, 2},
            {"Mask Variation (0 till 12)", "H3OPT_MASKS", 0, 0, 12}
        }
    }
}
aX.set = function(aE, z, o, aY)
    aY = aY or true
    local aZ = aE
    if z then
        aZ = "MP1_" .. aE
        aE = "MP0_" .. aE
    end
    aE = gameplay.get_hash_key(aE)
    stats.stat_set_int(aE, o, aY)
    if z then
        aZ = gameplay.get_hash_key(aZ)
        stats.stat_set_int(aZ, o, aY)
    end
end
local a_ = {}
a_.scids = {}
a_.names = {}
a_.update_ids = function()
    local b0, b1 = {}, {}
    local b2
    if c.f_exists(b["Blacklist"]) then
        local _ = c.o(b["Blacklist"], "r")
        if _ then
            for b3 in io.lines(b["Blacklist"]) do
                b2 = 1
                for b4 in string.gmatch(b3, "[^%s]+") do
                    if b2 == 1 then
                        table.insert(b0, b4)
                    else
                        if type(b4) == "string" then
                            table.insert(b1, b4)
                        else
                            table.insert(b1, "NoNameFound")
                        end
                    end
                    b2 = b2 + 1
                end
            end
        end
        io.close(_)
        a_.scids = b0
        a_.names = b1
    end
end
a_.remove_scid = function(aj)
    local _ = c.o(b["Blacklist"], "w")
    local b5
    io.output(_)
    for i = 1, #a_.scids do
        if a_.scids[i] ~= aj then
            local j = a_.names[i] or "NoNameFound"
            io.write(a_.scids[i] .. " " .. j .. "\n")
        else
            b5 = i
        end
    end
    io.close(_)
    if b5 then
        local j = a_.names[b5] or "NoNameFound"
        u("Removed SCID: '" .. aj .. "' with Name: '" .. j .. "' from Blacklist.", 48)
        a_.update_ids()
    end
end
local b6 = {"random_primary", "random_secondary", "random_pearlescent", "random_neon", "random_smoke", "random_xenon"}
local b7 = {
    "rainbow_primary",
    "rainbow_secondary",
    "rainbow_pearlescent",
    "rainbow_neon",
    "rainbow_smoke",
    "rainbow_xenon"
}
local b8 = {"synced_rainbow", "synced_random", "synced_rainbow_smooth"}
local b9 = {
    {"Max Online Health: 328", 328},
    {"Health: 100", 100},
    {"Health: 500", 500},
    {"Freemode Beast: 2500", 2500},
    {"Health: 10000", 10000},
    {"Health: 25000", 25000},
    {"Health: 50000", 50000},
    {"Health: 100000", 100000},
    {"Health: 5000000", 5000000}
}
local ba, bb, bc = 0, false, 0
local bd = v3()
local be, bf = nil, false
local bg = {}
local bh = {}
local bi, bj
local bk
local bl
local bm = nil
local bn
local bo = {}
local bp = {}
local bq, br, bs
local bt
local bu
local bv, bw
local bx = {}
local by = {}
local bz = {}
local bA = {}
local bB
local bC
local bD
local bE = {12, 13, 14, 43, 74}
local bF
local bG
local bH = nil
local bI = {
    ["flamethrower"] = nil,
    ["flamethrower_green"] = nil,
    ["alien"] = nil,
    ["fire_circle"] = {},
    ["fire_balls"] = {},
    ["fire_ass"] = nil,
    ["fire_ass_ball"] = nil
}
local function bJ(i, bK)
    a2.ctrl(i)
    entity.set_entity_velocity(i, v3())
    entity.set_entity_coords_no_offset(i, bK)
end
local function bL(bM, time)
    if bM and type(bM) == "table" then
        time = time or 50
        for i = 1, #bM do
            if bM[i] ~= a4.ped() and bM[i] ~= c.vehicle(a4.ped()) then
                a2.ctrl(bM[i], time)
                entity.detach_entity(bM[i])
                entity.set_entity_velocity(bM[i], v3())
                bJ(bM[i], v3(8000, 8000, -1000))
                entity.delete_entity(bM[i])
            end
        end
    end
end
event.add_event_listener(
    "exit",
    function()
        x("")
        x("2Take1Script got unloaded.")
        x("Cleaning up...")
        u("2Take1Script got unloaded.\nUnloading Script.. :(", 200)
        for i in pairs(bp) do
            bL({bp[i]})
        end
        for i in pairs(aV) do
            bL(aV[i])
        end
        bL({bv})
        bL({bt})
        if bI["flamethrower"] then
            graphics.remove_particle_fx(bI["flamethrower"], true)
        end
        if bI["flamethrower_green"] then
            graphics.remove_particle_fx(bI["flamethrower_green"], true)
        end
        if bI["fire_circle"][1] then
            for i = 1, #bI["fire_circle"] do
                graphics.remove_particle_fx(bI["fire_circle"][i], true)
            end
            bL(bI["fire_balls"])
        end
        if bI["fire_ass"] then
            graphics.remove_particle_fx(bI["fire_ass"], true)
        end
        bL({bI["fire_ass_ball"]})
        for i = 1, 32 do
            if bz[i] then
                hook.remove_script_event_hook(bz[i])
            end
        end
        for i = 1, 32 do
            if bA[i] then
                hook.remove_net_event_hook(bA[i])
            end
        end
        x("Going to remove Chat-Listeners...")
        for i in pairs(bh) do
            event.remove_event_listener("chat", bh[i])
        end
        if ae.event then
            event.remove_event_listener("player_join", ae.event)
        end
        x("Done.")
        _2t1s = false
        _2t1sEXT = false
    end
)
local function bN(g, bO, a3)
    x("Teleporting to Target.")
    local bP, aF, ac, bQ = a4.ped()
    if type(g) == "number" then
        bQ = c.vehicle(g)
        if bQ ~= 0 then
            if ped.is_ped_in_any_vehicle(bP) then
                ped.clear_ped_tasks_immediately(bP)
                c.wait(10)
            end
        end
    end
    ac = c.vehicle(bP)
    if ac ~= 0 then
        a2.ctrl(ac)
        entity.set_entity_velocity(ac, v3())
        bP = ac
    end
    if type(g) == "number" then
        aF = c.gcoords(g)
    else
        aF = g
    end
    if bO then
        aF.z = aF.z + bO
    end
    bJ(bP, aF)
    if a3 then
        entity.set_entity_heading(bP, a3)
    end
    if bQ then
        c.wait(1500)
        ped.set_ped_into_vehicle(a4.ped(), bQ, vehicle.get_free_seat(bQ))
    end
    x("Done.")
end
local function bR(a3, water, bS, bT, bU)
    if
        not a5.t["bl_mdl_change"].on or bU or
            a5.t["bl_mdl_change"].on and not ped.is_ped_in_any_vehicle(a4.ped()) and
                (water and entity.is_entity_in_water(a4.ped()) or not water and not entity.is_entity_in_water(a4.ped()))
     then
        if bT then
            bN(a4.coords(), 1.5)
        end
        a2.model(a3)
        player.set_player_model(a3)
        c.unload(a3)
        if bS then
            c.wait(0)
            ped.set_ped_component_variation(a4.ped(), 4, 0, 0, 2)
        end
        if a3 == 0x9C9EFFD8 or a3 == 0x705E61F2 then
            local D = "male"
            if player.is_player_female(c.id()) then
                D = "female"
            end
            if aW["bac_outfit"]["gender"] == D then
                local at = aW["bac_outfit"]["clothes"]
                local au = aW["bac_outfit"]["textures"]
                for Z = 1, 11 do
                    ped.set_ped_component_variation(a4.ped(), Z, at[Z], au[Z], 2)
                end
                local av = {0, 1, 2, 6, 7}
                local aw = aW["bac_outfit"]["prop_ind"]
                local ax = aW["bac_outfit"]["prop_text"]
                for ay = 1, #av do
                    ped.set_ped_prop_index(a4.ped(), av[ay], aw[ay], ax[ay], 0)
                end
            end
        end
    else
        u("Model Change not possible!", 125)
    end
end
local function bV(aC, id)
    local i = 0
    if aC then
        x("Lobby Kick!")
    end
    while i < 32 do
        if aC then
            id = i
        else
            i = 99
        end
        if a9.i(id) then
            u("Attempting to Kick Player: " .. D.name(id), 65)
            x("Attempting to Kick Player.")
            x(D.name(id) .. ":" .. D.scid(id))
            if network.network_is_host() then
                x("Haha, got a hostkick.")
                network.network_session_kick_player(id)
            end
            c.script(0x8197eaf0, id, {id, script.get_global_i(1628955 + 1 + id * 614 + 532)})
            c.script(0x8197eaf0, id, {id, script.get_global_i(1628955 + 1 + id * 614 + 532)})
            c.script(0x8197eaf0, id, {id, script.get_global_i(1628955 + 2 + id * 614 + 532)})
            c.wait(75)
            for i = 1, #B do
                c.script(B[i], id, {})
            end
        end
        i = i + 1
    end
end
local function bW(bX, id, bY)
    for i = 1, #bX do
        local bZ = v3(bX[i][3][1], bX[i][3][2], bX[i][3][3])
        local b_ = v3(bX[i][4][1], bX[i][4][2], bX[i][4][3])
        local c0
        local c1 = false
        if bY then
            c0 = bX[i][1]
        else
            a2.model(bX[i][1])
            if streaming.is_model_an_object(bX[i][1]) then
                c0 = aD.object(bX[i][1], bZ)
            else
                c1 = true
                c0 = aD.ped(bX[i][1], bZ)
                c.wait(0)
                ped.set_ped_can_ragdoll(c0, false)
                c.god(c0, true)
            end
            c.unload(bX[i][1])
        end
        aV["attach_obj"][#aV["attach_obj"] + 1] = c0
        if a5.t["attach_no_colision"].on then
            entity.set_entity_collision(c0, false, false, false)
        end
        if bX[i][5] then
            c.visible(c0, false)
        end
        c.attach(c0, c.ped(id), bX[i][2], bZ, b_, true, true, c1, 0, true)
    end
end
local function c2(id, a3)
    x("Lagging Area @Player.")
    local aF = c.gcoords(c.ped(id))
    a2.model(a3)
    aF.z = aF.z + 5
    for i = 1, 50 do
        aV["lag_area"][#aV["lag_area"] + 1] = aD.vehicle(a3, aF)
    end
    c.unload(a3)
    x("Done.")
end
local function c3(id)
    if a9.i(id) then
        c.navigate(false)
        local c4 = {}
        while a4.coords():magnitude(c.gcoords(c.ped(id))) < 5000 do
            local aF = a4.coords()
            bN(v3(aF.x, aF.y, aF.z + 500))
        end
        x("Sending Crash Entitys...")
        x("Distance: " .. a4.coords():magnitude(c.gcoords(c.ped(id))))
        for i = 1, #aT do
            local a3 = aT[i]
            a2.model(a3)
            local c5 = c.gcoords(c.ped(id)) + v3(0, 0, 2.5)
            c4[i] = aD.ped(a3, c5, 26)
            c.unload(a3)
        end
        x("Waiting.")
        u("Waiting ~ 7.5 seconds...")
        local time = c.time() + 7500
        while time > c.time() do
            x("Distance: " .. a4.coords():magnitude(c.gcoords(c.ped(id))))
            c.wait(125)
            while a4.coords():magnitude(c.gcoords(c.ped(id))) < 5000 do
                local aF = a4.coords()
                bN(v3(aF.x, aF.y, aF.z + 500))
            end
        end
        for i = 1, #c4 do
            if not a2.ctrl(c4[i], 5000) then
                u("Dont go near the player, there is a possibility that the crash peds still exist!")
            end
            bL({c4[i]}, 5000)
        end
        bL(c4[i], 5000)
        c.navigate(true)
    end
end
local function c6(ac)
    local c7 = {11, 12, 13, 16, 18}
    local c8 = {3, 2, 2, 4, 1}
    for i = 1, #c7 do
        if vehicle.get_vehicle_mod(ac, c7[i]) ~= c8[i] then
            a2.ctrl(ac)
            vehicle.set_vehicle_mod(ac, c7[i], c8[i])
        end
    end
    vehicle.set_vehicle_bulletproof_tires(ac, true)
end
local function c9(aF, aH, ca)
    aH = math.rad((aH - 180) * -1)
    aF.x = aF.x + math.sin(aH) * -ca
    aF.y = aF.y + math.cos(aH) * -ca
    return aF
end
local function cb(id)
    id = string.lower(id)
    local j
    for i = 0, 31 do
        if D.scid(i) ~= -1 then
            j = string.lower(D.name(i))
            if j == id then
                return i
            end
        end
    end
    return -1
end
local function cc(cd)
    for i = 1, #cd do
        if a5.t[cd[i]].on then
            a5.t[cd[i]].on = false
        end
    end
end
local function ce(ac, cf, i, b2)
    a2.ctrl(ac)
    c.wait(0)
    vehicle.set_vehicle_tire_smoke_color(ac, cf[1], cf[2], cf[3])
    vehicle.set_vehicle_custom_primary_colour(ac, d.rgbtohex({cf[1], cf[2], cf[3]}))
    vehicle.set_vehicle_custom_secondary_colour(ac, d.rgbtohex({cf[1], cf[2], cf[3]}))
    vehicle.set_vehicle_custom_pearlescent_colour(ac, d.rgbtohex({cf[1], cf[2], cf[3]}))
    vehicle.set_vehicle_neon_lights_color(ac, d.rgbtohex({cf[1], cf[2], cf[3]}))
    if not i then
        i = 0
    end
    if cf[1] > 200 and cf[1] < 256 and cf[2] > 200 and cf[2] < 256 and cf[3] > 220 and cf[3] < 256 then
        i = 0
    end
    if cf[1] >= 0 and cf[1] < 30 and cf[2] >= 0 and cf[2] < 50 and cf[3] > 220 and cf[3] < 256 then
        i = 1
    end
    if cf[1] >= 0 and cf[1] < 30 and cf[2] >= 50 and cf[2] < 110 and cf[3] > 220 and cf[3] < 256 then
        i = 2
    end
    if cf[1] >= 0 and cf[1] < 30 and cf[2] >= 110 and cf[2] < 256 and cf[3] > 100 and cf[3] <= 220 then
        i = 3
    end
    if cf[1] >= 30 and cf[1] < 120 and cf[2] >= 110 and cf[2] < 256 and cf[3] >= 0 and cf[3] <= 100 then
        i = 4
    end
    if cf[1] >= 120 and cf[1] < 256 and cf[2] >= 110 and cf[2] < 256 and cf[3] >= 0 and cf[3] < 100 then
        i = 5
    end
    if cf[1] >= 120 and cf[1] < 256 and cf[2] >= 110 and cf[2] < 200 and cf[3] >= 0 and cf[3] < 100 then
        i = 6
    end
    if cf[1] >= 120 and cf[1] < 256 and cf[2] > 45 and cf[2] < 109 and cf[3] >= 0 and cf[3] < 100 then
        i = 7
    end
    if cf[1] >= 120 and cf[1] < 256 and cf[2] >= 0 and cf[2] <= 45 and cf[3] >= 0 and cf[3] < 100 then
        i = 8
    end
    if cf[1] >= 120 and cf[1] < 256 and cf[2] > 45 and cf[2] < 100 and cf[3] >= 50 and cf[3] < 150 then
        i = 9
    end
    if cf[1] >= 120 and cf[1] < 256 and cf[2] >= 0 and cf[2] <= 45 and cf[3] >= 150 and cf[3] < 256 then
        i = 10
    end
    if cf[1] >= 0 and cf[1] < 120 and cf[2] >= 0 and cf[2] <= 45 and cf[3] >= 150 and cf[3] < 256 then
        i = 11
    end
    if cf[1] >= 0 and cf[1] < 30 and cf[2] >= 0 and cf[2] <= 45 and cf[3] >= 150 and cf[3] < 256 then
        i = 12
    end
    if b2 then
        i = b2
    end
    vehicle.set_vehicle_headlight_color(ac, i)
end
local function cg(id, T, ch)
    x("Detected Chat-Command!")
    x(D.name(id) .. ":" .. D.scid(id))
    x("Is trying to perform " .. ch .. " as a Chat-Command!")
    if a5.t["chat_cmd_friends"] and player.is_player_friend(id) or id == c.id() or a5.t["chat_cmd_all"] then
        local ci
        if T then
            ci = cb(T)
        else
            x("User is entitled to perfrom Command! Executing...")
            u("Performing " .. ch .. " Command for Player: " .. D.name(id) .. " on: " .. D.name(id))
            return true, plid
        end
        if ci ~= -1 then
            if ci == c.id() or player.is_player_friend(ci) and a5.t["exclude_friends"].on and ci ~= c.id() then
                u(D.name(id) .. " tried to perform a Command on you or a friend!")
                x("Blocked from Performing Command!")
                return false
            else
                x("User is entitled to perfrom Command! Executing...")
                u("Performing " .. ch .. " Command for Player: " .. D.name(id) .. " on: " .. D.name(ci))
                return true, ci
            end
        end
    end
    x("Command / format / player not found / entitled. Breaking up on performing it.")
    return false
end
local function cj(bX)
    x("Blocking Area.")
    for i = 1, #bX do
        if bX[i][1] ~= false then
            a2.model(bX[i][1])
            aV["bl_objects"][#aV["bl_objects"] + 1] = aD.object(bX[i][1])
            c.unload(bX[i][1])
            local aF
            if not bX[i][2][1] then
                aF =
                    v3(
                    c.random(bX[i][2][2], bX[i][2][3]),
                    c.random(bX[i][2][4], bX[i][2][5]),
                    c.random(bX[i][2][6], bX[i][2][7])
                )
            else
                aF = v3(bX[i][2][1], bX[i][2][2], bX[i][2][3])
            end
            bJ(aV["bl_objects"][#aV["bl_objects"]], aF)
            entity.set_entity_rotation(aV["bl_objects"][#aV["bl_objects"]], v3(bX[i][3][1], bX[i][3][2], bX[i][3][3]))
            if bX[i][4] then
                entity.freeze_entity(aV["bl_objects"][#aV["bl_objects"]], true)
            end
            if bX[i][5] then
                c.visible(aV["bl_objects"][#aV["bl_objects"]], false)
            end
        else
            if bX[i] then
                if a5.t["teleport_to_block"].on then
                    bN(v3(bX[i][2][1], bX[i][2][2], bX[i][2][3]), nil, bX[i][3])
                end
            end
        end
    end
    x("Blocking Done.")
end
local function ck(aC, cl, cm, cn, co, id)
    x("Sending Script Events to Player.")
    local i = 0
    while i < 32 do
        if aC then
            id = i
        else
            i = 99
        end
        if a9.i(id) then
            if cl ~= 0 and cl then
                c.script(cl, id, cm)
                x("SE 1 : " .. cl)
                x("Sent to Player: " .. D.name(id))
            end
            if cn ~= 0 and cn then
                c.script(cn, id, co)
                x("SE 2 : " .. cn)
                x("Sent to Player: " .. D.name(id))
            end
        end
        i = i + 1
    end
    x("Done.")
end
local function cp()
    if bf then
        bR(be, nil, nil, nil, true)
        c.wait(250)
        ped.set_ped_health(a4.ped(), 0)
        c.wait(3500)
        local cq = aW["session_crash"]["clothes"]
        local cr = aW["session_crash"]["textures"]
        for i = 1, 11 do
            ped.set_ped_component_variation(a4.ped(), i, cq[i], cr[i], 2)
        end
        local av = {0, 1, 2, 6, 7}
        local aw = aW["session_crash"]["prop_ind"]
        local ax = aW["session_crash"]["prop_text"]
        for ay = 1, #av do
            ped.set_ped_prop_index(a4.ped(), av[ay], aw[ay], ax[ay], 0)
        end
    else
        u("First Crash Session.")
    end
end
local function cs()
    local ct = bp["llbone"]
    local cu = bp["rlbone"]
    local cv = bp["tampa"]
    local cw = v3(-4.25, 0, 12.5)
    local cx = v3(4.25, 0, 12.5)
    if ct and cu and cv then
        if entity.is_an_entity(ct) and entity.is_an_entity(cu) and entity.is_an_entity(cv) then
            a2.ctrl(ct)
            a2.ctrl(cu)
            a2.ctrl(cv)
            c.attach(ct, cv, 0, cw, v3(), true, r["robot_collision"], false, 2, true)
            c.attach(cu, cv, 0, cx, v3(), true, r["robot_collision"], false, 2, true)
        end
    end
end
local function cy(bX, a6)
    x("Attempt to spawn Custom Vehicle.")
    c.navigate(false)
    temp_veh = {}
    local aF = v3()
    local cz = v3()
    local cA = 0
    local cB = 0
    local aH = 0
    local cC = false
    local cD = c.vehicle(a4.ped())
    if a5.t["spawn_preview"].on and aV["preview_veh"][1] then
        bL(aV["preview_veh"])
        aV["preview_veh"] = {}
        bb = false
        c.wait(250)
    end
    for i = 1, #bX[1] do
        a2.model(bX[1][i], 7500)
    end
    for i = 2, #bX do
        aF = a4.coords()
        if bX[i][6] and i == 2 then
            aF.z = aF.z + bX[i][6]
        end
        if i > 2 then
            aF.z = aF.z + 25
        end
        if
            a5.t["use_own_veh"].on and i == 2 and entity.get_entity_model_hash(cD) == bX[i][1] or
                bX[2][1] == 0 and i == 2 and a5.t["use_own_veh"].on and cD ~= 0
         then
            x("Detected Own Vehicle, using it.")
            temp_veh[i - 1] = cD
            cC = true
        elseif bX[2][1] == 0 and not a5.t["use_own_veh"].on then
            x("Failed at spawning Custom Vehicle.")
            u("No Vehicle found, get in a valid Vehicle")
            c.navigate(true)
            return
        else
            if streaming.is_model_a_vehicle(bX[i][1]) then
                if i == 2 then
                    aH = a4.heading()
                    if bX[i][11] then
                        bc = bX[i][11]
                    else
                        bc = 5
                    end
                    if bX[i][12] then
                        ba = bX[i][12]
                    else
                        ba = 1
                    end
                    aF = c9(aF, aH, bc)
                end
                temp_veh[i - 1] = aD.vehicle(bX[i][1], aF, aH)
                decorator.decor_set_int(temp_veh[i - 1], "MPBitset", 1 << 10)
                local v = c.random(0, 16777215)
                if bX[i][4] then
                    v = bX[i][4][1]
                end
                vehicle.set_vehicle_custom_primary_colour(temp_veh[i - 1], v)
                if bX[i][4] then
                    v = bX[i][4][2]
                end
                vehicle.set_vehicle_custom_secondary_colour(temp_veh[i - 1], v)
                if bX[i][4] then
                    v = bX[i][4][3]
                end
                vehicle.set_vehicle_custom_pearlescent_colour(temp_veh[i - 1], v)
                if bX[i][4] then
                    v = bX[i][4][4]
                end
                vehicle.set_vehicle_custom_wheel_colour(temp_veh[i - 1], v)
                v = c.random(0, 4)
                if bX[i][4] then
                    v = bX[i][4][5]
                end
                vehicle.set_vehicle_window_tint(temp_veh[i - 1], v)
                if streaming.is_model_a_plane(bX[i][1]) and i > 2 then
                    vehicle.control_landing_gear(temp_veh[i - 1], 3)
                end
            else
                temp_veh[i - 1] = aD.object(bX[i][1], aF)
            end
        end
        if i > 2 then
            aF.z = aF.z - 25
        end
        if a5.t["set_godmode"].on then
            c.god(temp_veh[i - 1], true)
        end
        if bX[i][5] then
            c.visible(temp_veh[i - 1], false)
        end
        if bX[i][13] then
            entity.set_entity_alpha(temp_veh[i - 1], bX[i][13], false)
        end
        if i > 2 then
            cA = 0
            if bX[i][7] then
                cA = bX[i][7]
            end
            cB = temp_veh[1]
            if bX[i][8] then
                cB = temp_veh[bX[i][8]]
            end
            local cE = bX[i][10]
            if cE == true then
                entity.set_entity_collision(temp_veh[i - 1], false, false, false)
            else
                cE = false
            end
            aF = v3()
            if bX[i][2] then
                aF = v3(bX[i][2][1], bX[i][2][2], bX[i][2][3])
            end
            cz = v3()
            if bX[i][3] then
                cz = v3(bX[i][3][1], bX[i][3][2], bX[i][3][3])
            end
            if bX[i][1] ~= 0 then
                c.attach(temp_veh[i - 1], cB, cA, aF, cz, false, not cE, false, 2, true)
            end
            if bX[i][9] then
                local cF
                a2.model(bX[i][9])
                aF = a4.coords()
                cF = aD.ped(bX[i][9], aF)
                c.wait(0)
                if a5.t["set_godmode"].on then
                    ped.set_ped_max_health(cF, 25000000.0)
                    ped.set_ped_health(cF, 25000000.0)
                    ped.set_ped_can_ragdoll(cF, false)
                    c.god(cF, true)
                end
                c.unload(bX[i][9])
                if bX[i][1] ~= 0 then
                    ped.set_ped_into_vehicle(cF, temp_veh[i - 1], -1)
                    vehicle.set_vehicle_doors_locked(temp_veh[i - 1], 2)
                else
                    aF = v3()
                    if bX[i][2] then
                        aF = v3(bX[i][2][1], bX[i][2][2], bX[i][2][3])
                    end
                    cz = v3()
                    if bX[i][3] then
                        cz = v3(bX[i][3][1], bX[i][3][2], bX[i][3][3])
                    end
                    c.attach(cF, cB, cA, aF, cz, false, not cE, true, 2, true)
                end
            end
        end
        if a5.t["spawn_preview"].on then
            aV["preview_veh"][#aV["preview_veh"] + 1] = temp_veh[i - 1]
        elseif a6 then
            aV[a6][#aV[a6] + 1] = temp_veh[i - 1]
        else
            aV["custom_veh"][#aV["custom_veh"] + 1] = temp_veh[i - 1]
        end
    end
    if not a5.t["spawn_preview"].on then
        if a5.t["auto_get_in"].on then
            ped.set_ped_into_vehicle(a4.ped(), temp_veh[1], -1)
        end
    end
    if not cC then
        c6(temp_veh[1])
    end
    for i = 1, #bX[1] do
        c.unload(bX[1][i])
    end
    c.navigate(true)
    x("Spawn Custom Vehicle Done.")
end
local function cG()
    x("Loading Features...")
    if r["2t1s_parent"] then
        a5.p["parent"] = a5.add.p("2Take1Script", 0).id
    end
    a5.p["bl"] = a5.add.p("Blacklist", a5.p["parent"])
    a5.p["bl"].hidden = r["bl_hidden"]
    a5.p["bl"] = a5.p["bl"].id
    a5.t["blacklist_enabled"] =
        a5.add.t(
        "Enable Blacklist",
        a5.p["bl"],
        function(k)
            r["blacklist_enabled"] = k.on
            if k.on then
                c.wait(1000)
                a_.update_ids()
                for i = 0, 31 do
                    if a9.i(i) then
                        for cH = 1, #a_.scids do
                            if tostring(D.scid(i)) == a_.scids[cH] then
                                local j = D.name(i)
                                u("Blocked player detected.", 27)
                                u("Current name: " .. j .. "\nReal name: " .. a_.names[cH], 27)
                                x("")
                                x("Blocked Player detected.")
                                x(j .. ":" .. a_.scids[cH])
                                x("Real name:" .. a_.names[cH])
                                if a5.t["mark_modder"].on then
                                    player.set_player_as_modder(i, t["blacklist"][2])
                                end
                                if a5.t["auto_kick"].on then
                                    bV(false, i)
                                end
                            end
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    a5.t["blacklist_enabled"].on = r["blacklist_enabled"]
    a5.t["auto_kick"] =
        a5.add.t(
        "Enable Auto-Kick",
        a5.p["bl"],
        function(k)
            r["auto_kick"] = k.on
        end
    )
    a5.t["auto_kick"].on = r["auto_kick"]
    a5.t["mark_modder"] =
        a5.add.t(
        "Mark as Modder",
        a5.p["bl"],
        function(k)
            r["mark_modder"] = k.on
        end
    )
    a5.t["mark_modder"].on = r["mark_modder"]
    a5.add.a(
        "Add player by SCID",
        a5.p["bl"],
        function()
            local aj = D.input("Enter SCID", 12, 3)
            local j = D.input("Enter Name")
            if not aj or not j then
                return HANDLER_POP
            end
            if j ~= "" and aj ~= "0" and aj ~= "-1" and aj ~= tostring(D.scid(c.id())) then
                d.write(c.o(b["Blacklist"], "a"), aj .. " " .. j)
                u("SCID with Name added to Blacklist.", 48)
                x("")
                x("Player added to Blacklist.")
                x(j .. ": " .. aj)
            end
        end
    )
    a5.add.a(
        "Remove SCID",
        a5.p["bl"],
        function()
            local aj = D.input("Enter SCID", 12, 3)
            if not aj then
                return HANDLER_POP
            end
            a_.remove_scid(aj)
        end
    )
    a5.add.a(
        "Count Currently Blocked Players",
        a5.p["bl"],
        function()
            a_.update_ids()
            if a_.scids then
                u("Currently blocking " .. #a_.scids .. " Players.", 48)
            end
        end
    )
    a5.t["enable_admin"] =
        a5.add.t(
        "Notify on Rockstar Admin SCID",
        a5.p["bl"],
        function(k)
            if k.on then
                c.wait(1000)
                for i = 0, 31 do
                    if a9.i(i) then
                        for cH = 1, #aU do
                            if tostring(D.scid(i)) == aU[cH] then
                                local j = D.name(i)
                                u("Rockstar Admin by SCID detected!\nName: " .. j, 27)
                                x("Rockstar Admin detected.")
                                x(j .. ":" .. D.scid(i))
                                if a5.t["kick_admin"].on then
                                    bV(false, i)
                                end
                                if a5.t["crash_admin"].on then
                                    c3(i)
                                end
                            end
                        end
                    end
                end
            end
            r["admin_enabled"] = k.on
            return d.stop(k)
        end
    )
    a5.t["enable_admin"].on = r["admin_enabled"]
    a5.t["kick_admin"] =
        a5.add.t(
        "Enable Auto-Kick Rockstar Admin",
        a5.p["bl"],
        function()
            u(
                "Thats the stupidest idea you ever had! Dont enable it, disable it!\nThis will get u banned for like 99%!",
                27
            )
        end
    )
    a5.t["kick_admin"].hidden = not C.enable_admin
    a5.t["crash_admin"] =
        a5.add.t(
        "Enable Auto-Crash Rockstar Admin",
        a5.p["bl"],
        function()
            u(
                "Thats the stupidest idea you ever had! Dont enable it, disable it!\nThis will get u banned for like 99%!",
                27
            )
        end
    )
    a5.t["crash_admin"].hidden = not C.enable_admin
    a5.t["kick_joining"] =
        a5.add.t(
        "Kick new joining Players",
        a5.p["bl"],
        function(k)
            if k.on then
                local time = c.time() + 2500
                while time > c.time() do
                    c.wait(250)
                    r["kick_joining"] = k.on
                end
                if bx[1] == nil then
                    for i = 0, 31 do
                        bx[i + 1] = D.scid(i)
                        by[D.scid(i)] = 0
                    end
                end
                for i = 0, 31 do
                    if a9.i(i) then
                        local P = true
                        for Z = 1, #bx do
                            if bx[Z] == D.scid(i) then
                                P = false
                            end
                        end
                        if P then
                            if by[bx[i + 1]] <= 3 then
                                u(D.name(i) .. " is new here, sending greetings..!", 65)
                                x(D.name(i) .. " is new here, sending greetings..!")
                                bV(false, i)
                                by[bx[i + 1]] = by[bx[i + 1]] + 1
                            else
                                by[bx[i + 1]] = by[bx[i + 1]] + 1
                                if by[bx[i + 1]] >= 17 then
                                    by[bx[i + 1]] = 0
                                end
                            end
                        end
                    end
                end
            end
            if not k.on then
                by = {}
                for i = 0, 31 do
                    bx[i + 1] = nil
                end
            end
            r["kick_joining"] = k.on
            return d.stop(k)
        end
    )
    a5.t["kick_joining"].on = r["kick_joining"]
    a5.p["modder"] = a5.add.p("Modders", a5.p["parent"])
    a5.p["modder"].hidden = r["modder_hidden"]
    a5.p["modder"] = a5.p["modder"].id
    a5.t["remember_modder"] =
        a5.add.t(
        "Remember every Modder",
        a5.p["modder"],
        function(k)
            if k.on then
                if c.f_exists(b["Modders"]) then
                    local _ = c.o(b["Modders"], "r")
                    if _ then
                        local c0 = {}
                        bg = {}
                        for cI in io.lines(b["Modders"]) do
                            while string.find(cI, " ", 1) do
                                cI = cI:gsub("(.*)%s.*$", "%1")
                            end
                            c0[#c0 + 1] = cI
                        end
                        bg = c0
                        io.close(_)
                    end
                end
                for i = 0, 31 do
                    if a9.i(i) then
                        local aj = D.scid(i)
                        local cJ = false
                        if bg[1] then
                            for cK = 1, #bg do
                                if tostring(aj) == bg[cK] then
                                    cJ = true
                                    if not player.is_player_modder(i, -1) then
                                        u("Remembered " .. D.name(i) .. " as a Modder, remarking...", 130)
                                        x("Remembered '" .. D.name(i) .. "' as a Modder, remarking...")
                                        player.set_player_as_modder(i, t["remembered"][2])
                                    end
                                end
                            end
                        end
                        if player.is_player_modder(i, -1) and not cJ then
                            d.write(c.o(b["Modders"], "a"), aj .. " " .. D.name(i))
                            u("Modder " .. D.name(i) .. " added to Remember-List.", 130)
                            x("Modder '" .. D.name(i) .. "' added to Remember-List.")
                        end
                    end
                end
            end
            r["remember_modder"] = k.on
            return d.stop(k)
        end
    )
    a5.t["remember_modder"].on = r["remember_modder"]
    a5.p["karma_modder_scripts"] =
        a5.add.t(
        "Karma Scripts from Modders",
        a5.p["modder"],
        function(k)
            if k.on and bB == nil then
                bB =
                    hook.register_script_event_hook(
                    function(S, T, U, V)
                        if player.is_player_modder(S, -1) then
                            local X = U[1]
                            table.remove(U, 1)
                            c.script(X, S, U)
                            x("Karma'd Script Event from: " .. D.name(S) .. ".")
                        end
                    end
                )
            end
            if not k.on and bB then
                hook.remove_script_event_hook(bB)
                bB = nil
            end
            r["karma_modder_scripts"] = k.on
        end
    )
    a5.p["karma_modder_scripts"].on = r["karma_modder_scripts"]
    a5.p["unmark_friends"] =
        a5.add.t(
        "Unmark Friends",
        a5.p["modder"],
        function(k)
            r["unmark_friends"] = k.on
            if k.on then
                for i = 0, 31 do
                    if c.valid(i) and player.is_player_friend(i) and player.is_player_modder(i, -1) then
                        player.unset_player_as_modder(i, -1)
                    end
                end
                c.wait(250)
            end
            return d.stop(k)
        end
    )
    a5.p["unmark_friends"].on = r["unmark_friends"]
    a5.add.a("Modder-Detection:", a5.p["modder"])
    a5.t["speed_bypass"] =
        a5.add.t(
        "Max-Speed-Bypass",
        a5.p["modder"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    local aj = D.scid(i)
                    if
                        a9.modder(i) and player.get_player_health(i) ~= 0 and
                            interior.get_interior_from_entity(c.ped(i)) == 0
                     then
                        local cL = 45
                        local id = c.ped(i)
                        if
                            ai.is_task_active(id, 403) or ai.is_task_active(id, 408) or ai.is_task_active(id, 335) or
                                ai.is_task_active(id, 2) or
                                ai.is_task_active(id, 422)
                         then
                            cL = 95
                        end
                        if ai.is_task_active(id, 97) or ai.is_task_active(id, 38) or ai.is_task_active(id, 160) then
                            cL = 60
                        end
                        if ai.is_task_active(id, 50) or ai.is_task_active(id, 1) then
                            cL = 100
                        end
                        local ac = c.vehicle(id)
                        if ac ~= 0 then
                            if id == vehicle.get_ped_in_vehicle_seat(ac, -1) then
                                id = ac
                                local aE = entity.get_entity_model_hash(ac)
                                if streaming.is_model_a_plane(aE) then
                                    cL = 170
                                else
                                    cL = 100
                                end
                            end
                        end
                        local cM = entity.get_entity_speed(id)
                        cM = math.floor(cM)
                        if cM > cL then
                            u(
                                D.name(i) ..
                                    " bypassed Max-Speed-Limit of: " ..
                                        cL .. " with a speed of: " .. cM .. "\nMarking him as a Modder...",
                                130
                            )
                            x(D.name(i) .. " bypassed Max-Speed-Limit of: " .. cL .. " with a speed of: " .. cM)
                            x("Marking him as a Modder...")
                            for cK = 0, 600 do
                                if ai.is_task_active(c.ped(i), cK) then
                                    x("Current active Task: " .. cK)
                                end
                            end
                            player.set_player_as_modder(i, t["maxspeed"][2])
                        end
                    end
                end
            end
            r["speed_bypass"] = k.on
            return d.stop(k)
        end
    )
    a5.t["speed_bypass"].on = r["speed_bypass"]
    a5.t["name_bypass"] =
        a5.add.t(
        "Illegal Name",
        a5.p["modder"],
        function(k)
            c.wait(500)
            if k.on then
                for i = 0, 31 do
                    local aj = D.scid(i)
                    if a9.modder(i) then
                        local j = D.name(i)
                        if string.len(j) < 6 or string.len(j) > 16 or not string.find(j, "^[%.%-%w_]+$") then
                            u(j .. " has an illegal name!\nMarking him as a Modder...", 130)
                            x(j .. " has an illegal name!")
                            x("Marking him as a Modder...")
                            player.set_player_as_modder(i, t["illegalname"][2])
                        end
                    end
                end
            end
            r["name_bypass"] = k.on
            return d.stop(k)
        end
    )
    a5.t["name_bypass"].on = r["name_bypass"]
    a5.t["modded_scid"] =
        a5.add.t(
        "Modded SCID",
        a5.p["modder"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    system.wait(25)
                    if a9.modder(i) then
                        local aj = D.scid(i)
                        if aj < 10000 or aj > 222222222 then
                            local j = D.name(i)
                            u(j .. " has an modded SCID!\nMarking him as a Modder...", 130)
                            x(j .. " has an modded SCID!")
                            x("Marking him as a Modder...")
                            player.set_player_as_modder(i, t["moddedscid"][2])
                        end
                    end
                end
            end
            r["modded_scid"] = k.on
            return d.stop(k)
        end
    )
    a5.t["modded_scid"].on = r["modded_scid"]
    a5.t["modded_net_events"] =
        a5.add.t(
        "Modded Net-Events",
        a5.p["modder"],
        function()
            if bD == nil then
                bD =
                    hook.register_net_event_hook(
                    function(S, T, cN)
                        if a9.modder(S) and T == c.id() then
                            local cO = false
                            for i = 1, #bE do
                                if cN == bE[i] then
                                    cO = true
                                end
                            end
                            if cN == 9 and not player.is_player_host(S) then
                                cO = true
                            end
                            if cN == 10 and bF == nil then
                                bF = S
                                bG = c.time()
                                cO = true
                            end
                            if bG then
                                if bG + 30000 < c.time() then
                                    bG = nil
                                    bF = nil
                                end
                            end
                            if cO then
                                u(D.name(S) .. " sent a Bad Net-Event: " .. cN, 130)
                                u("Marking him as a Modder!", 130)
                                x(D.name(S) .. " sent a Bad Net-Event: " .. cN)
                                player.set_player_as_modder(S, t["moddednetevent"][2])
                                return true
                            end
                        end
                    end
                )
            else
                hook.remove_net_event_hook(bD)
                bD = nil
            end
            r["modded_net_events"] = a5.t["modded_net_events"].on
        end
    )
    a5.t["modded_net_events"].on = r["modded_net_events"]
    a5.t["modder_force_sh"] =
        a5.add.t(
        "Forcing Script-Host",
        a5.p["modder"],
        function(k)
            r["modder_force_sh"] = k.on
            if k.on then
                if bk == nil then
                    bk = script.get_host_of_this_script()
                end
                local time = c.time() + 17500
                while time > c.time() do
                    c.wait(250)
                    r["modder_force_sh"] = k.on
                end
                local cP = script.get_host_of_this_script()
                if not c.valid(bk) or D.scid(bk) == -1 then
                    bk = nil
                end
                if bk then
                    if bk ~= cP then
                        if c.valid(bk) and c.valid(cP) then
                            if D.scid(bk) ~= -1 and D.scid(cP) ~= -1 then
                                x("Script-Host changed without previous SH leaving!")
                                x("SH changed from '" .. D.name(bk) .. "' to '" .. D.name(cP) .. "'.")
                                u("Script-Host changed from '" .. D.name(bk) .. "' to '" .. D.name(cP) .. "'.", 130)
                                player.set_player_as_modder(cP, t["force_sh"][2])
                                bk = cP
                            end
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    a5.t["modder_force_sh"].on = r["modder_force_sh"]
    a5.t["modded_script_event"] =
        a5.add.t(
        "Modded Script Event",
        a5.p["modder"],
        function(k)
            r["modded_script_event"] = k.on
            if bC == nil then
                bC =
                    hook.register_script_event_hook(
                    function(S, T, U, V)
                        local cO = false
                        if #U > 1 then
                            if S ~= U[2] then
                                cO = true
                            end
                        else
                            cO = true
                        end
                        if cO then
                            u("Detected '" .. D.name(S) .. "' sending a modded Script Event!", 130)
                            x("Detected '" .. D.name(S) .. "' sending a modded Script Event!")
                            local cQ = U[1] .. ", {"
                            for i = 2, #U do
                                cQ = cQ .. U[i]
                                if i ~= #U then
                                    cQ = cQ .. ", "
                                end
                            end
                            cQ = cQ .. "}"
                            x(cQ)
                            player.set_player_as_modder(S, t["script"][2])
                        end
                    end
                )
            else
                hook.remove_script_event_hook(bC)
                bC = nil
            end
        end
    )
    a5.t["modded_script_event"].on = r["modded_script_event"]
    a5.p["lobby"] = a5.add.p("Lobby", a5.p["parent"])
    a5.p["lobby"].hidden = r["lobby_hidden"]
    a5.p["lobby"] = a5.p["lobby"].id
    a5.p["bl_veh"] = a5.add.p("Block Vehicles in Session", a5.p["lobby"]).id
    a5.t["veh_blacklist"] =
        a5.add.t(
        "Activate Block Vehicles",
        a5.p["bl_veh"],
        function(k)
            r["veh_blacklist"] = k.on
            if k.on then
                local time = c.time() + 2000
                while time > c.time() do
                    c.wait(200)
                    r["veh_blacklist"] = k.on
                end
                for i = 0, 31 do
                    if a9.i(i) then
                        local ac = c.vehicle(c.ped(i))
                        if ac ~= 0 then
                            ac = entity.get_entity_model_hash(ac)
                            for b2 = 1, #aQ do
                                if a5.t[aQ[b2][1]].on and ac == aQ[b2][2] then
                                    x("Detected Blacklisted Vehicle " .. aQ[b2][1] .. " in Session!")
                                    ac = c.vehicle(c.ped(i))
                                    a2.ctrl(ac, 100)
                                    if entity.get_entity_god_mode(ac) then
                                        a2.ctrl(ac)
                                        c.god(ac, false)
                                    end
                                    if not entity.get_entity_god_mode(ac) then
                                        x("Exploding User: " .. D.name(i))
                                        u(
                                            "Detected Blacklisted Vehicle " ..
                                                aQ[b2][1] .. " from user: " .. D.name(i) .. ", exploding it!",
                                            28
                                        )
                                        entity.set_entity_velocity(ac, v3())
                                        vehicle.set_vehicle_forward_speed(ac, 0)
                                        vehicle.set_vehicle_out_of_control(ac, false, true)
                                        c.explode(c.gcoords(c.ped(i)), 59, false, true, 1, c.ped(i))
                                    end
                                end
                            end
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    a5.t["veh_blacklist"].on = r["veh_blacklist"]
    for i = 1, #aQ do
        a5.t[aQ[i][1]] =
            a5.add.t(
            "Block: " .. aQ[i][1],
            a5.p["bl_veh"],
            function(k)
                r[aQ[i][1]] = k.on
            end
        )
        a5.t[aQ[i][1]].on = r[aQ[i][1]]
    end
    a5.p["bl_area"] = a5.add.p("Block Areas", a5.p["lobby"]).id
    a5.t["teleport_to_block"] =
        a5.add.t(
        "Teleport to Block",
        a5.p["bl_area"],
        function(k)
            r["teleport_to_block"] = k.on
        end
    )
    a5.t["teleport_to_block"].on = r["teleport_to_block"]
    a5.add.a(
        "Clear blocking Objects",
        a5.p["bl_area"],
        function()
            bL(aV["bl_objects"])
            aV["bl_objects"] = {}
        end
    )
    a5.p["bl_area_lsc"] = a5.add.p("Block LSCs", a5.p["bl_area"]).id
    for i = 1, #aS["lscs"] do
        a5.add.a(
            aS["lscs"][i][1],
            a5.p["bl_area_lsc"],
            function()
                cj(aS["lscs"][i][2])
            end
        )
    end
    a5.p["bl_area_casino"] = a5.add.p("Block Casino", a5.p["bl_area"]).id
    for i = 1, #aS["casino"] do
        a5.add.a(
            aS["casino"][i][1],
            a5.p["bl_area_casino"],
            function()
                cj(aS["casino"][i][2])
            end
        )
    end
    a5.p["bl_area_mazebank"] = a5.add.p("Block Maze Bank", a5.p["bl_area"]).id
    for i = 1, #aS["mazebank"] do
        a5.add.a(
            aS["mazebank"][i][1],
            a5.p["bl_area_mazebank"],
            function()
                cj(aS["mazebank"][i][2])
            end
        )
    end
    a5.p["bl_area_custom"] = a5.add.p("Custom Areas", a5.p["bl_area"]).id
    for i = 1, #aS["custom"] do
        a5.add.a(
            aS["custom"][i][1],
            a5.p["bl_area_custom"],
            function()
                cj(aS["custom"][i][2])
            end
        )
    end
    a5.p["explode"] = a5.add.p("Explosion-Features", a5.p["lobby"]).id
    a5.t["laser_beam_explode_waypoint"] =
        a5.add.a(
        "Laser Beam Explode Waypoint",
        a5.p["explode"],
        function()
            local cR = ui.get_waypoint_coord()
            if cR.x ~= 16000 then
                local cS = c.gcoords(a4.ped()).z + 175
                for i = cS, -50, -2 do
                    local aF = v3(cR.x, cR.y, i)
                    aF.x = math.floor(aF.x)
                    aF.y = math.floor(aF.y)
                    c.explode(aF, 59, true, false, 0, 0)
                    for b2 = 1, 2 do
                        aF.x = c.random(aF.x - 3, aF.x + 3)
                        aF.y = c.random(aF.y - 3, aF.y + 3)
                        c.explode(aF, 59, true, false, 0, 0)
                    end
                    aF.x = c.random(aF.x - 6, aF.x + 6)
                    aF.y = c.random(aF.y - 6, aF.y + 6)
                    c.explode(aF, 8, true, false, 0, 0)
                    c.wait(0)
                end
            else
                u("No Waypoint found, set a waypoint first!")
            end
        end
    )
    a5.t["explode_lobby"] =
        a5.add.u(
        "Random Explosions",
        "value_i",
        a5.p["explode"],
        function(k)
            if k.on then
                for i = 1, 5 do
                    c.explode(
                        v3(c.random(-2700, 2700), c.random(-3300, 7500), c.random(30, 90)),
                        k.value_i,
                        true,
                        false,
                        0,
                        0
                    )
                end
            end
            r["explode_lobby_value"] = k.value_i
            r["explode_lobby"] = k.on
            return d.stop(k)
        end
    )
    a5.t["explode_lobby"].max_i = 74
    a5.t["explode_lobby"].min_i = 0
    a5.t["explode_lobby"].value_i = r["explode_lobby_value"]
    a5.t["explode_lobby"].on = r["explode_lobby"]
    a5.t["explode_lobby_shake"] =
        a5.add.t(
        "Shake Cam",
        a5.p["explode"],
        function(k)
            if k.on then
                local aF = v3()
                for i = 1, 10 do
                    aF.x = c.random(-2700, 2700)
                    aF.y = c.random(-3300, 7500)
                    aF.z = c.random(30, 90)
                    c.explode(aF, 8, false, true, 20, 0)
                end
            end
            r["explode_lobby_shake"] = k.on
            return d.stop(k)
        end
    )
    a5.t["explode_lobby_shake"].on = r["explode_lobby_shake"]
    a5.p["sound"] = a5.add.p("Sound-Features", a5.p["lobby"]).id
    a5.t["sound_rape"] =
        a5.add.t(
        "Sound Rape",
        a5.p["sound"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    if a9.i(i) then
                        audio.play_sound_from_entity(2, "Wasted", c.ped(i), "DLC_IE_VV_General_Sounds")
                    end
                end
            end
            r["sound_rape"] = k.on
            return d.stop(k)
        end
    )
    a5.t["sound_rape"].on = r["sound_rape"]
    a5.add.a(
        "Garage-Door Sound - Infinite Time",
        a5.p["sound"],
        function()
            for i = 0, 31 do
                if a9.i(i) then
                    audio.play_sound_from_entity(2, "Garage_Door", c.ped(i), "DLC_HEISTS_GENERIC_SOUNDS")
                end
            end
        end
    )
    a5.t["kill_all_peds"] =
        a5.add.t(
        "Kill all PEDs",
        a5.p["lobby"],
        function(k)
            if k.on then
                local cT = ped.get_all_peds()
                for i = 1, #cT do
                    if not ped.is_ped_a_player(cT[i]) then
                        ped.set_ped_health(cT[i], 0)
                    end
                end
            end
            r["kill_all_peds"] = k.on
            return d.stop(k)
        end
    )
    a5.t["kill_all_peds"].on = r["kill_all_peds"]
    a5.p["lobby_vehicle"] = a5.add.p("Vehicles", a5.p["lobby"]).id
    a5.t["disablecontrol"] =
        a5.add.t(
        "Disable Control from near Vehicles",
        a5.p["lobby_vehicle"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    if a9.i(i) then
                        local ac = c.vehicle(c.ped(i))
                        if ac ~= 0 then
                            a2.ctrl(ac)
                            vehicle.set_vehicle_forward_speed(ac, 25)
                            vehicle.set_vehicle_out_of_control(ac, false, true)
                        end
                    end
                end
            end
            r["disablecontrol"] = k.on
            return d.stop(k)
        end
    )
    a5.t["disablecontrol"].on = r["disablecontrol"]
    a5.t["modify_veh_speed"] =
        a5.add.u(
        "Modify Vehicle Speeds",
        "autoaction_value_i",
        a5.p["lobby_vehicle"],
        function(k)
            r["modify_veh_speed"] = k.value_i
            local cL = 540
            if r["modify_veh_speed_override"] then
                cL = k.value_i
            end
            for i = 0, 31 do
                if a9.i(i, r["modify_veh_speed_include"]) then
                    local ac = c.vehicle(c.ped(i))
                    if ac ~= 0 then
                        a2.ctrl(ac)
                        entity.set_entity_max_speed(ac, cL)
                        vehicle.modify_vehicle_top_speed(ac, k.value_i)
                    end
                end
            end
        end
    )
    a5.t["modify_veh_speed"].min_i = -500
    a5.t["modify_veh_speed"].max_i = 1000
    a5.t["modify_veh_speed"].mod_i = 25
    a5.t["modify_veh_speed"].value_i = r["modify_veh_speed"]
    a5.add.a(
        "Reset Modifies",
        a5.p["lobby_vehicle"],
        function()
            local cL = 540
            for i = 0, 31 do
                if c.valid(i) then
                    local ac = c.vehicle(c.ped(i))
                    if ac ~= 0 then
                        a2.ctrl(ac)
                        entity.set_entity_max_speed(ac, cL)
                        vehicle.modify_vehicle_top_speed(ac, 0)
                    end
                end
            end
        end
    )
    a5.t["modify_veh_speed_include"] =
        a5.add.t(
        "Include Self & Friends",
        a5.p["lobby_vehicle"],
        function(k)
            r["modify_veh_speed_include"] = k.on
        end
    )
    a5.t["modify_veh_speed_include"].on = r["modify_veh_speed_include"]
    a5.t["modify_veh_speed_overwrite"] =
        a5.add.t(
        "Overwrite default Speedlimit",
        a5.p["lobby_vehicle"],
        function(k)
            r["modify_veh_speed_overwrite"] = k.on
        end
    )
    a5.t["modify_veh_speed_overwrite"].on = r["modify_veh_speed_overwrite"]
    a5.p["lobby_bounty"] = a5.add.p("Bounty", a5.p["lobby"]).id
    a5.t["bounty_after_death"] =
        a5.add.u(
        "Set Bounty after Death",
        "value_i",
        a5.p["lobby_bounty"],
        function(k)
            r["bounty_after_death"] = k.on
            r["bounty_after_death_value"] = k.value_i
            if k.on then
                local cU = 0
                if a5.t["anonymous_bounty"].on then
                    cU = 1
                end
                for i = 0, 31 do
                    if a9.i(i) then
                        if player.get_player_health(i) == 0 then
                            u(D.name(i) .. " is dead!\nSetting bounty...", 33)
                            x(D.name(i) .. " is dead!")
                            x("Setting bounty...")
                            for cK = 0, 31 do
                                if D.scid(cK) ~= -1 then
                                    c.script(
                                        544453591,
                                        cK,
                                        {
                                            69,
                                            i,
                                            1,
                                            a5.t["bounty_after_death"].value_i,
                                            0,
                                            cU,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            script.get_global_i(1650640 + 9),
                                            script.get_global_i(1650640 + 10)
                                        }
                                    )
                                end
                            end
                            c.wait(1500)
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    a5.t["bounty_after_death"].min_i = 0
    a5.t["bounty_after_death"].max_i = 10000
    a5.t["bounty_after_death"].value_i = r["bounty_after_death_value"]
    a5.t["bounty_after_death"].on = r["bounty_after_death"]
    a5.t["anonymous_bounty"] =
        a5.add.t(
        "Anonymous Bounty",
        a5.p["lobby_bounty"],
        function(k)
            r["anonymous_bounty"] = k.on
        end
    )
    a5.t["anonymous_bounty"].on = r["anonymous_bounty"]
    for i = 1, #C.bounty_amount do
        a5.add.a(
            C.bounty_amount[i] .. "$",
            a5.p["lobby_bounty"],
            function()
                local cU = 0
                if a5.t["anonymous_bounty"].on then
                    cU = 1
                end
                for cK = 0, 31 do
                    if D.scid(cK) ~= -1 then
                        for cV = 0, 31 do
                            if D.scid(cV) ~= -1 then
                                c.script(
                                    544453591,
                                    cV,
                                    {
                                        69,
                                        cK,
                                        1,
                                        C.bounty_amount[i],
                                        0,
                                        cU,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        script.get_global_i(1650640 + 9),
                                        script.get_global_i(1650640 + 10)
                                    }
                                )
                            end
                        end
                    end
                end
            end
        )
    end
    a5.p["lobby_se"] = a5.add.p("Script Events", a5.p["lobby"]).id
    a5.p["lobby_se_custom"] = a5.add.p("Custom Script Events", a5.p["lobby_se"]).id
    a5.add.a(
        "Enter Custom Script Event with Parameters",
        a5.p["lobby_se_custom"],
        function()
            local cW = {}
            local cX
            local cY = D.input("Enter Custom SE (DEC)", 32, 3)
            if not cY then
                u("Aborted sending Custom Event...", 100)
                return HANDLER_POP
            end
            while cX ~= "#" do
                cX = D.input("Enter Parameter (DEC), to EXIT and send, enter #", 32, 0)
                if not cX then
                    u("Aborted sending Custom Event...", 100)
                    return HANDLER_POP
                end
                if cX == "#" then
                    break
                end
                cX = c.no(cX)
                if type(cX) == "number" then
                    cW[#cW + 1] = cX
                else
                    u("Aborted sending Custom Event...", 100)
                    return HANDLER_POP
                end
            end
            for i = 0, 31 do
                if a9.i(i) then
                    c.script(cY, i, cW)
                end
            end
            u("Sent Custom Script Event with Parameters to Players.", 100)
        end
    )
    for i = 1, #C.custom_se do
        a5.add.a(
            C.custom_se[i][1],
            a5.p["lobby_se_custom"],
            function()
                u("Sent Custom Script Event to Players.", 100)
                for Z = 0, 31 do
                    if a9.i(Z) then
                        for b2 = 1, #C.custom_se[i][2] do
                            c.script(C.custom_se[i][2][b2][1], Z, C.custom_se[i][2][b2][2])
                        end
                    end
                end
            end
        )
    end
    a5.p["lobby_send_2_mission"] = a5.add.p("Send all to Mission", a5.p["lobby_se"]).id
    for i = 1, #aM do
        a5.add.a(
            "Send to " .. aM[i][1],
            a5.p["lobby_send_2_mission"],
            function()
                ck(true, 0x692CC4BB, aM[i][2])
                u("Sent Session to Mission")
            end
        )
    end
    a5.p["lobby_ceo"] = a5.add.p("CEO all Player", a5.p["lobby_se"]).id
    for i = 1, 3 do
        a5.add.a(
            aN[i][1],
            a5.p["lobby_ceo"],
            function()
                ck(true, aN[i][2], aN[i][3], aN[i][4], aN[i][5])
                u("Modified Players CEO")
            end
        )
    end
    a5.add.a(
        "Block - Passive",
        a5.p["lobby_se"],
        function()
            ck(true, 0x54BAD868, {1, 1})
            u("Blocked all Players from activating Passive.")
        end
    )
    a5.add.a(
        "UN-Block - Passive",
        a5.p["lobby_se"],
        function()
            ck(true, 0x54BAD868, {2, 0})
            u("UN-Blocked all Players from Passive.")
        end
    )
    a5.p["lobby_sms"] =
        a5.add.p(
        "Send SMSs to Lobby",
        a5.p["lobby"],
        function()
            u("Players must have Voice-Chat enabled to recive SMS.")
            if a5.t["sms_spam"] then
                a5.t["sms_spam"].value_i = r["sms_spam_value"]
                a5.t["sms_spam"].on = r["sms_spam"]
            end
        end
    ).id
    a5.t["sms_spam"] =
        a5.add.u(
        "Spam SMS X times",
        "value_i",
        a5.p["lobby_sms"],
        function(k)
            r["sms_spam_value"] = k.value_i
            r["sms_spam"] = k.on
        end
    )
    a5.t["sms_spam"].min_i = 25
    a5.t["sms_spam"].max_i = 5000
    a5.t["sms_spam"].mod_i = 25
    a5.t["sms_spam"].value_i = r["sms_spam_value"]
    a5.t["sms_spam"].on = r["sms_spam"]
    a5.add.a(
        "Custom SMS input",
        a5.p["lobby_sms"],
        function()
            local cZ = D.input("Enter Custom SMS", 128, 0)
            if not cZ then
                return HANDLER_POP
            end
            for i = 0, 31 do
                if a9.i(i) then
                    local o = 1
                    if a5.t["sms_spam"].on then
                        o = a5.t["sms_spam"].value_i
                    end
                    for Z = 1, o do
                        player.send_player_sms(i, cZ)
                        c.wait(10)
                    end
                    if o > 1 then
                        u("Spamming SMS done.")
                    end
                end
            end
        end
    )
    a5.add.a(
        "Send SCID & IP",
        a5.p["lobby_sms"],
        function()
            for i = 0, 31 do
                if a9.i(i) then
                    local aj = tostring(D.scid(i))
                    local c_ = D.ip(i)
                    local o = 1
                    if a5.t["sms_spam"].on then
                        o = a5.t["sms_spam"].value_i
                    end
                    for ay = 1, o do
                        player.send_player_sms(i, "R*SCID: " .. aj .. "~n~IP: " .. c_)
                    end
                    if o > 1 then
                        u("Spamming SMS done.")
                    end
                end
            end
        end
    )
    for i = 1, #C.sms_texts do
        a5.add.a(
            C.sms_texts[i],
            a5.p["lobby_sms"],
            function()
                for Z = 0, 31 do
                    if a9.i(Z) then
                        local o = 1
                        if a5.t["sms_spam"].on then
                            o = a5.t["sms_spam"].value_i
                        end
                        for ay = 1, o do
                            player.send_player_sms(Z, C.sms_texts[i])
                            c.wait(20)
                        end
                        if o > 1 then
                            u("Spamming SMS done.")
                        end
                    end
                end
            end
        )
    end
    a5.p["lobby_malicious"] = a5.add.p("Malicious", a5.p["lobby"]).id
    a5.t["karma_se"] =
        a5.add.t(
        "Karma every Script Event",
        a5.p["lobby_malicious"],
        function(k)
            if bH == nil then
                bH =
                    hook.register_script_event_hook(
                    function(S, T, U, V)
                        local X = U[1]
                        table.remove(U, 1)
                        c.script(X, S, U)
                    end
                )
            else
                hook.remove_script_event_hook(bH)
            end
            r["karma_se"] = k.on
        end
    )
    a5.t["karma_se"].on = r["karma_se"]
    a5.t["punish_aliens"] =
        a5.add.t(
        "Punish Aliens in Lobby",
        a5.p["lobby_malicious"],
        function(k)
            r["punish_aliens"] = k.on
            if k.on then
                local time = c.time() + 15000
                while time > c.time() do
                    r["punish_aliens"] = k.on
                    c.wait(150)
                end
                for i = 0, 31 do
                    if a9.i(i) then
                        local cO = 0
                        if player.is_player_female(i) then
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 1) == 134 and
                                    (ped.get_ped_texture_variation(c.ped(i), 1) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 1) == 9)
                             then
                                cO = cO + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 4) == 113 and
                                    (ped.get_ped_texture_variation(c.ped(i), 4) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 4) == 9)
                             then
                                cO = cO + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 6) == 87 and
                                    (ped.get_ped_texture_variation(c.ped(i), 6) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 6) == 9)
                             then
                                cO = cO + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 11) == 287 and
                                    (ped.get_ped_texture_variation(c.ped(i), 11) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 11) == 9)
                             then
                                cO = cO + 1
                            end
                        else
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 1) == 134 and
                                    (ped.get_ped_texture_variation(c.ped(i), 1) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 1) == 9)
                             then
                                cO = cO + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 4) == 106 and
                                    (ped.get_ped_texture_variation(c.ped(i), 4) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 4) == 9)
                             then
                                cO = cO + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 6) == 83 and
                                    (ped.get_ped_texture_variation(c.ped(i), 6) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 6) == 9)
                             then
                                cO = cO + 1
                            end
                            if
                                ped.get_ped_drawable_variation(c.ped(i), 11) == 274 and
                                    (ped.get_ped_texture_variation(c.ped(i), 11) == 8 or
                                        ped.get_ped_texture_variation(c.ped(i), 11) == 9)
                             then
                                cO = cO + 1
                            end
                        end
                        if cO > 1 then
                            x(D.name(i) .. " is a useless alien!")
                            x("Guilty Level: " .. cO)
                            u(D.name(i) .. " is a useless alien! Punishing him!", 23)
                            player.send_player_sms(i, "Delete your stupid alien Outfit!")
                            bW(C.custom_attachments[5][2], i)
                            bW(C.custom_attachments[8][2], i)
                            c.explode(c.gcoords(c.ped(i)), 59, false, true, 1, c.ped(i))
                            c.explode(c.gcoords(c.ped(i)), 8, true, false, 1, c.ped(i))
                            c.explode(c.gcoords(c.ped(i)), 60, true, false, 1, c.ped(i))
                            c.explode(c.gcoords(c.ped(i)), 8, true, false, 1, c.ped(i))
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    a5.t["punish_aliens"].on = r["punish_aliens"]
    a5.add.a(
        "Kick all Players",
        a5.p["lobby_malicious"],
        function()
            bV(true)
        end
    )
    a5.add.a(
        "Host Kick All",
        a5.p["lobby_malicious"],
        function()
            if network.network_is_host() then
                for i = 0, 31 do
                    if a9.i(i) then
                        network.network_session_kick_player(i)
                    end
                end
            else
                u("You are not Session-Host!")
            end
        end
    )
    a5.t["force_host"] =
        a5.add.t(
        "Kick Hosts until You become Host",
        a5.p["lobby_malicious"],
        function(k)
            if k.on then
                local time = c.time() + 7500
                while time > c.time() do
                    c.wait(250)
                    r["force_host"] = k.on
                end
                local ak = player.get_host()
                if ak ~= c.id() and D.scid(ak) ~= -1 then
                    x("You are not Host!")
                    x(D.name(ak) .. ":" .. D.scid(ak) .. " is Host!")
                    u(D.name(ak) .. " is Host!")
                    bV(false, ak)
                end
            end
            r["force_host"] = k.on
            return d.stop(k)
        end
    )
    a5.t["force_host"].on = r["force_host"]
    a5.add.a(
        "Crash Session",
        a5.p["lobby_malicious"],
        function()
            x("Crashing Session...")
            c.navigate(false)
            be = entity.get_entity_model_hash(a4.ped())
            for i = 1, 11 do
                aW["session_crash"]["textures"][i] = ped.get_ped_texture_variation(a4.ped(), i)
                aW["session_crash"]["clothes"][i] = ped.get_ped_drawable_variation(a4.ped(), i)
            end
            local av = {0, 1, 2, 6, 7}
            for ay = 1, #av do
                aW["session_crash"]["prop_ind"][ay] = ped.get_ped_prop_index(a4.ped(), av[ay])
                aW["session_crash"]["prop_text"][ay] = ped.get_ped_prop_texture_index(a4.ped(), av[ay])
            end
            bR(0x471BE4B2, nil, nil, nil, true)
            bf = true
            c.wait(5000)
            cp()
            c.navigate(true)
            x("Done.")
        end
    )
    a5.add.a("Fix loading screen after Crash", a5.p["lobby_malicious"], cp)
    if r["2t1s_parent"] then
        a5.p["opl_parent"] = a5.add.pp("2Take1Script", 0).id
    end
    a5.add.pt(
        "Unmark Modder",
        a5.p["opl_parent"],
        function(k, id)
            if k.on then
                if player.is_player_modder(id, -1) then
                    player.unset_player_as_modder(id, -1)
                end
            end
            return d.stop(k)
        end
    )
    a5.add.pt(
        "Remote Control Vehicle",
        a5.p["opl_parent"],
        function(k, d0)
            local d1 = menu.get_player_feature(k.id)
            if k.on then
                if bm ~= d0 then
                    bm = d0
                    for i = 1, #d1.feats do
                        if i - 1 ~= d0 and d1.feats[i].on then
                            d1.feats[i].on = false
                        end
                    end
                end
                local ac = c.vehicle(c.ped(d0))
                if ac ~= 0 then
                    if bl == nil then
                        local aE = entity.get_entity_model_hash(ac)
                        bl = aD.vehicle(aE, a4.coords())
                        ped.set_ped_into_vehicle(a4.ped(), bl, -1)
                        c.wait(50)
                    end
                    c.visible(bl, false)
                    if entity.get_entity_attached_to(ac) ~= bl then
                        a2.ctrl(bl)
                        entity.set_entity_velocity(bl, v3())
                        bJ(bl, c.gcoords(ac))
                        c.wait(0)
                        entity.set_entity_rotation(bl, entity.get_entity_rotation(ac))
                        a2.ctrl(ac)
                        entity.set_entity_velocity(ac, v3())
                        entity.set_entity_max_speed(ac, 0)
                        vehicle.set_vehicle_out_of_control(ac, false, false)
                        c.attach(ac, bl, 0, v3(), v3(), true, false, false, 0, true)
                    end
                    return HANDLER_CONTINUE
                else
                    for i = 1, #d1.feats do
                        if d1.feats[i].on then
                            d1.feats[i].on = false
                        end
                    end
                    u("Target is not in a Vehicle!")
                    return HANDLER_POP
                end
            end
            if bl then
                ped.clear_ped_tasks_immediately(a4.ped())
                bL({bl})
                bl = nil
            end
            return HANDLER_POP
        end
    )
    a5.add.pa(
        "Repair Vehicle",
        a5.p["opl_parent"],
        function(k, d0)
            local ac = c.vehicle(c.ped(d0))
            if ac ~= 0 then
                a2.ctrl(ac)
                vehicle.set_vehicle_fixed(ac)
                vehicle.set_vehicle_deformation_fixed(ac)
                vehicle.set_vehicle_can_be_visibly_damaged(ac, false)
                x("Repaired Vehicle.")
            end
        end
    )
    a5.add.pt(
        "Waypoint Player",
        a5.p["opl_parent"],
        function(k, d0)
            local d1 = menu.get_player_feature(k.id)
            if k.on then
                if bu ~= d0 then
                    bu = d0
                    for i = 1, #d1.feats do
                        if i - 1 ~= d0 and d1.feats[i].on then
                            d1.feats[i].on = false
                        end
                    end
                end
                local aF = c.gcoords(c.ped(d0))
                ui.set_new_waypoint(v2(aF.x, aF.y))
                c.wait(500)
                return HANDLER_CONTINUE
            end
            c.wait(10)
            ui.set_waypoint_off()
            c.wait(10)
            return HANDLER_POP
        end
    )
    a5.add.pa(
        "Modify Speed (0-500)",
        a5.p["opl_parent"],
        function(k, d0)
            local ac = c.vehicle(c.ped(d0))
            if ac ~= 0 then
                local cM = D.input("Enter modified Speed (0-500)", 10, 3)
                if not cM then
                    return HANDLER_POP
                end
                cM = c.no(cM)
                if cM < 0 or cM > 500 then
                    u("Invalid Speed.")
                    return HANDLER_POP
                end
                u("Setting modified Speed.")
                a2.ctrl(ac)
                entity.set_entity_max_speed(ac, cM)
                vehicle.modify_vehicle_top_speed(ac, cM)
            end
        end
    )
    a5.p["attach"] = a5.add.pp("Attach Objects", a5.p["opl_parent"]).id
    a5.add.pa(
        "Attach Entity from Aim",
        a5.p["attach"],
        function(k, id)
            local d2 = player.get_entity_player_is_aiming_at(c.id())
            if d2 ~= 0 then
                bW({{d2, 0, {0, 0, 0}, {0, 0, 0}}}, id, true)
            else
                u("No Entity found. Aim @Entity to attach it to Player.")
            end
        end
    )
    a5.add.pa(
        "Clear Entitys",
        a5.p["attach"],
        function()
            x("Clearing Attachments.")
            bL(aV["attach_obj"])
            aV["attach_obj"] = {}
            u("Cleared all Attachment Entitys.")
        end
    )
    for i = 1, #C.custom_attachments do
        a5.add.pa(
            C.custom_attachments[i][1],
            a5.p["attach"],
            function(k, id)
                bW(C.custom_attachments[i][2], id)
            end
        )
    end
    a5.p["opl_event_logger"] = a5.add.pp("Log Events", a5.p["opl_parent"]).id
    a5.add.pt(
        "Log Script Events",
        a5.p["opl_event_logger"],
        function(k, id)
            if k.on then
                if bz[id] == nil then
                    bz[id] =
                        hook.register_script_event_hook(
                        function(S, T, U, V)
                            if S == id then
                                local aj = D.scid(id)
                                local j = D.name(id)
                                local an = tostring(aj) .. "-" .. j
                                local e = a["Event-Logger"] .. "\\" .. an .. "\\" .. "Script-Events.log"
                                local z = d.time_prefix() .. " [Script-Event-Logger]"
                                local f = z
                                if not c.d_exists(a["Event-Logger"]) then
                                    utils.make_dir(a["Event-Logger"])
                                end
                                if not c.d_exists(a["Event-Logger"] .. "\\" .. an) then
                                    utils.make_dir(a["Event-Logger"] .. "\\" .. an)
                                end
                                if not c.f_exists(e) then
                                    u("Logging to folder '2Take1Script/Event-Logger/" .. an, 14)
                                    f = "Starting to log Script-Events from Player: " .. j .. ":" .. aj .. "\n" .. z
                                end
                                f = f .. "\n" .. U[1] .. ", {"
                                for i = 2, #U do
                                    f = f .. U[i]
                                    if i ~= #U then
                                        f = f .. ", "
                                    end
                                end
                                f = f .. "}\n"
                                f = f .. "Parameter count: " .. V - 1 .. "\n"
                                d.write(c.o(e, "a"), f)
                            end
                        end
                    )
                end
                return HANDLER_CONTINUE
            end
            if not k.on and bz[id] then
                hook.remove_script_event_hook(bz[id])
                bz[id] = nil
            end
        end
    )
    a5.add.pa(
        "Reset Script Event Log",
        a5.p["opl_event_logger"],
        function(k, id)
            local aj = D.scid(id)
            local j = D.name(id)
            local an = tostring(aj) .. "-" .. j
            local e = a["Event-Logger"] .. "\\" .. an .. "\\" .. "Script-Events.log"
            if c.f_exists(e) then
                io.remove(e)
            else
                u("There was no log to reset.", 14)
            end
        end
    )
    a5.add.pt(
        "Log Net Events",
        a5.p["opl_event_logger"],
        function(k, id)
            if k.on then
                if bA[id] == nil then
                    bA[id] =
                        hook.register_net_event_hook(
                        function(S, T, cN)
                            if S == id then
                                local aj = D.scid(id)
                                local j = D.name(id)
                                local an = tostring(aj) .. "-" .. j
                                local e = a["Event-Logger"] .. "\\" .. an .. "\\" .. "Net-Events.log"
                                local z = d.time_prefix() .. " [Net-Event-Logger]"
                                local f = z
                                if not c.d_exists(a["Event-Logger"]) then
                                    utils.make_dir(a["Event-Logger"])
                                end
                                if not c.d_exists(a["Event-Logger"] .. "\\" .. an) then
                                    utils.make_dir(a["Event-Logger"] .. "\\" .. an)
                                end
                                if not c.f_exists(e) then
                                    u("Logging to folder '2Take1Script/Event-Logger/" .. an, 14)
                                    f = "Starting to log Net-Events from Player: " .. j .. ":" .. aj .. "\n" .. f
                                end
                                local d3 = "Unknown Net-Event"
                                if C.net_events[cN] then
                                    d3 = C.net_events[cN]
                                end
                                f = f .. "\nEvent: " .. d3 .. "\nEvent ID: " .. cN .. "\n"
                                d.write(c.o(e, "a"), f)
                            end
                        end
                    )
                end
                return HANDLER_CONTINUE
            end
            if not k.on and bA[id] then
                hook.remove_net_event_hook(bA[id])
                bA[id] = nil
            end
        end
    )
    a5.add.pa(
        "Reset Net Event Log",
        a5.p["opl_event_logger"],
        function(k, id)
            local aj = D.scid(id)
            local j = D.name(id)
            local an = tostring(aj) .. "-" .. j
            local e = a["Event-Logger"] .. "\\" .. an .. "\\" .. "Net-Events.log"
            if c.f_exists(e) then
                io.remove(e)
            else
                u("There was no log to reset.", 14)
            end
        end
    )
    a5.p["opl_se"] = a5.add.pp("Script-Events", a5.p["opl_parent"]).id
    a5.p["opl_se_custom"] = a5.add.pp("Custom Script Events", a5.p["opl_se"]).id
    a5.add.pa(
        "Enter Custom Script Event with Parameters",
        a5.p["opl_se_custom"],
        function(k, id)
            local cX
            local cW = {}
            local cY = D.input("Enter Custom SE (DEC)", 32, 3)
            if not cY then
                u("Aborted sending Custom Event...", 93)
                return HANDLER_POP
            end
            while cX ~= "#" do
                cX = D.input("Enter Parameter (DEC), to EXIT and send, enter #", 32)
                if not cX then
                    u("Aborted sending Custom Event...", 93)
                    return HANDLER_POP
                end
                if cX == "#" then
                    break
                end
                cX = c.no(cX)
                if type(cX) == "number" then
                    cW[#cW + 1] = cX
                else
                    u("Aborted sending Custom Event...", 93)
                    return HANDLER_POP
                end
            end
            c.script(cY, id, cW)
            u("Sent Custom Script Event with Parameters to Player.", 93)
        end
    )
    for i = 1, #C.custom_se do
        a5.add.pa(
            C.custom_se[i][1],
            a5.p["opl_se_custom"],
            function(k, id)
                u("Sent Custom Script Event to Player.", 93)
                for b2 = 1, #C.custom_se[i][2] do
                    c.script(C.custom_se[i][2][b2][1], id, C.custom_se[i][2][b2][2])
                end
            end
        )
    end
    a5.add.pa(
        "Block - Passive",
        a5.p["opl_se"],
        function(k, id)
            ck(false, 0x54BAD868, {1, 1}, nil, nil, id)
            u("Blocked Player from activating Passive.")
        end
    )
    a5.add.pa(
        "UN-Block - Passive",
        a5.p["opl_se"],
        function(k, id)
            ck(false, 0x54BAD868, {2, 0}, nil, nil, id)
            u("UN-Blocked Player from Passive.")
        end
    )
    a5.p["opl_send_2_mission"] = a5.add.pp("Send Player to Mission", a5.p["opl_se"]).id
    for i = 1, #aM do
        a5.add.pa(
            "Send to " .. aM[i][1],
            a5.p["opl_send_2_mission"],
            function(k, id)
                ck(false, 0x692CC4BB, aM[i][2], nil, nil, id)
                u("Sent Player to Mission")
            end
        )
    end
    a5.p["opl_ceo"] = a5.add.pp("CEO", a5.p["opl_se"]).id
    for i = 1, 3 do
        a5.add.pa(
            aN[i][1],
            a5.p["opl_ceo"],
            function(k, id)
                ck(false, aN[i][2], aN[i][3], aN[i][4], aN[i][5], id)
                u("Modified Players CEO")
            end
        )
    end
    a5.p["opl_assassins_peds"] = a5.add.pp("Send PEDs (Assassins)", a5.p["opl_parent"]).id
    a5.add.pa(
        "Clear PEDs",
        a5.p["opl_assassins_peds"],
        function()
            bL(aV["peds"])
            aV["peds"] = {}
        end
    )
    for i = 1, #C.ped_assassins do
        a5.add.pa(
            "Spawn " .. C.ped_assassins[i][1] .. " (3x)",
            a5.p["opl_assassins_peds"],
            function(k, id)
                x("Spawning PEDs.")
                bn = id
                local aE = C.ped_assassins[i][2]
                local aG = C.ped_assassins[i][3]
                local aF = v3()
                a2.model(aE)
                for i = 1, 3 do
                    aF = c.gcoords(c.ped(id))
                    aF.x = aF.x + c.random(-10, 10)
                    aF.y = aF.y + c.random(-10, 10)
                    aV["peds"][#aV["peds"] + 1] = aD.ped(aE, aF, aG)
                    if aG ~= 28 then
                        weapon.give_delayed_weapon_to_ped(aV["peds"][#aV["peds"]], 0xDBBD7280, 0, 0)
                    end
                    ped.set_ped_max_health(aV["peds"][#aV["peds"]], 25000000.0)
                    ped.set_ped_health(aV["peds"][#aV["peds"]], 25000000.0)
                    ped.set_ped_combat_attributes(aV["peds"][#aV["peds"]], 46, true)
                    ped.set_ped_combat_ability(aV["peds"][#aV["peds"]], 2)
                    ped.set_ped_config_flag(aV["peds"][#aV["peds"]], 187, 0)
                    ped.set_ped_can_ragdoll(aV["peds"][#aV["peds"]], false)
                    for cK = 1, 26 do
                        ped.set_ped_ragdoll_blocking_flags(aV["peds"][#aV["peds"]], cK)
                    end
                    ai.task_combat_ped(aV["peds"][#aV["peds"]], c.ped(id), 0, 16)
                end
                c.unload(aE)
                x("Done.")
            end
        )
    end
    a5.add.pa(
        "TP to Player",
        a5.p["opl_parent"],
        function(k, id)
            bN(c.gcoords(c.ped(id)), 3)
        end
    )
    a5.add.pa(
        "TP Players Vehicle to me",
        a5.p["opl_parent"],
        function(k, id)
            local ac = c.vehicle(c.ped(id))
            a2.ctrl(ac)
            entity.set_entity_velocity(ac, v3())
            bJ(ac, a4.coords())
        end
    )
    a5.add.pa(
        "Add Player to Blacklist",
        a5.p["opl_parent"],
        function(k, id)
            local aj = D.scid(id)
            if aj == D.scid(c.id()) or aj == -1 then
                u("Choose valid Player.")
            else
                d.write(c.o(b["Blacklist"], "a"), aj .. " " .. D.name(id))
                u("Player " .. D.name(id) .. " added to Blocklist.", 48)
                x("Player " .. D.name(id) .. " with SCID: " .. aj .. " added to Blacklist.")
            end
        end
    )
    a5.p["opl_misc"] = a5.add.pp("Miscellaneous", a5.p["opl_parent"]).id
    a5.p["opl_sms"] =
        a5.add.pp(
        "Send SMSs to Player",
        a5.p["opl_misc"],
        function()
            u("Player must have Voice-Chat enabled to recive SMS.")
        end
    ).id
    a5.add.pa(
        "Custom SMS input",
        a5.p["opl_sms"],
        function(k, id)
            local cZ = D.input("Enter Custom SMS", 128)
            if not cZ then
                return HANDLER_POP
            end
            player.send_player_sms(id, cZ)
        end
    )
    a5.add.pa(
        "Send his SCID & IP",
        a5.p["opl_sms"],
        function(k, id)
            local aj = tostring(D.scid(id))
            local c_ = D.ip(id)
            local o = 1
            player.send_player_sms(id, "R*SCID: " .. aj .. "~n~IP: " .. c_)
        end
    )
    for i = 1, #C.sms_texts do
        a5.add.pa(
            C.sms_texts[i],
            a5.p["opl_sms"],
            function(k, id)
                player.send_player_sms(id, C.sms_texts[i])
            end
        )
    end
    a5.add.pa(
        "Falling Asteroids",
        a5.p["opl_misc"],
        function(k, id)
            c.navigate(false)
            local aF = v3()
            local d4
            a2.model(3751297495)
            for i = 1, 25 do
                aF = c.gcoords(c.ped(id))
                aF.x = c.random(math.floor(aF.x - 80), math.floor(aF.x + 80))
                aF.y = c.random(math.floor(aF.y - 80), math.floor(aF.y + 80))
                aF.z = aF.z + c.random(45, 90)
                d4 = c.random(-125, 25)
                aV["asteroids"][#aV["asteroids"] + 1] = aD.object(3751297495, aF, true, true)
                entity.apply_force_to_entity(aV["asteroids"][#aV["asteroids"]], 3, 0, 0, d4, 0, 0, 0, true, true)
            end
            c.unload(3751297495)
            for i = 1, 5 do
                for i = 1, 25 do
                    aF = c.gcoords(aV["asteroids"][#aV["asteroids"] - 25 + i])
                    c.explode(aF, 8, true, false, 0, 0)
                    c.wait(50)
                end
            end
            c.navigate(true)
        end
    )
    a5.add.pa(
        "Delete Asteroids",
        a5.p["opl_misc"],
        function()
            x("Clearing Asteroids.")
            bL(aV["asteroids"])
            aV["asteroids"] = {}
            u("Cleared all Asteroids.")
        end
    )
    a5.add.pa(
        "Apply random Force to Player",
        a5.p["opl_misc"],
        function(k, id)
            local d5 = c.ped(id)
            if ped.is_ped_in_any_vehicle(d5) then
                d5 = c.vehicle(d5)
            else
                u("It works better, if target is in a Vehicle.")
            end
            a2.ctrl(d5)
            local d6 = entity.get_entity_velocity(d5)
            for i = 1, 5 do
                d6.x = c.random(math.floor(d6.x - 50), math.floor(d6.x + 50))
                d6.y = c.random(math.floor(d6.y - 50), math.floor(d6.y + 50))
                d6.z = c.random(math.floor(d6.z - 50), math.floor(d6.z + 50))
                entity.set_entity_velocity(d5, d6)
                c.wait(10)
            end
        end
    )
    a5.add.pa(
        "Trap in Stunt Tube",
        a5.p["opl_misc"],
        function(k, id)
            local aF = c.gcoords(c.ped(id))
            aF.z = aF.z - 5
            entity.set_entity_rotation(aD.object(1125864094, aF), v3(0, 90, 0))
        end
    )
    a5.add.pa(
        "Trap in invisible Cage",
        a5.p["opl_misc"],
        function(k, id)
            local aF = c.gcoords(c.ped(id))
            aF.x = aF.x + 1.24
            aF.y = aF.y + 0.24
            a2.model(401136338)
            local d7 = aD.object(401136338, aF)
            c.visible(d7, false)
            entity.set_entity_rotation(d7, v3(0, -90, 0))
            entity.freeze_entity(d7, true)
            aF = c.gcoords(c.ped(id))
            aF.x = aF.x + 0.02
            aF.y = aF.y + 0.82
            d7 = aD.object(401136338, aF)
            c.visible(d7, false)
            entity.set_entity_rotation(d7, v3(90, -90, 0))
            entity.freeze_entity(d7, true)
            c.unload(401136338)
        end
    )
    a5.p["opl_bounty"] = a5.add.pp("Bounty", a5.p["opl_parent"]).id
    for i = 1, #C.bounty_amount do
        a5.add.pa(
            C.bounty_amount[i] .. "$",
            a5.p["opl_bounty"],
            function()
                local cU = 0
                if a5.t["anonymous_bounty"].on then
                    cU = 1
                end
                for cK = 0, 31 do
                    if D.scid(cK) ~= -1 then
                        c.script(
                            544453591,
                            cK,
                            {
                                69,
                                id,
                                1,
                                C.bounty_amount[i],
                                0,
                                cU,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                script.get_global_i(1650640 + 9),
                                script.get_global_i(1650640 + 10)
                            }
                        )
                    end
                end
            end
        )
    end
    a5.p["opl_lag_area"] =
        a5.add.pp(
        "Lag Area with Vehicles",
        a5.p["opl_parent"],
        function()
            u("DANGEROUS! ONLY USE WITH CAUTION!", 208)
        end
    ).id
    for i = 1, #C.vehicle_lag_area do
        a5.add.pa(
            "Lag / Rain Area with " .. C.vehicle_lag_area[i][1],
            a5.p["opl_lag_area"],
            function(k, id)
                c2(id, C.vehicle_lag_area[i][2])
            end
        )
    end
    a5.add.pa(
        "Delete Vehicles",
        a5.p["opl_lag_area"],
        function()
            x("Clearing Vehicles.")
            bL(aV["lag_area"])
            aV["lag_area"] = {}
            u("Cleared Vehicles.")
        end
    )
    a5.p["opl_malicious"] = a5.add.pp("Malicious (Kick / Crash)", a5.p["opl_parent"]).id
    a5.add.pa(
        "Kick Player",
        a5.p["opl_malicious"],
        function(k, id)
            bV(false, id)
        end
    )
    a5.add.pa(
        "Host Kick Player",
        a5.p["opl_malicious"],
        function(k, id)
            if network.network_is_host() then
                network.network_session_kick_player(id)
            else
                u("You are not Session-Host!")
            end
        end
    )
    a5.add.pa(
        "Crash Player",
        a5.p["opl_malicious"],
        function(k, id)
            c3(id)
        end
    )
    a5.p["chat"] = a5.add.p("Chat-Features", a5.p["parent"])
    a5.p["chat"].hidden = r["chat_hidden"]
    a5.p["chat"] = a5.p["chat"].id
    a5.t["chat_log"] =
        a5.add.t(
        "Chat-Log",
        a5.p["chat"],
        function(k)
            if k.on and not bh["chat_log"] then
                bh["chat_log"] =
                    event.add_event_listener(
                    "chat",
                    function(N)
                        x("[" .. D.scid(N.player) .. ":" .. D.name(N.player) .. "] '" .. N.body .. "'", "[CHAT]")
                    end
                )
            end
            if not k.on and bh["chat_log"] then
                event.remove_event_listener("chat", bh["chat_log"])
                bh["chat_log"] = nil
            end
            r["chat_log"] = k.on
        end
    )
    a5.t["chat_log"].on = r["chat_log"]
    a5.t["chat_russki"] =
        a5.add.t(
        "Kick if Russki Char is typed",
        a5.p["chat"],
        function(k)
            if k.on and not bh["chat_russki"] then
                bh["chat_russki"] =
                    event.add_event_listener(
                    "chat",
                    function(N)
                        local id = N.player
                        if a9.i(id) then
                            local f = N.body
                            for i = 1, #C.russki_chars do
                                if string.find(f, C.russki_chars[i], 1) then
                                    x("Detected '" .. C.russki_chars[i] .. "' as a Russki Char!")
                                    x("Preparing to Kick " .. D.name(id) .. ".")
                                    u("Detected " .. D.name(id) .. " typing forbidden Russki! Kicking Player...", 115)
                                    bV(false, id)
                                    f = ""
                                end
                            end
                        end
                    end
                )
            end
            if not k.on and bh["chat_russki"] then
                event.remove_event_listener("chat", bh["chat_russki"])
                bh["chat_russki"] = nil
            end
            r["chat_russki"] = k.on
        end
    )
    a5.t["chat_russki"].on = r["chat_russki"]
    a5.t["chat_begger"] =
        a5.add.t(
        "Punish Money Beggers",
        a5.p["chat"],
        function(k)
            if k.on and not bh["chat_begger"] then
                bh["chat_begger"] =
                    event.add_event_listener(
                    "chat",
                    function(N)
                        local id = N.player
                        if a9.i(id) then
                            local f = N.body
                            for i = 1, #C.begger_texts do
                                if string.find(f, C.begger_texts[i], 1) then
                                    x("Detected " .. D.name(id) .. " begging for Money! Punishing Player...")
                                    u("Detected " .. D.name(id) .. " begging for Money! Punishing Player...", 115)
                                    bW(C.custom_attachments[5][2], id)
                                    bW(C.custom_attachments[8][2], id)
                                    local aF = c.gcoords(c.ped(id))
                                    local d8 = c.ped(id)
                                    c.explode(aF, 59, false, true, 1, d8)
                                    c.explode(aF, 8, false, true, 1, d8)
                                    c.explode(aF, 59, false, true, 1, d8)
                                end
                            end
                        end
                    end
                )
            end
            if not k.on and bh["chat_begger"] then
                event.remove_event_listener("chat", bh["chat_begger"])
                bh["chat_begger"] = nil
            end
            r["chat_begger"] = k.on
        end
    )
    a5.t["chat_begger"].on = r["chat_begger"]
    a5.t["send_msg_to_script_users"] =
        a5.add.a(
        "Send Message to 2Take1Script-Users",
        a5.p["chat"],
        function()
            local W = D.input("Enter Message", 128)
            if not W then
                return HANDLER_POP
            end
            if W ~= "" then
                local U = {}
                U[1] = 6666
                for bK, cf in utf8.codes(W) do
                    U[#U + 1] = cf
                end
                for i = 0, 31 do
                    if c.valid(i) then
                        if i ~= c.id() and D.scid(i) ~= -1 then
                            c.script(0xfaaab4a3, i, U)
                        end
                    end
                end
            end
        end
    )
    a5.t["chat_cmd"] =
        a5.add.t(
        "Enable Chat-Commands",
        a5.p["chat"],
        function(k)
            if k.on and not bh["chat_cmd"] then
                bh["chat_cmd"] =
                    event.add_event_listener(
                    "chat",
                    function(a3)
                        local id = a3.player
                        local f = a3.body
                        if a5.t["cmd_explode"] and string.find(f, "!explode ", 1) then
                            f = string.gsub(f, "!explode ", "")
                            local d9, ci = cg(id, f, "Explode")
                            if d9 then
                                local aF = c.gcoords(c.ped(ci))
                                local d8 = c.ped(id)
                                c.explode(aF, 59, false, true, 1, d8)
                                c.explode(aF, 8, false, true, 1, d8)
                                c.explode(aF, 59, false, true, 1, d8)
                            end
                        end
                        if a5.t["cmd_explode_all"] and string.find(f, "!explodeall", 1) and id == c.id() then
                            x("Detected !explodeall Command! Script-User is entitled, performing...")
                            for i = 0, 31 do
                                if a9.i(i) then
                                    c.explode(c.gcoords(c.ped(i)), 59, true, false, 1, c.ped(c.id()))
                                end
                            end
                        end
                        if a5.t["cmd_kick"] and string.find(f, "!kick ", 1) then
                            f = string.gsub(f, "!kick ", "")
                            local d9, ci = cg(id, f, "Kick")
                            if d9 then
                                bV(false, ci)
                            end
                        end
                        if a5.t["cmd_kick_all"] and string.find(f, "!kickall", 1) and id == c.id() then
                            x("Detected !kickall Command! Script-User is entitled, performing...")
                            bV(true)
                        end
                        if a5.t["cmd_crash"] and string.find(f, "!crash ", 1) then
                            x("Detected !crash Command!")
                            f = string.gsub(f, "!crash ", "")
                            local T = cb(f)
                            if T ~= -1 then
                                if T == c.id() then
                                    c3(id)
                                elseif a9.i(T) then
                                    c3(T)
                                end
                            end
                        end
                        if a5.t["cmd_crash_all"] and string.find(f, "!crashall", 1) and id == c.id() then
                            x("Detected !crashall Command! Script-User is entitled, performing...")
                            for i = 0, 31 do
                                if a9.i(i) then
                                    c3(i)
                                end
                            end
                        end
                        if a5.t["cmd_lag"] and string.find(f, "!lag ", 1) then
                            f = string.gsub(f, "!lag ", "")
                            local d9, ci = cg(id, f, "Lag")
                            if d9 and #aV["lag_area"] < 101 then
                                c2(ci, 0x15F27762)
                            end
                        end
                        if a5.t["cmd_trap"] and string.find(f, "!trap ", 1) then
                            f = string.gsub(f, "!trap ", "")
                            local d9, ci = cg(id, f, "Trap")
                            if d9 then
                                local aF = c.gcoords(c.ped(ci))
                                entity.set_entity_rotation(
                                    aD.object(1125864094, v3(aF.x, aF.y, aF.z - 5)),
                                    v3(0, 90, 0)
                                )
                            end
                        end
                        if a5.t["cmd_tp"] and string.find(f, "!tp ", 1) and id == c.id() then
                            x("Detected !tp Command! Script-User is entitled, performing...")
                            f = string.gsub(f, "!tp ", "")
                            local T = cb(f)
                            if T ~= -1 then
                                local bO = 10
                                local aF = c.gcoords(c.ped(T))
                                if aF.z < -50 then
                                    bO = 150
                                end
                                bN(c.ped(T), bO)
                            end
                        end
                        if a5.t["cmd_clearwanted"] and string.find(f, "!clearwanted", 1) then
                            local d9, ci = cg(id, nil, "Clearwanted")
                            if d9 then
                                c.script(0xf63f672f, id, {id, script.get_global_i(1628955 + 1 + id * 614 + 532)})
                            end
                        end
                        if a5.t["cmd_vehicle"] and string.find(f, "!vehicle ", 1) then
                            f = string.gsub(f, "!vehicle ", "")
                            local d9, ci = cg(id, nil, "Vehicle")
                            if d9 then
                                local aE = gameplay.get_hash_key(f)
                                if streaming.is_model_a_vehicle(aE) then
                                    a2.model(aE)
                                    local aH = player.get_player_heading(id)
                                    local da = aD.vehicle(aE, c9(c.gcoords(c.ped(id)), aH, 10), aH)
                                    a2.ctrl(da)
                                    c.unload(aE)
                                    vehicle.set_vehicle_custom_primary_colour(da, 0)
                                    vehicle.set_vehicle_custom_secondary_colour(da, 0)
                                    vehicle.set_vehicle_custom_pearlescent_colour(da, 0)
                                    vehicle.set_vehicle_custom_wheel_colour(da, 0)
                                    vehicle.set_vehicle_window_tint(da, 1)
                                    decorator.decor_set_int(da, "MPBitset", 1 << 10)
                                    c6(da)
                                    ped.set_ped_into_vehicle(c.ped(id), da, -1)
                                end
                            end
                        end
                        if a5.t["cmd_bigpp"] and string.find(f, "!bigpp ", 1) then
                            f = string.gsub(f, "!bigpp ", "")
                            local d9, ci = cg(id, f, "Bigpp")
                            if d9 then
                                bW(C.custom_attachments[5][2], ci)
                            end
                        end
                        if a5.t["cmd_bigppall"] and string.find(f, "!bigppall", 1) and id == c.id() then
                            x("Detected !bigppall Command! Script-User is entitled, performing...")
                            for i = 0, 31 do
                                if a9.i(i) then
                                    bW(C.custom_attachments[5][2], id)
                                end
                            end
                        end
                    end
                )
            end
            if not k.on and bh["chat_cmd"] then
                event.remove_event_listener("chat", bh["chat_cmd"])
                bh["chat_cmd"] = nil
            end
            r["chat_cmd"] = k.on
        end
    )
    a5.t["chat_cmd"].on = r["chat_cmd"]
    a5.p["chat_cmd"] = a5.add.p("Chat-Commands", a5.p["chat"]).id
    for i = 1, #aR do
        a5.t[aR[i][1]] =
            a5.add.t(
            aR[i][2],
            a5.p["chat_cmd"],
            function(k)
                r[aR[i][1]] = k.on
            end
        )
        a5.t[aR[i][1]].on = r[aR[i][1]]
    end
    a5.add.a("[SU] = Script-User", a5.p["chat_cmd"])
    a5.add.a(
        "Delete Vehicles from !lag",
        a5.p["chat"],
        function()
            bL(aV["lag_area"])
            aV["lag_area"] = {}
        end
    )
    a5.t["chat_cmd_friends"] =
        a5.add.t(
        "Chat Commands for Friends",
        a5.p["chat"],
        function(k)
            r["chat_cmd_friends"] = k.on
        end
    )
    a5.t["chat_cmd_friends"].on = r["chat_cmd_friends"]
    a5.t["chat_cmd_all"] =
        a5.add.t(
        "Chat Commands Everyone",
        a5.p["chat"],
        function(k)
            r["chat_cmd_all"] = k.on
        end
    )
    a5.t["chat_cmd_all"].on = r["chat_cmd_all"]
    a5.p["custom_veh"] = a5.add.p("Custom Vehicles", a5.p["parent"])
    a5.p["custom_veh"].hidden = r["custom_vehicles_hidden"]
    a5.p["custom_veh"] = a5.p["custom_veh"].id
    a5.p["moveablerobot"] = a5.add.p("Moveable Robot", a5.p["custom_veh"]).id
    a5.t["moveablerobot"] =
        a5.add.t(
        "Enable Robot",
        a5.p["moveablerobot"],
        function(k)
            if k.on then
                if bp["tampa"] == nil then
                    c.navigate(false)
                    local db = true
                    local ac = c.vehicle(a4.ped())
                    if ac ~= 0 then
                        if 3084515313 == entity.get_entity_model_hash(ac) then
                            bp["tampa"] = ac
                            db = false
                        end
                    end
                    if db then
                        a2.model(3084515313)
                        bp["tampa"] = aD.vehicle(3084515313, a4.coords(), a4.heading())
                        decorator.decor_set_int(bp["tampa"], "MPBitset", 1 << 10)
                        c.god(bp["tampa"], true)
                        c6(ac)
                        if a5.t["auto_get_in"].on then
                            ped.set_ped_into_vehicle(a4.ped(), bp["tampa"], -1)
                        end
                        if not r["disable_tampa_notify"] then
                            u(
                                "To get the best experience, upgrade the Tampa to use the Double Controllable Minigun!",
                                11
                            )
                            u("You can disable this message in Options.", 11)
                        end
                    end
                end
                if bp["ppdump"] == nil then
                    a2.model(0x810369E2)
                    bp["ppdump"] = aD.vehicle(0x810369E2)
                    c.god(bp["ppdump"], true)
                    c.attach(
                        bp["ppdump"],
                        bp["tampa"],
                        0,
                        v3(0, 0, 12.5),
                        v3(),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["llbone"] == nil then
                    a2.model(1803116220)
                    bp["llbone"] = aD.object(1803116220)
                    c.attach(
                        bp["llbone"],
                        bp["tampa"],
                        0,
                        v3(-4.25, 0, 12.5),
                        v3(),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["rlbone"] == nil then
                    a2.model(1803116220)
                    bp["rlbone"] = aD.object(1803116220)
                    c.attach(
                        bp["rlbone"],
                        bp["tampa"],
                        0,
                        v3(4.25, 0, 12.5),
                        v3(),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["lltrain"] == nil then
                    a2.model(1030400667)
                    bp["lltrain"] = aD.vehicle(1030400667)
                    c.god(bp["lltrain"], true)
                    c.attach(
                        bp["lltrain"],
                        bp["llbone"],
                        0,
                        v3(0, 0, -5),
                        v3(90),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["lfoot"] == nil then
                    a2.model(782665360)
                    bp["lfoot"] = aD.vehicle(782665360)
                    c.god(bp["lfoot"], true)
                    c.attach(
                        bp["lfoot"],
                        bp["llbone"],
                        0,
                        v3(0, 2, -12.5),
                        v3(),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["rltrain"] == nil then
                    a2.model(1030400667)
                    bp["rltrain"] = aD.vehicle(1030400667)
                    c.god(bp["rltrain"], true)
                    c.attach(
                        bp["rltrain"],
                        bp["rlbone"],
                        0,
                        v3(0, 0, -5),
                        v3(90),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["rfoot"] == nil then
                    a2.model(782665360)
                    bp["rfoot"] = aD.vehicle(782665360)
                    c.god(bp["rfoot"], true)
                    c.attach(
                        bp["rfoot"],
                        bp["rlbone"],
                        0,
                        v3(0, 2, -12.5),
                        v3(),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["body"] == nil then
                    a2.model(1030400667)
                    bp["body"] = aD.vehicle(1030400667)
                    c.god(bp["body"], true)
                    c.attach(
                        bp["body"],
                        bp["tampa"],
                        0,
                        v3(0, 0, 22.5),
                        v3(90),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["shoulder"] == nil then
                    a2.model(0x810369E2)
                    bp["shoulder"] = aD.vehicle(0x810369E2)
                    c.god(bp["shoulder"], true)
                    c.attach(
                        bp["shoulder"],
                        bp["tampa"],
                        0,
                        v3(0, 0, 27.5),
                        v3(),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["lheadbone"] == nil then
                    a2.model(1803116220)
                    bp["lheadbone"] = aD.object(1803116220)
                    c.attach(
                        bp["lheadbone"],
                        bp["tampa"],
                        0,
                        v3(-3.25, 0, 27.5),
                        v3(),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["rheadbone"] == nil then
                    a2.model(1803116220)
                    bp["rheadbone"] = aD.object(1803116220)
                    c.attach(
                        bp["rheadbone"],
                        bp["tampa"],
                        0,
                        v3(3.25, 0, 27.5),
                        v3(),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["lheadtrain"] == nil then
                    a2.model(1030400667)
                    bp["lheadtrain"] = aD.vehicle(1030400667)
                    c.god(bp["lheadtrain"], true)
                    c.attach(
                        bp["lheadtrain"],
                        bp["lheadbone"],
                        0,
                        v3(-3, 4, -5),
                        v3(325, 0, 45),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["lhand"] == nil then
                    a2.model(782665360)
                    bp["lhand"] = aD.vehicle(782665360)
                    c.god(bp["lhand"], true)
                    c.attach(
                        bp["lhand"],
                        bp["lheadtrain"],
                        0,
                        v3(0, 7.5, 0),
                        v3(),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["rheadtrain"] == nil then
                    a2.model(1030400667)
                    bp["rheadtrain"] = aD.vehicle(1030400667)
                    c.god(bp["rheadtrain"], true)
                    c.attach(
                        bp["rheadtrain"],
                        bp["rheadbone"],
                        0,
                        v3(3, 4, -5),
                        v3(325, 0, 315),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["rhand"] == nil then
                    a2.model(782665360)
                    bp["rhand"] = aD.vehicle(782665360)
                    c.god(bp["rhand"], true)
                    c.attach(
                        bp["rhand"],
                        bp["rheadtrain"],
                        0,
                        v3(0, 7.5, 0),
                        v3(),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["head"] == nil then
                    a2.model(-543669801)
                    bp["head"] = aD.object(-543669801)
                    c.attach(bp["head"], bp["tampa"], 0, v3(0, 0, 35), v3(), true, r["robot_collision"], false, 2, true)
                end
                c.navigate(true)
                return HANDLER_CONTINUE
            end
            if not k.on then
                for i in pairs(bp) do
                    bL({bp[i]})
                    bp[i] = nil
                end
                if #aV["robot_weapon_left"] ~= 0 then
                    bL(aV["robot_weapon_left"])
                    aV["robot_weapon_left"] = {}
                end
                if #aV["robot_weapon_right"] ~= 0 then
                    bL(aV["robot_weapon_right"])
                    aV["robot_weapon_right"] = {}
                end
            end
        end
    )
    a5.t["robot_shoot"] =
        a5.add.t(
        "Controllable Blasts",
        a5.p["moveablerobot"],
        function(k)
            if k.on then
                if not a5.t["moveablerobot"].on then
                    c.wait(2500)
                end
                local dc = gameplay.get_hash_key("weapon_airstrike_rocket")
                local aF = a4.coords()
                local dd = cam.get_gameplay_cam_rot()
                dd:transformRotToDir()
                dd = dd * 1000
                aF = aF + dd
                local de, df, dg, aE, dh = worldprobe.raycast(c9(a4.coords(), a4.heading(), 2) + v3(0, 0, 4), aF, -1, 0)
                while not de do
                    aF = a4.coords()
                    dd = cam.get_gameplay_cam_rot()
                    dd:transformRotToDir()
                    dd = dd * 1000
                    aF = aF + dd
                    de, df, dg, aE, dh = worldprobe.raycast(c9(a4.coords(), a4.heading(), 2) + v3(0, 0, 4), aF, -1, 0)
                    c.wait(0)
                end
                if ped.is_ped_shooting(a4.ped()) and c.vehicle(a4.ped()) == bp["tampa"] then
                    if a5.t["equip_weapons"].on then
                        local di = aV["robot_weapon_left"][1]
                        local dj = entity.get_entity_heading(di)
                        local dk = c9(c.gcoords(di), dj, 12) + v3(0, 0, 3)
                        gameplay.shoot_single_bullet_between_coords(dk, df, 1000, dc, a4.ped(), true, false, 50000)
                        c.wait(100)
                        local dl = aV["robot_weapon_right"][1]
                        local dm = entity.get_entity_heading(dl)
                        local dn = c9(c.gcoords(dl), dm, 12) + v3(0, 0, 3)
                        gameplay.shoot_single_bullet_between_coords(dn, df, 1000, dc, a4.ped(), true, false, 50000)
                    else
                        local dp = c9(a4.coords(), a4.heading(), 8) + v3(0, 0, 15)
                        gameplay.shoot_single_bullet_between_coords(dp, df, 1000, dc, a4.ped(), true, false, 10000)
                    end
                end
            end
            r["controllable_blasts"] = k.on
            return d.stop(k)
        end
    )
    a5.t["robot_shoot"].on = r["controllable_blasts"]
    a5.t["moveablelegs"] =
        a5.add.t(
        "Moveable Legs",
        a5.p["moveablerobot"],
        function(k)
            r["moveable_legs"] = k.on
            if k.on then
                if bp["llbone"] and bp["rlbone"] and bp["tampa"] then
                    local cM
                    local ct = bp["llbone"]
                    local cu = bp["rlbone"]
                    local cv = bp["tampa"]
                    local cw = v3(-4.25, 0, 12.5)
                    local cx = v3(4.25, 0, 12.5)
                    for i = 0, 50 do
                        if bp["tampa"] then
                            cM = entity.get_entity_speed(bp["tampa"])
                            if not k.on or cM < 2.5 then
                                cs()
                                return HANDLER_CONTINUE
                            end
                            a2.ctrl(ct)
                            a2.ctrl(cu)
                            a2.ctrl(cv)
                            c.attach(ct, cv, 0, cw, v3(i, 0, 0), true, r["robot_collision"], false, 2, true)
                            c.attach(cu, cv, 0, cx, v3(360 - i, 0, 0), true, r["robot_collision"], false, 2, true)
                            local dq = math.floor(51 - cM / 1)
                            if dq < 1 then
                                dq = 0
                            end
                            c.wait(dq)
                        end
                    end
                    for i = 50, -50, -1 do
                        if bp["tampa"] then
                            cM = entity.get_entity_speed(bp["tampa"])
                            if not k.on or cM < 2.5 then
                                cs()
                                return HANDLER_CONTINUE
                            end
                            a2.ctrl(ct)
                            a2.ctrl(cu)
                            a2.ctrl(cv)
                            c.attach(ct, cv, 0, cw, v3(i, 0, 0), true, r["robot_collision"], false, 2, true)
                            c.attach(cu, cv, 0, cx, v3(360 - i, 0, 0), true, r["robot_collision"], false, 2, true)
                            local dq = math.floor(51 - cM / 1)
                            if dq < 1 then
                                dq = 0
                            end
                            c.wait(dq)
                        end
                    end
                    for i = -50, 0 do
                        if bp["tampa"] then
                            cM = entity.get_entity_speed(bp["tampa"])
                            if not k.on or cM < 2.5 then
                                cs()
                                return HANDLER_CONTINUE
                            end
                            a2.ctrl(ct)
                            a2.ctrl(cu)
                            a2.ctrl(cv)
                            c.attach(ct, cv, 0, cw, v3(i, 0, 0), true, r["robot_collision"], false, 2, true)
                            c.attach(cu, cv, 0, cx, v3(360 - i, 0, 0), true, r["robot_collision"], false, 2, true)
                            local dq = math.floor(51 - cM / 1)
                            if dq < 1 then
                                dq = 0
                            end
                            c.wait(dq)
                        end
                    end
                end
                return HANDLER_CONTINUE
            end
            if not k.on then
                cs()
            end
        end
    )
    a5.t["moveablelegs"].on = r["moveable_legs"]
    a5.t["robot_collision"] =
        a5.add.t(
        "Collision",
        a5.p["moveablerobot"],
        function(k)
            r["robot_collision"] = k.on
            if c.vehicle(a4.ped()) == bp["tampa"] then
                u("Re-enable Robot to take effect of collision!", 11)
            end
        end
    )
    a5.t["robot_collision"].on = r["robot_collision"]
    a5.t["rocket_propulsion"] =
        a5.add.t(
        "Rocket Propulsion (Visual)",
        a5.p["moveablerobot"],
        function(k)
            if k.on and bp["body"] then
                if bp["spinning_1"] == nil then
                    a2.model(0xFB133A17)
                    bp["spinning_1"] = aD.vehicle(0xFB133A17, a4.coords())
                    c.god(bp["spinning_1"], true)
                    c.visible(bp["spinning_1"], false)
                    c.attach(
                        bp["spinning_1"],
                        bp["body"],
                        0,
                        v3(0, -5, 0),
                        v3(-180, 0, 0),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                vehicle.set_heli_blades_speed(bp["spinning_1"], 100)
                if bp["spinning_middle"] == nil then
                    a2.model(94602826)
                    bp["spinning_middle"] = aD.object(94602826)
                    c.god(bp["spinning_middle"], true)
                    c.attach(
                        bp["spinning_middle"],
                        bp["spinning_1"],
                        0,
                        v3(0, 0, 0),
                        v3(0, 0, 0),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["spinning_middle2"] == nil then
                    a2.model(94602826)
                    bp["spinning_middle2"] = aD.object(94602826)
                    c.god(bp["spinning_middle2"], true)
                    c.attach(
                        bp["spinning_middle2"],
                        bp["spinning_1"],
                        0,
                        v3(0, 0, 1.5),
                        v3(0, 0, 0),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["spinning_middle3"] == nil then
                    a2.model(94602826)
                    bp["spinning_middle3"] = aD.object(94602826)
                    c.god(bp["spinning_middle3"], true)
                    c.attach(
                        bp["spinning_middle3"],
                        bp["spinning_1"],
                        0,
                        v3(0, 0, 3),
                        v3(0, 0, 0),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                local q = entity.get_entity_bone_index_by_name(bp["spinning_1"], "rotor_main")
                if bp["glow_1"] == nil then
                    a2.model(2655881418)
                    bp["glow_1"] = aD.object(2655881418)
                    c.god(bp["glow_1"], true)
                    c.attach(
                        bp["glow_1"],
                        bp["spinning_1"],
                        q,
                        v3(2, 3, 3),
                        v3(0, 0, 0),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["glow_2"] == nil then
                    a2.model(2655881418)
                    bp["glow_2"] = aD.object(2655881418)
                    c.god(bp["glow_2"], true)
                    c.attach(
                        bp["glow_2"],
                        bp["spinning_1"],
                        q,
                        v3(2, -3, 3),
                        v3(0, 0, 0),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["glow_3"] == nil then
                    a2.model(2655881418)
                    bp["glow_3"] = aD.object(2655881418)
                    c.god(bp["glow_3"], true)
                    c.attach(
                        bp["glow_3"],
                        bp["spinning_1"],
                        q,
                        v3(4, 0, 3),
                        v3(0, 0, 0),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["glow_4"] == nil then
                    a2.model(2655881418)
                    bp["glow_4"] = aD.object(2655881418)
                    c.god(bp["glow_4"], true)
                    c.attach(
                        bp["glow_4"],
                        bp["spinning_1"],
                        q,
                        v3(-2, 3, 3),
                        v3(0, 0, 0),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["glow_5"] == nil then
                    a2.model(2655881418)
                    bp["glow_5"] = aD.object(2655881418)
                    c.god(bp["glow_5"], true)
                    c.attach(
                        bp["glow_5"],
                        bp["spinning_1"],
                        q,
                        v3(-2, -3, 3),
                        v3(0, 0, 0),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
                if bp["glow_6"] == nil then
                    a2.model(2655881418)
                    bp["glow_6"] = aD.object(2655881418)
                    c.god(bp["glow_6"], true)
                    c.attach(
                        bp["glow_6"],
                        bp["spinning_1"],
                        q,
                        v3(-4, 0, 3),
                        v3(0, 0, 0),
                        true,
                        r["robot_collision"],
                        false,
                        2,
                        true
                    )
                end
            end
            if not k.on then
                local dr = {
                    "spinning_1",
                    "glow_1",
                    "glow_2",
                    "glow_3",
                    "glow_4",
                    "glow_5",
                    "glow_6",
                    "spinning_middle",
                    "spinning_middle2",
                    "spinning_middle3"
                }
                for i = 1, #dr do
                    if bp[dr[i]] then
                        bL({bp[dr[i]]})
                        bp[dr[i]] = nil
                    end
                end
                return HANDLER_POP
            end
            r["rocket_propulsion"] = k.on
            return HANDLER_CONTINUE
        end
    )
    a5.t["rocket_propulsion"].on = r["rocket_propulsion"]
    a5.t["equip_weapons"] =
        a5.add.t(
        "Equip Miniguns on hands",
        a5.p["moveablerobot"],
        function(k)
            r["equip_weapons"] = k.on
            if k.on and bp["lheadtrain"] and bp["rheadtrain"] then
                if #aV["robot_weapon_left"] == 0 and #aV["robot_weapon_right"] == 0 then
                    local ds = false
                    if a5.t["spawn_preview"].on then
                        ds = true
                        a5.t["spawn_preview"].on = false
                    end
                    local dt = false
                    if a5.t["auto_get_in"].on then
                        dt = true
                        a5.t["auto_get_in"].on = false
                    end
                    local bX = C.custom_vehicles[1][2]
                    cy(bX, "robot_weapon_left")
                    cy(bX, "robot_weapon_right")
                    local du = aV["robot_weapon_left"][1]
                    local dv = aV["robot_weapon_right"][1]
                    local dw = bp["lheadtrain"]
                    local dx = bp["rheadtrain"]
                    a2.ctrl(du)
                    a2.ctrl(dv)
                    a2.ctrl(dw)
                    a2.ctrl(dx)
                    c.attach(du, dw, 0, v3(0, 5, 0), v3(), true, r["robot_collision"], false, 2, true)
                    c.attach(dv, dx, 0, v3(0, 5, 0), v3(), true, r["robot_collision"], false, 2, true)
                    if ds then
                        a5.t["spawn_preview"].on = true
                    end
                    if dt then
                        a5.t["auto_get_in"].on = true
                    end
                end
            end
            if not k.on then
                if #aV["robot_weapon_left"] ~= 0 then
                    bL(aV["robot_weapon_left"])
                    aV["robot_weapon_left"] = {}
                end
                if #aV["robot_weapon_right"] ~= 0 then
                    bL(aV["robot_weapon_right"])
                    aV["robot_weapon_right"] = {}
                end
                return HANDLER_POP
            end
            return HANDLER_CONTINUE
        end
    )
    a5.t["equip_weapons"].on = r["equip_weapons"]
    a5.add.a(
        "Drive Robot",
        a5.p["moveablerobot"],
        function()
            if bp["tampa"] then
                ped.set_ped_into_vehicle(a4.ped(), bp["tampa"], -1)
            end
        end
    )
    a5.add.a(
        "Self Destruction",
        a5.p["moveablerobot"],
        function()
            if bp["tampa"] then
                for i = 1, #aV["robot_weapon_left"] do
                    entity.detach_entity(aV["robot_weapon_left"][i])
                    entity.freeze_entity(aV["robot_weapon_left"][i], false)
                    c.god(aV["robot_weapon_left"][i], false)
                end
                for i = 1, #aV["robot_weapon_right"] do
                    entity.detach_entity(aV["robot_weapon_right"][i])
                    entity.freeze_entity(aV["robot_weapon_right"][i], false)
                    c.god(aV["robot_weapon_right"][i], false)
                end
                for i in pairs(bp) do
                    entity.detach_entity(bp[i])
                    entity.freeze_entity(bp[i], false)
                    c.god(bp[i], false)
                end
                for i = 1, #aV["robot_weapon_left"] do
                    c.explode(c.gcoords(aV["robot_weapon_left"][i]), 8, true, false, 0, 0)
                    c.wait(33)
                end
                for i = 1, #aV["robot_weapon_right"] do
                    c.explode(c.gcoords(aV["robot_weapon_right"][i]), 8, true, false, 0, 0)
                    c.wait(33)
                end
                for i in pairs(bp) do
                    c.explode(c.gcoords(bp[i]), 8, true, false, 0, 0)
                    c.wait(33)
                end
                aV["robot_weapon_left"] = {}
                aV["robot_weapon_right"] = {}
                bp = {}
                a5.t["moveablerobot"].on = false
            end
        end
    )
    a5.p["custom_spawner"] = a5.add.p("Custom Vehicles", a5.p["custom_veh"]).id
    a5.t["spawn_preview"] =
        a5.add.t(
        "Preview Custom Vehicles",
        a5.p["custom_spawner"],
        function(k)
            if #aV["preview_veh"] > 0 and k.on then
                if ped.is_ped_in_any_vehicle(a4.ped()) then
                    ped.clear_ped_tasks_immediately(a4.ped())
                end
                local aF = a4.coords()
                if not bb then
                    for i = 1, #aV["preview_veh"] do
                        entity.set_entity_no_collsion_entity(aV["preview_veh"][i], a4.ped(), true)
                    end
                    bb = true
                end
                aF.z = aF.z + ba
                local aH = a4.heading()
                aF = c9(aF, aH, bc)
                bJ(aV["preview_veh"][1], aF)
                entity.set_entity_rotation(aV["preview_veh"][1], bd)
                bd.z = bd.z + 1
                if bd.z > 360 then
                    bd.z = 0
                end
            end
            if not k.on then
                bL(aV["preview_veh"])
                aV["preview_veh"] = {}
                bb = false
                return HANDLER_POP
            end
            return d.stop(k)
        end
    )
    a5.add.a(
        "Delete Custom Vehicles",
        a5.p["custom_spawner"],
        function()
            x("Clearing Custom Vehicles.")
            bL(aV["custom_veh"])
            aV["custom_veh"] = {}
            bL(aV["preview_veh"])
            aV["preview_veh"] = {}
            bb = false
            u("Cleared Custom Vehicles.")
        end
    )
    for i = 1, #C.custom_vehicles do
        a5.add.a(
            C.custom_vehicles[i][1],
            a5.p["custom_spawner"],
            function()
                local bX = C.custom_vehicles[i][2]
                cy(bX)
            end
        )
    end
    a5.p["custom_veh_opt"] = a5.add.p("Options", a5.p["custom_veh"]).id
    a5.t["auto_get_in"] =
        a5.add.t(
        "Spawn in Custom Vehicle",
        a5.p["custom_veh_opt"],
        function(k)
            r["spawn_in_vehicle"] = k.on
        end
    )
    a5.t["auto_get_in"].on = r["spawn_in_vehicle"]
    a5.t["use_own_veh"] =
        a5.add.t(
        "Use Own Vehicle for Custom ones",
        a5.p["custom_veh_opt"],
        function(k)
            r["use_own_veh"] = k.on
        end
    )
    a5.t["use_own_veh"].on = r["use_own_veh"]
    a5.t["set_godmode"] =
        a5.add.t(
        "Godmode on Custom Vehicles",
        a5.p["custom_veh_opt"],
        function(k)
            r["set_godmode"] = k.on
        end
    )
    a5.t["set_godmode"].on = r["set_godmode"]
    a5.t["disable_tampa_notify"] =
        a5.add.t(
        "Disable Moveable Robot Tampa Notify",
        a5.p["custom_veh_opt"],
        function(k)
            r["disable_tampa_notify"] = k.on
        end
    )
    a5.t["disable_tampa_notify"].on = r["disable_tampa_notify"]
    a5.p["custom_veh_builder"] = a5.add.p("Custom Vehicle Creator", a5.p["custom_veh"])
    a5.p["custom_veh_builder"].hidden = true
    local dy = {
        {
            "WarMachine",
            {
                {0x9dae1398, 1030400667, 0x2F03547B, 2971578861, 3871829598, 3229200997, 0x187D938D, 782665360},
                {0x9dae1398, nil, nil, {0, 0, 0, 0, 1}, nil, nil, nil, nil, nil, nil, 15},
                {1030400667, {0, -4, 0}, nil, {0, 0, 0, 0, 1}},
                {0x2F03547B, {0, -8, 4}, {-90, 0, 0}, {0, 0, 0, 0, 1}, false, nil, nil, nil, 0x97F5FE8D, true},
                {2971578861, {-0.3, -0.6, 9.8}, {-90, 0, 0}, nil, nil, nil, 16, 3},
                {3229200997, {0, 0, 9.8}, {-90, 0, 0}, nil, nil, nil, 16, 3},
                {0x187D938D, {0, -8.25, 5.3}, nil, {0, 0, 0, 0, 1}},
                {782665360, {0, -8, 3.1}, nil, {0, 0, 0, 0, 1}}
            }
        },
        {
            "Deer Rider",
            {
                {0xE5BA6858},
                {0xE5BA6858, nil, nil, {0, 0, 0, 0, 1}, true, nil, nil, nil, nil, nil, 3},
                {0, {0, -0.225, 0.225}, nil, nil, nil, nil, nil, nil, 0xD86B5A95}
            }
        },
        {"Attach Tree", {{3015194288}, {0}, {3015194288, {0, 0, -0.3}}}},
        {
            "XXL Plane 2",
            {
                {0x39D6E83F, 0xFB133A17, 0x3D6AAA9B, 0x810369E2, 0xD577C962},
                {0x39D6E83F, nil, nil, {0, 0, 0, 0, 1}},
                {0xFB133A17, {13, 0, 0}, {90, 0, 180}, {0, 0, 0, 0, 1}, false, nil, nil, nil, 0x97F5FE8D, true},
                {0xFB133A17, {35, 0, 0}, {90, 0, 180}, {0, 0, 0, 0, 1}, false, nil, nil, nil, 0x97F5FE8D, true},
                {0xFB133A17, {-13, 0, 0}, {90, 0, 180}, {0, 0, 0, 0, 1}, false, nil, nil, nil, 0x97F5FE8D, true},
                {0xFB133A17, {-35, 0, 0}, {90, 0, 180}, {0, 0, 0, 0, 1}, false, nil, nil, nil, 0x97F5FE8D, true},
                {0x3D6AAA9B, {-13, -3.5, 0}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {-35, -3.5, 0}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {13, -3.5, 0}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {35, -3.5, 0}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {27.5, -0.5, 0}, {0, -90, -90}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {27.5, -2.8, 0}, {0, 90, -90}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {12.4, -0.5, 0}, {0, 90, 90}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {12.4, -2.8, 0}, {0, -90, 90}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {-27.5, -0.5, 0}, {0, 90, 90}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {-27.5, -2.8, 0}, {0, -90, 90}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {-12.4, -0.5, 0}, {0, -90, -90}, {0, 0, 0, 0, 1}},
                {0x3D6AAA9B, {-12.4, -2.8, 0}, {0, 90, -90}, {0, 0, 0, 0, 1}},
                {0x810369E2, {0, 2, -1}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0xD577C962, {3.5, -4, -0.5}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0xD577C962, {-3.5, -4, -0.5}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0xD577C962, {0, 0, 0}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0xD577C962, {0, 0, 0}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0xD577C962, {0, 0, 0}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0xD577C962, {0, 0, 0}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0xD577C962, {0, 0, 0}, {0, 0, 0}, {0, 0, 0, 0, 1}},
                {0xD577C962, {0, 0, 0}, {0, 0, 0}, {0, 0, 0, 0, 1}}
            }
        }
    }
    a5.add.a(
        "Delete Custom Vehicles",
        a5.p["custom_veh_builder"].id,
        function()
            x("Clearing Custom Vehicles.")
            bL(aV["vehicle_builder"])
            aV["vehicle_builder"] = {}
            u("Cleared Custom Vehicles.")
        end
    )
    for i = 1, #dy do
        a5.add.a(
            dy[i][1],
            a5.p["custom_veh_builder"].id,
            function()
                local bX = dy[i][2]
                cy(bX, "vehicle_builder")
            end
        )
    end
    local dz, dA, dB, dC, dD, dE, dF, dG
    dz =
        a5.add.u(
        "Select Vehicle",
        "autoaction_value_i",
        a5.p["custom_veh_builder"].id,
        function()
            dB.value_i = 0
            dC.value_i = 0
            dD.value_i = 0
            dE.value_i = 0
            dF.value_i = 0
            dG.value_i = 0
        end
    )
    dz.min_i = 2
    dz.max_i = 250
    dA =
        a5.add.u(
        "Attach To BoneID",
        "autoaction_value_i",
        a5.p["custom_veh_builder"].id,
        function(k)
            local bO = v3(dB.value_i / 10, dC.value_i / 10, dD.value_i / 10)
            local dH = v3(dE.value_i, dF.value_i, dG.value_i)
            local cv = aV["vehicle_builder"][1]
            local dI = aV["vehicle_builder"][dz.value_i]
            if cv and dI then
                a2.ctrl(cv)
                a2.ctrl(dI)
                c.attach(dI, cv, dA.value_i, bO, dH, false, false, false, 2, true)
            end
        end
    )
    dA.min_i = 0
    dA.max_i = 100
    dB =
        a5.add.u(
        "Offset X",
        "autoaction_value_i",
        a5.p["custom_veh_builder"].id,
        function(k)
            local bO = v3(k.value_i / 10, dC.value_i / 10, dD.value_i / 10)
            local dH = v3(dE.value_i, dF.value_i, dG.value_i)
            local cv = aV["vehicle_builder"][1]
            local dI = aV["vehicle_builder"][dz.value_i]
            if cv and dI then
                a2.ctrl(cv)
                a2.ctrl(dI)
                c.attach(dI, cv, dA.value_i, bO, dH, false, false, false, 2, true)
            end
        end
    )
    dB.min_i = -500
    dB.max_i = 500
    dC =
        a5.add.u(
        "Offset Y",
        "autoaction_value_i",
        a5.p["custom_veh_builder"].id,
        function(k)
            local bO = v3(dB.value_i / 10, k.value_i / 10, dD.value_i / 10)
            local dH = v3(dE.value_i, dF.value_i, dG.value_i)
            local cv = aV["vehicle_builder"][1]
            local dI = aV["vehicle_builder"][dz.value_i]
            if cv and dI then
                a2.ctrl(cv)
                a2.ctrl(dI)
                c.attach(dI, cv, dA.value_i, bO, dH, false, false, false, 2, true)
            end
        end
    )
    dC.min_i = -500
    dC.max_i = 500
    dD =
        a5.add.u(
        "Offset Z",
        "autoaction_value_i",
        a5.p["custom_veh_builder"].id,
        function(k)
            local bO = v3(dB.value_i / 10, dC.value_i / 10, k.value_i / 10)
            local dH = v3(dE.value_i, dF.value_i, dG.value_i)
            local cv = aV["vehicle_builder"][1]
            local dI = aV["vehicle_builder"][dz.value_i]
            if cv and dI then
                a2.ctrl(cv)
                a2.ctrl(dI)
                c.attach(dI, cv, dA.value_i, bO, dH, false, false, false, 2, true)
            end
        end
    )
    dD.min_i = -500
    dD.max_i = 500
    dE =
        a5.add.u(
        "Rotation X",
        "autoaction_value_i",
        a5.p["custom_veh_builder"].id,
        function(k)
            local bO = v3(dB.value_i / 10, dC.value_i / 10, dD.value_i / 10)
            local dH = v3(k.value_i, dF.value_i, dG.value_i)
            local cv = aV["vehicle_builder"][1]
            local dI = aV["vehicle_builder"][dz.value_i]
            if cv and dI then
                a2.ctrl(cv)
                a2.ctrl(dI)
                c.attach(dI, cv, dA.value_i, bO, dH, false, false, false, 2, true)
            end
        end
    )
    dE.min_i = -360
    dE.max_i = 360
    dF =
        a5.add.u(
        "Rotation Y",
        "autoaction_value_i",
        a5.p["custom_veh_builder"].id,
        function(k)
            local bO = v3(dB.value_i / 10, dC.value_i / 10, dD.value_i / 10)
            local dH = v3(dE.value_i, k.value_i, dG.value_i)
            local cv = aV["vehicle_builder"][1]
            local dI = aV["vehicle_builder"][dz.value_i]
            if cv and dI then
                a2.ctrl(cv)
                a2.ctrl(dI)
                c.attach(dI, cv, dA.value_i, bO, dH, false, false, false, 2, true)
            end
        end
    )
    dF.min_i = -360
    dF.max_i = 360
    dG =
        a5.add.u(
        "Rotation Z",
        "autoaction_value_i",
        a5.p["custom_veh_builder"].id,
        function(k)
            local bO = v3(dB.value_i / 10, dC.value_i / 10, dD.value_i / 10)
            local dH = v3(dE.value_i, dF.value_i, k.value_i)
            local cv = aV["vehicle_builder"][1]
            local dI = aV["vehicle_builder"][dz.value_i]
            if cv and dI and cv ~= dI then
                a2.ctrl(cv)
                a2.ctrl(dI)
                c.attach(dI, cv, dA.value_i, bO, dH, false, false, false, 2, true)
            end
        end
    )
    dG.min_i = -360
    dG.max_i = 360
    a5.p["exp_beam"] = a5.add.p("Explosive Beam on Horn", a5.p["parent"])
    a5.p["exp_beam"].hidden = r["explosive_beam_hidden"]
    a5.p["exp_beam"] = a5.p["exp_beam"].id
    a5.t["exp_beam"] =
        a5.add.t(
        "Enable Beam on Horn",
        a5.p["exp_beam"],
        function(k)
            r["exp_beam"] = k.on
            if k.on then
                local dJ = c.id()
                if D.scid(a5.t["exp_beam_other"].value_i) ~= -1 then
                    dJ = a5.t["exp_beam_other"].value_i
                end
                local d5 = c.ped(dJ)
                local ac, aF, b_, dK, dL
                local dM = v3()
                local dN, dO, dP, dQ, dR, dS
                if player.is_player_pressing_horn(dJ) then
                    ac = c.vehicle(d5)
                    for i = 0, 5 do
                        aF = c.gcoords(ac)
                        c.wait(5)
                        if i > 0 then
                            b_ = c.gcoords(ac)
                            dM.x = b_.x - aF.x
                            dM.y = b_.y - aF.y
                            dM.z = b_.z - aF.z
                            if dM.x ~= 0 and dM.y ~= 0 and dM.z ~= 0 then
                                dK = 1 / (dM.x * dM.x + dM.y * dM.y + dM.z * dM.z) ^ 0.5
                                dL = c.random(r["exp_beam_min"], r["exp_beam_max"])
                                b_.x = b_.x + dL * dK * dM.x
                                b_.y = b_.y + dL * dK * dM.y
                                b_.z = b_.z + dL * dK * dM.z
                                dN = math.floor(b_.x - r["exp_beam_radius"])
                                dO = math.floor(b_.x + r["exp_beam_radius"])
                                dP = math.floor(b_.y - r["exp_beam_radius"])
                                dQ = math.floor(b_.y + r["exp_beam_radius"])
                                dR = math.floor(b_.z - r["exp_beam_radius"])
                                dS = math.floor(b_.z + r["exp_beam_radius"])
                                b_.x = c.random(dN, dO)
                                b_.y = c.random(dP, dQ)
                                b_.z = c.random(dR, dS)
                                c.explode(b_, r["exp_beam_type"], true, false, 0.1, d5)
                                b_.x = c.random(dN, dO)
                                b_.y = c.random(dP, dQ)
                                b_.z = c.random(dR, dS)
                                c.explode(b_, r["exp_beam_type_2"], true, false, 0.1, d5)
                            end
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    a5.t["exp_beam"].on = r["exp_beam"]
    a5.t["exp_beam_type"] =
        a5.add.u(
        "Select Explosion",
        "action_value_i",
        a5.p["exp_beam"],
        function()
            r["exp_beam_type"] = a5.t["exp_beam_type"].value_i
            u("Beam Explosion Type 1: " .. r["exp_beam_type"])
        end
    )
    a5.t["exp_beam_type"].max_i = 74
    a5.t["exp_beam_type"].min_i = 0
    a5.t["exp_beam_type"].value_i = r["exp_beam_type"]
    a5.t["exp_beam_type_2"] =
        a5.add.u(
        "Select Explosion 2",
        "action_value_i",
        a5.p["exp_beam"],
        function()
            r["exp_beam_type_2"] = a5.t["exp_beam_type_2"].value_i
            u("Beam Explosion Type 2: " .. r["exp_beam_type_2"])
        end
    )
    a5.t["exp_beam_type_2"].max_i = 74
    a5.t["exp_beam_type_2"].min_i = 0
    a5.t["exp_beam_type_2"].value_i = r["exp_beam_type_2"]
    a5.t["exp_beam_radius"] =
        a5.add.u(
        "Select Scattering",
        "action_value_i",
        a5.p["exp_beam"],
        function()
            r["exp_beam_radius"] = a5.t["exp_beam_radius"].value_i
            u("Beam Radius: " .. r["exp_beam_radius"])
        end
    )
    a5.t["exp_beam_radius"].max_i = 10
    a5.t["exp_beam_radius"].min_i = 1
    a5.t["exp_beam_radius"].value_i = r["exp_beam_radius"]
    a5.t["exp_beam_min"] =
        a5.add.u(
        "Select Min Range",
        "action_value_i",
        a5.p["exp_beam"],
        function()
            r["exp_beam_min"] = a5.t["exp_beam_min"].value_i
            u("Beam Min Range: " .. r["exp_beam_min"])
        end
    )
    a5.t["exp_beam_min"].max_i = 100
    a5.t["exp_beam_min"].min_i = 10
    a5.t["exp_beam_min"].value_i = r["exp_beam_min"]
    a5.t["exp_beam_min"].mod_i = 5
    a5.t["exp_beam_max"] =
        a5.add.u(
        "Select Max Range",
        "action_value_i",
        a5.p["exp_beam"],
        function()
            r["exp_beam_max"] = a5.t["exp_beam_max"].value_i
            u("Beam Max Range: " .. r["exp_beam_max"])
        end
    )
    a5.t["exp_beam_max"].max_i = 300
    a5.t["exp_beam_max"].min_i = 100
    a5.t["exp_beam_max"].value_i = r["exp_beam_max"]
    a5.t["exp_beam_max"].mod_i = 5
    a5.t["exp_beam_other"] =
        a5.add.u(
        "Enable Horn for Player",
        "action_value_i",
        a5.p["exp_beam"],
        function()
            if D.scid(a5.t["exp_beam_other"].value_i) ~= -1 then
                u("Selected Player: " .. D.name(a5.t["exp_beam_other"].value_i))
            else
                u("Not a valid Player.")
            end
        end
    )
    a5.t["exp_beam_other"].max_i = 31
    a5.t["exp_beam_other"].min_i = -1
    a5.t["exp_beam_other"].value_i = -1
    a5.p["bac"] =
        a5.add.p(
        "Better Animal Changer",
        a5.p["parent"],
        function()
            if a5.t["revert_outfit"].on then
                if #aW["bac_outfit"]["clothes"] < 1 then
                    if player.get_player_model(c.id()) == 0x9C9EFFD8 or player.get_player_model(c.id()) == 0x705E61F2 then
                        for i = 1, 11 do
                            aW["bac_outfit"]["textures"][i] = ped.get_ped_texture_variation(a4.ped(), i)
                            aW["bac_outfit"]["clothes"][i] = ped.get_ped_drawable_variation(a4.ped(), i)
                        end
                        local av = {0, 1, 2, 6, 7}
                        for ay = 1, #av do
                            aW["bac_outfit"]["prop_ind"][ay] = ped.get_ped_prop_index(a4.ped(), av[ay])
                            aW["bac_outfit"]["prop_text"][ay] = ped.get_ped_prop_texture_index(a4.ped(), av[ay])
                        end
                        local D = "male"
                        if player.is_player_female(c.id()) then
                            D = "female"
                        end
                        aW["bac_outfit"]["gender"] = D
                    end
                end
            end
        end
    )
    a5.p["bac"].hidden = r["animal_changer_hidden"]
    a5.p["bac"] = a5.p["bac"].id
    a5.p["bac_ga"] = a5.add.p("Ground Animals", a5.p["bac"]).id
    a5.add.a(
        "Bigfoot",
        a5.p["bac_ga"],
        function()
            bR(0x61D4C771, nil, true, nil, true)
        end
    )
    a5.add.a(
        "Bigfoot 2",
        a5.p["bac_ga"],
        function()
            bR(0xAD340F5A, nil, true, nil, true)
        end
    )
    a5.add.a(
        "Boar",
        a5.p["bac_ga"],
        function()
            bR(0xCE5FF074)
        end
    )
    a5.add.a(
        "Cat",
        a5.p["bac_ga"],
        function()
            bR(0x573201B8)
        end
    )
    a5.add.a(
        "Chimp",
        a5.p["bac_ga"],
        function()
            bR(0xA8683715, nil, nil, true)
        end
    )
    a5.add.a(
        "Chop",
        a5.p["bac_ga"],
        function()
            bR(0x14EC17EA, nil, true)
        end
    )
    a5.add.a(
        "Cow",
        a5.p["bac_ga"],
        function()
            bR(0xFCFA9E1E)
        end
    )
    a5.add.a(
        "Coyote",
        a5.p["bac_ga"],
        function()
            bR(0x644AC75E)
        end
    )
    a5.add.a(
        "Deer",
        a5.p["bac_ga"],
        function()
            bR(0xD86B5A95)
        end
    )
    a5.add.a(
        "German Shepherd",
        a5.p["bac_ga"],
        function()
            bR(0x431FC24C, nil, true)
        end
    )
    a5.add.a(
        "Hen",
        a5.p["bac_ga"],
        function()
            bR(0x6AF51FAF)
        end
    )
    a5.add.a(
        "Husky",
        a5.p["bac_ga"],
        function()
            bR(0x4E8F95A2, nil, true)
        end
    )
    a5.add.a(
        "Mountain Lion",
        a5.p["bac_ga"],
        function()
            bR(0x1250D7BA, nil, true)
        end
    )
    a5.add.a(
        "Pig",
        a5.p["bac_ga"],
        function()
            bR(0xB11BAB56)
        end
    )
    a5.add.a(
        "Poodle",
        a5.p["bac_ga"],
        function()
            bR(0x431D501C)
        end
    )
    a5.add.a(
        "Pug",
        a5.p["bac_ga"],
        function()
            bR(0x6D362854)
        end
    )
    a5.add.a(
        "Rabbit",
        a5.p["bac_ga"],
        function()
            bR(0xDFB55C81)
        end
    )
    a5.add.a(
        "Rat",
        a5.p["bac_ga"],
        function()
            bR(0xC3B52966)
        end
    )
    a5.add.a(
        "Golden Retriever",
        a5.p["bac_ga"],
        function()
            bR(0x349F33E1, nil, true)
        end
    )
    a5.add.a(
        "Rhesus",
        a5.p["bac_ga"],
        function()
            bR(0xC2D06F53, nil, nil, true)
        end
    )
    a5.add.a(
        "Rottweiler",
        a5.p["bac_ga"],
        function()
            bR(0x9563221D, nil, true)
        end
    )
    a5.add.a(
        "Westy",
        a5.p["bac_ga"],
        function()
            bR(0xAD7844BB)
        end
    )
    a5.p["bac_wa"] =
        a5.add.p(
        "Water Animals",
        a5.p["bac"],
        function()
            u("Note that these Models will only work in Water!", 48)
        end
    ).id
    a5.add.a(
        "Dolphin",
        a5.p["bac_wa"],
        function()
            bR(0x8BBAB455, true)
        end
    )
    a5.add.a(
        "Fish",
        a5.p["bac_wa"],
        function()
            bR(0x2FD800B7, true)
        end
    )
    a5.add.a(
        "Hammershark",
        a5.p["bac_wa"],
        function()
            bR(0x3C831724, true)
        end
    )
    a5.add.a(
        "Humpback",
        a5.p["bac_wa"],
        function()
            bR(0x471BE4B2, true)
        end
    )
    a5.add.a(
        "Killerwhale",
        a5.p["bac_wa"],
        function()
            bR(0x8D8AC8B9, true)
        end
    )
    a5.add.a(
        "Shark",
        a5.p["bac_wa"],
        function()
            bR(0x06C3F072, true, true)
        end
    )
    a5.add.a(
        "Stingray",
        a5.p["bac_wa"],
        function()
            bR(0xA148614D, true)
        end
    )
    a5.p["bac_fa"] = a5.add.p("Flying Animals", a5.p["bac"]).id
    a5.add.a(
        "Cormorant",
        a5.p["bac_fa"],
        function()
            bR(0x56E29962)
        end
    )
    a5.add.a(
        "Chickenhawk",
        a5.p["bac_fa"],
        function()
            bR(0xAAB71F62)
        end
    )
    a5.add.a(
        "Crow",
        a5.p["bac_fa"],
        function()
            bR(0x18012A9F)
        end
    )
    a5.add.a(
        "Pigeon",
        a5.p["bac_fa"],
        function()
            bR(0x06A20728)
        end
    )
    a5.add.a(
        "Seagull",
        a5.p["bac_fa"],
        function()
            bR(0xD3939DFD)
        end
    )
    a5.p["bac_sm"] = a5.add.p("Standard Models", a5.p["bac"]).id
    a5.add.a(
        "Franklin",
        a5.p["bac_sm"],
        function()
            bR(0x9B22DBAF, nil, nil, nil, true)
        end
    )
    a5.add.a(
        "Michael",
        a5.p["bac_sm"],
        function()
            bR(0x0D7114C9, nil, nil, nil, true)
        end
    )
    a5.add.a(
        "Trevor",
        a5.p["bac_sm"],
        function()
            bR(0x9B810FA2, nil, nil, nil, true)
        end
    )
    a5.add.a(
        "MP Female",
        a5.p["bac_sm"],
        function()
            bR(0x9C9EFFD8, nil, true, nil, true)
        end
    )
    a5.add.a(
        "MP Male",
        a5.p["bac_sm"],
        function()
            bR(0x705E61F2, nil, true, nil, true)
        end
    )
    a5.t["bl_mdl_change"] =
        a5.add.t(
        "Safe Model Change",
        a5.p["bac"],
        function(k)
            r["bl_mdl_change"] = k.on
        end
    )
    a5.t["bl_mdl_change"].on = r["bl_mdl_change"]
    a5.t["revert_outfit"] =
        a5.add.t(
        "Revert back Outfit",
        a5.p["bac"],
        function(k)
            r["revert_outfit"] = k.on
        end
    )
    a5.t["revert_outfit"].on = r["revert_outfit"]
    a5.add.a(
        "Fix endless loading Screen",
        a5.p["bac"],
        function()
            bR(0x9B22DBAF, nil, nil, nil, true)
            c.wait(100)
            ped.set_ped_health(a4.ped(), 0)
        end
    )
    a5.p["ptfx"] = a5.add.p("PTFX", a5.p["parent"])
    a5.p["ptfx"].hidden = r["ptfx_hidden"]
    a5.p["ptfx"] = a5.p["ptfx"].id
    a5.t["sparkling_ass"] =
        a5.add.t(
        "Sparkling Ass",
        a5.p["ptfx"],
        function(k)
            if k.on then
                graphics.set_next_ptfx_asset("scr_indep_fireworks")
                while not graphics.has_named_ptfx_asset_loaded("scr_indep_fireworks") do
                    graphics.request_named_ptfx_asset("scr_indep_fireworks")
                    c.wait(0)
                end
                graphics.start_networked_particle_fx_non_looped_at_coord(
                    "scr_indep_firework_trail_spawn",
                    a4.coords(),
                    v3(60, 0, 0),
                    0.33,
                    true,
                    true,
                    true
                )
                c.wait(25)
            end
            r["sparkling_ass"] = k.on
            return d.stop(k)
        end
    )
    a5.t["sparkling_ass"].on = r["sparkling_ass"]
    a5.t["sparkling_tires"] =
        a5.add.t(
        "Sparkling Tires",
        a5.p["ptfx"],
        function(k)
            if k.on then
                local ac = c.vehicle(a4.ped())
                if ac ~= 0 then
                    local dT = {"wheel_lf", "wheel_rf", "wheel_lr", "wheel_rr"}
                    for i = 1, #dT do
                        a2.model(1803116220)
                        local dU = aD.object(1803116220, a4.coords())
                        entity.set_entity_collision(dU, false, false, false)
                        c.visible(dU, false)
                        local q = entity.get_entity_bone_index_by_name(ac, dT[i])
                        c.attach(dU, ac, q, v3(), v3(), true, true, false, 0, true)
                        graphics.set_next_ptfx_asset("scr_indep_fireworks")
                        while not graphics.has_named_ptfx_asset_loaded("scr_indep_fireworks") do
                            graphics.request_named_ptfx_asset("scr_indep_fireworks")
                            c.wait(0)
                        end
                        graphics.start_networked_particle_fx_non_looped_at_coord(
                            "scr_indep_firework_trail_spawn",
                            c.gcoords(dU),
                            v3(60, 0, 0),
                            0.5,
                            true,
                            true,
                            true
                        )
                        a2.ctrl(dU, 5)
                        entity.detach_entity(dU)
                        entity.set_entity_velocity(dU, v3())
                        bJ(dU, v3(8000, 8000, -1000))
                        entity.delete_entity(dU)
                    end
                    c.unload(1803116220)
                    c.wait(25)
                end
            end
            r["sparkling_tires"] = k.on
            return d.stop(k)
        end
    )
    a5.t["sparkling_tires"].on = r["sparkling_tires"]
    a5.t["smoke_area"] =
        a5.add.t(
        "Smoke Area",
        a5.p["ptfx"],
        function(k)
            if k.on then
                for i = 1, 16 do
                    local aF = a4.coords()
                    local dV = 2 * math.pi
                    dV = dV / 16
                    dV = dV * i
                    aF.x = aF.x + 18 * math.cos(dV)
                    aF.y = aF.y + 18 * math.sin(dV)
                    aF.z = aF.z - 2.5
                    graphics.set_next_ptfx_asset("scr_recartheft")
                    while not graphics.has_named_ptfx_asset_loaded("scr_recartheft") do
                        graphics.request_named_ptfx_asset("scr_recartheft")
                        c.wait(0)
                    end
                    graphics.start_networked_particle_fx_non_looped_at_coord(
                        "scr_wheel_burnout",
                        aF,
                        v3(),
                        2.5,
                        true,
                        true,
                        true
                    )
                    c.wait(40)
                end
            end
            r["smoke_area"] = k.on
            return d.stop(k)
        end
    )
    a5.t["smoke_area"].on = r["smoke_area"]
    a5.t["fire_circle"] =
        a5.add.t(
        "Fire Circle",
        a5.p["ptfx"],
        function(k)
            if k.on then
                if bI["fire_balls"][1] == nil then
                    for i = 1, 48 do
                        a2.model(1803116220)
                        bI["fire_balls"][i] = aD.object(1803116220, a4.coords())
                        entity.set_entity_collision(bI["fire_balls"][i], false, false, false)
                        c.visible(bI["fire_balls"][i], false)
                    end
                    c.unload(1803116220)
                end
                for i = 1, 48 do
                    local aF = a4.coords()
                    local dV = 2 * math.pi
                    dV = dV / 48
                    dV = dV * c.random(1, 64)
                    aF.x = aF.x + 10 * math.cos(dV)
                    aF.y = aF.y + 10 * math.sin(dV)
                    aF.z = aF.z - 1.5
                    bJ(bI["fire_balls"][i], aF)
                end
                c.wait(10)
                if bI["fire_circle"][1] == nil then
                    for i = 1, 48 do
                        graphics.set_next_ptfx_asset("weap_xs_vehicle_weapons")
                        while not graphics.has_named_ptfx_asset_loaded("weap_xs_vehicle_weapons") do
                            graphics.request_named_ptfx_asset("weap_xs_vehicle_weapons")
                            c.wait(0)
                        end
                        bI["fire_circle"][i] =
                            graphics.start_ptfx_looped_on_entity(
                            "muz_xs_turret_flamethrower_looping",
                            bI["fire_balls"][i],
                            v3(),
                            v3(90, 0, 0),
                            1
                        )
                    end
                end
            end
            if not k.on then
                bL(bI["fire_balls"])
                bI["fire_balls"] = {}
                if bI["fire_circle"][1] then
                    for i = 1, #bI["fire_circle"] do
                        graphics.remove_particle_fx(bI["fire_circle"][i], true)
                    end
                    bI["fire_circle"] = {}
                end
            end
            return d.stop(k)
        end
    )
    a5.t["fire_circle"].on = r["fire_circle"]
    a5.t["fire_fart"] =
        a5.add.u(
        "Fire Fart",
        "action_value_i",
        a5.p["ptfx"],
        function(k)
            r["fire_fart"] = a5.t["fire_fart"].value_i
            local ac = c.vehicle(a4.ped())
            if ac ~= 0 then
                u("Fire Fart in a vehicle is too dangerous, get out!", 162)
            else
                local aE = 0x187D938D
                local dW = "weap_xs_vehicle_weapons"
                local dX = "muz_xs_turret_flamethrower_looping"
                a2.model(aE)
                local aH = a4.heading()
                local da = aD.vehicle(aE, a4.coords(), aH)
                a2.ctrl(da)
                c.visible(da, false)
                c.unload(aE)
                decorator.decor_set_int(da, "MPBitset", 1 << 10)
                ped.set_ped_into_vehicle(a4.ped(), da, -1)
                c.wait(500)
                graphics.set_next_ptfx_asset(dW)
                while not graphics.has_named_ptfx_asset_loaded(dW) do
                    graphics.request_named_ptfx_asset(dW)
                    c.wait(0)
                end
                local dY = k.value_i
                local fire = graphics.start_ptfx_looped_on_entity(dX, a4.ped(), v3(), v3(180, 0, 0), dY * 0.1)
                local aF = c.gcoords(da)
                local cz = entity.get_entity_rotation(da)
                local dd = cz
                dd:transformRotToDir()
                dd = dd * 1 * dY
                dd.z = aF.z + 0.6666666 * dY
                local dZ = dd
                entity.set_entity_velocity(da, dZ)
                c.wait(250 * dY)
                graphics.remove_particle_fx(fire, true)
                while ped.is_ped_in_any_vehicle(a4.ped()) do
                    ai.task_leave_vehicle(a4.ped(), da, 16)
                    c.wait(25)
                end
                bL({da})
            end
        end
    )
    a5.t["fire_fart"].max_i = 16
    a5.t["fire_fart"].min_i = 4
    a5.t["fire_fart"].value_i = r["fire_fart"]
    a5.t["fire_ass"] =
        a5.add.t(
        "Fire Ass",
        a5.p["ptfx"],
        function(k)
            r["fire_ass"] = k.on
            if k.on then
                if bI["fire_ass_ball"] == nil then
                    a2.model(1803116220)
                    bI["fire_ass_ball"] = aD.object(1803116220, a4.coords())
                    entity.set_entity_collision(bI["fire_ass_ball"], false, false, false)
                    c.visible(bI["fire_ass_ball"], false)
                    c.unload(1803116220)
                end
                if bI["fire_ass"] == nil then
                    local dW = "weap_xs_vehicle_weapons"
                    local dX = "muz_xs_turret_flamethrower_looping"
                    graphics.set_next_ptfx_asset(dW)
                    while not graphics.has_named_ptfx_asset_loaded(dW) do
                        graphics.request_named_ptfx_asset(dW)
                        c.wait(0)
                    end
                    bI["fire_ass"] = graphics.start_ptfx_looped_on_entity(dX, a4.ped(), v3(), v3(180, 0, 0), 0.333)
                end
                local aF = a4.coords()
                bJ(bI["fire_ass_ball"], a4.coords())
            end
            if not k.on then
                if bI["fire_ass"] then
                    graphics.remove_particle_fx(bI["fire_ass"], true)
                    bI["fire_ass"] = nil
                end
                bL({bI["fire_ass_ball"]})
                bI["fire_ass_ball"] = nil
            end
            return d.stop(k)
        end
    )
    a5.t["fire_ass"].on = r["fire_ass"]
    a5.p["misc"] = a5.add.p("Miscellaneous", a5.p["parent"])
    a5.p["misc"].hidden = r["misc_hidden"]
    a5.p["misc"] = a5.p["misc"].id
    a5.p["weapon"] = a5.add.p("Weapon-Features", a5.p["misc"]).id
    a5.t["load_weapons"] =
        a5.add.t(
        "Load Weapons",
        a5.p["weapon"],
        function(k)
            if k.on then
                local time = c.time() + 500
                while k.on do
                    c.wait(0)
                    if time < c.time() then
                        break
                    end
                end
                local d_ = weapon.get_all_weapon_hashes()
                for i = 1, #d_ do
                    if weapon.has_ped_got_weapon(a4.ped(), d_[i]) then
                        local e0 = false
                        for Z = 1, #C.weapons do
                            if d_[i] == C.weapons[Z][1] then
                                e0 = true
                            end
                        end
                        if not e0 then
                            weapon.remove_weapon_from_ped(a4.ped(), d_[i])
                        end
                    end
                end
                for i = 1, #C.weapons do
                    if not weapon.has_ped_got_weapon(a4.ped(), C.weapons[i][1]) then
                        weapon.give_delayed_weapon_to_ped(a4.ped(), C.weapons[i][1], 0, 0)
                    end
                end
                for i = 1, #C.weapons do
                    for cK = 2, #C.weapons[i] do
                        if not weapon.has_ped_got_weapon_component(a4.ped(), C.weapons[i][1], C.weapons[i][cK]) then
                            for cV = 2, #C.weapons[i] do
                                weapon.give_weapon_component_to_ped(a4.ped(), C.weapons[i][1], C.weapons[i][cV])
                            end
                            weapon.set_ped_ammo(a4.ped(), C.weapons[i][1], 9999)
                        end
                    end
                end
            end
            r["load_weapons"] = k.on
            return d.stop(k)
        end
    )
    a5.t["load_weapons"].on = r["load_weapons"]
    a5.p["flamethrower"] = a5.add.p("Flamethrower", a5.p["weapon"]).id
    a5.t["flamethrower_scale"] =
        a5.add.u(
        "Scale",
        "autoaction_value_i",
        a5.p["flamethrower"],
        function()
            r["flamethrower_scale"] = a5.t["flamethrower_scale"].value_i
        end
    )
    a5.t["flamethrower_scale"].min_i = 1
    a5.t["flamethrower_scale"].max_i = 25
    a5.t["flamethrower_scale"].value_i = r["flamethrower_scale"]
    a5.t["flamethrower"] =
        a5.add.t(
        "Flamethrower",
        a5.p["flamethrower"],
        function(k)
            if k.on then
                if player.is_player_free_aiming(c.id()) then
                    graphics.set_next_ptfx_asset("weap_xs_vehicle_weapons")
                    while not graphics.has_named_ptfx_asset_loaded("weap_xs_vehicle_weapons") do
                        graphics.request_named_ptfx_asset("weap_xs_vehicle_weapons")
                        c.wait(0)
                    end
                    if bI["alien"] == nil then
                        a2.model(1803116220)
                        bI["alien"] = aD.object(1803116220, a4.coords())
                        entity.set_entity_collision(bI["alien"], false, false, false)
                        c.visible(bI["alien"], false)
                        c.unload(1803116220)
                    end
                    local e1, e2 = ped.get_ped_bone_coords(a4.ped(), 0xdead, v3())
                    while not e1 do
                        c.wait(0)
                        e1, e2 = ped.get_ped_bone_coords(a4.ped(), 0xdead, v3())
                    end
                    bJ(bI["alien"], e2)
                    entity.set_entity_rotation(bI["alien"], cam.get_gameplay_cam_rot())
                    if bI["flamethrower"] == nil then
                        bI["flamethrower"] =
                            graphics.start_ptfx_looped_on_entity(
                            "muz_xs_turret_flamethrower_looping",
                            bI["alien"],
                            v3(),
                            v3(),
                            r["flamethrower_scale"]
                        )
                        graphics.set_particle_fx_looped_scale(bI["flamethrower"], r["flamethrower_scale"])
                    end
                else
                    if bI["flamethrower"] then
                        graphics.remove_particle_fx(bI["flamethrower"], true)
                        bI["flamethrower"] = nil
                        bL({bI["alien"]})
                        bI["alien"] = nil
                    end
                end
            end
            if not k.on then
                if bI["flamethrower"] then
                    graphics.remove_particle_fx(bI["flamethrower"], true)
                    bI["flamethrower"] = nil
                    bL({bI["alien"]})
                    bI["alien"] = nil
                end
            end
            r["flamethrower"] = k.on
            return d.stop(k)
        end
    )
    a5.t["flamethrower"].on = r["flamethrower"]
    a5.t["flamethrower_green"] =
        a5.add.t(
        "Flamethrower - Green",
        a5.p["flamethrower"],
        function(k)
            if k.on then
                if player.is_player_free_aiming(c.id()) then
                    graphics.set_next_ptfx_asset("weap_xs_vehicle_weapons")
                    while not graphics.has_named_ptfx_asset_loaded("weap_xs_vehicle_weapons") do
                        graphics.request_named_ptfx_asset("weap_xs_vehicle_weapons")
                        c.wait(0)
                    end
                    if bI["alien"] == nil then
                        a2.model(1803116220)
                        bI["alien"] = aD.object(1803116220, a4.coords())
                        entity.set_entity_collision(bI["alien"], false, false, false)
                        c.visible(bI["alien"], false)
                        c.unload(1803116220)
                    end
                    local e1, e2 = ped.get_ped_bone_coords(a4.ped(), 0xdead, v3())
                    while not e1 do
                        c.wait(0)
                        e1, e2 = ped.get_ped_bone_coords(a4.ped(), 0xdead, v3())
                    end
                    bJ(bI["alien"], e2)
                    entity.set_entity_rotation(bI["alien"], cam.get_gameplay_cam_rot())
                    if bI["flamethrower_green"] == nil then
                        bI["flamethrower_green"] =
                            graphics.start_ptfx_looped_on_entity(
                            "muz_xs_turret_flamethrower_looping_sf",
                            bI["alien"],
                            v3(),
                            v3(),
                            r["flamethrower_scale"]
                        )
                    end
                else
                    if bI["flamethrower_green"] then
                        graphics.remove_particle_fx(bI["flamethrower_green"], true)
                        bI["flamethrower_green"] = nil
                        bL({bI["alien"]})
                        bI["alien"] = nil
                    end
                end
            end
            if not k.on then
                if bI["flamethrower_green"] then
                    graphics.remove_particle_fx(bI["flamethrower_green"], true)
                    bI["flamethrower_green"] = nil
                    bL({bI["alien"]})
                    bI["alien"] = nil
                end
            end
            r["flamethrower_green"] = k.on
            return d.stop(k)
        end
    )
    a5.t["flamethrower_green"].on = r["flamethrower_green"]
    a5.p["shoot"] = a5.add.p("Shoot Objects", a5.p["weapon"]).id
    a5.t["shoot"] =
        a5.add.t(
        "Enable Object Shoot",
        a5.p["shoot"],
        function(k)
            if k.on then
                for i = 1, #aO do
                    if r[aO[i][1]] and ped.is_ped_shooting(a4.ped()) then
                        if #aV["shooting"] > 128 then
                            bL(aV["shooting"])
                            aV["shooting"] = {}
                        end
                        a2.model(aO[i][2])
                        local aF = a4.coords()
                        local dd = cam.get_gameplay_cam_rot()
                        dd:transformRotToDir()
                        dd = dd * 8
                        aF = aF + dd
                        if streaming.is_model_an_object(aO[i][2]) then
                            aV["shooting"][#aV["shooting"] + 1] = aD.object(aO[i][2], aF)
                        end
                        dd = nil
                        local e3 = a4.coords()
                        dd = cam.get_gameplay_cam_rot()
                        dd:transformRotToDir()
                        dd = dd * 100
                        e3 = e3 + dd
                        local dM = e3 - aF
                        entity.apply_force_to_entity(
                            aV["shooting"][#aV["shooting"]],
                            3,
                            dM.x,
                            dM.y,
                            dM.z,
                            0.0,
                            0.0,
                            0.0,
                            true,
                            true
                        )
                    end
                end
            end
            if not k.on then
                bL(aV["shooting"])
                aV["shooting"] = {}
            end
            r["shoot_entitys"] = k.on
            return d.stop(k)
        end
    )
    a5.t["shoot"].on = r["shoot_entitys"]
    a5.add.a(
        "Delete Objects",
        a5.p["shoot"],
        function()
            bL(aV["shooting"])
            aV["shooting"] = {}
        end
    )
    for i = 1, #aO do
        a5.t[aO[i][1]] =
            a5.add.t(
            "Shoot " .. aO[i][1],
            a5.p["shoot"],
            function(k)
                aO[i][3] = k.on
                r[aO[i][1]] = k.on
            end
        )
        a5.t[aO[i][1]].on = r[aO[i][1]]
    end
    a5.t["delete_gun"] =
        a5.add.t(
        "Delete Gun",
        a5.p["weapon"],
        function(k)
            if k.on then
                if ped.is_ped_shooting(a4.ped()) then
                    local e4 = player.get_entity_player_is_aiming_at(c.id())
                    if e4 then
                        bL({e4})
                    end
                end
            end
            r["delete_gun"] = k.on
            return d.stop(k)
        end
    )
    a5.t["delete_gun"].on = r["delete_gun"]
    a5.t["kick_gun"] =
        a5.add.t(
        "Kick Gun",
        a5.p["weapon"],
        function(k)
            if k.on then
                if ped.is_ped_shooting(a4.ped()) then
                    local e5 = player.get_entity_player_is_aiming_at(c.id())
                    if ped.is_ped_a_player(e5) then
                        u("Kick-Gun hit: " .. D.name(e5))
                        bV(false, player.get_player_from_ped(e5))
                    end
                end
            end
            r["kick_gun"] = k.on
            return d.stop(k)
        end
    )
    a5.t["kick_gun"].on = r["kick_gun"]
    a5.t["demigod_gun"] =
        a5.add.t(
        "Give Demi-God for Player",
        a5.p["weapon"],
        function(k)
            if k.on then
                if ped.is_ped_shooting(a4.ped()) then
                    local e5 = player.get_entity_player_is_aiming_at(c.id())
                    if ped.is_ped_a_player(e5) then
                        u("Attached Demi-God on Player: " .. D.name(e5))
                        bW(C.custom_attachments[1][2], player.get_player_from_ped(e5))
                    end
                end
            end
            r["demigod_gun"] = k.on
            return d.stop(k)
        end
    )
    a5.t["demigod_gun"].on = r["demigod_gun"]
    a5.p["model_gun"] = a5.add.p("Model Gun", a5.p["weapon"]).id
    a5.t["model_gun"] =
        a5.add.t(
        "Standard Model Gun (PEDs)",
        a5.p["model_gun"],
        function(k)
            if k.on then
                if bw then
                    c.visible(a4.ped(), false)
                    if bv then
                        c.visible(bv, true)
                    end
                else
                    c.visible(a4.ped(), true)
                end
                if player.is_player_free_aiming(c.id()) then
                    local e6 = player.get_entity_player_is_aiming_at(c.id())
                    if e6 ~= 0 then
                        e6 = entity.get_entity_model_hash(e6)
                        if streaming.is_model_a_ped(e6) then
                            if bv then
                                bL({bv})
                                bv = nil
                            end
                            local e7 = entity.get_entity_model_hash(a4.ped())
                            if e6 ~= e7 then
                                bw = false
                                c.wait(50)
                                local e8 = ped.get_current_ped_weapon(a4.ped())
                                bR(e6, nil, nil, nil, true)
                                c.wait(25)
                                weapon.give_delayed_weapon_to_ped(a4.ped(), e8, 0, 1)
                            end
                        elseif streaming.is_model_a_vehicle(e6) and a5.t["model_gun_ext"].on then
                            bL({bv})
                            bv = nil
                            bw = true
                            bv = aD.vehicle(e6, a4.coords())
                            c.attach(bv, a4.ped(), 0, v3(), v3(), true, true, false, 0, true)
                        elseif streaming.is_model_an_object(e6) and a5.t["model_gun_ext"].on then
                            bL({bv})
                            bv = nil
                            a2.model(e6)
                            bv = aD.object(e6, a4.coords())
                            c.unload(e6)
                            bw = true
                            c.attach(bv, a4.ped(), 0, v3(), v3(), true, true, false, 0, true)
                        end
                    end
                end
            end
            if not k.on then
                bL({bv})
                bv = nil
                c.visible(a4.ped(), true)
            end
            r["model_gun"] = k.on
            return d.stop(k)
        end
    )
    a5.t["model_gun"].on = r["model_gun"]
    a5.t["model_gun_ext"] =
        a5.add.t(
        "Add Objects and Vehicles to Model Gun",
        a5.p["model_gun"],
        function(k)
            r["model_gun_ext"] = k.on
        end
    )
    a5.t["model_gun_ext"].on = r["model_gun_ext"]
    a5.t["rapid_fire"] =
        a5.add.t(
        "Rapid Fire",
        a5.p["weapon"],
        function(k)
            if k.on then
                if player.is_player_free_aiming(c.id()) then
                    if ped.is_ped_shooting(a4.ped()) then
                        for i = 1, 20 do
                            local e1, e9 = ped.get_ped_bone_coords(a4.ped(), 0x67f2, v3())
                            while not e1 do
                                e1, e9 = ped.get_ped_bone_coords(a4.ped(), 0x67f2, v3())
                                c.wait(0)
                            end
                            local dd = cam.get_gameplay_cam_rot()
                            dd:transformRotToDir()
                            dd = dd * 1.5
                            e9 = e9 + dd
                            dd = nil
                            local ea = a4.coords()
                            dd = cam.get_gameplay_cam_rot()
                            dd:transformRotToDir()
                            dd = dd * 1500
                            ea = ea + dd
                            local eb = ped.get_current_ped_weapon(a4.ped())
                            gameplay.shoot_single_bullet_between_coords(e9, ea, 1, eb, a4.ped(), true, false, 1000)
                            c.wait(25)
                        end
                    end
                end
            end
            r["rapid_fire"] = k.on
            return d.stop(k)
        end
    )
    a5.t["rapid_fire"].on = r["rapid_fire"]
    a5.t["teleport_high_in_air"] =
        a5.add.a(
        "Teleport High in Air",
        a5.p["misc"],
        function()
            local aF = a4.coords()
            while aF.z < 25000 do
                aF.z = aF.z + 500
                bN(aF)
                c.wait(50)
            end
        end
    )
    a5.p["vehicle"] = a5.add.p("Vehicle", a5.p["misc"]).id
    a5.t["tp_own_veh_to_me"] =
        a5.add.a(
        "Teleport Own Vehicle to me",
        a5.p["vehicle"],
        function()
            local ac = player.get_personal_vehicle()
            local ec = c.vehicle(a4.ped())
            if ac ~= 0 and ec ~= ac then
                bJ(ac, c9(a4.coords(), a4.heading(), 5))
                entity.set_entity_heading(ac, a4.heading())
            end
        end
    )
    a5.t["tp_own_veh_to_me_drive"] =
        a5.add.a(
        "Teleport Own Vehicle to me and drive",
        a5.p["vehicle"],
        function()
            local ac = player.get_personal_vehicle()
            local ec = c.vehicle(a4.ped())
            if ac ~= 0 and ec ~= ac then
                bJ(ac, a4.coords())
                entity.set_entity_heading(ac, a4.heading())
                ped.set_ped_into_vehicle(a4.ped(), ac, -1)
            end
        end
    )
    a5.t["drive_own_veh"] =
        a5.add.a(
        "Drive Own Vehicle",
        a5.p["vehicle"],
        function()
            local ac = player.get_personal_vehicle()
            local ec = c.vehicle(a4.ped())
            if ac ~= 0 and ec ~= ac then
                ped.set_ped_into_vehicle(a4.ped(), ac, -1)
            end
        end
    )
    a5.t["tp_to_own_veh"] =
        a5.add.a(
        "Teleport to Own Vehicle",
        a5.p["vehicle"],
        function()
            local ac = player.get_personal_vehicle()
            local ec = c.vehicle(a4.ped())
            x(ac)
            x(ec)
            if ac ~= 0 and ec ~= ac then
                bN(c9(c.gcoords(ac), entity.get_entity_heading(ac), -5), 0, entity.get_entity_heading(ac))
            end
        end
    )
    a5.t["always_apply_mods"] =
        a5.add.t(
        "Always apply Vehicle Mods",
        a5.p["vehicle"],
        function(k)
            r["always_apply_mods"] = k.on
        end
    )
    a5.t["always_apply_mods"].on = r["always_apply_mods"]
    a5.p["vehicle_colors"] = a5.add.p("Vehicle Colors", a5.p["vehicle"]).id
    a5.t["light_speed"] =
        a5.add.u(
        "Set Speed in Milliseconds",
        "autoaction_value_i",
        a5.p["vehicle_colors"],
        function(k)
            r["veh_lights_speed"] = k.value_i
        end
    )
    a5.t["light_speed"].min_i = 25
    a5.t["light_speed"].max_i = 2500
    a5.t["light_speed"].mod_i = 25
    a5.t["light_speed"].value_i = r["veh_lights_speed"]
    a5.p["random_col"] = a5.add.p("Random Colors", a5.p["vehicle_colors"]).id
    a5.t["random_primary"] =
        a5.add.t(
        "Random Primary",
        a5.p["random_col"],
        function(k)
            if k.on then
                cc(b8)
                cc({"rainbow_primary"})
                local ac = c.vehicle(a4.ped())
                if a9.vehicle(ac) then
                    a2.ctrl(ac)
                    vehicle.set_vehicle_custom_primary_colour(ac, c.random(0, 0xffffff))
                    c.wait(a5.t["light_speed"].value_i)
                end
            end
            r["random_primary"] = k.on
            return d.stop(k)
        end
    )
    a5.t["random_primary"].on = r["random_primary"]
    a5.t["random_secondary"] =
        a5.add.t(
        "Random Secondary",
        a5.p["random_col"],
        function(k)
            if k.on then
                cc(b8)
                cc({"rainbow_secondary"})
                local ac = c.vehicle(a4.ped())
                if a9.vehicle(ac) then
                    a2.ctrl(ac)
                    vehicle.set_vehicle_custom_secondary_colour(ac, c.random(0, 0xffffff))
                    c.wait(a5.t["light_speed"].value_i)
                end
            end
            r["random_secondary"] = k.on
            return d.stop(k)
        end
    )
    a5.t["random_secondary"].on = r["random_secondary"]
    a5.t["random_pearlescent"] =
        a5.add.t(
        "Random Pearlescent",
        a5.p["random_col"],
        function(k)
            if k.on then
                cc(b8)
                cc({"rainbow_pearlescent"})
                local ac = c.vehicle(a4.ped())
                if a9.vehicle(ac) then
                    a2.ctrl(ac)
                    vehicle.set_vehicle_custom_pearlescent_colour(ac, c.random(0, 0xffffff))
                    c.wait(a5.t["light_speed"].value_i)
                end
            end
            r["random_pearlescent"] = k.on
            return d.stop(k)
        end
    )
    a5.t["random_pearlescent"].on = r["random_pearlescent"]
    a5.t["random_neon"] =
        a5.add.t(
        "Random Neon Lights",
        a5.p["random_col"],
        function(k)
            if k.on then
                cc(b8)
                cc({"rainbow_neon"})
                local ac = c.vehicle(a4.ped())
                if a9.vehicle(ac) then
                    a2.ctrl(ac)
                    local v = c.random(0, 0xffffff)
                    vehicle.set_vehicle_neon_lights_color(ac, v)
                    c.wait(a5.t["light_speed"].value_i)
                end
            end
            r["random_neon"] = k.on
            return d.stop(k)
        end
    )
    a5.t["random_neon"].on = r["random_neon"]
    a5.t["random_smoke"] =
        a5.add.t(
        "Random Smoke",
        a5.p["random_col"],
        function(k)
            if k.on then
                cc(b8)
                cc({"rainbow_smoke"})
                local ac = c.vehicle(a4.ped())
                if a9.vehicle(ac) then
                    a2.ctrl(ac)
                    local ed = c.random(0, 255)
                    local ee = c.random(0, 255)
                    local ef = c.random(0, 255)
                    vehicle.set_vehicle_tire_smoke_color(ac, ed, ee, ef)
                    c.wait(a5.t["light_speed"].value_i)
                end
            end
            r["random_smoke"] = k.on
            return d.stop(k)
        end
    )
    a5.t["random_smoke"].on = r["random_smoke"]
    a5.t["random_xenon"] =
        a5.add.t(
        "Random Xenon",
        a5.p["random_col"],
        function(k)
            if k.on then
                cc(b8)
                cc({"rainbow_xenon"})
                local ac = c.vehicle(a4.ped())
                if a9.vehicle(ac) then
                    a2.ctrl(ac)
                    vehicle.set_vehicle_headlight_color(ac, c.random(0, 12))
                    c.wait(a5.t["light_speed"].value_i)
                end
            end
            r["random_xenon"] = k.on
            return d.stop(k)
        end
    )
    a5.t["random_xenon"].on = r["random_xenon"]
    a5.p["rainbow_col"] = a5.add.p("Rainbow Colors", a5.p["vehicle_colors"]).id
    a5.t["rainbow_primary"] =
        a5.add.t(
        "Rainbow Primary",
        a5.p["rainbow_col"],
        function(k)
            if k.on then
                cc(b8)
                cc({"random_primary"})
                local ac = c.vehicle(a4.ped())
                if a9.vehicle(ac) then
                    a2.ctrl(ac)
                    for i = 1, #aP do
                        vehicle.set_vehicle_custom_primary_colour(ac, d.rgbtohex({aP[i][1], aP[i][2], aP[i][3]}))
                        c.wait(a5.t["light_speed"].value_i)
                    end
                end
            end
            r["rainbow_primary"] = k.on
            return d.stop(k)
        end
    )
    a5.t["rainbow_primary"].on = r["rainbow_primary"]
    a5.t["rainbow_secondary"] =
        a5.add.t(
        "Rainbow Secondary",
        a5.p["rainbow_col"],
        function(k)
            if k.on then
                cc(b8)
                cc({"random_secondary"})
                local ac = c.vehicle(a4.ped())
                if a9.vehicle(ac) then
                    a2.ctrl(ac)
                    for i = 1, #aP do
                        vehicle.set_vehicle_custom_secondary_colour(ac, d.rgbtohex({aP[i][1], aP[i][2], aP[i][3]}))
                        c.wait(a5.t["light_speed"].value_i)
                    end
                end
            end
            r["rainbow_secondary"] = k.on
            return d.stop(k)
        end
    )
    a5.t["rainbow_secondary"].on = r["rainbow_secondary"]
    a5.t["rainbow_pearlescent"] =
        a5.add.t(
        "Rainbow Pearlescent",
        a5.p["rainbow_col"],
        function(k)
            if k.on then
                cc(b8)
                cc({"random_pearlescent"})
                local ac = c.vehicle(a4.ped())
                if a9.vehicle(ac) then
                    a2.ctrl(ac)
                    for i = 1, #aP do
                        vehicle.set_vehicle_custom_pearlescent_colour(ac, d.rgbtohex({aP[i][1], aP[i][2], aP[i][3]}))
                        c.wait(a5.t["light_speed"].value_i)
                    end
                end
            end
            r["rainbow_pearlescent"] = k.on
            return d.stop(k)
        end
    )
    a5.t["rainbow_pearlescent"].on = r["rainbow_pearlescent"]
    a5.t["rainbow_neon"] =
        a5.add.t(
        "Rainbow Neon Lights",
        a5.p["rainbow_col"],
        function(k)
            if k.on then
                cc(b8)
                cc({"random_neon"})
                local ac = c.vehicle(a4.ped())
                if a9.vehicle(ac) then
                    a2.ctrl(ac)
                    for i = 1, #aP do
                        vehicle.set_vehicle_neon_lights_color(ac, d.rgbtohex({aP[i][1], aP[i][2], aP[i][3]}))
                        c.wait(a5.t["light_speed"].value_i)
                    end
                end
            end
            r["rainbow_neon"] = k.on
            return d.stop(k)
        end
    )
    a5.t["rainbow_neon"].on = r["rainbow_neon"]
    a5.t["rainbow_smoke"] =
        a5.add.t(
        "Rainbow Smoke",
        a5.p["rainbow_col"],
        function(k)
            if k.on then
                cc(b8)
                cc({"random_smoke"})
                local ac = c.vehicle(a4.ped())
                if a9.vehicle(ac) then
                    a2.ctrl(ac)
                    for i = 1, #aP do
                        local cf = aP[i]
                        vehicle.set_vehicle_tire_smoke_color(ac, cf[1], cf[2], cf[3])
                        c.wait(a5.t["light_speed"].value_i)
                    end
                end
            end
            r["rainbow_smoke"] = k.on
            return d.stop(k)
        end
    )
    a5.t["rainbow_smoke"].on = r["rainbow_smoke"]
    a5.t["rainbow_xenon"] =
        a5.add.t(
        "Rainbow Xenon",
        a5.p["rainbow_col"],
        function(k)
            if k.on then
                cc(b8)
                cc({"random_xenon"})
                local ac = c.vehicle(a4.ped())
                if a9.vehicle(ac) then
                    a2.ctrl(ac)
                    for i = 0, 12 do
                        vehicle.set_vehicle_headlight_color(ac, i)
                        c.wait(a5.t["light_speed"].value_i)
                    end
                end
            end
            r["rainbow_xenon"] = k.on
            return d.stop(k)
        end
    )
    a5.t["rainbow_xenon"].on = r["rainbow_xenon"]
    a5.t["synced_random"] =
        a5.add.t(
        "Synced Random Colors",
        a5.p["vehicle_colors"],
        function(k)
            if k.on then
                cc(b7)
                cc(b6)
                cc({"synced_rainbow_smooth", "synced_rainbow"})
                local ac = c.vehicle(a4.ped())
                if a9.vehicle(ac) then
                    ce(ac, {c.random(0, 255), c.random(0, 255), c.random(0, 255)})
                    c.wait(a5.t["light_speed"].value_i)
                end
            end
            r["synced_random"] = k.on
            return d.stop(k)
        end
    )
    a5.t["synced_random"].on = r["synced_random"]
    a5.t["synced_rainbow"] =
        a5.add.t(
        "Synced Rainbow Colors",
        a5.p["vehicle_colors"],
        function(k)
            if k.on then
                cc(b7)
                cc(b6)
                cc({"synced_random", "synced_rainbow_smooth"})
                local ac = c.vehicle(a4.ped())
                if a9.vehicle(ac) then
                    for i = 1, #aP do
                        local cf = aP[i]
                        ce(ac, {cf[1], cf[2], cf[3]}, i)
                        c.wait(a5.t["light_speed"].value_i)
                    end
                end
            end
            r["synced_rainbow"] = k.on
            return d.stop(k)
        end
    )
    a5.t["synced_rainbow"].on = r["synced_rainbow"]
    a5.t["synced_rainbow_smooth"] =
        a5.add.t(
        "Synced Smooth Rainbow",
        a5.p["vehicle_colors"],
        function(k)
            if k.on then
                cc(b7)
                cc(b6)
                cc({"synced_random", "synced_rainbow"})
                local ac = c.vehicle(a4.ped())
                if a9.vehicle(ac) then
                    local eg
                    eg = math.floor((101 - a5.t["light_speed"].value_i / 25) / 2)
                    if eg < 1 then
                        eg = 1
                    end
                    for i = 0, 255, eg do
                        ce(ac, {255, i, 0})
                    end
                    eg = math.floor((101 - a5.t["light_speed"].value_i / 25) / 2)
                    if eg < 1 then
                        eg = 1
                    end
                    for i = 255, 0, -eg do
                        ce(ac, {i, 255, 0})
                    end
                    eg = math.floor((101 - a5.t["light_speed"].value_i / 25) / 2)
                    if eg < 1 then
                        eg = 1
                    end
                    for i = 0, 255, eg do
                        ce(ac, {0, 255, i})
                    end
                    eg = math.floor((101 - a5.t["light_speed"].value_i / 25) / 2)
                    if eg < 1 then
                        eg = 1
                    end
                    for i = 255, 0, -eg do
                        ce(ac, {0, i, 255})
                    end
                    eg = math.floor((101 - a5.t["light_speed"].value_i / 25) / 2)
                    if eg < 1 then
                        eg = 1
                    end
                    for i = 0, 255, eg do
                        ce(ac, {i, 0, 255})
                    end
                    eg = math.floor((101 - a5.t["light_speed"].value_i / 25) / 2)
                    if eg < 1 then
                        eg = 1
                    end
                    for i = 255, 0, -eg do
                        ce(ac, {255, 0, i})
                    end
                end
            end
            r["synced_rainbow_smooth"] = k.on
            return d.stop(k)
        end
    )
    a5.t["synced_rainbow_smooth"].on = r["synced_rainbow_smooth"]
    a5.add.a(
        "100% Black",
        a5.p["vehicle_colors"],
        function()
            local ac = c.vehicle(a4.ped())
            if a9.vehicle(ac) then
                ce(ac, {0, 0, 0}, 0)
            else
                u("Get in a valid Vehicle!", 173)
            end
        end
    )
    a5.t["black_100"] =
        a5.add.t(
        "100% Black",
        a5.p["vehicle_colors"],
        function(k)
            if k.on then
                cc(b7)
                cc(b6)
                cc(b8)
                cc({"fade_black_red"})
                local ac = c.vehicle(a4.ped())
                if a9.vehicle(ac) then
                    ce(ac, {0, 0, 0}, 0)
                end
            end
            r["black_100"] = k.on
            return d.stop(k)
        end
    )
    a5.t["black_100"].on = r["black_100"]
    a5.t["fade_black_red"] =
        a5.add.t(
        "Fade Black-Red",
        a5.p["vehicle_colors"],
        function(k)
            if k.on then
                cc(b7)
                cc(b6)
                cc(b8)
                cc({"black_100"})
                local ac = c.vehicle(a4.ped())
                if a9.vehicle(ac) then
                    local eg
                    eg = math.floor((101 - a5.t["light_speed"].value_i / 25) / 2)
                    if eg < 1 then
                        eg = 1
                    end
                    for i = 0, 255, eg do
                        ce(ac, {i, 0, 0}, 0, 8)
                    end
                    eg = math.floor((101 - a5.t["light_speed"].value_i / 25) / 2)
                    if eg < 1 then
                        eg = 1
                    end
                    for i = 255, 0, -eg do
                        ce(ac, {i, 0, 0}, 0, 8)
                    end
                end
            end
            r["fade_black_red"] = k.on
            return d.stop(k)
        end
    )
    a5.t["fade_black_red"].on = r["fade_black_red"]
    a5.t["heli"] =
        a5.add.u(
        "Heli Blades Speed 0-100%",
        "value_i",
        a5.p["vehicle"],
        function(k)
            r["heli"] = k.on
            r["heli_i"] = k.value_i
            local ac = c.vehicle(a4.ped())
            if k.on then
                if a9.vehicle(ac) then
                    a2.ctrl(ac)
                    local cM = k.value_i / 100
                    vehicle.set_heli_blades_speed(ac, cM)
                end
            end
            return d.stop(k)
        end
    )
    a5.t["heli"].max_i = 100
    a5.t["heli"].min_i = 0
    a5.t["heli"].mod_i = 5
    a5.t["heli"].value_i = r["heli_i"]
    a5.t["heli"].on = r["heli"]
    a5.t["sel_boost_speed"] =
        a5.add.u(
        "Boost Vehicle",
        "value_i",
        a5.p["vehicle"],
        function(k)
            r["sel_boost_speed"] = k.on
            r["sel_boost_speed_speed"] = k.value_i
            local ac = c.vehicle(a4.ped())
            if k.on then
                if a9.vehicle(ac) then
                    a2.ctrl(ac)
                    entity.set_entity_max_speed(ac, k.value_i)
                    vehicle.set_vehicle_forward_speed(ac, k.value_i)
                end
            end
            if not k.on then
                entity.set_entity_max_speed(ac, 540)
            end
            return d.stop(k)
        end
    )
    a5.t["sel_boost_speed"].max_i = 50000
    a5.t["sel_boost_speed"].min_i = 0
    a5.t["sel_boost_speed"].mod_i = 50
    a5.t["sel_boost_speed"].value_i = r["sel_boost_speed_speed"]
    a5.t["sel_boost_speed"].on = r["sel_boost_speed"]
    a5.t["speedometer"] =
        a5.add.u(
        "License Plate Speedometer",
        "value_i",
        a5.p["vehicle"],
        function(k)
            r["speedometer"] = k.on
            r["speedometer_type"] = k.value_i
            bi = k.value_i
            if k.on then
                local ac = c.vehicle(a4.ped())
                if a9.vehicle(ac) then
                    if bi ~= bj then
                        u("Displaying Speed now with Unit:\n" .. C.speedometer_units[k.value_i][3], 96)
                    end
                    local eh = entity.get_entity_speed(ac) * C.speedometer_units[k.value_i][2]
                    if eh < 10 and eh > 0.01 then
                        eh = string.format("%.2f", eh)
                    elseif eh >= 10 and eh < 100 then
                        eh = string.format("%.1f", eh)
                    elseif eh < 0.01 and k.value_i == 7 then
                        eh = string.format("%.5f", eh)
                    else
                        eh = math.floor(eh)
                    end
                    a2.ctrl(ac)
                    vehicle.set_vehicle_number_plate_text(ac, tostring(eh) .. C.speedometer_units[k.value_i][1])
                end
            end
            bj = k.value_i
            return d.stop(k)
        end
    )
    a5.t["speedometer"].max_i = #C.speedometer_units
    a5.t["speedometer"].min_i = 1
    a5.t["speedometer"].value_i = r["speedometer_type"]
    a5.t["speedometer"].on = r["speedometer"]
    a5.t["veh_no_colision"] =
        a5.add.t(
        "No collision",
        a5.p["vehicle"],
        function(k)
            if k.on then
                local ac = c.vehicle(a4.ped())
                if a9.vehicle(ac) then
                    local ei = ped.get_all_peds()
                    for i = 1, #ei do
                        entity.set_entity_no_collsion_entity(ei[i], ac, true)
                        entity.set_entity_no_collsion_entity(ac, ei[i], true)
                    end
                    ei = object.get_all_objects()
                    for i = 1, #ei do
                        entity.set_entity_no_collsion_entity(ei[i], ac, true)
                        entity.set_entity_no_collsion_entity(ac, ei[i], true)
                    end
                    ei = vehicle.get_all_vehicles()
                    for i = 1, #ei do
                        entity.set_entity_no_collsion_entity(ei[i], ac, true)
                        entity.set_entity_no_collsion_entity(ac, ei[i], true)
                    end
                end
            end
            r["veh_no_colision"] = k.on
            return d.stop(k)
        end
    )
    a5.t["veh_no_colision"].on = r["veh_no_colision"]
    a5.t["auto_repair"] =
        a5.add.t(
        "Auto Repair Vehicle",
        a5.p["vehicle"],
        function(k)
            if k.on then
                local ac = c.vehicle(a4.ped())
                if a9.vehicle(ac) then
                    if vehicle.is_vehicle_damaged(ac) then
                        a2.ctrl(ac)
                        vehicle.set_vehicle_fixed(ac)
                        vehicle.set_vehicle_deformation_fixed(ac)
                        vehicle.set_vehicle_engine_health(ac, 1000)
                        vehicle.set_vehicle_can_be_visibly_damaged(ac, false)
                    end
                end
            end
            r["auto_repair"] = k.on
            return d.stop(k)
        end
    )
    a5.t["auto_repair"].on = r["auto_repair"]
    a5.t["drive_on_ocean"] =
        a5.add.t(
        "Drive / Walk on the Ocean",
        a5.p["misc"],
        function(k)
            if k.on then
                local aF = a4.coords()
                if bq == nil then
                    a2.model(1822550295)
                    bq = aD.object(1822550295, v3(aF.x, aF.y, -4))
                    c.visible(bq, false)
                end
                water.set_waves_intensity(-100000000)
                aF.z = -4
                bJ(bq, aF)
            end
            r["drive_on_ocean"] = k.on
            if not k.on and bq then
                water.reset_waves_intensity()
                bL({bq})
                bq = nil
            end
            return d.stop(k)
        end
    )
    a5.t["drive_on_ocean"].on = r["drive_on_ocean"]
    a5.t["drive_this_height"] =
        a5.add.t(
        "Drive / Walk this Height",
        a5.p["misc"],
        function(k)
            if k.on then
                local aF, bO
                if ped.is_ped_in_any_vehicle(a4.ped()) then
                    local ac = c.vehicle(a4.ped())
                    aF = c.gcoords(ac)
                    bO = 5.25
                else
                    aF = a4.coords()
                    bO = 5.85
                end
                if br == nil then
                    a2.model(1822550295)
                    bs = aF.z - bO
                    br = aD.object(1822550295, v3(aF.x, aF.y, bs))
                    c.visible(br, false)
                end
                water.set_waves_intensity(-100000000)
                aF.z = bs
                bJ(br, aF)
            end
            r["drive_this_height"] = k.on
            if not k.on and br then
                water.reset_waves_intensity()
                bL({br})
                br = nil
                bs = nil
            end
            return d.stop(k)
        end
    )
    a5.t["drive_this_height"].on = r["drive_this_height"]
    a5.t["weird_ent"] =
        a5.add.t(
        "Weird Entity",
        a5.p["misc"],
        function(k)
            local ac = c.vehicle(a4.ped())
            local dh = a4.ped()
            if k.on then
                if ac ~= 0 and bt == nil then
                    local aE = entity.get_entity_model_hash(ac)
                    bt = aD.vehicle(aE, a4.coords())
                    dh = ac
                elseif bt == nil then
                    bt = ped.clone_ped(a4.ped())
                end
                c.visible(dh, false)
                entity.set_entity_collision(bt, false, false, false)
                entity.set_entity_rotation(bt, v3(c.random(-180, 180), c.random(-180, 180), c.random(-180, 180)))
                bJ(bt, a4.coords())
            end
            if not k.on then
                bL({bt})
                bt = nil
                c.visible(dh, true)
            end
            r["weird_ent"] = k.on
            return d.stop(k)
        end
    )
    a5.t["weird_ent"].on = r["weird_ent"]
    a5.t["real_time"] =
        a5.add.t(
        "Real Time (Clientside)",
        a5.p["misc"],
        function(k)
            if k.on then
                local g = os.date("*t")
                time.set_clock_time(g.hour, g.min, g.sec)
                gameplay.clear_cloud_hat()
            end
            r["real_time"] = k.on
            return d.stop(k)
        end
    )
    a5.t["real_time"].on = r["real_time"]
    a5.t["clear_area"] =
        a5.add.t(
        "Gameplay Clear Area",
        a5.p["misc"],
        function(k)
            if k.on then
                local aF = a4.coords()
                gameplay.clear_area_of_cops(aF, 10000, true)
                gameplay.clear_area_of_peds(aF, 10000, true)
                gameplay.clear_area_of_vehicles(aF, 10000, false, false, false, false, false)
                gameplay.clear_area_of_objects(aF, 10000, 0)
                gameplay.clear_area_of_objects(aF, 10000, 1)
                gameplay.clear_area_of_objects(aF, 10000, 2)
                gameplay.clear_area_of_objects(aF, 10000, 6)
                gameplay.clear_area_of_objects(aF, 10000, 16)
                gameplay.clear_area_of_objects(aF, 10000, 17)
            end
            r["clear_area"] = k.on
            return d.stop(k)
        end
    )
    a5.t["clear_area"].on = r["clear_area"]
    a5.t["clear_area_2"] =
        a5.add.t(
        "Clear Area",
        a5.p["misc"],
        function(k)
            if k.on then
                local ej = ped.get_all_peds()
                for i = 1, #ej do
                    local ek = ej[i]
                    if not ped.is_ped_a_player(ek) and k.on then
                        a2.ctrl(ek, 250)
                        entity.set_entity_velocity(ek, v3())
                        bJ(ek, v3(8000, 8000, -1000))
                        entity.delete_entity(ek)
                    end
                end
                ej = object.get_all_objects()
                for i = 1, #ej do
                    local ek = ej[i]
                    if k.on then
                        a2.ctrl(ek, 250)
                        entity.set_entity_velocity(ek, v3())
                        bJ(ek, v3(8000, 8000, -1000))
                        entity.delete_entity(ek)
                        c.wait(0)
                    end
                end
                ej = vehicle.get_all_vehicles()
                local el = {}
                for Z = 0, 31 do
                    if D.scid(Z) ~= -1 then
                        local ac = c.vehicle(c.ped(Z))
                        if a9.vehicle(ac) then
                            el[#el + 1] = ac
                        end
                    end
                end
                for i = 1, #ej do
                    local ek = ej[i]
                    if k.on then
                        local e4 = true
                        for ay = 1, #el do
                            if ek == el[ay] then
                                e4 = false
                            end
                        end
                        if e4 then
                            a2.ctrl(ek, 250)
                            entity.set_entity_velocity(ek, v3())
                            bJ(ek, v3(8000, 8000, -1000))
                            entity.delete_entity(ek)
                        end
                    end
                end
            end
            r["clear_area_2"] = k.on
            return d.stop(k)
        end
    )
    a5.t["clear_area_2"].on = r["clear_area_2"]
    a5.t["auto_tp_wp"] =
        a5.add.t(
        "Auto Teleport to Waypoint",
        a5.p["misc"],
        function(k)
            if k.on then
                local cR = ui.get_waypoint_coord()
                if cR.x ~= 16000 then
                    local aF = a4.coords()
                    local em = v2()
                    em.x = aF.x
                    em.y = aF.y
                    if cR:magnitude(em) > 35 then
                        u("Detected Waypoint, teleporting...", 172)
                        local a5 = a4.ped()
                        local en = c.vehicle(a5)
                        if en ~= 0 then
                            a5 = en
                        end
                        local eo = 850
                        local e1, ep = gameplay.get_ground_z(v3(cR.x, cR.y, eo))
                        while not e1 do
                            eo = eo - 5
                            e1, ep = gameplay.get_ground_z(v3(cR.x, cR.y, eo))
                            if eo < -200 then
                                eo = -200
                                e1 = true
                            end
                        end
                        bN(v3(cR.x, cR.y, ep))
                    end
                end
            end
            r["auto_tp_wp"] = k.on
            return d.stop(k)
        end
    )
    a5.t["auto_tp_wp"].on = r["auto_tp_wp"]
    a5.t["ban_screen"] =
        a5.add.t(
        "You've Been Banned",
        a5.p["misc"],
        function(k)
            if k.on then
                local aF = v2()
                local b_ = v2()
                local eq = v2()
                aF.x = 0.5
                aF.y = 0.325
                b_.x = 0.5
                b_.y = 0.5
                eq.x = 0.5
                eq.y = 0.54
                ui.set_text_scale(3.0)
                ui.set_text_font(7)
                ui.set_text_centre(0)
                ui.set_text_color(255, 206, 67, 255)
                ui.set_text_outline(true)
                ui.draw_text("alert", aF)
                ui.set_text_scale(0.5)
                ui.set_text_centre(0)
                ui.set_text_color(255, 255, 255, 255)
                ui.draw_text("You have been banned from Grand Theft Auto Online permanently", b_)
                ui.set_text_scale(0.5)
                ui.set_text_centre(0)
                ui.draw_text("Return to Grand Theft Auto V", eq)
                ui.draw_rect(.5, .5, 1, 1, 0, 0, 0, 255)
                ui.draw_rect(.5, .492, .52, .0019, 255, 255, 255, 255)
                ui.draw_rect(.5, .585, .52, .0019, 255, 255, 255, 255)
            end
            return d.stop(k)
        end
    )
    a5.t["swap_seats"] =
        a5.add.u(
        "Swap Vehicle Seat",
        "autoaction_value_i",
        a5.p["misc"],
        function()
            local en = c.vehicle(a4.ped())
            if en ~= 0 then
                ped.set_ped_into_vehicle(a4.ped(), en, a5.t["swap_seats"].value_i)
            end
        end
    )
    a5.t["swap_seats"].min_i = -1
    a5.t["swap_seats"].value_i = -1
    a5.t["swap_seats"].max_i = 15
    a5.p["stats"] = a5.add.p("Stats", a5.p["misc"]).id
    a5.add.a(
        "Fill Snacks and Armor",
        a5.p["stats"],
        function()
            local er = aX.hashes["snacks_and_armor"]
            for i = 1, #er do
                aX.set(er[i][1], true, er[i][2])
            end
            u("Filled Inventory with Snacks and Armor!", 39)
        end
    )
    a5.add.a(
        "Set KD (Kills / Death)",
        a5.p["stats"],
        function()
            local es = D.input("Enter KD (Kills / Death", 10, 5)
            if not es then
                return HANDLER_POP
            end
            es = c.no(es)
            local er = aX.hashes["kills_deaths"]
            local dY = c.random(1000, 2000)
            local cT = math.floor(es * dY)
            local et = math.floor(cT / es)
            x("Setting Stat " .. er[1] .. " to: " .. cT)
            x("Setting Stat " .. er[2] .. " to: " .. et)
            aX.set(er[1], false, cT)
            aX.set(er[2], false, et)
            u("New KD set, to update the KD, earn a legit kill or death!", 39)
        end
    )
    a5.add.a(
        "Unlock Fast-Run Ability",
        a5.p["stats"],
        function()
            local er = aX.hashes["fast_run"]
            for i = 1, #er do
                aX.set(er[i], true, -1)
            end
            u("New Ability set, change lobby to show effect!", 39)
        end
    )
    a5.p["chc"] = a5.add.p("Casino Heist Control", a5.p["stats"]).id
    a5.add.a(
        "Teleport to Boards",
        a5.p["chc"],
        function()
            bN(v3(2712.885, -369.604, -54.781), 1, -173.626159)
        end
    )
    local eu = aX.hashes["chc"]["board1"]
    local ev = aX.hashes["chc"]["board2"]
    local ew = aX.hashes["chc"]["misc"]
    a5.add.a(
        "Reset Heist",
        a5.p["chc"],
        function()
            local er = ev
            for i = 1, #er do
                aX.set(er[i][2], true, er[i][3])
            end
            er = eu
            for i = 1, #er do
                aX.set(er[i][2], true, er[i][3])
            end
            er = ew
            for i = 1, #er do
                aX.set(er[i][2], true, er[i][3])
            end
            u("Resettet Casino Heist!", 39)
        end
    )
    a5.add.a(
        "Quick start, random",
        a5.p["chc"],
        function()
            local er = ew
            aX.set(er[1][2], true, er[1][4])
            aX.set(er[2][2], true, er[2][4])
            er = eu
            for i = 1, #er do
                local o = er[i][4]
                if er[i][5] then
                    o = c.random(er[i][4], er[i][5])
                end
                aX.set(er[i][2], true, o)
            end
            er = ew
            aX.set(er[3][2], true, er[3][4])
            er = ev
            for i = 1, #er do
                local o = er[i][4]
                if er[i][5] then
                    o = c.random(er[i][4], er[i][5])
                end
                aX.set(er[i][2], true, o)
            end
            er = ew
            aX.set(er[4][2], true, er[4][4])
            u("Setted up Casino Heist with random execution. If you dont like it, Reset Heist and try again!", 39)
        end
    )
    a5.add.a(
        "Highest Payout (worst crew-members)",
        a5.p["chc"],
        function()
            local er = ew
            aX.set(er[1][2], true, er[1][4])
            aX.set(er[2][2], true, er[2][4])
            er = eu
            for i = 1, #er do
                local o = er[i][6] or er[i][4]
                aX.set(er[i][2], true, o)
            end
            er = ew
            aX.set(er[3][2], true, er[3][4])
            er = ev
            for i = 1, #er do
                local o = er[i][6] or er[i][4]
                if #er[i] == 5 then
                    o = c.random(er[i][4], er[i][5])
                end
                aX.set(er[i][2], true, er[i][4])
            end
            er = ew
            aX.set(er[4][2], true, er[4][4])
            u("Setted up Casino Heist with highest Payout. If you dont like it, Reset Heist and try again!", 39)
        end
    )
    a5.p["chc_manual"] = a5.add.p("Manual Mode", a5.p["chc"]).id
    a5.add.a(
        "Reset last Approach",
        a5.p["chc_manual"],
        function()
            local er = ew
            aX.set(er[1][2], true, er[1][4])
            aX.set(er[2][2], true, er[2][4])
        end
    )
    a5.o["chc_approach"] =
        a5.add.u(
        eu[1][1],
        "action_value_i",
        a5.p["chc_manual"],
        function(k)
            local er = eu
            local o = k.value_i
            aX.set(er[1][2], true, o)
        end
    )
    a5.o["chc_approach"].min_i = 1
    a5.o["chc_approach"].max_i = 3
    a5.o["chc_approach"].value_i = 1
    a5.o["chc_hard"] =
        a5.add.u(
        eu[2][1],
        "action_value_i",
        a5.p["chc_manual"],
        function(k)
            local er = eu
            local o = k.value_i
            aX.set(er[2][2], true, o)
        end
    )
    a5.o["chc_hard"].min_i = 1
    a5.o["chc_hard"].max_i = 3
    a5.o["chc_hard"].value_i = 1
    a5.o["chc_content"] =
        a5.add.u(
        eu[3][1],
        "action_value_i",
        a5.p["chc_manual"],
        function(k)
            aX.set(eu[3][2], true, k.value_i)
        end
    )
    a5.o["chc_content"].min_i = 0
    a5.o["chc_content"].max_i = 3
    a5.add.a(
        eu[4][1],
        a5.p["chc_manual"],
        function()
            local er = eu
            aX.set(er[4][2], true, er[4][4])
        end
    )
    a5.add.a(
        eu[5][1],
        a5.p["chc_manual"],
        function()
            local er = eu
            aX.set(er[5][2], true, er[5][4])
        end
    )
    a5.add.a(
        ew[3][1],
        a5.p["chc_manual"],
        function()
            local er = ew
            aX.set(er[3][2], true, er[3][4])
        end
    )
    a5.add.a("Crew-Member-Weapon, Payout:", a5.p["chc_manual"])
    a5.o["chc_content_2"] =
        a5.add.u(
        ev[1][1],
        "action_value_i",
        a5.p["chc_manual"],
        function(k)
            local er = ev
            aX.set(er[1][2], true, k.value_i)
        end
    )
    a5.o["chc_content_2"].min_i = 0
    a5.o["chc_content_2"].max_i = 5
    a5.o["chc_content_2"].value_i = 1
    a5.add.a("Crew-Member-Driver, Payout:", a5.p["chc_manual"])
    a5.o["chc_content_3"] =
        a5.add.u(
        ev[2][1],
        "action_value_i",
        a5.p["chc_manual"],
        function(k)
            local er = ev
            aX.set(er[2][2], true, k.value_i)
        end
    )
    a5.o["chc_content_3"].min_i = 0
    a5.o["chc_content_3"].max_i = 5
    a5.o["chc_content_3"].value_i = 1
    a5.add.a("Crew-Member-Hacker, Payout:", a5.p["chc_manual"])
    a5.o["chc_content_4"] =
        a5.add.u(
        ev[3][1],
        "action_value_i",
        a5.p["chc_manual"],
        function(k)
            local er = ev
            aX.set(er[3][2], true, k.value_i)
        end
    )
    a5.o["chc_content_4"].min_i = 0
    a5.o["chc_content_4"].max_i = 5
    a5.o["chc_content_4"].value_i = 1
    a5.o["chc_content_5"] =
        a5.add.u(
        ev[4][1],
        "action_value_i",
        a5.p["chc_manual"],
        function(k)
            local er = ev
            aX.set(er[4][2], true, k.value_i)
        end
    )
    a5.o["chc_content_5"].min_i = 0
    a5.o["chc_content_5"].max_i = 1
    a5.o["chc_content_6"] =
        a5.add.u(
        ev[5][1],
        "action_value_i",
        a5.p["chc_manual"],
        function(k)
            local er = ev
            aX.set(er[5][2], true, k.value_i)
        end
    )
    a5.o["chc_content_6"].min_i = 0
    a5.o["chc_content_6"].max_i = 3
    a5.add.a(
        ev[6][1],
        a5.p["chc_manual"],
        function()
            local er = ev
            aX.set(er[6][2], true, er[6][4])
        end
    )
    a5.add.a(
        ev[7][1],
        a5.p["chc_manual"],
        function()
            local er = ev
            aX.set(er[7][2], true, er[7][4])
        end
    )
    a5.add.a(
        ev[8][1],
        a5.p["chc_manual"],
        function()
            local er = ev
            aX.set(er[8][2], true, er[8][4])
        end
    )
    a5.o["chc_content_7"] =
        a5.add.u(
        ev[9][1],
        "action_value_i",
        a5.p["chc_manual"],
        function(k)
            local er = ev
            aX.set(er[9][2], true, k.value_i)
        end
    )
    a5.o["chc_content_7"].min_i = 0
    a5.o["chc_content_7"].max_i = 12
    a5.add.a(
        ew[4][1],
        a5.p["chc_manual"],
        function()
            local er = ew
            aX.set(er[4][2], true, er[4][4])
        end
    )
    a5.p["player_history"] = a5.add.p("Player History", a5.p["misc"]).id
    a5.t["detect_lobby_change_for_history"] =
        a5.add.t(
        "Detect lobby change",
        a5.p["player_history"],
        function(k)
            if k.on and not r["disable_history"] then
                if ae.lobby == nil and ae.event == nil then
                    ae.parents[1] =
                        a5.add.p(
                        "Lobby 1 (1-50 Players)",
                        a5.p["player_history"],
                        function()
                            ae.add_players()
                            ae.tags(ae.parents[1])
                        end
                    )
                    a5.add.p("Lobby Information", ae.parents[1].id).hidden = true
                    ae.lobby = ae.parents[1]
                    ae.event =
                        event.add_event_listener(
                        "player_join",
                        function(N)
                            if N.player == c.id() and not r["disable_history"] then
                                ae.new_lobby(c.no(string.sub(ae.lobby.name, 7, 8)) + 1 .. " (1-50 Players)")
                                ae.start_loop = #ae.players - 1
                            end
                        end
                    )
                end
                c.wait(100)
                local V = 0
                for i = 1, #ae.parents do
                    if c.no(string.sub(ae.lobby.name, 7, 8)) == c.no(string.sub(ae.parents[i].name, 7, 7)) then
                        V = V + 1
                    end
                end
                if #ae.lobby.children >= 51 then
                    local aA = c.no(string.sub(ae.lobby.name, 7, 8))
                    aA = aA .. " (" .. V * 50 + 1 .. "-" .. V * 50 + 50 .. " Players)"
                    ae.new_lobby(aA)
                end
            end
            c.wait(250)
            return d.stop(k)
        end
    )
    a5.t["detect_lobby_change_for_history"].on = true
    a5.t["detect_lobby_change_for_history"].hidden = true
    a5.t["get_players_for_history"] =
        a5.add.t(
        "Get Players",
        a5.p["player_history"],
        function(k)
            if k.on and not r["disable_history"] then
                ae.add_players()
                c.wait(2500)
                for i = 0, 31 do
                    if c.valid(i) then
                        local aj = D.scid(i)
                        local j = D.name(i)
                        local ex = true
                        local an = aj .. ":" .. j .. ":" .. i .. ":" .. string.sub(ae.lobby.name, 7, 8)
                        for Z = ae.start_loop, #ae.players do
                            if not ae.players[Z] then
                                ex = true
                            elseif an == ae.players[Z]["uuid"] then
                                ex = false
                            end
                        end
                        if ex then
                            local au = {}
                            local at = {}
                            for ay = 1, 11 do
                                au[ay] = ped.get_ped_texture_variation(c.ped(i), ay)
                                at[ay] = ped.get_ped_drawable_variation(c.ped(i), ay)
                            end
                            local aw = {}
                            local ax = {}
                            local av = {0, 1, 2, 6, 7}
                            for ay = 1, #av do
                                aw[ay] = ped.get_ped_prop_index(c.ped(i), av[ay])
                                ax[ay] = ped.get_ped_prop_texture_index(c.ped(i), av[ay])
                            end
                            ae.players[#ae.players + 1] = {
                                ["scid"] = aj,
                                ["name"] = j,
                                ["ip"] = D.ip(i),
                                ["first_seen"] = d.time_prefix(),
                                ["is_female"] = player.is_player_female(i),
                                ["h_textures"] = au,
                                ["h_clothes"] = at,
                                ["h_prop_ind"] = aw,
                                ["h_prop_text"] = ax,
                                ["uuid"] = an,
                                ["player_id"] = i,
                                ["added"] = false
                            }
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    a5.t["get_players_for_history"].on = true
    a5.t["get_players_for_history"].hidden = true
    a5.p["utils"] = a5.add.p("Utils", a5.p["misc"]).id
    a5.p["outfits"] =
        a5.add.p(
        "Delete Custom Outfits",
        a5.p["utils"],
        function()
            u("Attention!\nDeleting cant be reverted!", 208)
            local aW = utils.get_all_files_in_directory(a["outfits"] .. "\\", "ini")
            local ey = a5.p["outfits"].children
            for i = 1, #aW do
                local ex = true
                for Z = 1, #ey do
                    if ey[Z].name == aW[i] then
                        ex = false
                    end
                end
                if ex then
                    a5.add.a(
                        aW[i],
                        a5.p["outfits"].id,
                        function(k)
                            if c.f_exists(a["outfits"] .. "\\" .. aW[i]) then
                                if io.remove(a["outfits"] .. "\\" .. aW[i]) == true then
                                    x("Deleted Outfit: " .. aW[i])
                                    return HANDLER_CONTINUE
                                end
                                u("ERROR deleting the file, try again!")
                                return HANDLER_POP
                            end
                            menu.delete_feature(k.id)
                        end
                    )
                end
            end
        end
    )
    a5.p["vehicles"] =
        a5.add.p(
        "Delete Custom Vehicles",
        a5.p["utils"],
        function()
            u("Attention!\nDeleting cant be reverted!", 208)
            local ez = utils.get_all_files_in_directory(a["vehicles"] .. "\\", "ini")
            local ey = a5.p["vehicles"].children
            for i = 1, #ez do
                local ex = true
                for Z = 1, #ey do
                    if ey[Z].name == ez[i] then
                        ex = false
                    end
                end
                if ex then
                    a5.add.a(
                        ez[i],
                        a5.p["vehicles"].id,
                        function(k)
                            if c.f_exists(a["vehicles"] .. "\\" .. ez[i]) then
                                if io.remove(a["vehicles"] .. "\\" .. ez[i]) then
                                    x("Deleted Vehicle: " .. aW[i])
                                    return HANDLER_CONTINUE
                                end
                                u("ERROR deleting the file, try again!")
                                return HANDLER_POP
                            end
                            menu.delete_feature(k.id)
                        end
                    )
                end
            end
        end
    )
    a5.t["auto_load"] =
        a5.add.t(
        "autoexec Scripts from folder 'autoload'",
        a5.p["utils"],
        function(k)
            r["auto_load"] = k.on
            if k.on then
                if c.d_exists(a["autoload"]) then
                    local b = utils.get_all_files_in_directory(a["autoload"], "lua")
                    if b then
                        x("Found Scripts for autoexecuting!")
                        for i = 1, #b do
                            x(b[i])
                            local eA = string.sub(b[i], 1, -5)
                            c.wait(5000)
                            if not require("\\autoload\\" .. eA) then
                                u("ERROR Loading Script " .. b[i] .. "!", 208)
                            else
                                u("Loaded Script " .. b[i] .. " succesfully!", 166)
                                x("Loaded Script " .. b[i] .. " succesfully!")
                            end
                        end
                    end
                else
                    u("No folder 'autoload' found, create a folder and place any script inside!", 174)
                end
            end
        end
    )
    a5.t["auto_load"].on = r["auto_load"]
    a5.t["leave_session"] =
        a5.add.a(
        "Leave-Session",
        a5.p["utils"],
        function()
            local time = c.time() + 8500
            while time > c.time() do
            end
        end
    )
    a5.add.t(
        "Auto-Hostkick-Yourself",
        a5.p["utils"],
        function(k)
            if k.on then
                if network.network_is_host() then
                    u("Hostkicking-Yourself!")
                    x("Hostkicking-Yourself!")
                    network.network_session_kick_player(c.id())
                end
            end
            return d.stop(k)
        end
    )
    a5.p["ipl_config"] =
        a5.add.p(
        "IPL-Loader",
        a5.p["misc"],
        function()
            if not c.f_exists(b["IPLlist"]) then
                u("No IPL-List File found.")
                u("Download '2Take1Script.zip' again and make sure you have all files!")
                bo["load_ipls"].hidden = true
                bo["range_start"].hidden = true
                bo["range_end"].hidden = true
                bo["remove_ipls"].hidden = true
            else
                bo["load_ipls"].hidden = false
                bo["range_start"].hidden = false
                bo["range_end"].hidden = false
                bo["remove_ipls"].hidden = false
            end
        end
    ).id
    bo["load_ipls"] =
        a5.add.a(
        "Load ALL IPLs from File",
        a5.p["ipl_config"],
        function()
            for eB in io.lines(b["IPLlist"]) do
                streaming.request_ipl(eB)
            end
        end
    )
    bo["range_start"] = a5.add.u("Select starting line for range", "action_value_i", a5.p["ipl_config"])
    bo["range_start"].max_i = 8550
    bo["range_start"].mod_i = 50
    bo["range_end"] = a5.add.u("Select ending line for range", "action_value_i", a5.p["ipl_config"])
    bo["range_end"].max_i = 8550
    bo["range_end"].mod_i = 50
    bo["remove_ipls"] =
        a5.add.a(
        "Remove ALL IPLs between selected Range",
        a5.p["ipl_config"],
        function()
            local b2 = 0
            local eC = bo["range_start"].value_i
            for eB in io.lines(b["IPLlist"]) do
                if b2 == eC then
                    eC = eC + 1
                    if eC <= bo["range_end"].value_i then
                        streaming.remove_ipl(eB)
                    end
                end
                b2 = b2 + 1
            end
        end
    )
    a5.p["debug"] = a5.add.p("Dev Tools", a5.p["misc"]).id
    a5.add.a(
        "Delete Entity from Aim",
        a5.p["debug"],
        function()
            bL({player.get_entity_player_is_aiming_at(c.id())})
        end
    )
    a5.add.a(
        "Get input Hash Key",
        a5.p["debug"],
        function()
            local eD = D.input("Enter Name(PED, OBJECT, etc)")
            if not eD then
                return HANDLER_POP
            end
            x("")
            x("******************************")
            x("String: " .. eD)
            local aE = tostring(gameplay.get_hash_key(eD))
            x("Hash: " .. aE)
            u(string.format("%s %s", eD, aE))
        end
    )
    a5.add.a(
        "Notify & Print String from file",
        a5.p["debug"],
        function()
            local eE = "slod_small_quadped"
            local eF = gameplay.get_hash_key(eE)
            x("")
            x("******************************")
            x("String: " .. eE)
            x("Hash: " .. eF)
            u("String: " .. eE)
            u("Hash: " .. eF)
        end
    )
    a5.t["print_info_from_entity"] =
        a5.add.a(
        "Print Info from Entity @Aim to file",
        a5.p["debug"],
        function()
            local d2 = player.get_entity_player_is_aiming_at(c.id())
            local eG, aF, cz
            if d2 ~= 0 then
                while d2 ~= 0 do
                    eG = entity.get_entity_model_hash(d2)
                    aF = entity.get_entity_coords(d2)
                    cz = entity.get_entity_rotation(d2)
                    x("")
                    x("Printing infos about Entity:")
                    x("******************************")
                    x("Hash: " .. eG)
                    x("Entity Type: " .. entity.get_entity_type(d2))
                    x("Entity: " .. d2)
                    x("Coords X: " .. aF.x)
                    x("Coords Y: " .. aF.y)
                    x("Coords Z: " .. aF.z)
                    x("Rot X: " .. cz.x)
                    x("Rot Y: " .. cz.y)
                    x("Rot Z: " .. cz.z)
                    x("Heading: " .. entity.get_entity_heading(d2))
                    x("Entity population_type: " .. entity.get_entity_population_type(d2))
                    if entity.is_entity_static(d2) then
                        x("Entity is static")
                    end
                    if entity.does_entity_have_drawable(d2) then
                        x("Entity has a drawable")
                    end
                    if entity.is_entity_in_water(d2) then
                        x("Entity is in water")
                    end
                    if entity.is_entity_a_ped(d2) then
                        x("Entity is a PED")
                    elseif entity.is_entity_a_vehicle(d2) then
                        x("Entity is a VEHICLE")
                    elseif entity.is_entity_an_object(d2) then
                        x("Entity is a OBJECT")
                    end
                    if entity.is_entity_dead(d2) then
                        x("Entity is DEAD")
                    end
                    if entity.is_entity_on_fire(d2) then
                        x("Entity is ON FIRE")
                    end
                    if entity.is_entity_visible(d2) then
                        x("Entity is VISIBLE")
                    else
                        x("Entity is INvisible")
                    end
                    if entity.is_entity_attached(d2) then
                        d2 = entity.get_entity_attached_to(d2)
                        x("")
                        x("Attached Entity found. Continue printing infos of Entity.")
                        x("Attached Entity Info:")
                    else
                        d2 = 0
                        x("")
                        x("")
                        x("")
                    end
                end
                u("Printed Info about Entity to file.")
            else
                u("Nothing found for Info-Printing.")
            end
        end
    )
    a5.add.a(
        "Clear 2Take1Script.log",
        a5.p["debug"],
        function()
            d.write(c.o(b["Log_file"], "w"), "Cleared 2Take1Script.log")
            u("Cleared 2Take1Script.log", 204)
        end
    )
    a5.add.a(
        "Clear Menu Log-Files",
        a5.p["debug"],
        function()
            d.write(c.o(b["Auth"], "w"), "PopstarAuth.log cleared by 2Take1Script")
            u("Cleared PopstarAuth.log", 204)
            x("Cleared PopstarAuth.log")
            d.write(c.o(b["Menu_log"], "w"), "2Take1Menu.log cleared by 2Take1Script")
            u("Cleared 2Take1Menu.log", 204)
            x("Cleared 2Take1Menu.log")
            d.write(c.o(b["Prep"], "w"), "2Take1Prep.log cleared by 2Take1Script")
            u("Cleared 2Take1Prep.log", 204)
            x("Cleared 2Take1Prep.log")
        end
    )
    a5.add.a(
        "Clear crashdumps",
        a5.p["debug"],
        function()
            local eH = utils.get_all_files_in_directory(a["dumps"], "dump")
            if eH[1] then
                u("Found dumps, deleting...", 204)
                for i = 1, #eH do
                    io.remove(a["dumps"] .. "\\" .. eH[i])
                end
                u("Cleared crashdumps.", 204)
                x("Cleared crashdumps.")
            else
                u("No dumps found.", 204)
            end
        end
    )
    a5.t["log_modder_flags"] =
        a5.add.t(
        "Log Modder Flags",
        a5.p["debug"],
        function(k)
            if k.on then
                local time = c.time() + 2500
                while time > c.time() do
                    c.wait(250)
                    r["log_modder_flags"] = k.on
                end
                for i = 0, 31 do
                    if c.valid(i) then
                        for Z = 1, #A do
                            if player.is_player_modder(i, A[Z]) then
                                local az = A[Z]
                                local f = player.get_modder_flag_text(az)
                                if ad[D.scid(i)] then
                                    if not ad[D.scid(i)][az] then
                                        ad[D.scid(i)][az] = true
                                        x(D.scid(i) .. ":" .. D.name(i) .. " is a Modder with Tag: " .. f)
                                    end
                                else
                                    ad[D.scid(i)] = {}
                                end
                            end
                        end
                    end
                end
            end
            r["log_modder_flags"] = k.on
            return d.stop(k)
        end
    )
    a5.t["log_modder_flags"].on = r["log_modder_flags"]
    a5.t["logger"] =
        a5.add.t(
        "Enable Log from this Lua-Script",
        a5.p["debug"],
        function(k)
            r["logger"] = k.on
        end
    )
    a5.t["logger"].on = r["logger"]
    a5.p["bodyguards"] = a5.add.p("Bodyguards", a5.p["parent"])
    a5.p["bodyguards"].hidden = r["bodyguards_hidden"]
    a5.p["bodyguards"] = a5.p["bodyguards"].id
    a5.t["bodyguards_god"] =
        a5.add.t(
        "Godmode for Bodyguards",
        a5.p["bodyguards"],
        function(k)
            r["bodyguards_god"] = k.on
        end
    )
    a5.t["bodyguards_god"].on = r["bodyguards_god"]
    a5.t["bodyguards_health"] =
        a5.add.u(
        "Set Health of Bodyguards",
        "autoaction_value_i",
        a5.p["bodyguards"],
        function(k)
            u("Bodyguards Health set to: " .. k.value_i)
            r["bodyguards_health"] = k.value_i
        end
    )
    a5.t["bodyguards_health"].min_i = 5000
    a5.t["bodyguards_health"].max_i = 50000
    a5.t["bodyguards_health"].mod_i = 5000
    a5.t["bodyguards_health"].value_i = r["bodyguards_health"]
    a5.t["bodyguards_equip_weapon"] =
        a5.add.t(
        "Equip Bodyguards with MG",
        a5.p["bodyguards"],
        function(k)
            r["bodyguards_equip_weapon"] = k.on
        end
    )
    a5.t["bodyguards_equip_weapon"].on = r["bodyguards_equip_weapon"]
    a5.t["bodyguards_formation"] =
        a5.add.u(
        "Set Formation",
        "autoaction_value_i",
        a5.p["bodyguards"],
        function(k)
            r["bodyguards_formation_type"] = k.value_i
        end
    )
    a5.t["bodyguards_formation"].min_i = 0
    a5.t["bodyguards_formation"].max_i = 3
    a5.t["bodyguards_formation"].value_i = r["bodyguards_formation_type"]
    a5.t["bodyguards"] =
        a5.add.t(
        "Enable Bodyguards",
        a5.p["bodyguards"],
        function(k)
            if k.on then
                local eI = player.get_player_group(c.id())
                local aE = 0x613E626C
                for i = 1, 7 do
                    if not aV["bodyguards"][i] or entity.is_entity_dead(aV["bodyguards"][i]) then
                        if aV["bodyguards"][i] and entity.is_entity_dead(aV["bodyguards"][i]) then
                            bL({aV["bodyguards"][i]})
                        end
                        a2.model(aE)
                        aV["bodyguards"][i] = aD.ped(aE, c9(a4.coords(), a4.heading(), 4), 29)
                        c.unload(aE)
                        if a5.t["bodyguards_god"].on then
                            c.god(aV["bodyguards"][i], true)
                        else
                            ped.set_ped_max_health(aV["bodyguards"][i], a5.t["bodyguards_health"].value_i)
                            ped.set_ped_health(aV["bodyguards"][i], a5.t["bodyguards_health"].value_i)
                        end
                        local eJ = ui.add_blip_for_entity(aV["bodyguards"][i])
                        ui.set_blip_sprite(eJ, 310)
                        ui.set_blip_colour(eJ, 80)
                        if a5.t["bodyguards_equip_weapon"].on then
                            weapon.give_delayed_weapon_to_ped(aV["bodyguards"][i], 0x22D8FE39, 0, 1)
                            weapon.give_delayed_weapon_to_ped(aV["bodyguards"][i], 0xDBBD7280, 0, 1)
                        end
                        ped.set_ped_combat_ability(aV["bodyguards"][i], 100)
                        ped.set_ped_as_group_member(aV["bodyguards"][i], eI)
                        entity.set_entity_as_mission_entity(aV["bodyguards"][i], 1, 1)
                    end
                    if not entity.is_entity_dead(aV["bodyguards"][i]) then
                        a2.ctrl(aV["bodyguards"][i])
                        ped.set_group_formation(eI, a5.t["bodyguards_formation"].value_i)
                        if player.is_player_free_aiming(c.id()) then
                            local T = player.get_entity_player_is_aiming_at(c.id())
                            if T ~= 0 then
                                ai.task_shoot_at_entity(aV["bodyguards"][i], T, 100, 0xC6EE6B4C)
                            else
                                local aF = a4.coords()
                                local dd = cam.get_gameplay_cam_rot()
                                dd:transformRotToDir()
                                dd = dd * c.random(1, 50)
                                aF = aF + dd
                                ai.task_shoot_gun_at_coord(aV["bodyguards"][i], aF, 100, 0xC6EE6B4C)
                            end
                        end
                        if a4.coords():magnitude(c.gcoords(aV["bodyguards"][i])) > 50 then
                            bJ(aV["bodyguards"][i], c9(a4.coords(), a4.heading(), -5))
                        end
                    end
                end
            end
            if not k.on then
                bL(aV["bodyguards"])
                aV["bodyguards"] = {}
            end
            return d.stop(k)
        end
    )
    a5.p["self"] = a5.add.p("Self", a5.p["parent"])
    a5.p["self"].hidden = r["self_hidden"]
    a5.p["self"] = a5.p["self"].id
    a5.t["random_clothes"] =
        a5.add.u(
        "Random Clothes",
        "value_i",
        a5.p["self"],
        function(k)
            if k.on then
                c.wait(math.floor(1000 / k.value_i))
                ped.set_ped_random_component_variation(a4.ped())
            end
            r["random_clothes"] = k.on
            return d.stop(k)
        end
    )
    a5.t["random_clothes"].min_i = 1
    a5.t["random_clothes"].max_i = 25
    a5.t["random_clothes"].value_i = r["random_clothes_value"]
    a5.t["random_clothes"].on = r["random_clothes"]
    a5.t["police_outfit"] =
        a5.add.t(
        "Force Police Outfit",
        a5.p["self"],
        function(k)
            if k.on then
                local D = "male"
                if player.is_player_female(c.id()) then
                    D = "female"
                end
                local eK = aW["police_outfit"][D]
                for i = 1, #eK["clothes"] do
                    ped.set_ped_component_variation(a4.ped(), i, eK["clothes"][i][2], eK["clothes"][i][1], 2)
                end
                for i = 1, #eK["props"] do
                    ped.set_ped_prop_index(a4.ped(), eK["props"][i][1], eK["props"][i][2], eK["props"][i][3], 0)
                end
                c.wait(250)
            end
            r["police_outfit"] = k.on
            return d.stop(k)
        end
    )
    a5.t["police_outfit"].on = r["police_outfit"]
    a5.p["health"] = a5.add.p("Health", a5.p["self"]).id
    a5.add.a(
        "Fill Health",
        a5.p["health"],
        function()
            local eL = player.get_player_max_health(c.id())
            local eM = player.get_player_health(c.id())
            if eL ~= eM then
                ped.set_ped_health(a4.ped(), eL)
                u("Filled health!")
            end
        end
    )
    a5.t["undead_otr"] =
        a5.add.t(
        "Undead OTR",
        a5.p["health"],
        function(k)
            if k.on then
                local eL = player.get_player_max_health(c.id())
                if eL ~= 0 then
                    ped.set_ped_max_health(a4.ped(), 0)
                end
            end
            if not k.on then
                ped.set_ped_max_health(a4.ped(), 328)
            end
            r["undead_otr"] = k.on
            return d.stop(k)
        end
    )
    a5.t["undead_otr"].on = r["undead_otr"]
    a5.t["quick_regen"] =
        a5.add.t(
        "Quick regen",
        a5.p["health"],
        function(k)
            if k.on then
                local eL = player.get_player_max_health(c.id())
                local eM = player.get_player_health(c.id())
                if eL > eM then
                    ped.set_ped_health(a4.ped(), eM + 1)
                end
            end
            r["quick_regen"] = k.on
            return d.stop(k)
        end
    )
    a5.t["quick_regen"].on = r["quick_regen"]
    a5.t["unlimited_regen"] =
        a5.add.t(
        "Unlimited health-regen!",
        a5.p["health"],
        function(k)
            if k.on then
                local eM = player.get_player_health(c.id())
                local eN = eM + eM * 0.005
                if eN < 500000000 then
                    ped.set_ped_health(a4.ped(), eN)
                    ped.set_ped_max_health(a4.ped(), eN)
                end
            end
            if not k.on and r["revert_health"] then
                ped.set_ped_max_health(a4.ped(), 328)
                ped.set_ped_health(a4.ped(), 328)
            end
            r["unlimited_regen"] = k.on
            return d.stop(k)
        end
    )
    a5.t["unlimited_regen"].on = r["unlimited_regen"]
    a5.t["revert_health"] =
        a5.add.t(
        "Revert health after disabling Unlimited-regen",
        a5.p["health"],
        function(k)
            r["revert_health"] = k.on
        end
    )
    a5.t["revert_health"].on = r["revert_health"]
    a5.p["more_health"] = a5.add.p("Health Boosts", a5.p["health"]).id
    for i = 1, #b9 do
        a5.add.a(
            b9[i][1],
            a5.p["more_health"],
            function()
                ped.set_ped_health(a4.ped(), b9[i][2])
                ped.set_ped_max_health(a4.ped(), b9[i][2])
                u("Health set to:\n" .. b9[i][2])
            end
        )
    end
    a5.p["aim_protection"] = a5.add.p("Aim Protection", a5.p["self"]).id
    a5.t["enable_aim_prot"] =
        a5.add.t(
        "Enable Aim Protection",
        a5.p["aim_protection"],
        function(k)
            if k.on then
                for i = 0, 31 do
                    if a9.i(i) then
                        local T = player.get_entity_player_is_aiming_at(i)
                        if T ~= 0 then
                            if T == a4.ped() then
                                u(D.name(i) .. " is aiming at you!", 173)
                                local d8 = a4.ped()
                                if r["anonymous_punishment"] then
                                    d8 = c.ped(i)
                                end
                                if r["aim_prot_ragdoll"] then
                                    u("Ragdolling " .. D.name(i) .. "!", 173)
                                    x("Ragdolling " .. D.name(i) .. "!")
                                    c.explode(c.gcoords(c.ped(i)), 70, true, false, 1, d8)
                                    c.wait(75)
                                end
                                if r["aim_prot_fire"] then
                                    u("Setting " .. D.name(i) .. " on fire!", 173)
                                    x("Setting " .. D.name(i) .. " on fire!")
                                    c.explode(c.gcoords(c.ped(i)), 3, true, false, 0, d8)
                                    c.wait(75)
                                end
                                if r["aim_prot_kill"] then
                                    u("Killing " .. D.name(i) .. "!", 173)
                                    x("Killing " .. D.name(i) .. "!")
                                    c.explode(c.gcoords(c.ped(i)), 8, false, true, 0, d8)
                                    c.wait(75)
                                end
                                if r["aim_prot_remove_weapon"] then
                                    u("Removing Weapon from " .. D.name(i) .. "!", 173)
                                    x("Removing Weapon from " .. D.name(i) .. "!")
                                    ped.set_ped_can_switch_weapons(c.ped(i), false)
                                    weapon.remove_weapon_from_ped(c.ped(i), ped.get_current_ped_weapon(c.ped(i)))
                                    ped.set_ped_can_switch_weapons(c.ped(i), false)
                                    c.wait(75)
                                end
                                if r["aim_prot_kick"] then
                                    bV(false, i)
                                end
                            end
                        end
                    end
                end
            end
            r["enable_aim_prot"] = k.on
            return d.stop(k)
        end
    )
    a5.t["enable_aim_prot"].on = r["enable_aim_prot"]
    a5.t["anonymous_punishment"] =
        a5.add.t(
        "Anonymous Punishment",
        a5.p["aim_protection"],
        function(k)
            r["anonymous_punishment"] = k.on
        end
    )
    a5.t["anonymous_punishment"].on = r["anonymous_punishment"]
    a5.t["aim_prot_ragdoll"] =
        a5.add.t(
        "Ragdoll Player",
        a5.p["aim_protection"],
        function(k)
            r["aim_prot_ragdoll"] = k.on
        end
    )
    a5.t["aim_prot_ragdoll"].on = r["aim_prot_ragdoll"]
    a5.t["aim_prot_fire"] =
        a5.add.t(
        "Set on Fire",
        a5.p["aim_protection"],
        function(k)
            r["aim_prot_fire"] = k.on
        end
    )
    a5.t["aim_prot_fire"].on = r["aim_prot_fire"]
    a5.t["aim_prot_kill"] =
        a5.add.t(
        "Kill Player",
        a5.p["aim_protection"],
        function(k)
            r["aim_prot_kill"] = k.on
        end
    )
    a5.t["aim_prot_kill"].on = r["aim_prot_kill"]
    a5.t["aim_prot_remove_weapon"] =
        a5.add.t(
        "Remove Current Weapon",
        a5.p["aim_protection"],
        function(k)
            r["aim_prot_remove_weapon"] = k.on
        end
    )
    a5.t["aim_prot_remove_weapon"].on = r["aim_prot_remove_weapon"]
    a5.t["aim_prot_kick"] =
        a5.add.t(
        "Kick Player",
        a5.p["aim_protection"],
        function(k)
            r["aim_prot_kick"] = k.on
        end
    )
    a5.t["aim_prot_kick"].on = r["aim_prot_kick"]
    a5.t["do_ragdoll"] =
        a5.add.a(
        "Ragdoll",
        a5.p["self"],
        function()
            ped.set_ped_to_ragdoll(a4.ped(), 2500, 0, 0)
        end
    )
    a5.t["ragdoll"] =
        a5.add.t(
        "Ragdoll",
        a5.p["self"],
        function(k)
            if k.on then
                ped.set_ped_to_ragdoll(a4.ped(), 2500, 0, 0)
            end
            r["ragdoll"] = k.on
            return d.stop(k)
        end
    )
    a5.t["ragdoll"].on = r["ragdoll"]
    a5.p["opt"] = a5.add.p("Options", a5.p["parent"])
    a5.p["opt"].hidden = r["options_hidden"]
    a5.p["opt"] = a5.p["opt"].id
    a5.p["hotkeys"] = a5.add.p("Hotkey Settings", a5.p["opt"]).id
    a5.t["enable_hotkeys"] =
        a5.add.t(
        "Enable Hotkeys",
        a5.p["hotkeys"],
        function(k)
            r["enable_hotkeys"] = k.on
            if k.on then
                c.wait(50)
                if not c.f_exists(b["Hotkeys"]) then
                    K.overwrite_hotkeys()
                end
                for i = 1, #s[0] do
                    local eO = s[0][i]
                    local eP = s[eO]
                    if eP ~= "none" then
                        local n = MenuKey()
                        n:push_str(eP)
                        if n:is_down() then
                            local eQ = a5.t[eO]
                            local eR = eQ.name
                            x(eP .. ":'" .. eR .. "' got pressed.")
                            if r["hotkey_notification"] then
                                u(eP .. ":'" .. eR .. "' got pressed.", 86)
                            end
                            if eQ.type == 512 then
                                eQ.on = true
                                c.wait(100)
                                eQ.on = false
                            else
                                if eQ.on then
                                    eQ.on = false
                                else
                                    eQ.on = true
                                end
                            end
                            c.wait(250)
                        end
                    end
                end
            end
            return d.stop(k)
        end
    )
    a5.t["enable_hotkeys"].on = r["enable_hotkeys"]
    a5.add.a(
        "Reload 2Take1Hotkeys.ini",
        a5.p["hotkeys"],
        function()
            K.hotkeys()
            u("Reloaded Hotkeys.ini", 86)
        end
    )
    a5.t["hotkey_notification"] =
        a5.add.t(
        "Hotkey Notifications",
        a5.p["hotkeys"],
        function(k)
            r["hotkey_notification"] = k.on
        end
    )
    a5.t["hotkey_notification"].on = r["hotkey_notification"]
    a5.add.a(
        "Print active Hotkeys",
        a5.p["hotkeys"],
        function()
            for i = 1, #s[0] do
                local n = s[0][i]
                if s[n] ~= "none" then
                    u(s[n] .. ': "' .. a5.t[n].name .. '"', 86)
                end
            end
        end
    )
    a5.add.a("Overwrite / Update File - Hotkeys.ini", a5.p["hotkeys"], K.overwrite_hotkeys)
    a5.p["mwh"] = a5.add.p("Menu-Wide-Hotkeys", a5.p["opt"]).id
    local eS = {}
    local eT = {}
    local eU = {}
    local eV = c.o(b["Exclude"], "r")
    if eV then
        for eW in io.lines(b["Exclude"]) do
            if not string.find(eW, ";", 1) then
                eU[#eU + 1] = eW
            end
        end
        io.close(eV)
    end
    a5.t["mwh_notify"] =
        a5.add.t(
        "Menu-Wide Hotkey Notifications",
        a5.p["mwh"],
        function(k)
            if k.on then
                c.wait(50)
                if #eS == 0 then
                    local _ = c.o(a["Menu"] .. "\\2Take1Menu.ini", "r")
                    if _ then
                        local i = 1
                        for eW in io.lines(a["Menu"] .. "\\2Take1Menu.ini") do
                            if i > 1 and i < 50 then
                                local q = ""
                                while string.find(eW, "=", 1) do
                                    q = q .. string.sub(eW, 1, 1)
                                    eW = string.sub(eW, 2)
                                end
                                q = string.sub(q, 1, #q - 1)
                                if string.find(eW, "NOMOD+", 1) then
                                    eW = string.gsub(eW, "NOMOD*+", "")
                                end
                                eS[i - 1] = eW
                                eT[i - 1] = q
                            end
                            i = i + 1
                        end
                        io.close(_)
                    end
                end
                for i = 1, #eS do
                    local eP = eS[i]
                    local eX = eT[i]
                    local ab = eP ~= "none"
                    local aq = true
                    if r["mwh_exclude_navigation"] then
                        if string.find(eX, "Menu", 1) then
                            aq = false
                        end
                    end
                    if r["mwh_exclude_noclip"] then
                        if string.find(eX, "NoClip", 1) then
                            aq = false
                        end
                    end
                    if r["mwh_exclude_editorrot"] then
                        if string.find(eX, "EditorRot", 1) then
                            aq = false
                        end
                    end
                    if r["mwh_exclude_file"] then
                        for Z = 1, #eU do
                            if string.find(eX, eU[Z], 1) then
                                aq = false
                            end
                        end
                    end
                    if ab and aq then
                        local n = MenuKey()
                        n:push_str(eP)
                        if n:is_down() then
                            u(eP .. ":'" .. eX .. "' got pressed.", 86)
                            c.wait(250)
                        end
                    end
                end
            end
            r["mwh_notify"] = k.on
            return d.stop(k)
        end
    )
    a5.t["mwh_notify"].on = r["mwh_notify"]
    a5.t["mwh_exclude_navigation"] =
        a5.add.t(
        "Exclude Navigation Keys",
        a5.p["mwh"],
        function(k)
            r["mwh_exclude_navigation"] = k.on
        end
    )
    a5.t["mwh_exclude_navigation"].on = r["mwh_exclude_navigation"]
    a5.t["mwh_exclude_noclip"] =
        a5.add.t(
        "Exclude NoClip Keys",
        a5.p["mwh"],
        function(k)
            r["mwh_exclude_noclip"] = k.on
        end
    )
    a5.t["mwh_exclude_noclip"].on = r["mwh_exclude_noclip"]
    a5.t["mwh_exclude_editorrot"] =
        a5.add.t(
        "Exclude EditorRotation Keys",
        a5.p["mwh"],
        function(k)
            r["mwh_exclude_editorrot"] = k.on
        end
    )
    a5.t["mwh_exclude_editorrot"].on = r["mwh_exclude_editorrot"]
    a5.t["mwh_exclude_file"] =
        a5.add.t(
        "Exclude Keys from File",
        a5.p["mwh"],
        function(k)
            if not c.f_exists(b["Exclude"]) then
                local eY = c.o(b["Exclude"], "a")
                io.output(eY)
                io.write(";Write down each Hotkey from 2Take1Menu.ini file which should not get a notify.\n")
                io.write(';Example, the "Exit" Hotkey should not get a notify, then just add it here.\n')
                io.write(";Each excluded hotkey gets a single line:\n")
                io.write("Exit")
                io.close(eY)
                u(
                    "Edit '2Take1Exclude.ini' to exclude specific hotkeys. The file is found in '2Take1Script/Config'",
                    86
                )
            end
            r["mwh_exclude_file"] = k.on
        end
    )
    a5.t["mwh_exclude_file"].on = r["mwh_exclude_file"]
    a5.add.a(
        "Reload 2Take1Exclude.ini",
        a5.p["mwh"],
        function()
            local eV = c.o(b["Exclude"], "r")
            if eV then
                eU = {}
                for eW in io.lines(b["Exclude"]) do
                    if not string.find(eW, ";", 1) then
                        eU[#eU + 1] = eW
                    end
                end
                io.close(eV)
                u("Reloaded Exclude Hotkeys.", 86)
            end
        end
    )
    a5.t["exclude_friends"] =
        a5.add.t(
        "Exclude Friends from Harmful Lobby Events",
        a5.p["opt"],
        function(k)
            r["exclude_friends"] = k.on
        end
    )
    a5.t["exclude_friends"].on = r["exclude_friends"]
    a5.t["attach_no_colision"] =
        a5.add.t(
        "Attached Entitys No Collision",
        a5.p["opt"],
        function(k)
            r["attach_no_colision"] = k.on
        end
    )
    a5.t["attach_no_colision"].on = r["attach_no_colision"]
    a5.t["continuously_assassins"] =
        a5.add.t(
        "Continuously Assassin Peds",
        a5.p["opt"],
        function(k)
            r["continuously_assassins"] = k.on
            if k.on and #aV["peds"] > 0 then
                if D.scid(bn) ~= -1 then
                    local T = c.ped(bn)
                    for i = 1, #aV["peds"] do
                        ai.task_goto_entity(aV["peds"][i], T, 10, 500, 500)
                        ai.task_combat_ped(aV["peds"][i], T, 0, 16)
                    end
                end
            else
                c.wait(500)
            end
            return d.stop(k)
        end
    )
    a5.t["continuously_assassins"].on = r["continuously_assassins"]
    a5.t["disable_history"] =
        a5.add.t(
        "Disable Player-History",
        a5.p["opt"],
        function(k)
            r["disable_history"] = k.on
        end
    )
    a5.t["override_notify_color"] =
        a5.add.u(
        "Force Notification Color",
        "value_i",
        a5.p["opt"],
        function(k)
            r["override_notify_color"] = k.on
            r["notify_color"] = k.value_i
        end
    )
    a5.t["override_notify_color"].max_i = 223
    a5.t["override_notify_color"].on = r["override_notify_color"]
    a5.t["override_notify_color"].value_i = r["notify_color"]
    a5.add.a(
        "Show Notification Color",
        a5.p["opt"],
        function()
            u("Example Text\nNotification color: " .. r["notify_color"])
        end
    )
    a5.t["2t1s_parent"] =
        a5.add.t(
        "2Take1Script Parent",
        a5.p["opt"],
        function(k)
            r["2t1s_parent"] = k.on
        end
    )
    a5.t["2t1s_parent"].on = r["2t1s_parent"]
    a5.t["save_config"] =
        a5.add.a(
        "Save Configuration",
        a5.p["opt"],
        function()
            local _ = c.o(b["Config"], "w+")
            io.output(_)
            for i = 1, #r[0] do
                local q = r[0][i]
                if not string.find(q, "section", 1) then
                    io.write(q .. "=" .. tostring(r[q]) .. "\n")
                else
                    io.write(tostring(r[q]) .. "\n")
                end
            end
            io.close(_)
            x("Saved Configuration to file.")
            u("Saved Configuration to file.", 25)
        end
    )
    x("")
    x("")
    x("Loaded 2Take1Script successfully. :)")
    x("")
    u("2Take1Script successfully loaded. :)", 210)
    _2t1s = true
end
cG()
