--[[####################################################################################
	2Take1Script
		made by haekkzer (· · · · · - - · - · - · - · · ·#1337)
		
		Feature-List
			-- Blacklist
				-- Notify on Player joins
				-- Mark as Modder
				-- Auto-Kick
			-- Modders
				-- Remember every Modder
				-- Modder detections
					-- Max-Speed-Bypass
					-- Illegal Name
					-- Teleport
					-- Req-Ctrl
			-- Block Vehicles in Session
			-- Block Areas with Objects / Map-Mods
			-- Random Explosions / Shake Cam Lobby
			-- Sound Rape
			-- Bounty
				-- Set Bounty after Death
				-- Set Bounty value
					-- Set it anonymously
			-- Send Player / Session to Missions
			-- CEO Player / Session Ban, Dismiss, Terminate
			-- Block - / Unblock from Passive
			-- Disable Control from near Vehicles
			-- Punish Aliens in Lobby
			-- Kick Session / Player with many kick methods
			-- Host Kick / Kick Hosts until You become Host
			-- Crash Session / Player
			-- Attach Objects / Custom build Objects
			-- Send Assassin PEDs to Player
			-- Send SMSs to Player
			-- Falling Asteroids
			-- Apply random force to Player
			-- Trap in Stunt Tube
			-- TP to Player
			-- TP Players vehicle to me
			-- Add Player to Blacklist from Player-menu
			-- Lag Area with Vehicles
			-- Place Bounty on Player / Session anonymously
			-- Spawn Custom created Vehicles
				-- Possibility to do a Preview of the Vehicle
			-- Explosive Beam on Horn
				-- Possibility to enable it on an other player
			-- Chat Log
			-- Auto Kick forbidden typed russki chars   :troll:
			-- Punish if someone asks for a money drop :troll:
			-- Chat commands
				-- !kick / kickall
				-- !explode / explodeall
				-- !crash / crashall
				-- !vehicle
				-- !tp
				-- !clearwanted
				-- !bigpp
				-- Some Commands are just for the Script-User! Safety and Possibility
			-- Animal Model Changer
			-- Load a preset of my favourite Weapons
			-- Shoot Entitys, Tank, Bikes, XMAS Trees, etc
			-- Teleport high in air
			-- Boost Vehicle
			-- License Plate Speedo
				-- Currently shows up to 14 units!
			-- Drive on Ocean / Height
			-- Sync GTA Time with System Time
			-- Random Cloths
			-- Clear Area from All
			-- DEV
				-- Delete Entity from Aim
				-- Just to print some infos about an entity
			-- Options
				-- Exclude Friends from harmful Lobby Events
				-- Spawn in Custom Vehicle
				-- Continuously Assassin PEDs
				-- a few more
			-- Saveable Config

		To some Features u can add ur own Stuff.
		-- Kick Script Events
		-- Texts to detect a money begger
		-- Presaved SMS Texts
		-- PED Assassins
		-- Vehicles for Lag Area
		-- Custom Attachments
		-- Custom Vehicles
		-- Custom Maps / Block Areas
		-- Units for the Speedometer
		-- In every function is a little explanation if necessary

		Thanks to
		-- Biggest Thanks goes to:

			!! Proddy, Lua shit, especially Looping and Calculating POS infront (Vehicle Spawner / Preview) !!

		-- Second Biggest Thanks to all innocent People that got harmed for shit testing for this lua
		-- Sterz, Script Events and the idea of the blocklist
		-- Moist, Script Events
		-- TheSuspect, Custom Vehicles / Attachments, helping finding Bugs / Crashes
		-- Entrodur, Script Events, Crash a Single Player
		-- And all others i might have forgotten to mention
		-- sub1to for this awesome menu!

		Other / FAQ
		-- Kick Hosts until You become Host can cause issues!
		-- Too many Custom Vehicles may cause issues! Just delete them afer use
		-- How do i enter a Custom Vehicle?
			-- Enable Spawn in Vehicle under Settings
		-- Real Time will likely to bring the clouds to flash (this should be fixed, but doesnt work 100%)
		-- After Disabling 2Take1Script-Parent you have to reload the script
		-- Does it work with other scripts?
			-- It should work, tested with Sai's Script-Adviser, OmniSpawner and Sai's ToolBox
		-- Some Features wont work properly if the distance between you and the target is too high
		-- How do i add Stuff?
			-- Everywhere you can add stuff, there is a little explanation, if not, its not possible to add something or it should be easy to add stuff
		-- Using to many Kicks might cause issues
		-- Shoot Entitys have currenntly a weired behavior (work in progress)
			

		If you enabled bodyguards, happy birthday!
			They are just a work in progress, thats the reason why its disabled.


######################################################################################]]--

math.randomseed(utils.time_ms())

_2t1s_ped_assassins = {
	{"Cop", 0x5E3DA4A4, 6},
	{"FIB", 0x5CDEF405, 6},
	{"Juggernaut", 0x90EF5134, 4},
	{"Bigfoot", 0x61D4C771, 28},
	{"Cat", 0x573201B8, 28},
	{"Mountain Lion", 0x1250D7BA, 28},
	{"Humpback", 0x471BE4B2, 28}
	--{"NAME", HASH, TYPE}
}

_2t1s_russki_chars = {
	"а", "б", "в", "г", "д", "е", "ë", "ж", "з", "и", "й", "к", "л", "м", "н", "о", "п", "р", "с", "т", "у", "ф", "х", "ц", "ч", "ш", "щ", "ъ", "ы", "ь", "э", "ю", "я"
}

_2t1s_begger_texts = {
	"money please", "gib mal money hier", "any money dropper", "money dropper anyone?", "give me money", "pls money", "modder please money", "drop money", "could a modder help me out with cash", "pls man drop", "drop money or report", "can someone drop?",
	"reported if you dont drop money", "moneydrop pls", "drop in 2500", "give me some money", "money pls", "can i get money?", "me drop", "one drop money", "drop moeny", "i need money", "pls give my money", "monney please", "monney pls", "drop pls",
	"give money", "drop me", "give cash", "need money", "can i get a money drop", "can i get money", "money me", "do a drop", "do a money drop", "do money drop", "can you give me please 1 milion dollars", "men give mone", "gib money", "mod me money",
	"modder please drop", "drop cashw", "drop cash", "please money", "drop plz", "gif me money", "money droping", "give me $", "drop me monay", "drop $"
}

_2t1s_speedometer_units = {
	{" MPS", 1, "Meter per Second"},
	{" MPH", 2.23694, "Miles per Hour"},
	{" KMH", 3.6, "Kilometers per Hour"},
	{ " KN", 1.94384, "Knots"},
	{" FPS", 3.28084, "Feet per Second"},
	{"MACH", 0.002915451895, "MACH / Soundspeed"},
	{   "C", 0.00000333564095198, "Lightspeed in 300,000 Kilometers"},
	{" KPS", 0.001, "Kilometers per Second"},
	{" MPK", 864, "Meters per Kermit"},
	{" KPK", 0.864, "Kilometers per Kermit"},
	{" MPM", 90, "Meters per Moment"},
	{" HPS", 9.84252, "Hands per Second"},
	{" HPM", 25, "Horses per Minute"},
	{" BPM", 39.37007874, "Bathtubs per Minute"},
	--{" Unit", number to convert from meter per second to unit}
}

_2t1s_block_custom = {
	-- {"NAME", {
	-- 	{HASH, {POS X, Y, Z}, {ROT X, Y, Z}, bool FREEZE, bool INvisible },  -- Repeat this line for more Objects
	--	{false, {TELEPORT POS X, Y, Z}, float heading},  -- This last line will add a Teleporting POS
	-- 	}, },
	{"Block Orbital Room", {
		{3291218330, {335.9567565918, 4834.3325195312, -58.686454772949}, {0, 0, 35}, true, true},
		{3291218330, {326.33291625977, 4827.6704101562, -60.25874710083}, {0, -90, 0}, true, true},
		{false, {342.8, 4838.2, -57}, 121.2},
		}, },
	{"Inactive Screens Orbital Room", {
		{0xAC905876, {336.016083, 4834.12988, -58.0754662}, {-25.160162, 2.82980454e-06, 122.541527}, true, false},
		{0xAC905876, {336.016083, 4834.12988, -58.9853134}, {-25.160162, 2.82980454e-06, 122.541527}, true, false},
		{0xAC905876, {336.016083, 4834.12988, -59.5252228}, {-25.160162, 2.82980454e-06, 122.541527}, true, false},
		{0xAC905876, {336.016083, 4834.12988, -57.5355568}, {-25.160162, 2.82980454e-06, 122.541527}, true, false},
		{false, {342.8, 4838.2, -57}, 121.2},
		}, },
	{"Random Trees LSIA", {
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{3015194288, {nil, -1515, -1100, -3220, -2915, 13, 13}, {0, 0, 0}, true, false},
		{false, {-1336.65, -3044.05, 14}},
		}, },
	{"Trees Main LSC", {
		{3015194288, {nil, -415, -350, -165, -97, 36, 45}, {0, 0, 0}, true, false},
		{3015194288, {nil, -415, -350, -165, -97, 36, 45}, {0, 0, 0}, true, false},
		{3015194288, {nil, -415, -350, -165, -97, 36, 45}, {0, 0, 0}, true, false},
		{3015194288, {nil, -415, -350, -165, -97, 36, 45}, {0, 0, 0}, true, false},
		{3015194288, {nil, -415, -350, -165, -97, 36, 45}, {0, 0, 0}, true, false},
		{false, {-370.4, -104.72, 47}, -110.83449554443},
		}, },	
	{"Windmill Main LSC", {
		{1952396163, {-354.17001342773, -96.722999572754, 36.232788085938}, {-90, 0, 150}, true, false},
		{false, {-370.4, -104.72, 47}, -110.83449554443},
		}, },
	{"Windmill Casino Entrance", {
		{1952396163, {917.71301269531, 7.8880000114441, 78.632781982422}, {-90, 0, 0}, true, false},
		{false, {890.75, 18.9, 80}, -42.7},
		}, }
}

_2t1s_custom_attachments = {
	-- {"NAME", {
	--	{HASH, BONE_ID, {POS X, Y, Z}, {ROT X, Y, Z}, bool invisible},   -- Repeat this line to add more Attachments
	--	}, },
	{"DEMI-GOD - Light", {
		{148511758, 0, {0, 0, 0}, {0, 0, 0}, true},
		}, },
	{"DEMI-GOD - Heavy", {
		{148511758, 0, {0, 0, 0}, {0, 0, 0}, true},
		{3291218330, 0, {0, 0, -3.5}, {0, 90, 0}, true},
		{3291218330, 0, {0, 0, 0}, {0, 90, 0}, true},
		{3291218330, 0, {0, 0, 3.5}, {0, 90, 0}, true},
		}, },
	{"Campfire", {
		{3229200997, 0, {0, 0, 0}, {0, 0, 0}},
		}, },
	{"Weedbush", {
		{452618762, 0, {0, 0, -0.5}, {0, 0, 0}},
		}, },
	{"Big Penis", {
		{3348797566, 0, {-0.1125, 0.15, -0.2}, {0, 0,    0}},
		{3348797566, 0, { 0.1125, 0.15, -0.2}, {0, 0,    0}},
		{2988919045, 0, {      0,  0.5, -0.1}, {0, 0, -180}},
		}, },
	{"Big Balls", {
		{42399216, 0, {-0.1125, 0.15, -0.2}, {0, 0, 0}},
		{42399216, 0, { 0.1125, 0.15, -0.2}, {0, 0, 0}},
		}, },
	{"Pylon Cap", {
		{1324389995, 119, {0, 0, 0}, {0, 0, 0}}, 
		}, },
	{"Black Room", {
		{3136319403, 0, {-1.5,    0,    0}, {180, 90, 0}},
		{3136319403, 0, {-1.5,    0,    0}, {  0, 90, 0}},
		{3136319403, 0, { 1.5,    0,    0}, {180, 90, 0}},
		{3136319403, 0, { 1.5,    0,    0}, {  0, 90, 0}},
		{3136319403, 0, {   0, -1.5,    0}, {270,  0, 0}},
		{3136319403, 0, {   0, -1.5,    0}, { 90,  0, 0}},
		{3136319403, 0, {   0,  1.5,    0}, {270,  0, 0}},
		{3136319403, 0, {   0,  1.5,    0}, { 90,  0, 0}},
		{3136319403, 0, {   0,    0, -0.5}, {180,  0, 0}},
		{3136319403, 0, {   0,    0, -0.5}, {  0,  0, 0}},
		{3136319403, 0, {   0,    0,  1.5}, {180,  0, 0}},
		{3136319403, 0, {   0,    0,  1.5}, {  0,  0, 0}},
		}, },
	{"UFO Ball", {
		{3026699584, 0, {-1.5,    0,    0}, {180, 90, 0}},
		{3026699584, 0, {-1.5,    0,    0}, {  0, 90, 0}},
		{3026699584, 0, { 1.5,    0,    0}, {180, 90, 0}},
		{3026699584, 0, { 1.5,    0,    0}, {  0, 90, 0}},
		{3026699584, 0, {   0, -1.5,    0}, {270,  0, 0}},
		{3026699584, 0, {   0, -1.5,    0}, { 90,  0, 0}},
		{3026699584, 0, {   0,  1.5,    0}, {270,  0, 0}},
		{3026699584, 0, {   0,  1.5,    0}, { 90,  0, 0}},
		{3026699584, 0, {   0,    0, -0.5}, {180,  0, 0}},
		{3026699584, 0, {   0,    0, -0.5}, {  0,  0, 0}},
		{3026699584, 0, {   0,    0,  1.5}, {180,  0, 0}},
		{3026699584, 0, {   0,    0,  1.5}, {  0,  0, 0}},
		}, },
	{"UFO Damaged Ball", {
		{3974683782, 0, {-1.5,    0,    0}, {180, 90, 0}},
		{3974683782, 0, {-1.5,    0,    0}, {  0, 90, 0}},
		{3974683782, 0, { 1.5,    0,    0}, {180, 90, 0}},
		{3974683782, 0, { 1.5,    0,    0}, {  0, 90, 0}},
		{3974683782, 0, {   0, -1.5,    0}, {270,  0, 0}},
		{3974683782, 0, {   0, -1.5,    0}, { 90,  0, 0}},
		{3974683782, 0, {   0,  1.5,    0}, {270,  0, 0}},
		{3974683782, 0, {   0,  1.5,    0}, { 90,  0, 0}},
		{3974683782, 0, {   0,    0, -0.5}, {180,  0, 0}},
		{3974683782, 0, {   0,    0, -0.5}, {  0,  0, 0}},
		{3974683782, 0, {   0,    0,  1.5}, {180,  0, 0}},
		{3974683782, 0, {   0,    0,  1.5}, {  0,  0, 0}},
		}, },
	{"Damaged UFO", {
		{3974683782, 0, {0, 0.5, -0.8}, {0, 0, -180}},
		}, },
	{"Bunker", {
		{1354899844, 0, {0, 0, 0}, {0, 0, 0}},
		}, },
	{"Truck", {
		{2984635849, 0, {0, 0.5, -0.8}, {0, 0, -180}},
		}, },
	{"Damaged Plane", {
		{2710556893, 0, {0, 0, 0}, {0, 0, 0}},
		}, }
}

_2t1s_custom_vehicles = {
	-- nil will be handeld as 0 -> Set every unused value to nil
	-- FIRST LINE JUST FOR THE NAME
	-- {"NAME", {
	--  SECOND LINE, ALL HASHES YOU USE IN THE VEHICLE
	--	{HASH 1, HASH 2, HASH 3, etc.}
	--	{THIRD LINE, HASHES, POS, ROT, etc.}
	--		1 			2			3				4																	5			6					7						8					9				     10					11					12
	--	{HASH, {POS X, Y, Z}, {ROT X, Y, Z}, {COLOR: primary 0x0-0xffffff, secondary, pearlescent, wheel, window}, bool inVisible, int spawnheight, int boneindex, int attach to entity, PED HASH to se into vehicle, bool no_collision, int offset to spawn, int offset Z preview},
	--	}, },
	{"WarMachine", {
		{0x9dae1398, 1030400667, 0x2F03547B, 2971578861, 3871829598, 3229200997, 0x187D938D, 782665360},
		{0x9dae1398, nil, nil, {0, 0, 0, 0, 1}, nil, nil, nil, nil, nil, nil, 15},
		{1030400667, {0, -4, 0}, nil, {0, 0, 0, 0, 1}},
		{0x2F03547B, {0, -8, 4}, {-90, 0, 0}, {0, 0, 0, 0, 1}, true, nil, nil, nil, 1581098148, true},
		{2971578861, {-0.3, -0.6, 9.8}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{2971578861, { 0.3,  0.6, 9.8}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{2971578861, {-0.7,    0, 9.8}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{2971578861, { 0.7,    0, 9.8}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{2971578861, {-0.3,  0.6, 9.8}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{2971578861, { 0.3, -0.6, 9.8}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{2971578861, {-0.3, -0.6, 5.9}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{2971578861, { 0.3,  0.6, 5.9}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{2971578861, {-0.7,    0, 5.9}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{2971578861, { 0.7,    0, 5.9}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{2971578861, {-0.3,  0.6, 5.9}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{2971578861, { 0.3, -0.6, 5.9}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{2971578861, {-0.3, -0.6, 2}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{2971578861, { 0.3,  0.6, 2}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{2971578861, {-0.7,    0, 2}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{2971578861, { 0.7,    0, 2}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{2971578861, {-0.3,  0.6, 2}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{2971578861, { 0.3, -0.6, 2}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{3871829598, {0, 0,   2}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{3871829598, {0, 0, 5.9}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{3871829598, {0, 0, 9.8}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{3229200997, {0, 0,   2}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{3229200997, {0, 0, 5.9}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{3229200997, {0, 0, 9.8}, {-90, 0, 0}, nil, nil, nil, 16, 3},
		{0x187D938D, {0, -8.25, 5.3}, nil, {0, 0, 0, 0, 1}},
		{782665360, {0, -8, 3.1}, nil, {0, 0, 0, 0, 1}},
		}, },
	{"WarMachine XXL", {
		{0x9dae1398, 1030400667, 0x761E2AD3, 0x2F03547B, 1980814227, 782665360, 94602826, 3229200997, 0x187D938D},
		{0x9dae1398, nil, nil, {0, 0, 0, 0, 1}, nil, nil, nil, nil, nil, nil, 20, 5},
		{1030400667, {   0, -4, 0}, nil, {0, 0, 0, 0, 1}},
		{0x9dae1398, {-1.9, -4, 0}, nil, {0, 0, 0, 0, 1}},
		{1030400667, {-1.9, -8, 0}, nil, {0, 0, 0, 0, 1}},
		{0x9dae1398, { 1.9, -4, 0}, nil, {0, 0, 0, 0, 1}},
		{1030400667, { 1.9, -8, 0}, nil, {0, 0, 0, 0, 1}},
		{0x761E2AD3, {0, -15, 3.5}, nil, {0, 0, 0, 0, 1}},
		{0x2F03547B, {-4.85, -16.5, 5.8}, {-90, 0, 0}, {0, 0, 0, 0, 1}, true, nil, nil, nil, 1581098148, true},
		{0x2F03547B, { 4.85, -16.5, 5.8}, {-90, 0, 0}, {0, 0, 0, 0, 1}, true, nil, nil, nil, 1581098148, true},
		{0x2F03547B, { -9.7, -16.5, 5.8}, {-90, 0, 0}, {0, 0, 0, 0, 1}, true, nil, nil, nil, 1581098148, true},
		{0x2F03547B, {  9.7, -16.5, 5.8}, {-90, 0, 0}, {0, 0, 0, 0, 1}, true, nil, nil, nil, 1581098148, true},
		{1980814227, {-0.5, -0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 9},
		{1980814227, { 0.5,  0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 9},
		{1980814227, {-0.9,    0,  4}, {-90, 0, 0}, nil, nil, nil, 16, 9},
		{1980814227, { 0.9,    0,  4}, {-90, 0, 0}, nil, nil, nil, 16, 9},
		{1980814227, {-0.5,  0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 9},
		{1980814227, { 0.5, -0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 9},
		{1980814227, {-0.5, -0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 9},
		{1980814227, { 0.5,  0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 9},
		{1980814227, {-0.9,    0, 12}, {-90, 0, 0}, nil, nil, nil, 16, 9},
		{1980814227, { 0.9,    0, 12}, {-90, 0, 0}, nil, nil, nil, 16, 9},
		{1980814227, {-0.5,  0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 9},
		{1980814227, { 0.5, -0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 9},
		{1980814227, {-0.5, -0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 10},
		{1980814227, { 0.5,  0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 10},
		{1980814227, {-0.9,    0,  4}, {-90, 0, 0}, nil, nil, nil, 16, 10},
		{1980814227, { 0.9,    0,  4}, {-90, 0, 0}, nil, nil, nil, 16, 10},
		{1980814227, {-0.5,  0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 10},
		{1980814227, { 0.5, -0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 10},
		{1980814227, {-0.5, -0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 10},
		{1980814227, { 0.5,  0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 10},
		{1980814227, {-0.9,    0, 12}, {-90, 0, 0}, nil, nil, nil, 16, 10},
		{1980814227, { 0.9,    0, 12}, {-90, 0, 0}, nil, nil, nil, 16, 10},
		{1980814227, {-0.5,  0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 10},
		{1980814227, { 0.5, -0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 10},
		{1980814227, {-0.5, -0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 11},
		{1980814227, { 0.5,  0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 11},
		{1980814227, {-0.9,    0,  4}, {-90, 0, 0}, nil, nil, nil, 16, 11},
		{1980814227, { 0.9,    0,  4}, {-90, 0, 0}, nil, nil, nil, 16, 11},
		{1980814227, {-0.5,  0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 11},
		{1980814227, { 0.5, -0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 11},
		{1980814227, {-0.5, -0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 11},
		{1980814227, { 0.5,  0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 11},
		{1980814227, {-0.9,    0, 12}, {-90, 0, 0}, nil, nil, nil, 16, 11},
		{1980814227, { 0.9,    0, 12}, {-90, 0, 0}, nil, nil, nil, 16, 11},
		{1980814227, {-0.5,  0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 11},
		{1980814227, { 0.5, -0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 11},
		{1980814227, {-0.5, -0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 8},
		{1980814227, { 0.5,  0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 8},
		{1980814227, {-0.9,    0,  4}, {-90, 0, 0}, nil, nil, nil, 16, 8},
		{1980814227, { 0.9,    0,  4}, {-90, 0, 0}, nil, nil, nil, 16, 8},
		{1980814227, {-0.5,  0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 8},
		{1980814227, { 0.5, -0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 8},
		{1980814227, {-0.5, -0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 8},
		{1980814227, { 0.5,  0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 8},
		{1980814227, {-0.9,    0, 12}, {-90, 0, 0}, nil, nil, nil, 16, 8},
		{1980814227, { 0.9,    0, 12}, {-90, 0, 0}, nil, nil, nil, 16, 8},
		{1980814227, {-0.5,  0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 8},
		{1980814227, { 0.5, -0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 8},
		{0x9dae1398, {   0,  -6, 3.5}, nil, {0, 0, 0, 0, 1}},
		{1030400667, {   0, -10, 3.5}, nil, {0, 0, 0, 0, 1}},
		{0x9dae1398, {-1.9, -10, 3.5}, nil, {0, 0, 0, 0, 1}},
		{1030400667, {-1.9, -14, 3.5}, nil, {0, 0, 0, 0, 1}},
		{0x9dae1398, { 1.9, -10, 3.5}, nil, {0, 0, 0, 0, 1}},
		{1030400667, { 1.9, -14, 3.5}, nil, {0, 0, 0, 0, 1}},
		{0x187D938D, {0, -10, 7}, nil, {0, 0, 0, 0, 1}},
		{1030400667, {-10, -18, 5.5}, {0, 180,  90}, {0, 0, 0, 0, 1}},
		{1030400667, { 10, -18, 5.5}, {0, 180, -90}, {0, 0, 0, 0, 1}},
		{782665360, {-4.85, -16.5, 5.8}, nil},
		{782665360, { 4.85, -16.5, 5.8}, nil},
		{782665360, { -9.7, -16.5, 5.8}, nil},
		{782665360, {  9.7, -16.5, 5.8}, nil},
		{782665360, {-4.85, -16.5, 5.8}, {-90, 0, 0}},
		{782665360, { 4.85, -16.5, 5.8}, {-90, 0, 0}},
		{782665360, { -9.7, -16.5, 5.8}, {-90, 0, 0}},
		{782665360, {  9.7, -16.5, 5.8}, {-90, 0, 0}},
		{94602826, {0, 0, 3.5}, nil, nil, nil, nil, 16,  9},
		{94602826, {0, 0,  12}, nil, nil, nil, nil, 16,  9},
		{94602826, {0, 0, 3.5}, nil, nil, nil, nil, 16,  10},
		{94602826, {0, 0,  12}, nil, nil, nil, nil, 16,  10},
		{94602826, {0, 0, 3.5}, nil, nil, nil, nil, 16, 11},
		{94602826, {0, 0,  12}, nil, nil, nil, nil, 16, 11},
		{94602826, {0, 0, 3.5}, nil, nil, nil, nil, 16, 8},
		{94602826, {0, 0,  12}, nil, nil, nil, nil, 16, 8},
		{3229200997, {0, 0, 3.5}, nil, nil, nil, nil, 16,  9},
		{3229200997, {0, 0,  12}, nil, nil, nil, nil, 16,  9},
		{3229200997, {0, 0,  15}, nil, nil, nil, nil, 16,  9},
		{3229200997, {0, 0, 3.5}, nil, nil, nil, nil, 16,  10},
		{3229200997, {0, 0,  12}, nil, nil, nil, nil, 16,  10},
		{3229200997, {0, 0,  15}, nil, nil, nil, nil, 16,  10},
		{3229200997, {0, 0, 3.5}, nil, nil, nil, nil, 16, 11},
		{3229200997, {0, 0,  12}, nil, nil, nil, nil, 16, 11},
		{3229200997, {0, 0,  15}, nil, nil, nil, nil, 16, 11},
		{3229200997, {0, 0, 3.5}, nil, nil, nil, nil, 16, 8},
		{3229200997, {0, 0,  12}, nil, nil, nil, nil, 16, 8},
		{3229200997, {0, 0,  15}, nil, nil, nil, nil, 16, 8},
		}, },
	--[[{"2-Wheeler", {
		{0xdff0594c, 0x43935b76, 0x3086f33b, 0xb685e324, 0xb34e141d},
		{0xdff0594c, nil, nil, nil, true, nil, nil, nil, nil, nil, 3},
		{0x43935b76, {-0.32, 0.02, -0.2}, {0, 0, 90}},
		{0x3086f33b, {-0.3, 0.5, -0.07}},
		{0x43935b76, {0.34, 0.01, -0.18}, {0, 0, 90}},
		{0x3086f33b, {0.34, 0.52, -0.07}, {0, 0, 180}},
		{0xb685e324, {0, 0.48, -0.07}, {0, -90, 0}},
		{0xb685e324, {-0.3, 0.32, 0.3}, {30, 0, 0}},
		{0xb34e141d, nil, nil, nil, nil, nil, 24},
		}, },
	{"Cartman", {
		{1131912276, 979462386},
		{1131912276, nil, nil, nil, true, nil, nil, nil, nil, nil, 2},
		{979462386, {0, 0, 0.13}},
	}, },
	{"Cartman 2", {
		{0x43779c54, 0x334b38db},
		{0x43779c54, nil, nil, nil, true, nil, nil, nil, nil, nil, 2},
		{0x334b38db, {0, -0.3, -0.4}},
	}, },]]
	{"Broomstick", {
		{0x7B54A9D3, 1689385044},
		{0x7B54A9D3, nil, nil, nil, true, nil, nil, nil, nil, nil, 1},
		{1689385044, {0, -0.6, 0.2}, {32.5, 0, 180}},
		}, },
	{"Gaming PC", {
		{2704629607, 2084153992},
		{2704629607, nil, nil, {0, 0, 0, 0, 1}, nil, nil, nil, nil, nil, nil, 3},
		{2084153992, {0, 0.9, -0.1}},
		}, },
	{"Driving Seashark", {
		{0xE5BA6858, 0xED762D49},
		{0xE5BA6858, nil, nil, nil, true, nil, nil, nil, nil, nil, 3},
		{0xED762D49, {0, 0, -0.35}},
		}, },
	{"Surfboard", {
		{0xE2E7D4AB, 344984267},
		{0xE2E7D4AB, nil, nil, nil, true, nil, nil, nil, nil, nil, 7},
		{344984267, {-0.5, -0.75, -0.3}, {-90, 0, 0}},
		}, },
	{"Hoverboard", {
		{0x58CDAF30, 1159992493},
		{0x58CDAF30, nil, nil, nil, true, nil, nil, nil, nil,nil, 2},
		{1159992493, {0, 0.45, -0.8}, {-90, 0, 0}, nil, nil, nil, nil, nil, nil, true},
		}, },
	{"Floating Dump", {
		{0xE2E7D4AB, 0x810369E2},
		{0xE2E7D4AB, nil, nil, nil, true, nil, nil, nil, nil, nil, 12},
		{0x810369E2},
		}, },
	{"Flying Dump", {
		{0x2F03547B, 0x810369E2},
		{0x2F03547B, nil, nil, nil, true, nil, nil, nil, nil, nil, 10, 2},
		{0x810369E2},
		}, },
	{"Submarine Blimp", {
		{0xC07107EE, 0xF7004C86},
		{0xC07107EE, nil, nil, nil, true, nil, nil, nil, nil, nil, 20},
		{0xF7004C86},
		}, },
	{"Bandito Tree", {
		{0xEEF345EC, 3015194288},
		{0xEEF345EC, nil, nil, nil, nil, nil, nil, nil, nil, nil, 2},
		{3015194288, {0, 0, -0.3}},
		}, },
	{"Attach Tree", {
		{3015194288},
		{0},
		{3015194288, {0, 0, -0.3}},
		}, },
	{"Flying Seamine", {
		{0x58CDAF30, 1039126093},
		{0x58CDAF30, nil, nil, nil, nil, nil, nil, nil, nil, nil, 2},
		{1039126093},
		}, },
	{"Attach Ramp", {
		{3233397978},
		{0},
		{3233397978, {0, 4.5, 0.25}, {0, 0, 180}},
		}, },
	{"Attach Invisible Ramp", {
		{3233397978},
		{0},
		{3233397978, {0, 4.5, 0.25}, {0, 0, 180}, nil, true},
		}, },
	{"Attach Invisible Ramp 2", {
		{0x9dae1398},
		{0},
		{0x9dae1398, {0, -2.25, 0}, nil, nil, true},
		}, },
	{"Attach Invisible Ramp 3", {
		{0xED62BFA9},
		{0},
		{0xED62BFA9, {0, 2.25, 0.25}, {-7.5, 0, 0}, nil, true},
		}, },
	{"Sofa Car", {
		{376180694}, 
		{0, nil, nil, nil, true},
		{376180694, {0, -0.2, -0.75}, {0, 0, 180}},
		}, },
	{"Hydra 5-Seats", {
		{970385471, 1131912276, 1840382115},
		{970385471, nil, nil, nil, nil, nil, nil, nil, nil, nil, 10},
		{1131912276, {-2.25, -2.31, 0.34}, nil, nil, true},
		{1131912276, { 2.25, -2.31, 0.34}, nil, nil, true},
		{1131912276, { -4.5, -3.35, 0.31}, nil, nil, true},
		{1131912276, {  4.5, -3.35, 0.31}, nil, nil, true},
		{1840382115, {-2.25, -2.81, 0.74}, {0, 0, 180}},
		{1840382115, { 2.25, -2.81, 0.74}, {0, 0, 180}},
		{1840382115, { -4.5, -3.85, 0.44}, {0, 0, 180}},
		{1840382115, {  4.5, -3.85, 0.44}, {0, 0, 180}},
		}, },
	{"Hakuchou + Sidecar", {
		{1265391242, 55628203, 1840382115},
		{1265391242, nil, nil, nil, nil, nil, nil, nil, nil, nil, 2},
		{55628203, {0.5, 0, -0.3}},
		{1840382115, {0.5, -0.5, 0.1}, {0, 0, 180}},
		}, },
	{"Wheelchair", {
		{0x187D938D, 1262298127},
		{0x187D938D, nil, nil, nil, true, nil, nil, nil, nil, nil, 3},
		{1262298127, {-0.425, -0.05, -0.25}, {0, 0, 180}},
		}, },
	{"Wheelbarrow + Jesus", {
		{0x187D938D, 1133730678, 1265391242},
		{0x187D938D, nil, nil, nil, true, nil, nil, nil, nil, nil, 3},
		{1133730678, {-0.425, 0.1, -0.75}, {0, 0, 90}},
		{1265391242, {-0.425, -1.125, -0.345}, nil, nil, true, nil, nil, nil, 0xCE2CB751, true},
		}, },
	{"Big Penis", {
		{0x187D938D, 3859819303, 148511758},
		{0x187D938D, nil, nil, nil, true, nil, nil, nil, nil, nil, 7},
		{3859819303, {0, 0, 2}},
		{3859819303, {0, 0, 6}},
		{3859819303, {0, 0, 10}},
		{148511758, {-2, 0, 0}},
		{148511758, {2, 0, 0}},
		}, },
	{"Street Blazer + Spinning Wheels", {
		{0xE5BA6858, 1230400944},
		{0xE5BA6858, nil, nil, nil, nil, nil, nil, nil, nil, nil, 3},
		{1230400944, nil, {0, -90, 0}, nil, nil, nil, 1},
		{1230400944, nil, {0, -90, 0}, nil, nil, nil, 2},
		{1230400944, nil, {0, -90, 0}, nil, nil, nil, 3},
		{1230400944, nil, {0, -90, 0}, nil, nil, nil, 4},
		}, },
	{"Driveable Train", {
		{3471458123, 1030400667},
		{3471458123, nil, nil, nil, true, nil, nil, nil, nil, nil, 15},
		{1030400667},
		}, },
	{"Cargoplane XXL", {
		{0x15F27762},
		{0x15F27762, nil, nil, nil, nil, 350, nil, nil, nil, nil, 100, 75},
		{0x15F27762, { -50,  -50, 0}},
		{0x15F27762, {  50,  -50, 0}},
		{0x15F27762, {-100, -100, 0}},
		{0x15F27762, { 100, -100, 0}},
		}, },
	{"UFO", {
		{970385471, 3026699584},
		{970385471, nil, nil, nil, true, 100, nil, nil, nil, nil, 45, 10},
		{3026699584, {0, 0, 10}},
		}, },
	{"UFO Damaged", {
		{970385471, 3974683782}, 
		{970385471, nil, nil, nil, true, 100, nil, nil, nil, nil, 45, 10},
		{3974683782, {0, 0, 10}},
		}, },
	{"Spinning UFO", {
		{970385471, 0x2F03547B, 3026699584},
		{970385471, nil, nil, nil, true, 125, nil, nil, nil, nil, 45, 10},
		{0x2F03547B, {0, 0, 10}, nil, nil, true, nil, nil, nil, 1581098148, 1},
		{3026699584, {0, 0, 1}, nil, nil, nil, nil, 16, 2, nil, true},
		}, },
	{"Driveable Tug Boat", {
		{3471458123, 2194326579},
		{3471458123, nil, nil, nil, true, nil, nil, nil, nil, nil, 20},
		{2194326579},
		}, },
	{"Hydra Luxor", {
		{970385471, 3080673438},
		{970385471, nil, nil, nil, true, 100, nil, nil, nil, nil, 12},
		{3080673438},
		}, },
	{"XL Tank", {
		{782665360},
		{782665360, nil, nil, nil, nil, nil, nil, nil, nil, nil, 15},
		{782665360, { 0, -6, 0}},
		{782665360, {-4,  0, 0}},
		{782665360, {-4, -6, 0}},
		{782665360, {-2, -2, 2}},
		}, },
	{"XXL Tank", {
		{782665360},
		{782665360, nil, nil, nil, nil, nil, nil, nil, nil, nil, 20},
		{782665360, { 0,  -6, 0}},
		{782665360, { 0, -12, 0}},
		{782665360, {-3,   0, 0}},
		{782665360, {-3,  -6, 0}},
		{782665360, {-3, -12, 0}},
		{782665360, { 3,   0, 0}},
		{782665360, { 3,  -6, 0}},
		{782665360, { 3, -12, 0}},
		{782665360, { 0,   0, 2}},
		{782665360, { 0,  -6, 2}},
		{782665360, { 0, -12, 2}},
		{782665360, {-3,   0, 2}},
		{782665360, {-3,  -6, 2}},
		{782665360, {-3, -12, 2}},
		{782665360, { 3,   0, 2}},
		{782665360, { 3,  -6, 2}},
		{782665360, { 3, -12, 2}},
		{782665360, { 0,   0, 4}},
		{782665360, { 0,  -6, 4}},
		{782665360, { 0, -12, 4}},
		{782665360, {-3,   0, 4}},
		{782665360, {-3,  -6, 4}},
		{782665360, {-3, -12, 4}},
		{782665360, { 3,   0, 4}},
		{782665360, { 3,  -6, 4}},
		{782665360, { 3, -12, 4}},
		{782665360, { 1.5, -3, 6}},
		{782665360, { 1.5, -9, 6}},
		{782665360, {-1.5, -9, 6}},
		{782665360, {-1.5, -3, 6}},
		{782665360, {   0, -6, 8}},
		}, },
	{"StarWars Tie-Fighter", {
		{0xB39B0AE6, 0x3d6aaa9b, 0x9dae1398, 0x3defce4d, 0x708d300f, 0x70b0e25a, 0x592c8b76, 0xffd7d47d, 0x177606a2, 0x3794acc9, 0x79454d60, 0x9e4d88ca, 0x5b7e4520, 0xd9621159, 0xf697c81b, 0xd43979f7},
		{0xB39B0AE6, nil, nil, nil, nil, 350, nil, nil, nil, nil, 35, 15},
		{0x3d6aaa9b, {-1, -2, 0}, {0, -90, 0}},
		{0x3d6aaa9b, {1, -2, 0}, {0, 90, 0}},
		{0x3d6aaa9b, {-16.8, -12.7, -0.6}, {0, -90, 90}},
		{0x3d6aaa9b, {17, -12.7, -0.6}, {0, 90, -90}},
		{0x3d6aaa9b, {-8.5, -12.7, -0.6}, {0, -90, 90}},
		{0x3d6aaa9b, {8.7, -12.7, -0.6}, {0, 90, -90}},
		{0x9dae1398, {2, 2, 0}, {0, 90, 0}},
		{0x9dae1398, {-2, 2, 0}, {0,-90, 0}},
		{0x9dae1398, {-4, -2, 0}, {0, -90, 0}},
		{0x9dae1398, { 4, -2, 0}, {0, 90, 0}},
		{0x3defce4d, {0, 7.1, -0.22}, {-90, 0, 0}},
		{0x708d300f, {-5, -13,   1.6}, { 13,  78,  135}},
		{0x708d300f, { 4, -13,   1.6}, { 13, -78, -135}},
		{0x708d300f, { 5, -13,  -4.6}, {-13, -78, -135}},
		{0x708d300f, {-5, -13,  -4.6}, { -9,  75,  135}},
		{0x708d300f, { 0,  -9, 0.173}, {  0,  90,    0}},
		{0x708d300f, { 0,  -9,   0.2}, {  0, -90,    0}},
		{0x70b0e25a, { 3.7, -7, 0}, { 90, 0, 91}},
		{0x70b0e25a, {-3.6, -7, 0}, {-90, 0, 90}},
		{0x592c8b76, {    0,  -0.5, -2.1}, {-180,   0, -90}},
		{0x592c8b76, {    0,  -8.6, -2.1}, { 180,   0, -90}},
		{0x592c8b76, {-17.7, -13.1,  0.4}, { 178, -15,   0}},
		{0x592c8b76, {-17.6, -12.8, -1.7}, {   0, -15,   0}},
		{0x592c8b76, { 17.7, -12.9,  0.6}, {-180,  15,   0}},
		{0x592c8b76, { 17.4, -12.7, -2.2}, {   0,  15,   0}},
		{0xffd7d47d, { 20, -6.4, -7.3}, {-60, 0, 90}},
		{0xffd7d47d, { 20, -6.5,  6.3}, { 60, 0, 90}},
		{0xffd7d47d, {-20, -6.4, -7.3}, { 60, 0, 90}},
		{0xffd7d47d, {-20, -6.5,  6.3}, {-60, 0, 90}},
		{0x177606a2, {  -20, -6.9,    8}, {-90, 0,  0}},
		{0x177606a2, {-21.5, -6.9,  5.4}, {-90, 0, 0}},
		{0x177606a2, {   20, -6.9,    8}, {-90, 0, 0}},
		{0x177606a2, { 21.5, -6.9,  5.4}, {-90, 0, 0}},
		{0x177606a2, {  -20, -6.8,   -9}, {-90, 0, 0}},
		{0x177606a2, {-21.4, -6.8, -6.4}, {-90, 0, 0}},
		{0x177606a2, { 19.9, -6.8,   -9}, {-90, 0, 0}},
		{0x177606a2, { 21.3, -6.8, -6.3}, {-90, 0, 0}},
		{0x3794acc9, {  -20, 0.8,     8}, {0, 0, 0}},
		{0x3794acc9, {-21.5, 0.8,   5.4}, {0, 0, 0}},
		{0x3794acc9, {   20, 0.8,     8}, {0, 0, 0}},
		{0x3794acc9, { 21.5, 0.8,   5.4}, {0, 0, 0}},
		{0x3794acc9, {  -20, 0.9,    -9}, {0, 0, 0}},
		{0x3794acc9, {-21.4, 0.9,  -6.4}, {0, 0, 0}},
		{0x3794acc9, {   20, 0.9,    -9}, {0, 0, 0}},
		{0x3794acc9, { 21.3, 0.9, -6.34}, {0, 0, 0}},
		{0x79454d60, { -16.1, -11.42, -0.56}, {   90,   0,  0}},
		{0x79454d60, { 16.05, -11.51, -0.49}, {   90,   0,  0}},
		{0x79454d60, {-15.88, -16.01, -0.59}, {  -90,   0,  0}},
		{0x79454d60, { 16.11, -16.01,  -0.6}, {  -90,   0,  0}},
		{0x79454d60, {  19.7, -15.31,  6.35}, {  -30,  90,  90}},
		{0x79454d60, { -19.8,  -15.3,  -7.4}, {  -30,  90,  90}},
		{0x79454d60, { -19.6, -15.34,   6.4}, {-30.3, -90, -90}},
		{0x79454d60, {  19.8, -15.21,  -7.4}, {  150, -90, -90}},
		{0x9e4d88ca, {-6.7,   -24, -0.8}, {90, 0, 0}},
		{0x9e4d88ca, {-2.9, -24.4,  1.9}, {90, 0, 0}},
		{0x9e4d88ca, { 2.9, -24.4,  1.9}, {90, 0, 0}},
		{0x9e4d88ca, {   6,   -24, -0.8}, {90, 0, 0}},
		{0x9e4d88ca, {-2.7, -24.4, -3.9}, {90, 0, 0}},
		{0x9e4d88ca, { 3.1, -24.4, -3.9}, {90, 0, 0}},
		{0x5b7e4520, {0, -16.63, -1}, {90, 0, 0}},
		{0xd9621159, {0,   3.24, -0.19}, { 90, 0, 0}},
		{0xd9621159, {0, -18.81,    -1}, {-90, 0, 0}},
		{0xf697c81b, {     0,   0.7,    1.2}, {    180,      0,     90}},
		{0xf697c81b, {     0,  -9.3,    2.6}, {    180,      0,     90}},
		{0xf697c81b, { -22.5, -8.15,   1.79}, { -149.6, -124.6,     90}},
		{0xf697c81b, { -17.2, -7.99, -11.72}, {  150.4,   -124,     90}},
		{0xf697c81b, { -22.4, -7.91,   -2.8}, {    152, -54.82,   87.8}},
		{0xf697c81b, {-17.21, -8.09,  10.78}, {  -31.6,  124.1,    -90}},
		{0xf697c81b, {  17.2,    -8, -11.73}, {   -149, -124.1,   91.5}},
		{0xf697c81b, { 22.46, -8.02,  -2.57}, {   -151,    -56,   89.6}},
		{0xf697c81b, { 22.52, -8.11,   1.65}, {-148.66,  124.7, -91.15}},
		{0xf697c81b, { 17.18, -8.09,  10.74}, {  157.7, -50.51,   79.9}},
		{0xd43979f7, {0, -0.73, -2.4}, {0, 180, 0}},
		{0xd43979f7, {0, -8.84, -2.4}, {0, 180, 0}},
		}, },
	{"StarWars Star-Destroyer", {
		{970385471, 0x2F03547B, 0x9dae1398, 1030400667, 0x761E2AD3, 0x810369E2, 0x3D6AAA9B, 2655881418, 4206403457, 932490441, 350630312, 3764890420, 4057348071, 1980814227, 0x187D938D, 782665360, 94602826, 3229200997},
		{970385471, nil, nil, nil, true, 150, nil, nil, nil, nil, 80, 50},
		{0x2F03547B, { 20, -25, -24}, {-90, 0, 180}, nil, true, nil, nil, nil, 1581098148, 1},
		{0x2F03547B, {  0, -25, -24}, {-90, 0, 180}, nil, true, nil, nil, nil, 1581098148, 1},
		{0x2F03547B, {-20, -25, -24}, {-90, 0, 180}, nil, true, nil, nil, nil, 1581098148, 1},
		{0x9dae1398, {0, 40, -20}},
		{1030400667, {   0, -4, 0}, nil, nil, nil, nil, nil, 5},
		{0x9dae1398, {-1.9, -4, 0}, nil, nil, nil, nil, nil, 5},
		{1030400667, {-1.9, -8, 0}, nil, nil, nil, nil, nil, 5},
		{0x9dae1398, { 1.9, -4, 0}, nil, nil, nil, nil, nil, 5},
		{1030400667, { 1.9, -8, 0}, nil, nil, nil, nil, nil, 5},
		{0x761E2AD3, {0, -15, 3.5}, nil, nil, nil, nil, nil, 5},
		{0x2F03547B, {-4.85, -16.5, 5.8}, {-90, 0, 0}, nil, true, nil, nil, 5, 1581098148, 1},
		{0x2F03547B, { 4.85, -16.5, 5.8}, {-90, 0, 0}, nil, true, nil, nil, 5, 1581098148, 1},
		{0x2F03547B, { -9.7, -16.5, 5.8}, {-90, 0, 0}, nil, true, nil, nil, 5, 1581098148, 1},
		{0x2F03547B, {  9.7, -16.5, 5.8}, {-90, 0, 0}, nil, true, nil, nil, 5, 1581098148, 1},
		{0x810369E2, {0, -15, -8}},
		{0x3D6AAA9B, { 4, -10, -12}, {90, 0, 0}},
		{0x3D6AAA9B, {-4, -10, -12}, {90, 0, 0}},
		{0x3D6AAA9B, { 4, -18, -12}, {90, 0, 0}},
		{0x3D6AAA9B, {-4, -18, -12}, {90, 0, 0}},
		{2655881418, {2,  3, 5}, nil, nil, nil, nil, 16, 2},
		{2655881418, {2, -3, 5}, nil, nil, nil, nil, 16, 2},
		{2655881418, {4,  0, 5}, nil, nil, nil, nil, 16, 2},
		{2655881418, {-2, 3, 5}, nil, nil, nil, nil, 16, 2},
		{2655881418, {-2,-3, 5}, nil, nil, nil, nil, 16, 2},
		{2655881418, {-4, 0, 5}, nil, nil, nil, nil, 16, 2},
		{2655881418, {2,  3, 5}, nil, nil, nil, nil, 16, 3},
		{2655881418, {2, -3, 5}, nil, nil, nil, nil, 16, 3},
		{2655881418, {4,  0, 5}, nil, nil, nil, nil, 16, 3},
		{2655881418, {-2, 3, 5}, nil, nil, nil, nil, 16, 3},
		{2655881418, {-2,-3, 5}, nil, nil, nil, nil, 16, 3},
		{2655881418, {-4, 0, 5}, nil, nil, nil, nil, 16, 3},
		{2655881418, {2,  3, 5}, nil, nil, nil, nil, 16, 4},
		{2655881418, {2, -3, 5}, nil, nil, nil, nil, 16, 4},
		{2655881418, {4,  0, 5}, nil, nil, nil, nil, 16, 4},
		{2655881418, {-2, 3, 5}, nil, nil, nil, nil, 16, 4},
		{2655881418, {-2,-3, 5}, nil, nil, nil, nil, 16, 4},
		{2655881418, {-4, 0, 5}, nil, nil, nil, nil, 16, 4},
		{4206403457, { 0, 0, 4}, nil, nil, nil, nil, 16, 2},
		{4206403457, { 0, 0, 4}, nil, nil, nil, nil, 16, 3},
		{4206403457, { 0, 0, 4}, nil, nil, nil, nil, 16, 4},
		{932490441, { 1,  1.5, 5}, {90, 0, 0}, nil, nil, nil, 16, 2},
		{932490441, { 1, -1.5, 5}, {90, 0, 0}, nil, nil, nil, 16, 2},
		{932490441, { 2,    0, 5}, {90, 0, 0}, nil, nil, nil, 16, 2},
		{932490441, {-1,  1.5, 5}, {90, 0, 0}, nil, nil, nil, 16, 2},
		{932490441, {-1, -1.5, 5}, {90, 0, 0}, nil, nil, nil, 16, 2},
		{932490441, {-2,    0, 5}, {90, 0, 0}, nil, nil, nil, 16, 2},
		{932490441, { 1,  1.5, 5}, {90, 0, 0}, nil, nil, nil, 16, 3},
		{932490441, { 1, -1.5, 5}, {90, 0, 0}, nil, nil, nil, 16, 3},
		{932490441, { 2,    0, 5}, {90, 0, 0}, nil, nil, nil, 16, 3},
		{932490441, {-1,  1.5, 5}, {90, 0, 0}, nil, nil, nil, 16, 3},
		{932490441, {-1, -1.5, 5}, {90, 0, 0}, nil, nil, nil, 16, 3},
		{932490441, {-2,    0, 5}, {90, 0, 0}, nil, nil, nil, 16, 3},
		{932490441, { 1,  1.5, 5}, {90, 0, 0}, nil, nil, nil, 16, 4},
		{932490441, { 1, -1.5, 5}, {90, 0, 0}, nil, nil, nil, 16, 4},
		{932490441, { 2,    0, 5}, {90, 0, 0}, nil, nil, nil, 16, 4},
		{932490441, {-1,  1.5, 5}, {90, 0, 0}, nil, nil, nil, 16, 4},
		{932490441, {-1, -1.5, 5}, {90, 0, 0}, nil, nil, nil, 16, 4},
		{932490441, {-2,    0, 5}, {90, 0, 0}, nil, nil, nil, 16, 4}, 
		{350630312, {0, 40, -30}, {0, 180, 90}},
		{350630312, {0, 40, -22.5}, {0, 180, 90}},
		{350630312, { 15.5, 5, -30}, {0, 180, 90}},
		{350630312, {-15.5, 5, -30}, {0, 180, 90}},
		{3764890420, {25, -15, -30}, {0, 0, 23}},
		{3764890420, {-25, -15, -30}, {0, 0, -23}},
		{3764890420, {25, -15, -20}, {0, 17.5, 23}},
		{3764890420, {-25, -15, -20}, {0, -17.5, -23}},
		{3764890420, {20.75, -5, -20}, {0, 17.5, 23}},
		{3764890420, {-20.75, -5, -20}, {0, -17.5, -23}},
		{3764890420, {0, 25, -22.5}, {0, 0, 0}},
		{3764890420, {0, 25, -30}, {0, 0, 0}},
		{3764890420, {0, -20, -30}, {0, 0, 0}},
		{0x3D6AAA9B, {2, 70, -27.2}, {0, -90, 23}},
		{0x3D6AAA9B, {9, 54, -27.2}, {0, -90, 23}},
		{0x3D6AAA9B, {16, 38, -27.2}, {0, -90, 23}},
		{0x3D6AAA9B, {23, 22, -27.2}, {0, -90, 23}},
		{0x3D6AAA9B, {30, 6, -27.2}, {0, -90, 23}},
		{0x3D6AAA9B, {37, -10, -27.2}, {0, -90, 23}},
		{0x3D6AAA9B, {44, -26, -27.2}, {0, -90, 23}},
		{0x3D6AAA9B, {2, 70, -24.4}, {0, -90, 23}},
		{0x3D6AAA9B, {9, 54, -24.4}, {0, -90, 23}},		
		{0x3D6AAA9B, {16, 38, -24.4}, {0, -90, 23}},
		{0x3D6AAA9B, {23, 22, -24.4}, {0, -90, 23}},
		{0x3D6AAA9B, {30, 6, -24.4}, {0, -90, 23}},
		{0x3D6AAA9B, {37, -10, -24.4}, {0, -90, 23}},
		{0x3D6AAA9B, {44, -26, -24.4}, {0, -90, 23}},
		{0x3D6AAA9B, {30, 6, -30}, {0, -90, 23}},
		{0x3D6AAA9B, {37, -10, -30}, {0, -90, 23}},
		{0x3D6AAA9B, {44, -26, -30}, {0, -90, 23}},
		{0x3D6AAA9B, {-2, 70, -27.2}, {0, 90, -23}},
		{0x3D6AAA9B, {-9, 54, -27.2}, {0, 90, -23}},
		{0x3D6AAA9B, {-16, 38, -27.2}, {0, 90, -23}},
		{0x3D6AAA9B, {-23, 22, -27.2}, {0, 90, -23}},
		{0x3D6AAA9B, {-30, 6, -27.2}, {0, 90, -23}},
		{0x3D6AAA9B, {-37, -10, -27.2}, {0, 90, -23}},
		{0x3D6AAA9B, {-44, -26, -27.2}, {0, 90, -23}},
		{0x3D6AAA9B, {-2, 70, -24.4}, {0, 90, -23}},
		{0x3D6AAA9B, {-9, 54, -24.4}, {0, 90, -23}},
		{0x3D6AAA9B, {-16, 38, -24.4}, {0, 90, -23}},
		{0x3D6AAA9B, {-23, 22, -24.4}, {0, 90, -23}},
		{0x3D6AAA9B, {-30, 6, -24.4}, {0, 90, -23}},
		{0x3D6AAA9B, {-37, -10, -24.4}, {0, 90, -23}},
		{0x3D6AAA9B, {-44, -26, -24.4}, {0, 90, -23}},
		{0x3D6AAA9B, {-30, 6, -30}, {0, 90, -23}},
		{0x3D6AAA9B, {-37, -10, -30}, {0, 90, -23}},
		{0x3D6AAA9B, {-44, -26, -30}, {0, 90, -23}},
		{4057348071, {20, 20, -22.5}, {0, 0, 23}},
		{4057348071, {-20, 20, -22.5}, {0, 0, -23}},
		{4057348071, {5, -15, -15}, {0, 0, 23}},
		{4057348071, {-5, -15, -15}, {0, 0, -23}},
		{4057348071, {0, 0, -15}, {0, 0, 0}},
		{4057348071, {10, -25, -15}, {0, 0, 90}},
		{4057348071, {0, -25, -15}, {0, 0, 90}},
		{4057348071, {-10, -25, -15}, {0, 0, 90}},
		{4057348071, {0, 15, -20}, {-90, 90, 0}},
		{4057348071, {15, 15, -22.5}, {-90, -60, 0}},
		{4057348071, {-15, 15, -22.5}, {-90, 60, 0}},
		{4057348071, {0, -30, -25}, {-90, 90, 0}},
		{4057348071, {15, -30, -25}, {-90, 90, 0}},
		{4057348071, {30, -30, -25}, {-90, 90, 0}},
		{4057348071, {35, -30, -25}, {-90, 90, 0}},
		{4057348071, {-15, -30, -25}, {-90, 90, 0}},
		{4057348071, {-30, -30, -25}, {-90, 90, 0}},
		{4057348071, {-35, -30, -25}, {-90, 90, 0}},
		{4057348071, {0, -30, -15}, {-90, 90, 0}},
		{4057348071, {15, -30, -17.5}, {-90, -60, 0}},
		{4057348071, {-15, -30, -17.5}, {-90, 60, 0}},
		{1980814227, {-0.5, -0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 12},
		{1980814227, { 0.5,  0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 12},
		{1980814227, {-0.9,    0,  4}, {-90, 0, 0}, nil, nil, nil, 16, 12},
		{1980814227, { 0.9,    0,  4}, {-90, 0, 0}, nil, nil, nil, 16, 12},
		{1980814227, {-0.5,  0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 12},
		{1980814227, { 0.5, -0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 12},
		{1980814227, {-0.5, -0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 12},
		{1980814227, { 0.5,  0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 12},
		{1980814227, {-0.9,    0, 12}, {-90, 0, 0}, nil, nil, nil, 16, 12},
		{1980814227, { 0.9,    0, 12}, {-90, 0, 0}, nil, nil, nil, 16, 12},
		{1980814227, {-0.5,  0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 12},
		{1980814227, { 0.5, -0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 12},
		{1980814227, {-0.5, -0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 13},
		{1980814227, { 0.5,  0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 13},
		{1980814227, {-0.9,    0,  4}, {-90, 0, 0}, nil, nil, nil, 16, 13},
		{1980814227, { 0.9,    0,  4}, {-90, 0, 0}, nil, nil, nil, 16, 13},
		{1980814227, {-0.5,  0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 13},
		{1980814227, { 0.5, -0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 13},
		{1980814227, {-0.5, -0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 13},
		{1980814227, { 0.5,  0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 13},
		{1980814227, {-0.9,    0, 12}, {-90, 0, 0}, nil, nil, nil, 16, 13},
		{1980814227, { 0.9,    0, 12}, {-90, 0, 0}, nil, nil, nil, 16, 13},
		{1980814227, {-0.5,  0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 13},
		{1980814227, { 0.5, -0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 13},
		{1980814227, {-0.5, -0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 14},
		{1980814227, { 0.5,  0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 14},
		{1980814227, {-0.9,    0,  4}, {-90, 0, 0}, nil, nil, nil, 16, 14},
		{1980814227, { 0.9,    0,  4}, {-90, 0, 0}, nil, nil, nil, 16, 14},
		{1980814227, {-0.5,  0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 14},
		{1980814227, { 0.5, -0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 14},
		{1980814227, {-0.5, -0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 14},
		{1980814227, { 0.5,  0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 14},
		{1980814227, {-0.9,    0, 12}, {-90, 0, 0}, nil, nil, nil, 16, 14},
		{1980814227, { 0.9,    0, 12}, {-90, 0, 0}, nil, nil, nil, 16, 14},
		{1980814227, {-0.5,  0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 14},
		{1980814227, { 0.5, -0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 14},
		{1980814227, {-0.5, -0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 15},
		{1980814227, { 0.5,  0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 15},
		{1980814227, {-0.9,    0,  4}, {-90, 0, 0}, nil, nil, nil, 16, 15},
		{1980814227, { 0.9,    0,  4}, {-90, 0, 0}, nil, nil, nil, 16, 15},
		{1980814227, {-0.5,  0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 15},
		{1980814227, { 0.5, -0.8,  4}, {-90, 0, 0}, nil, nil, nil, 16, 15},
		{1980814227, {-0.5, -0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 15},
		{1980814227, { 0.5,  0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 15},
		{1980814227, {-0.9,    0, 12}, {-90, 0, 0}, nil, nil, nil, 16, 15},
		{1980814227, { 0.9,    0, 12}, {-90, 0, 0}, nil, nil, nil, 16, 15},
		{1980814227, {-0.5,  0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 15},
		{1980814227, { 0.5, -0.8, 12}, {-90, 0, 0}, nil, nil, nil, 16, 15},
		{0x9dae1398, {   0,  -6, 3.5}, nil, nil, nil, nil, nil, 5},
		{1030400667, {   0, -10, 3.5}, nil, nil, nil, nil, nil, 5},
		{0x9dae1398, {-1.9, -10, 3.5}, nil, nil, nil, nil, nil, 5},
		{1030400667, {-1.9, -14, 3.5}, nil, nil, nil, nil, nil, 5},
		{0x9dae1398, { 1.9, -10, 3.5}, nil, nil, nil, nil, nil, 5},
		{1030400667, { 1.9, -14, 3.5}, nil, nil, nil, nil, nil, 5},
		{0x187D938D, {0, -10, 7}, nil, nil, nil, nil, nil, 5},
		{1030400667, {-10, -18, 5.5}, {0, 180,  90}, nil, nil, nil, nil, 5},
		{1030400667, { 10, -18, 5.5}, {0, 180, -90}, nil, nil, nil, nil, 5},
		{782665360, {-4.85, -16.5, 5.8}, nil, nil, nil, nil, nil, 5},
		{782665360, { 4.85, -16.5, 5.8}, nil, nil, nil, nil, nil, 5},
		{782665360, { -9.7, -16.5, 5.8}, nil, nil, nil, nil, nil, 5},
		{782665360, {  9.7, -16.5, 5.8}, nil, nil, nil, nil, nil, 5},
		{782665360, {-4.85, -16.5, 5.8}, {-90, 0, 0}, nil, nil, nil, nil, 5},
		{782665360, { 4.85, -16.5, 5.8}, {-90, 0, 0}, nil, nil, nil, nil, 5},
		{782665360, { -9.7, -16.5, 5.8}, {-90, 0, 0}, nil, nil, nil, nil, 5},
		{782665360, {  9.7, -16.5, 5.8}, {-90, 0, 0}, nil, nil, nil, nil, 5},
		{94602826, {0, 0, 3.5}, nil, nil, nil, nil, 16, 12},
		{94602826, {0, 0,  12}, nil, nil, nil, nil, 16, 12},
		{94602826, {0, 0, 3.5}, nil, nil, nil, nil, 16, 13},
		{94602826, {0, 0,  12}, nil, nil, nil, nil, 16, 13},
		{94602826, {0, 0, 3.5}, nil, nil, nil, nil, 16, 14},
		{94602826, {0, 0,  12}, nil, nil, nil, nil, 16, 14},
		{94602826, {0, 0, 3.5}, nil, nil, nil, nil, 16, 15},
		{94602826, {0, 0,  12}, nil, nil, nil, nil, 16, 15},
		{3229200997, {0, 0, 3.5}, nil, nil, nil, nil, 16, 12},
		{3229200997, {0, 0,  12}, nil, nil, nil, nil, 16, 12},
		{3229200997, {0, 0,  15}, nil, nil, nil, nil, 16, 12},
		{3229200997, {0, 0, 3.5}, nil, nil, nil, nil, 16, 13},
		{3229200997, {0, 0,  12}, nil, nil, nil, nil, 16, 13},
		{3229200997, {0, 0,  15}, nil, nil, nil, nil, 16, 13},
		{3229200997, {0, 0, 3.5}, nil, nil, nil, nil, 16, 14},
		{3229200997, {0, 0,  12}, nil, nil, nil, nil, 16, 14},
		{3229200997, {0, 0,  15}, nil, nil, nil, nil, 16, 14},
		{3229200997, {0, 0, 3.5}, nil, nil, nil, nil, 16, 15},
		{3229200997, {0, 0,  12}, nil, nil, nil, nil, 16, 15},
		{3229200997, {0, 0,  15}, nil, nil, nil, nil, 16, 15},
		}, }
}

_2t1s_vehicle_lag_area = {
	--{"NAME", HASH},
	{"Cargoplanes", 0x15F27762},
	{"Volatols", 0x1AAD0DED},
	{"Dumps", 0x810369E2},
	{"Jets", 0x3F119114},
	{"Mowers", 0x6A4BD8F6},
	{"Caddys", 0x44623884},
	{"Fire Trucks", 0x73920F8E}
}

_2t1s_bounty_amount = {
	0, 1, 10, 69, 420, 666, 1337, 5555, 9999, 10000
}

_2t1s_sms_texts = {
	"Fucking bitch", "REKT", "NOOB", "GET ON MY LEVEL", "Send Nudes", "UR MOM GAY", "no u"
}

_2t1s_weapons = {
	{0x1B06D571, 0xD7391086},
	{0x22D8FE39, 0x249A17D5, 0x359B7AAE, 0xC304849A, 0x9B76C72C},
	{0xCB96392F, 0xEFBF25, 0x420FD713, 0x27077CCB},
	{0xE284C527, 0x86BD7F72, 0x7BC4CDDC, 0x837445AA, 0xC164F53},
	{0xDBBD7280, 0x17DF42E9, 0xC66B6542, 0x9D65907A, 0xEC9068CC, 0xB5E2575B},
	{0xA914799, 0x2CD8FF9D, 0xBC54DA77, 0x108AB09E, 0x302731EC, 0x5F7DCE4D},
	{0x6A6C02E0, 0xE6CFD1AA, 0x5B1C713C, 0x68373DDC, 0xEC9068CC, 0x193B40E8},
	{0xA284510B, 0xAA2C45B4,  0xC164F53, 0x7BC4CDDC},
	{0x42BF8A85},
	{0x63AB0442},
	{0x2C3731D9}
}